class CourseOfStudyRelationController < ApplicationController
  
  authorize(
    :RIGHT_EVERYONE => [:combinations],
    :RIGHT_CM_APP_ADMISSION_EDIT_ADMISSIONPACKAGE => [:index, :show],
    :RIGHT_CM_EXA_STUDIES_EDIT_COURSE_OF_STUDY => [:new, :check_activity_config, :create, :delete, :edit, :index, :search_ajax, :show, :update,
      :edit_orgunit, :edit_periodcontainer_studies, :edit_unit_studies, :structreverse, :studysemesterrestrictions, #simple
      :action_combinations, :action_is_valid_combination, :action_next_studies, :action_uncached_combination, :action_uncached_next_studies, :build_cache, :cache_study_combinations, :cache_study_combinations_tree, :combination_rules, :combinations, :editstruct, :editstruct_copy, :editstruct_cut, :restrict_access_by_ip, :to_xml, :updatestruct, #combination
      :create_structure, :create_structure_index, :editstruct, :editstruct_copy, :editstruct_cut, :struct_partial, :updatestruct, :wait_for_create_structure ] #relation
  )
  
  before_filter :check_activity_config

  def check_activity_config
    if !studies_active
      flash.now[:notice] = 'Please check your configuration parameter "cm.exa.curricula.studies.active" before use new study editor'
      redirect_to :controller => 'course_of_study', :action => 'index'
    end
  end

  # Tree-Handling
  before_filter :save_tree_structure, :only => [:editstruct, :updatestruct, :struct_partial]

  def struct_partial

    # handle additional ajax parameters
    level = params[:start_level].to_i
    all_parents = params[:all_parent_types_of_root].scan(/\w+/)
    all_parent_types = params[:all_parent_types].scan(/\w+/).collect{ |key| key.to_sym }
    all_parents_array = params[:all_parents_array].split(/,\s*/)
    all_parents_array = all_parents_array.collect do |ids_couple|
      if ids_couple and !ids_couple.empty?
        ids_couple = ids_couple.scan(/\w+/)
        unit = CourseOfStudy.find_by_id(ids_couple[0].to_i)
        unit_rel = ids_couple[1].to_i if(ids_couple[1] and !ids_couple[1].empty?)
        [unit, unit_rel]
      end
    end
    has_next = 'false'.eql?(params[:has_next]) ? false : true
    has_previous = 'false'.eql?(params[:has_previous]) ? false : true
    
    find_struct(level+2)

    if @course_of_study
      @course_of_study.has_next = has_next
      @course_of_study.has_previous = has_previous
      # load childunits implicitly with additional parameters
      @study_tree = @course_of_study.children(level + 2, @node_states['course_of_study'], level, all_parents, all_parent_types, all_parents_array)
    end

    out = render_to_string(:action => "struct_partial", :layout => false)
    render(:text => out)
  end

  def updatestruct
    if !@clipboard_acted
      @studyrelations = []
      # insert activeunits as children of the selected (:newbelow)
      if params[:newbelow]
        parent = CourseOfStudy.find params[:newbelow]
        study_toinsert = @clipboard.elements_activated('course_of_study')
        if parent and study_toinsert
          study_toinsert.each { |u| @studyrelations << parent.add_child(u) }
        end
      end
      # insert activeunits as siblings after the selected (:newdown)
      if params[:newdown]
        rel = CourseOfStudyRelation.find params[:newdown]
        neighbor = CourseOfStudy.find rel.child_course_of_study_id
        study_toinsert = @clipboard.elements_activated('course_of_study')
        if neighbor and study_toinsert
          study_toinsert.each { |u| @studyrelations << neighbor.insert_after(u, rel) }
        end
      end
      # insert activeunits as siblings before the selected (:newup)
      if params[:newup]
        rel = CourseOfStudyRelation.find params[:newup]
        neighbor = CourseOfStudy.find rel.child_course_of_study_id
        study_toinsert = @clipboard.elements_activated('course_of_study')
        if neighbor and study_toinsert
          study_toinsert.each { |u| @studyrelations << neighbor.insert_before(u, rel) }
        end
      end
    end
    
    editstruct
    render :action => :editstruct
  end
  
  def editstruct
    if params[:editstruct_cut]
      editstruct_cut params[:editstruct_cut]
    elsif params[:editstruct_copy]
      editstruct_copy [params[:editstruct_copy]].flatten
    end
    find_struct
    #@study_tree = @course_of_study.children
  end

  def create_structure_index
    if params[:activated_id_list]
      activated_id_list = params[:activated_id_list].split(",")
    else
      activated_id_list = []
    end
    
    activate_elements = []
    if params['cos_hierarchy']
      params['cos_hierarchy'].each do |key, value|
        activate_elements << value
        activated_id_list << value if not activated_id_list.include?(value)
      end
    end
    
    if params[:paginate_id_list]
      deactivate_pagination = params[:paginate_id_list].split(',').delete_if { |item| activate_elements.include?(item.to_s) }
    else
      deactivate_pagination = []
    end
    
    params['course_of_study'] = {} unless params['course_of_study']
    search_options = params['course_of_study']
    search_options[:page] = search_options[:current_page] if (!search_options[:page] && search_options[:current_page])
    search_options[:sort_col] = "defaulttext" if (!search_options[:sort_col] or search_options[:sort_col].empty?)
    search_options[:finder] = ['find_simple', 'find_hist']
    
    @search = search_options[:search] if search_options[:search]
    @course_of_study_list = search_paginated(CourseOfStudy, search_options)
    
    @activated_id_list = activated_id_list.delete_if { |item| deactivate_pagination.include?(item.to_s) }.join(",")
    @paginate_id_list = @course_of_study_list.collect { |element| element.id }.join(",")
    @activated_elements = CourseOfStudy.find(:all, :conditions =>{ :id => activated_id_list})
    
    if params[:next_step] && params[:next_step].eql?(I18n.translate("view.controls.create_hierarchy"))
      if params[:index_selection][:course_of_study].eql?('all')
        create_structure
      elsif params[:index_selection][:course_of_study].eql?('all_on_site')
        create_structure @paginate_id_list.split(',')
      elsif params[:index_selection][:course_of_study].eql?('selected')
        if @activated_id_list && !@activated_id_list.empty?
          create_structure @activated_id_list.split(',')
        else
          flash.now[:warn] = I18n.translate('activerecord.notices.models.course_of_study_simple.no_course_of_study')
          return
        end
      end
      render :action => 'create_structure'
    end
  end

  #
  # crete a default structure
  def create_structure(activated_id_list = [])
    if params['hierarchy_id_list']
      activated_id_list = params['hierarchy_id_list'].split(',')
      "Parameter laden: " + activated_id_list.size.to_s
    end
     
    if activated_id_list && !activated_id_list.empty?
      puts "Aktive Liste: " + activated_id_list.size.to_s
      @course_of_study_id_list = execute_generic_search(CourseOfStudy, activated_id_list)
      @hierarchy_id_list = activated_id_list.join(",")
    else
      @course_of_study_id_list = execute_generic_search(CourseOfStudy)
    end
    
    conditions = !@course_of_study_id_list.empty? ? {:id => @course_of_study_id_list} : {}
    @course_of_study_id_list = CourseOfStudy.find_simple.find_hist.find(:all, :conditions => conditions).collect{|i| i.id}
    puts "Nach dem Laden:" + @course_of_study_id_list.size.to_s

    #for debugging
    #course_of_study_id_list = [338,365,409,287,406,323]
    @structure = Structure.new params[:structure], @course_of_study_id_list

    if params[:new_level_submit]
      @structure.add_new_level(params[:new_level_table])
      render :action => :create_structure
    elsif params[:remove_level]
      @structure.remove_level(params[:remove_level].keys[0])
      render :action => :create_structure
    elsif params[:create_struct]
      if @structure.name.nil? or (!@structure.name.nil? and @structure.name.empty?)
        flash.now[:error] = I18n.translate('activerecord.notices.models.course_of_study.mandatory_structure_name')
        return
      else

        # Check uniqueness of the name
        nul = CourseOfStudy.find :all, :conditions => {:uniquename => @structure.name}
        unless nul.empty?
          flash.now[:error] = I18n.translate('activerecord.notices.models.course_of_study.unique_structure_name')
          return
        else

          thread_id = random_alphanumeric(20)
          Rails.cache.write "thread_id", thread_id
          params[:thread_id] = thread_id

          block_to_execute = Proc.new do
            Thread.current[:direct_connection] = true
            Thread.current[:connection_timeout] = 60*24 # 24 stunden
            begin
              Thread.current[:no_metadata_validations] = true
              logger.info "----- START #{thread_id} -----"
              Rails.cache.write "cos_structure_#{thread_id}", 'active'
              ids = []
              root_node = @structure.build_tree(ids)
              # root_node.save_tree
              Rails.cache.write "cos_structure_#{thread_id}", root_node.id
              ActiveRecord::Base.clear_active_connections!
            rescue Exception => bang
              logger.error "Error creating structure: #{bang.inspect}"
              # remove all nodes and connections: rollback
              CourseOfStudyRelation.destroy_all(:parent_course_of_study_id => ids)
              CourseOfStudyRelation.destroy_all(:child_course_of_study_id => ids)
              CourseOfStudy.destroy_all(:id => ids)
              ActiveRecord::Base.clear_active_connections!
              Rails.cache.write "cos_structure_#{thread_id}", bang
              Thread.current[:no_metadata_validations] = false
            else
              logger.info "----- END #{thread_id} -----"
              ActiveRecord::Base.clear_active_connections!
              Thread.current[:no_metadata_validations] = false
            end
            Thread.current[:direct_connection] = false
            Thread.current[:connection_timeout] = nil
          end

          if ENV['RAILS_ENV'].eql?('production')
            # create a thread
            Thread.new(block_to_execute, thread_id){ |to_execute, thread_id| to_execute.call }
          else
            # no threads!
            block_to_execute.call
          end
          @alive = true
          render :action => :wait_for_create_structure
        end
      end
    end
  end

  def wait_for_create_structure
    thread_id = params[:id]
    cos_structure = Rails.cache.read "cos_structure_#{thread_id}"
    if cos_structure
      if cos_structure.kind_of?(Exception)
        @error = cos_structure
        @alive = false
        Rails.cache.write "cos_structure_#{thread_id}", nil
      elsif cos_structure.kind_of?(String) and cos_structure.eql?('active')
        @alive = true
        params[:thread_id] = thread_id
      else
        @course_of_study = CourseOfStudy.find cos_structure
        Rails.cache.write "cos_structure_#{thread_id}", nil
        render :action => :editstruct
      end
    else
      flash.now[:notice] = "Thread with id #{thread_id} not found!"
      reset_generic_search_bean(CourseOfStudy)
      redirect_to :controller => 'course_of_study', :action => 'index'
    end
    
  end

  private
  
  def find_struct(level = nil)
    CourseOfStudy.connection.clear_query_cache
    node_include = [{:admissionshare => :admissionpackage}, :k_place_of_studies, :k_examinationversion, :k_type_of_study, :k_course_of_study_type,
      {:subjectobj => :current_versions}, 
      {:degreeobj => :current_versions}, 
      {:major_field_of_studyobj => :current_versions },
      {:course_specializationobj => :current_versions }
      ]
    relation_includes = []
    if params['expand_all'] || level
      @course_of_study = CourseOfStudy.find(params[:id]).find_forest(:node_includes => node_include, :level => level)
    else
      @course_of_study = CourseOfStudy.find_full_net(params[:id], node_include, relation_includes, 1)
    end
  end

  def editstruct_cut(relation_id)
    relation_to_destroy = CourseOfStudyRelation.find relation_id
    @clipboard.add [relation_to_destroy.child_course_of_study_id], 'course_of_study'
    CourseOfStudyRelation.destroy relation_id
  end

  def editstruct_copy(course_of_study_id)
    @clipboard.add course_of_study_id, 'course_of_study'
  end

end

##### START: helper classes for generating a new structure #####
#

# structure - main obejct
# * contains structure levels
class Structure

  attr_accessor :name
  attr_accessor :course_of_study_id_list

  def initialize(attr = {}, course_of_study_id_list = nil)
    attr = {} if attr.nil?
    self.name = attr[:name]
    self.course_of_study_id_list = course_of_study_id_list
    @levels = []
    levels = attr[:levels] if attr
    if levels and !levels.empty?
      level_list = levels.sort
      level_list.each{ |v| @levels << Level.new(v[1], course_of_study_id_list) }
    end
  end

  def levels
    @levels
  end

  def add_new_level(table_name)
    @levels << Level.new(table_name)
  end

  def remove_level(level_index)
    level_index = level_index.to_i
    @levels.delete_at(level_index)
  end

  def free_level_options
    busy_levels = @levels.collect { |item| item.table_name }
    free_levels = Level.all - busy_levels
    free_levels.collect{ |item| "<option value='#{item}'>#{I18n.translate("activerecord.titles.models.#{item}.#{item}s")}</option>"}
  end

  def build_tree(ids = [])
    
    #sorted_levels # sot the list
    # create root
    root = Node.new(:uniquename => self.name, :defaulttext => self.name, :longtext => self.name, :k_language_id => KLanguage.default_language_obj.id)
    levels = Array.new @levels
    if levels and !levels.empty?
      first_level = levels.shift
      if self.course_of_study_id_list
        first_level.struct(root, levels,
          {:k_course_of_study_type_id => [KCourseOfStudyType.full_study, KCourseOfStudyType.partial_study], :id => self.course_of_study_id_list}, 0, ids)
      else
        first_level.struct(root, levels,
          {:k_course_of_study_type_id => [KCourseOfStudyType.full_study, KCourseOfStudyType.partial_study]}, 0, ids)
      end
    else
      if self.course_of_study_id_list
        root.child_members =
          CourseOfStudy.find_hist.find(:all, :conditions => {:id => self.course_of_study_id_list, :k_course_of_study_type_id => [KCourseOfStudyType.full_study, KCourseOfStudyType.partial_study]}, :order => "defaulttext, shorttext, longtext")
      else
        root.child_members =
          CourseOfStudy.find_hist.find(:all, :conditions => {:k_course_of_study_type_id => [KCourseOfStudyType.full_study, KCourseOfStudyType.partial_study]}, :order => "defaulttext, shorttext, longtext")
      end
      root.save_node!(ids)
    end
    # root.debug_tree
    root
  end

end

# structure level
class Level
  
  @@lid_list = ['degree','subject','major_field_of_study','course_specialization']
  @@id_list = ['k_subject_indicator','k_place_of_studies','k_enrollment','k_type_of_study','k_form_of_studies']

  attr_accessor :members, :table_name, :course_of_study_id_list
  
  def self.lid_entities_list
    @@lid_list
  end
  
  def self.all
    @@lid_list + @@id_list
  end

  def initialize(table_name, course_of_study_id_list = nil)
    self.table_name = table_name
    self.members = init_members(course_of_study_id_list)
    self.course_of_study_id_list = course_of_study_id_list
  end

  def table_name_string
    I18n.translate("activerecord.titles.models.#{table_name}.#{table_name}s")
  end

  def struct(parent_node, following_levels, conditions = {}, level = 0, ids = [])
    puts("Verify connections!")
    ActiveRecord::Base.verify_active_connections!
    following_copy = following_levels.dup
    conditions_copy = conditions.dup
    # remove self
    next_level = following_copy.shift
    self.members.each do |obj|
      node = Node.new_using_orig_obj_and_aparent_node(obj, parent_node, self)
      conditions_copy[self.column_name.to_sym] = obj
      if next_level
        go_to_the_next = true
        unless level.eql?(0)
          dummy_check = CourseOfStudy.find_hist.find(:all, :conditions => conditions_copy, :order => "defaulttext, shorttext, longtext")
          go_to_the_next = (dummy_check.empty? ? false : true)
        end
        if go_to_the_next
          next_level.struct(node, following_copy, conditions_copy, level + 1, ids)
        end
      else
        # search and connect real studies
        node.child_members = CourseOfStudy.find_hist.find(:all, :conditions => conditions_copy, :order => "defaulttext, shorttext, longtext")
        # !!! and save
        node.save_node!(ids)
      end
      parent_node.child_members << node if !node.child_members.empty?
      # empty child_memebers
      node.child_members = []
    end

    # !!! save
    parent_node.save_node!(ids)
    # empty child_memebers
    # parent_node.child_members = []
  end
  
  def real_object obj
    if @@lid_list.member?(self.table_name)
      obj.current_version
    elsif @@id_list.member?(self.table_name)
      obj
    end
  end

  def defaulttext_for_object(obj)
    attribute_for_object(obj, 'defaulttext')
  end

  def attribute_for_object(obj, method = 'defaulttext')
    if real_object obj
      real_object(obj).send(method)
    else
      "WARNING: no current version for #{table_name} lid #{obj.id} available"
    end
  end

  def column_name
    if @@lid_list.member?(self.table_name)
      "#{self.table_name}_lid"
    elsif @@id_list.member?(self.table_name)
      "#{self.table_name}_id"
    end
  end

  def init_members(course_of_study_id_list)
    if @@lid_list.member?(self.table_name)
      sql = "SELECT DISTINCT #{self.table_name}_lid as level_lid FROM course_of_study"
      sql = "#{sql} WHERE course_of_study.id IN (#{course_of_study_id_list.join(',')})" if course_of_study_id_list
      list = CourseOfStudy.connection.execute(sql).collect { |item| item['level_lid'] }.compact
      "#{self.table_name}obj".classify.constantize.find :all, :conditions => {:id => list}, :joins => "INNER JOIN #{self.table_name} ON (#{self.table_name}.lid = #{self.table_name}obj.id)", :order => "#{self.table_name}.sortorder, #{self.table_name}.defaulttext"
    elsif @@id_list.member?(self.table_name)
      sql = "SELECT DISTINCT #{self.table_name}_id as level_id FROM course_of_study"
      sql = "#{sql} WHERE course_of_study.id IN (#{course_of_study_id_list.join(',')})" if course_of_study_id_list
      list = CourseOfStudy.connection.execute(sql).collect { |item| item['level_id'] }.compact
      self.table_name.classify.constantize.find :all, :conditions => {:id => list}, :order => 'sortorder, defaulttext'
    else
      []
    end
  end
  
end

#
##### END: helper classes for generating s new structure #####


#
# http://bibwild.wordpress.com/2007/08/28/threading-in-rails/
#
#class StructureCreator
#
#  include java.io.Serializable
#  include java.lang.Runnable
#
#  def initialize(structure_opt, rj_id)
#    @structure = structure_opt
#    @rj = rj_id
#  end
#
#  def run
#    puts "----- START #{@structure}, #{@rj} -----"
#    structure = Structure.new @structure
#    root_node = structure.build_tree
#    root_node.save_tree
#    job = RubyJob.find @rj
#    job.progress = 100
#    job.status = 'finished'
#    job.save
#    ActiveRecord::Base.verify_active_connections!
#    puts "----- END -----"
#  end
#
#end
# is a category node with additional attribute child_memebers
# and possibility for recursive saving the tree
class Node < CourseOfStudyCategory
  
  acts_as_translated_entity_object

  attr_accessor :child_members, :orig_obj, :parent_node, :level

  after_initialize :init_child_memebers
  def init_child_memebers
    self.child_members = []
  end
  
  def self.new_using_orig_obj_and_aparent_node obj, parent_node, level
    newobj = self.new(
      :k_language_id => KLanguage.default_language_obj.id,
      :defaulttext => "#{level.defaulttext_for_object(obj)}",
      :shorttext => "#{parent_node.shorttext} / #{level.attribute_for_object(obj, :shorttext)}")
    
    newobj.orig_obj = level.real_object obj
    newobj.parent_node = parent_node
    newobj
  end
  
  after_save :save_foreigtexts
  def save_foreigtexts
    if !self.orig_obj.nil? && !self.parent_node.nil?
      KLanguage.all.each do |lang|
        if !self.k_language.eql?(lang)
          # defaulttext
          i18n_value = self.orig_obj.__defaulttext_for_locale lang.iso_639_1
          if !i18n_value.nil?
            self.__save_defaulttext_for_locale lang.iso_639_1, i18n_value
          end
          # shorttext
          i18n_value = self.orig_obj.__shorttext_for_locale lang.iso_639_1
          if !i18n_value.nil?
            i18n_value = "#{self.parent_node.shorttext} / #{i18n_value}"
            self.__save_shorttext_for_locale lang.iso_639_1, i18n_value
          end
        end
      end
    end
  end

  def save_tree
    ActiveRecord::Base.verify_active_connections!
    self.save
    self.child_members.each do |child|
      # save
      if child.is_a?(Node)
        child.save_tree
      else
        #ActiveRecord::Base.verify_active_connections!
        child.save
      end
      # .. and connect
      #ActiveRecord::Base.verify_active_connections!
      self.add_child child
    end
  end

  def debug_tree level = ""
    puts "#{level} #{self.defaulttext}"
    self.child_members.each do |child|
      if child.is_a?(Node)
        child.debug_tree(level + "  ")
      else
        puts level + "  -" + child.defaulttext
      end
    end
  end

  def save_node!(obj_guids = [])
    # !!! save
    unless self.child_members.empty?
      self.save
      obj_guids << self.id
      # !!! connect children, course_of_study_relation
      self.child_members.each do |child|
        self.add_child child
      end
    end
  end

end
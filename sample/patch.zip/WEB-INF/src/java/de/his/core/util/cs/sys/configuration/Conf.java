/* $Id: Conf.java,v 1.360.4.11 2013-12-04 11:39:17 wassmann#his.de Exp $
 * $Log: Conf.java,v $
 * Revision 1.360.4.11  2013-12-04 11:39:17  wassmann#his.de
 * Portalmeldungen nur senden, wenn Person auch einen Account hat (#99881)
 *
 * Revision 1.360.4.10  2013-11-21 09:29:52  lustig#his.de
 * Anfrage #92874 – APP: Einstellungen zu den angebotenen FS sollte funktionsspezifisch erfolgen können
 *
 * Revision 1.360.4.9  2013-11-15 12:08:35  strube#his.de
 * Refactoring; JUnit-Test implementiert (fixes #98777)
 *
 * Revision 1.360.4.8  2013-11-11 14:49:58  guenther#his.de
 * fixes #100548. the different times are now supported: 0 = as applicant, 1 = as cand. student, 2 = as Student
 *
 * Revision 1.360.4.7  2013-10-24 10:43:55  yu#his.de
 * #95172， #96519– Task: iTAN-Schlüssel:
 * core.psv.itan.secure_direct_debit_edit.should_query
 * core.psv.itan.secure_mandate_save.should_query
 *
 * Revision 1.360.4.6  2013-10-08 12:17:11  jgrimm#werkstoffbit.de
 * added company logo as requested in HISzilla-Ticket #92584 (fixes #92584)
 *
 * Revision 1.360.4.5  2013-10-01 12:36:19  wahrendorff#his.de
 * Korrigiert falsche Beschreibung und defaultwert, fixes #98943
 *
 * Revision 1.360.4.4  2013-08-24 20:02:59  lustig#his.de
 * Generische Suche zwischen Fragment- und Präfixsuche schaltbar - Standard ist Fragmentsuche (fixes #92072)
 *
 * Revision 1.360.4.3  2013-08-16 13:23:43  brandt#his.de
 * typo #82102
 *
 * Revision 1.360.4.2  2013-08-15 07:09:30  jgrimm#werkstoffbit.de
 * renamed configuration key to clarify its usage (related to #95495)
 *
 * Revision 1.360.4.1  2013-08-14 16:36:59  kassner#his.de
 * #59879 Bescheidanforderungen konfigurieren
 *
 * Revision 1.360  2013-08-07 09:39:40  jgrimm#werkstoffbit.de
 * switched from "Hochschulpartner" to "Alumni-Partner"
 *
 * Revision 1.359  2013-08-07 09:11:04  burchard#his.de
 * Task: Automatische Erzeugung und Anzeige der MTKNR - fixes #87128
 *
 * Revision 1.358  2013-08-05 08:48:38  eden#his.de
 * Hilfstexte für "Hochschulzugang für berufl. Qualifizierte"
 *
 * Revision 1.357  2013-08-01 09:30:46  wahrendorff#his.de
 * Defaultwerte für Langzeit und temporäre Speicherdauer für Dokumente
 *
 * Revision 1.356  2013-07-30 14:53:07  yu#his.de
 * #66291 der Konfigurationsschalter(cm.stu.fee.credit_clearing) gelöscht
 *
 * Revision 1.355  2013-07-29 13:54:36  brandt#his.de
 * course of study variations for partial studies #90968
 *
 * Revision 1.354  2013-07-24 12:38:21  jgrimm#werkstoffbit.de
 * added settings to configure which subscription contexts will be available for various alu-functions
 *
 * Revision 1.353  2013-07-18 06:36:46  hoersch#his.de
 * Weitere Hilfsmethode um Boolean-Confkey zu ermitteln
 *
 * Revision 1.352  2013-07-16 15:27:01  paul#his.de
 * Veto Skript für die Abgabe von Anträgen über neues Entity editierbar für den Kunden gemacht.
 *
 * Revision 1.351  2013-07-16 15:12:31  brandt#his.de
 * set different degrees for course of study combinations #82102
 *
 * Revision 1.350  2013-07-16 09:15:37  brandt#his.de
 * change descriptions #93352
 *
 * Revision 1.349  2013-07-11 09:34:35  guenther#his.de
 * added key to save default creditor identification for domain STU in global conf.
 *
 * Revision 1.348  2013-07-10 10:21:03  weyland#werkstoffbit.de
 * add initial version for kfw web service communication
 *
 * Revision 1.347  2013-07-08 08:41:55  freese#his.de
 * Zutrittskontrolle in der globalen Konfiguration aus HRM nach PSV verschoben
 *
 * Revision 1.346  2013-06-27 10:30:29  jgrimm#werkstoffbit.de
 * added configuration setting to set the maximum validity compared to the beginning of the validity period (fixes #92585)
 *
 * Revision 1.345  2013-06-26 13:25:10  strube#his.de
 * Einblenden einer Zwischenseite bei der Selbstregistrierung (fixes #92700)
 *
 * Revision 1.344  2013-06-26 12:00:52  bergemann#his.de
 * - Task: Globaler Schalter für Aktivierung Gebührenberechnung nach Annahme Zulassungsangebot (#65203)
 *
 * Revision 1.343  2013-06-26 11:35:59  bergemann#his.de
 * - Task: Globaler Schalter für Aktivierung Lastschriftauftrag bei Online-Imma (#65199)
 *
 * Revision 1.342  2013-06-24 11:20:27  koczewski#his.de
 * Haupt-/Hilfsantrag
 *
 * Revision 1.341  2013-06-19 10:05:41  hoersch#his.de
 * Schlüssel um das Importverfahren für Zahlungen festzulegen #(86339)
 *
 * Revision 1.340  2013-06-19 08:15:44  jgrimm#werkstoffbit.de
 * added explicit contact persons for university partner and career service
 *
 * Revision 1.339  2013-06-18 12:09:30  brummermann#his.de
 * added support for owa 2010 with isa2006 (fixes #89088)
 *
 * Revision 1.338  2013-06-13 07:48:59  guenther#his.de
 * Moved config key for SEPA Activation to head
 *
 * Revision 1.337  2013-06-12 09:05:23  jgrimm#werkstoffbit.de
 * Added configuration settings to global configuration for career service and university partner.
 * Prepared career service and university partner rights and roles.
 *
 * Revision 1.336  2013-06-06 13:58:31  yu#his.de
 * Schalter für Fieldsets-Sichtbarkeit in der Bewerberübernahme
 *
 * Revision 1.335  2013-06-06 07:17:48  schwaff#his.de
 * #80590 revert
 *
 * Revision 1.333  2013-05-29 13:34:09  yu#his.de
 * Einbau Konfigurationsschalter Verrechnung von Gutschriften(#66291)
 *
 * Revision 1.332  2013-05-23 12:54:40  koczewski#his.de
 * Anfrage #91098 – Für Bewerver irreführende Anzeige vom Status der Werte in hochschuleigener Auswahl
 *
 * Revision 1.331  2013-05-17 08:52:25  rademacker#his.de
 * helptext für cm.stu.reports.bsa_reports_for_students hinzugefügt
 *
 * Revision 1.330  2013-05-16 13:04:47  rademacker#his.de
 * Anzuzeigende Bescheidanforderungen für Studenten werden über den Conf-Parameter bsa_reports_for_students ausgewählt (#84236)
 *
 * Revision 1.329  2013-04-30 09:46:12  eden#his.de
 * Helptext geändert (fixes #85624)
 *
 * Revision 1.328  2013-04-26 12:00:30  wagenmann#his.de
 * Compile-Fehler behoben
 *
 * Revision 1.327  2013-04-26 09:51:35  rong.li#his.de
 * Conf.Param "pm.hrm.application.show_question_of_unemployment" angelegt, die Frage nach Arbeitslosigkeit kann ausgeblendet werden (nach Wünsche der Hochschule Niederrhein).
 *
 * Revision 1.326  2013-04-25 08:36:26  bergemann#his.de
 * - Task: Fortsetzung Ermittlung der personenbezogenen Studienkontencharakteristik implementieren (#87748)
 *
 * Revision 1.325  2013-04-24 16:24:40  lustig#his.de
 * versehentlich gelöschte Confkeys wieder hergestellt.
 *
 * Revision 1.323  2013-04-23 10:50:55  mshenavai#werkstoffbit.de
 * adjustment of the change-history
 *
 * Revision 1.322  2013-04-19 15:28:51  lustig#his.de
 * Darstellung von Schnelldruck-Knöpfen auf der Übersichtsseite von 'Studierende bearbeiten', wenn im Confkey 'cm.stu.reports.fast_reports_for_staff' Schlüssel von Stu-Jobs eingetragen sind. (fixes #89710)
 *
 * Revision 1.321  2013-04-19 06:48:57  rademacker#his.de
 * - Bescheidanfordeungstabelle für Studierende unter "Meine Berichte" eingefügt
 * - neuer Parameter in der Gloabeln Konfiguration, welche Bescheidarten in der Tabelle angezeigt werden sollen
 *
 * Revision 1.320  2013-04-18 13:07:28  schwaff#his.de
 * #89616 – PA: Zielantragsstatus bei Posteingangsfunktion konfigurierbar machen
 *
 * Revision 1.319  2013-04-16 10:18:18  bolte#his.de
 * cm.exa.enrollment.studyplanner.cancelation wieder eingebaut.
 *
 * Revision 1.318  2013-04-16 08:40:57  eden#his.de
 * Helptext ergänzt (fixes #76822)
 *
 * Revision 1.317  2013-04-15 13:12:22  jgrimm#werkstoffbit.de
 * added configuration for default validity period
 *
 * Revision 1.316  2013-04-15 10:53:32  eden#his.de
 *  Umstellung id->obj_guid in glob Konf (cm.app.application.apprenticeship.unit_id , cm.app.application.measurementseconddegree.unitid) (fixes #88979)
 *
 * Revision 1.315  2013-04-15 10:21:05  weyland#werkstoffbit.de
 * initial checkin for kfw import; refactored package structure
 *
 * Revision 1.314  2013-04-09 08:32:15  wassmann#his.de
 * Den fehlenden Schalter "cm.app.application.course_of_study_text" ergaenzt (#77812)
 *
 * Revision 1.313  2013-04-08 12:21:52  koczewski#his.de
 * Anfrage #89102 – PA: Ausblenden der Links zu "Angebot zurückstellen" und "Platz zurückgeben"
 *
 * Revision 1.312  2013-04-02 15:03:50  bolte#his.de
 * #80508: Abmeldearten
 *
 * Revision 1.311  2013-03-27 11:08:37  koczewski#his.de
 * Anfrage #88286 – PA: Bewerber mit HZB = berufl. Qual. ohne HZB sollen kein Datum, keine Note erfassen
 *
 * Revision 1.309  2013-03-26 13:45:27  poeschel#his.de
 * Umschaltung Fach- / Lehrplansemester #87132
 *
 * Revision 1.308  2013-03-15 15:18:26  mshenavai#werkstoffbit.de
 * removal of cm.alu.profile.picture, cm.alu.profile.picture.height, cm.alu.profile.picture.width, AlumniPictureSettingsFactory
 *
 * Revision 1.307  2013-03-14 14:35:06  weyland#werkstoffbit.de
 * added KfW functionality from branch
 *
 * Revision 1.306  2013-02-27 16:28:08  wagenmann#his.de
 * Rücknahme der Notenfreigabe und ITANs. (fixes #83211, #86761)
 *
 * Revision 1.305  2013-02-22 11:37:14  wagenmann#his.de
 * Und wieder ITAN-Konfiguration für die Rücknahme der Notenfreigabe, weils jemand überschrieben hat. (fixes #83211)
 *
 * Revision 1.304  2013-02-19 11:15:56  eden#his.de
 *  Anzahl möglicher HZBs einschränkbar in Abhängigkeit von cm.app.application.single_entrance_qualification (fixes #86060)
 *
 * Revision 1.303  2013-02-14 14:02:20  kromm#his.de
 * * Scriptauswertung bei der Antragsabgabe
 * * Warnungen für Studiengänge
 *
 * Revision 1.302  2013-02-12 19:18:35  weyland#werkstoffbit.de
 * added javadoc comments
 * using prepared kfw export settings
 * structuring services
 * added i18n texts
 *
 * Revision 1.301  2013-02-12 16:55:08  wagenmann#his.de
 * ITAN-Konfiguration für die Rücknahme der Notenfreigabe. (fixes #83211)
 *
 * Revision 1.300  2013-02-11 12:34:10  deutsch#his.de
 * added global key 'cm.stu.fee.fia.bulkposting.underpayment'
 *
 * Revision 1.299  2013-02-11 10:10:08  wassmann#his.de
 * Mails des Email-Portlets cachen, damit es nicht bei jedem Request den Mail-Server abfragt (#80764)
 *
 * Revision 1.298  2013-02-10 17:08:21  wassmann#his.de
 * Logout-Images in der Gl. Konf. verwalten (#83623)
 *
 * Revision 1.297  2013-02-08 11:03:59  l.wolter#his.de
 * Korrektur DOSV-WebService-Schlüssel
 *
 * Revision 1.296  2013-02-07 14:35:18  jgrimm#werkstoffbit.de
 * updated description of cm.alu.usermanagement.student.registration.default_orgunit
 *
 * Revision 1.295  2013-02-07 10:03:47  bergemann#his.de
 * - Task: Einstellung und Aenderung Studienkontenmodelle implementieren (#36632)
 *
 * Revision 1.294  2013-02-01 13:28:17  brummer#his.de
 * New key core.bi.components.use_psql (default false) use psql for data loading in edustore (fixes #82225)
 *
 * Revision 1.293  2013-01-29 12:22:04  wagenmann#his.de
 * TAN-Abfragen eingebaut. (fixes #67531)
 *
 * Revision 1.292  2013-01-28 16:22:19  wagenmann#his.de
 * TAN-Abfragen eingebaut. (fixes #67531)
 *
 * Revision 1.291  2013-01-22 14:22:39  wagenmann#his.de
 * Außerdem TAN-Funktion in Noteneingabe und Leistungsbearbeitung eingebaut. (fixes #67531)
 *
 * Revision 1.290  2013-01-21 10:05:17  brandt#his.de
 * new rightsparameter for create/edit_curricula_elements #84282
 *
 * Revision 1.289  2013-01-18 14:12:12  wagenmann#his.de
 * Neue Konfigurationsparameter für TANs in der Leistungsbearbeitung. (fixes #67531)
 *
 * Revision 1.288  2013-01-14 17:22:52  wassmann#his.de
 * Auf nicht mehr vorhandene aber in der Vergangenheit ausgewaehlte Parameter in Auswahllisten hinweisen (#81341)
 *
 * Revision 1.287  2013-01-09 13:28:36  m.kastner#his.de
 * Schlüssel zur Angabe eines URL-Kursmusters für Moodle 1 eingefügt (#70360)
 *
 * Revision 1.286  2013-01-08 13:57:09  poeschel#his.de
 * cm.exa.terms entfernt (#78043)
 *
 * Revision 1.285  2013-01-08 13:38:27  bergemann#his.de
 * - Task: Einstellung und Aenderung Studienkontenmodelle implementieren (#36632)
 *
 * Revision 1.284  2013-01-08 12:56:02  mshenavai#werkstoffbit.de
 * bugfix for "Global Configuration Consistency Check". (Casting String-values to Long-values)
 *
 * Revision 1.283  2013-01-07 10:32:39  deutsch#his.de
 * new key 'export liabilities' added
 *
 * Revision 1.282  2012-12-19 14:35:41  koczewski#his.de
 * Anfrage #82670 – PA: hochschulweite Unterdrückung der Abfrage zur HZB
 *
 * Revision 1.281  2012-12-19 14:06:47  koczewski#his.de
 * Anfrage #82675 – PA: Studienvergangenheit ausblenden
 *
 * Revision 1.280  2012-12-19 13:40:00  koczewski#his.de
 * Anfrage #82676 – PA: Abfrage Härtefall ausblenden
 *
 * Revision 1.279  2012-12-07 15:20:33  wassmann#his.de
 * Confparameter zum steuern ob sich der Browser Passwoerter merken soll (#82644)
 *
 * Revision 1.278  2012-12-07 10:18:47  schwaff#his.de
 * added new conf-key cm.app.edit.use_new_application_processing
 *
 * Revision 1.277  2012-12-04 07:37:44  wassmann#his.de
 * Confparmeter fuer die Tabellenkonfiguration nach core.sys.ui verschoben
 *
 * Revision 1.276  2012-11-30 17:41:12  kassner#his.de
 * (fixes #80899) – STU: Registerkarte "Chipkarte" in Funktion Gasthörer erfassen/bearbeiten
 *
 * Revision 1.275  2012-11-30 10:32:37  kassner#his.de
 * (fixes #81111) – STU : Kleine Zweithörer (NRW) - Erfassung der Haupthochschule erforderlich
 *
 * Revision 1.274  2012-11-27 09:03:51  mshenavai#werkstoffbit.de
 * added settings for disable the subscription-step of the registration
 *
 * Revision 1.273  2012-11-26 10:47:14  strube#his.de
 * Conf. Param "Chipkarte bei der STU-Initialisierung erstellen" angelegt; Initialiisierung, Validierung und Speicherung des STU-Kunden erweitert (fixes #80720)
 *
 * Revision 1.272  2012-11-12 10:20:15  eden#his.de
 * fixes #80340
 *
 * Revision 1.271  2012-11-08 09:44:51  dreyer#his.de
 * neu für Forschung: Workflow Projektbeschreibungen
 *
 * Revision 1.270  2012-11-07 15:26:06  schirmeister#his.de
 * APP-Parameter für HEA angepasst. #80086
 *
 * Revision 1.269  2012-11-06 16:59:08  schirmeister#his.de
 * APP-Parameter für HEA angepasst. #80086
 *
 * Revision 1.268  2012-11-02 09:20:19  lierath#his.de
 * added new AF-workflow
 *
 * Revision 1.267  2012-10-29 10:04:17  scheid#his.de
 * neuen Configkey zum Erzwingen der systemweiten Benutzung des internationalen Kontoformats angelegt "core.psv.person.bankaccount.use_only_iban"
 *
 * Revision 1.266  2012-10-19 09:18:49  kassner#his.de
 * (fixes #67871) Neuer Konfigurationsparameter für Krankenversicherungsstatus - Übertragung aus  3 Release 2
 *
 * Revision 1.265  2012-10-08 15:07:24  paul#his.de
 * Anpassung von Meldungen in der Selbstregistrierung APP. #76524
 *
 * Revision 1.264  2012-10-02 11:46:00  paul#his.de
 * SFTP Funktion aus dem DoSV Konnektor und WebSetup ausgebaut. #72948
 *
 * Revision 1.263  2012-09-28 09:41:29  paul#his.de
 * SFTP Funktionalität aus dem DoSV-Konnektor entfernt. Desweiteren wurde die Properties-Config aus dem DoSV-Konnektor entfernt. #72948
 *
 * Revision 1.262  2012-09-26 07:14:03  jauer#his.de
 * Auswahl EXA-Reports über globale Konfiguration vorbereitet (fixes #00000)
 *
 * Revision 1.261  2012-09-25 12:18:01  wassmann#his.de
 * Globale Konfiguration repariert und aktuallisiert - HEAD und Version 4 (#77812)
 *
 * Revision 1.260  2012-09-24 09:34:17  mshenavai#werkstoffbit.de
 * reverted overwritten conf-key
 *
 * Revision 1.259  2012-09-23 16:22:57  lustig#his.de
 * Compilerfehler in Conf behoben
 *
 * Revision 1.257  2012-09-21 12:44:57  schwaff#his.de
 * removed superfluous conf-keys (fixes #76833)
 *
 * Revision 1.256  2012-09-21 07:02:23  paul#his.de
 * Allgemeiner Schlüssel für das Erlauben von Teilzulassungen. #77726
 *
 * Revision 1.255  2012-09-20 11:38:00  brummermann#his.de
 * merged with previous version
 *
 * Revision 1.253  2012-09-20 09:20:59  brummermann#his.de
 * only use a global singleton for the configuration, if spring is not available with comments
 *
 * Revision 1.252  2012-09-20 09:19:51  brummermann#his.de
 * only use a global singleton for the configuration, if spring is not available
 *
 * Revision 1.251  2012-09-17 21:27:34  brummermann#his.de
 * support for Conf without Spring
 *
 * Revision 1.250  2012-09-17 12:18:47  schirmeister#his.de
 * #76784
 *
 * Revision 1.249  2012-09-14 12:48:40  kassner#his.de
 * (fixes #52813) – Zusaetzliche Informationen vom Bewerber (Bemerkung) werden bei Immatrikulation als Hinweis gezeigt.
 *
 * Revision 1.248  2012-09-10 12:08:58  mshenavai#werkstoffbit.de
 * revert overwritten keys
 *
 * Revision 1.247  2012-09-10 10:08:59  keunecke#his.de
 * add parameters for configuration center again
 *
 * Revision 1.246  2012-09-04 13:03:31  paul#his.de
 * Auswertung der Zeiträume für die Übertragung von Studienangeboten an die Servicestelle überarbeitet. #75777
 *
 * Revision 1.245  2012-08-30 06:13:08  m.kastner#his.de
 * Parameter zum Angeben des Pfades zum Antivirenscanner angelegt. (#75538)
 *
 * Revision 1.244  2012-08-29 11:03:58  mshenavai#werkstoffbit.de
 * change history for alumni-management - added filtering for not matching elements (#72685)
 *
 * Revision 1.240  2012-08-21 15:15:53  brummermann#his.de
 * workaround for accessing Conf in QIS without HISinOne
 *
 * Revision 1.239  2012-08-13 10:23:21  weyland#werkstoffbit.de
 * added contact data validation for central HISinOne profile
 * refactored discriminator handling for address dtos
 *
 * Revision 1.238  2012-08-09 14:05:38  jauer#his.de
 * Jobauswahl für studentische Reports auf DB-Auswahl umgestellt
 *
 * Revision 1.237  2012-08-09 09:14:55  wassmann#his.de
 * Neuer ParameterType manyselect_src
 *
 * Revision 1.236  2012-08-08 13:57:53  jauer#his.de
 * studentische Berichte aus der Gl. Konf. dynamisch anzeigen
 *
 * Revision 1.235  2012-08-08 09:00:49  jgrimm#werkstoffbit.de
 * added configuration for alumni student registration
 *
 * Revision 1.234  2012-08-07 10:35:36  paul#his.de
 * Gruppierung von DoSV Serviceverfahren Überschreibungskonfigurationen.
 *
 * Revision 1.233  2012-08-07 10:20:54  weyland#werkstoffbit.de
 * improved usability of contact data within  the central HISinOne profile (fixes #59647)
 *
 * Revision 1.232  2012-08-01 14:40:06  kromm#his.de
 * Teilzulassungen in der OI und div. Fehelerkorrekturen APP
 *
 * Revision 1.231  2012-07-24 19:23:49  lustig#his.de
 * Distributed ClearCache für einzelne Parameter der globalen Konfiguration eingeführt. Dadurch geht das Speichern nach Änderung eines Confparams jetzt flott (fixes #43198).
 *
 * Revision 1.230  2012-07-24 17:32:40  lustig#his.de
 * Semantik des Caches für die globale Konfiguration (Conf) umgedreht. Beim Leeren des Caches wird er nun nicht mehr automatisch komplett neu gefüllt, sondern er füllt sich erst nach und nach (wichtig für Geschwindigkeit der JUnit-Tests). Wenn es in der Anwendung doch vorteilhaft sein sollte, dass der Cache komplett auf einmal gefüllt wird (z.B. vor dem Anzeigen des Editors der glob. Konfiguration), kann man mit dies dem Cache mit 'suggestFetchAll' vorschlagen (fixes #43198). Bei der Gelegenheit habe ich auch die Tests der glob. Konfiguration wieder eingebunden. Diese laufen fast alle wieder durch.
 *
 * Revision 1.229  2012-07-23 06:46:55  lustig#his.de
 * Angefangen, den Cache der Glob. Konfiguration 'umzudrehen'
 *
 * Revision 1.228  2012-07-19 09:50:15  yu#his.de
 * Funktion 'Online-Rückmeldung' werden mit iTan abgesichert
 * Schlüssel: core.psv.itan.secure_online_reregistration.should_query
 *
 * Revision 1.227  2012-07-18 15:36:53  wahrendorff#his.de
 * minElements Parameter für Menüsuche in Globale KOnfiguration, css für Menüsuche in experimental
 *
 * Revision 1.226  2012-07-17 09:15:11  koczewski#his.de
 * Textanpassung für cm.app.application.default_application_term_online_application
 *
 * Revision 1.225  2012-07-17 07:46:10  jauer#his.de
 * fixes #73386 – Anzahl von Zurückliegenden Semestern einschränken: Max. Anzahl zurückliegender Semester für STU-Berichte  cm.stu.reports.periodlimit  3 (HIS) (Korrektur)
 *
 * Revision 1.223  2012-07-12 16:13:03  scheid#his.de
 * neue Schlüssel ergänzt
 *
 * Revision 1.222  2012-07-10 12:31:06  schwaff#his.de
 * changed old key cm.app.common.terms_current to cm.app.edit.default_application_term_edit_application (fixes #48030)
 *
 * Revision 1.221  2012-07-09 21:01:28  v.zorn#ifore.de
 * feeClearing - batchVerfahren
 *
 * Revision 1.220  2012-07-09 14:04:51  schwaff#his.de
 * change confkey cm.app.application.default_application_term_online_application (fixes #48030)
 *
 * Revision 1.219  2012-07-03 09:24:27  freese#his.de
 * Neuer Schlüssel zur Steuerung des automatischen Ausstempelns aus der Zeiterfassung
 *
 * Revision 1.218  2012-07-02 14:04:49  bergemann#his.de
 * - Task: Antrag auf Darlehensberechtigung implementieren (#69596)
 * - Task: Antrag auf Darlehenslaufzeitverlaengerung implementieren (#69597)
 * - Task: Antrag auf Studienkontenaenderung (#72089)
 * - Task: Einstellung und Aenderung Darlehensberechtigung implementieren (#36631)
 * - Task: Einstellung und Aenderung Studienkontenmodelle implementieren (#36632)
 * - Task: Ermittlung der personenbezogenen Darlehensberechtigung implementieren (#36615)
 *
 * Revision 1.217  2012-07-02 12:14:11  paul#his.de
 * Neuer Parameter für DoSV-Konnektor Proxy Auth.
 *
 * Revision 1.216  2012-06-28 14:09:41  jgrimm#werkstoffbit.de
 * added explicit minimum_age-key for alumni-partner-registration
 *
 * Revision 1.215  2012-06-28 11:36:49  wahrendorff#his.de
 * Suchmenü eingebaut (#70280) kann über globale Konfiguration an- und abgeschaltet werden (core.sys.ui.show_menu_search)
 *
 * Revision 1.214  2012-06-25 13:10:11  kassner#his.de
 * #48802 – Zuletzt bearbeitete Studierende - Schnellzugriff auf Leistungsdaten - Konfiguration für Anzahl der Fälle, die angezeigt werden.
 *
 * Revision 1.213  2012-06-25 06:21:38  strube#his.de
 * Alumni aus Online-Imma und STU-Sachbearbeiter-Uebersichtsmaske entfernt (fixes #58992)
 *
 * Revision 1.212  2012-06-22 07:52:19  wahrendorff#his.de
 * Konfiguration der OpenOffice Verbindung vorbereitet
 *
 * Revision 1.211  2012-06-20 11:49:28  deicke#his.de
 * Turnusmäßige Übernahme für Veranstaltungen
 *
 * Revision 1.210  2012-06-19 06:47:31  schwaff#his.de
 * added new entry cm.app.application.default_application_term for defining a default-application-term
 *
 * Revision 1.209  2012-06-15 12:28:26  mshenavai#werkstoffbit.de
 * initial check-in: alumni candidate lock management
 *
 * Revision 1.208  2012-06-12 12:00:56  hoersch#his.de
 * neuer Schalter um CSS Zusammenfassung und Kompression außerhalb vom Operation mode Production zu aktivieren (# 70599)
 *
 * Revision 1.207  2012-06-12 07:28:22  wassmann#his.de
 * Mehr Debug-Ausgaben
 *
 * Revision 1.206  2012-06-08 11:59:15  freese#his.de
 * Neue Konfigurationsschlüssel für die Arbeit mit Kaba Zeiterfassungsterminals
 *
 * Revision 1.205  2012-06-07 11:07:43  eden#his.de
 * cm.app.edit_old_admission_regulation gelöscht (fixes #70176)
 *
 * Revision 1.204  2012-06-06 09:37:17  wagenmann#his.de
 * Es ist nun konfigurierbar, ob in der Noteneingabe und Leistungsbearbeitung prüfungsweise beim Import auch leere Bewertungen importiert werden sollen oder nicht. (fixes #66720)
 *
 * Revision 1.203  2012-06-01 10:05:11  jgrimm#werkstoffbit.de
 * re-added deleted alu-keys
 *
 * Revision 1.202  2012-06-01 08:58:40  wassmann#his.de
 * Feeds auf Untrusted-Domain rendern (#61775)
 *
 * Revision 1.201  2012-05-31 14:46:02  kostecki#his.de
 * Ein paar Optionen für den System Monitor entfernt und teilweise angepasst.
 *
 * Revision 1.200  2012-05-31 14:21:13  kostecki#his.de
 * Revert
 *
 * Revision 1.198  2012-05-31 08:51:37  m.kastner#his.de
 * Verwendung des UntrustedDomainUtil, der spezielle Gl. Konf. Schlüssel zur UntrustedDomain für Dokumente wurde entfernt (#61778)
 *
 * Revision 1.197  2012-05-29 12:31:02  jgrimm#werkstoffbit.de
 * added missing configuration
 * added description for initial configuration
 * added confparameter checks
 *
 * Revision 1.196  2012-05-24 16:39:31  wassmann#his.de
 * Untrusted Domain veralgemeinert (#61778)
 *
 * Revision 1.195  2012-05-24 13:26:16  jauer#his.de
 * Stacktrace wird jetzt ausgegeben
 *
 * Revision 1.194  2012-05-24 07:04:31  jgrimm#werkstoffbit.de
 * added global configuration settings for the alumni partner registration and implemented the settings factory
 *
 * Revision 1.193  2012-05-21 14:12:01  m.kastner#his.de
 * Parameter zur Angabe einer Untrusted Domain hinzugefügt
 *
 * Revision 1.192  2012-05-14 13:01:04  schirmeister#his.de
 * Abfrage Nachteilsaugleich Note und Wartezeit in der Online-Bewerbung abschaltbar # 66763
 *
 * Revision 1.191  2012-05-14 10:26:37  freese#his.de
 * Allgemeine Einstellungen für die Zeiterfassung
 *
 * Revision 1.190  2012-05-14 08:29:40  schirmeister#his.de
 * Abfrage Nachteilsaugleich Note und Wartezeit in der Online-Bewerbung abschaltbar # 66763
 *
 * Revision 1.189  2012-05-10 13:38:51  koczewski#his.de
 * Anfrage #68930 – Fehlende Unterlagen für bestimmte Bewerbergruppen automatisch anlegen (weitere fehlende Unterlagen)
 *
 * Revision 1.188  2012-05-09 14:29:31  brummermann#his.de
 * exchange version
 *
 * Revision 1.187  2012-05-09 12:13:32  koczewski#his.de
 * DMS in der Onlinebewerbung per GlobalConf abschaltbar
 *
 * Revision 1.186  2012-05-08 08:43:48  brummermann#his.de
 * owa url
 *
 * Revision 1.185  2012-05-04 16:26:06  mshenavai#werkstoffbit.de
 * configuration option for partners
 *
 * Revision 1.184  2012-05-03 09:48:17  lierath#his.de
 * confirmation workflow for projectMember
 *
 * Revision 1.183  2012-05-03 06:37:03  koczewski#his.de
 * Anfrage #68930 – Fehlende Unterlagen für bestimmte Bewerbergruppen automatisch anlegen
 *
 * Revision 1.182  2012-05-02 12:48:31  koczewski#his.de
 * Anfrage #68930 – Fehlende Unterlagen für bestimmte Bewerbergruppen automatisch anlegen
 *
 * Revision 1.181  2012-05-02 09:48:22  bolte#his.de
 * Konfigurationsschalter für das Ausblenden der Semesterumschaltung im Studienplaner, #67777
 *
 * Revision 1.180  2012-04-26 13:39:30  wassmann#his.de
 * Passwoerter vom Typ STRING zu PASSWORD_PLAINTEXT geaendert (#68723)
 *
 * Revision 1.179  2012-04-25 09:26:40  brandt#his.de
 * ajax_request to check if unit is deletable #67940
 *
 * Revision 1.178  2012-04-24 09:19:11  dreyer#his.de
 * neu: Segment Forschungsmanagement mit zwei Parametern
 *
 * Revision 1.177  2012-04-18 12:58:47  schwaff#his.de
 * added key cm.app.application.multipleenrollment
 *
 * Revision 1.176  2012-04-17 09:42:47  m.kastner#his.de
 * Konfigurationsparameter für das Setzen des Logout-Links hinzugefügt
 *
 * Revision 1.175  2012-04-17 08:03:59  schirmeister#his.de
 * Konfigurationsschalter für Nachweis Bev Zul #67583
 *
 * Revision 1.174  2012-04-16 15:55:38  wassmann#his.de
 * Alternativer Link auf dem Logo (#67518)
 *
 * Revision 1.173  2012-04-10 16:04:39  l.wolter#his.de
 * Anpassung auf neue hsst-URLs
 *
 * Revision 1.172  2012-04-04 14:00:02  paul#his.de
 * Generierte Conf Keys für die DoSV Jobs.
 *
 * Revision 1.171  2012-03-31 23:39:08  kromm#his.de
 * Umbau Online-Imma - Merge in den HEAD
 *
 * Revision 1.168  2012-03-23 08:06:08  bergemann#his.de
 * - Task: Globaler Schalter fuer Toleranzbetrag zur Rueckmeldung (#63461)
 *
 * Revision 1.167  2012-03-22 14:01:08  graebel#his.de
 * BIA  Controll Parameter aus eduETL für FF Zuordnung, Globale Parameter #65837
 *
 * Revision 1.166  2012-03-19 00:50:31  brummermann#his.de
 * facebook app configuration
 *
 * Revision 1.165  2012-03-13 12:55:20  schwaff#his.de
 * replaced setting the defaultvalue in selfregistration's address country field via data-dictionary with global configuration (fixes #65068)
 *
 * Revision 1.164  2012-03-12 13:20:12  scheid#his.de
 * neuen Schlüssel ergänzt
 *
 * Revision 1.163  2012-03-09 16:20:17  m.kastner#his.de
 * Konfigurationsparameter für die Angabe eines URL-Musters für Moodle-Kurse (Backlink zur Veranstaltung im Externen System)
 *
 * Revision 1.162  2012-03-09 13:10:48  paul#his.de
 * HHK Bestandteile aus dem DoSV-Konnektor entfernt. (#65174)
 *
 * Revision 1.161  2012-03-08 10:42:50  jgrimm#werkstoffbit.de
 * Added an option to perform the opt-in for the alumni registration automatically. This option is especially required for lead-tests.
 *
 * Revision 1.160  2012-03-06 15:39:14  kostecki#his.de
 * Zwei weitere Optionen angelegt für System Monitor
 *
 * Revision 1.159  2012-03-05 15:08:58  mclaren#his.de
 * Refactoring: KeyEnum verschoben #62354
 *
 * Revision 1.158  2012-03-01 15:22:14  kostecki#his.de
 * Neue Konfigurationsoptionen für "System Monitor" hinzugefügt
 *
 * Revision 1.157  2012-03-01 13:27:11  gerke#his.de
 * bankfileformat Requestparameter geändert
 *
 * Revision 1.156  2012-03-01 11:05:19  gerke#his.de
 * neuer Schalter cm.stu.fee.fia.bankfileformat
 *
 * Revision 1.155  2012-03-01 09:25:23  poeschel#his.de
 * neuer Parameter cm.exa.report.ectscohort.min_examplans
 *
 * Revision 1.154  2012-02-29 17:26:49  wassmann#his.de
 * Refactoring des Portals: Name des Portal aus I18n beziehen (#23757)
 *
 * Revision 1.153  2012-02-29 11:21:57  keunecke#his.de
 * Die Zeitplanung aus der job.xml für die DoSV-Jobs kann durch Parameter in der Globalen Konfiguration übersteuert werden (fixes #64426)
 *
 * Revision 1.151  2012-02-28 12:54:43  m.kastner#his.de
 * Parameter für die Moodle 2.x Synchronisation erstellt
 *
 * Revision 1.150  2012-02-23 09:06:50  paul#his.de
 * Anpassungen für Clearing (#64311)
 *
 * Revision 1.149  2012-02-22 08:48:22  m.kastner#his.de
 * AristaFlow-Einstellung "Startknoten" umbenannt in "Serverknoten"
 *
 * Revision 1.148  2012-02-20 11:01:47  m.kastner#his.de
 * ConfParam für die Konfigurierung eines Startknotens für Aristaflow angelegt
 *
 * Revision 1.147  2012-02-03 11:05:57  kassner#his.de
 * #59336 Änderungen in java-Klassen für Gasthörer
 *
 * Revision 1.146  2012-01-27 10:19:18  schwaff#his.de
 * enable to inquire information about health insurance from online-applicants
 *
 * Revision 1.145  2012-01-25 10:22:49  hoersch#his.de
 * neue Konfigurationsschlüssel
 *
 * Revision 1.144  2012-01-24 14:25:39  kassner#his.de
 * (fixes #59336) – Task: Ergänzungen zu Gast- Zweithörern implementieren - Klassen und Konfigurationsdateien
 *
 * Revision 1.143  2012-01-23 15:40:34  bergemann#his.de
 * - Task: Anzeige der Rechnungen mit Rechnungspositionen aus FIA (#59859)
 *
 * Revision 1.141  2012-01-20 16:59:46  mshenavai#werkstoffbit.de
 * using tableActionsPanel for alumni prospect management
 *
 * Revision 1.140  2011-12-22 15:05:27  bergemann#his.de
 * - Task: Fieldset „Gebuehren“ für Online-Rueckmeldung implementieren (#37568)
 *
 * Revision 1.139  2011-12-15 13:24:34  bergemann#his.de
 * - Bugfix: Saeumnisgebuehren stehen lassen bei nachtraeglicher Befreiung (#59985)
 *
 * Revision 1.138  2011-12-14 10:44:47  d.scholz#his.de
 * Blättern-Funktion kann jetzt auch global für alle Tabellen aktiviert werden (fixes #59702)
 *
 * Revision 1.137  2011-12-12 14:06:02  brummermann#his.de
 * created global configuration key core.psv.account.password_hash_type
 *
 * Revision 1.136  2011-12-09 13:28:05  bergemann#his.de
 * - Task: Schalter HISinOne - OpenBravo (#52618)
 *
 * Revision 1.135  2011-12-08 15:06:28  mshenavai#werkstoffbit.de
 * added help text (#49598)
 *
 * Revision 1.134  2011-12-08 13:44:23  mshenavai#werkstoffbit.de
 * rename (#49598)
 *
 * Revision 1.133  2011-12-07 16:25:40  mshenavai#werkstoffbit.de
 * configuration possibility for the written agreement + renaming
 * (#49598)
 *
 * Revision 1.132  2011-12-05 08:32:32  wassmann#his.de
 * Verschiedene Aenderungen am Setup
 *
 * Revision 1.131  2011-12-01 16:36:43  mshenavai#werkstoffbit.de
 * search for duplicates & lru list
 *
 * Revision 1.130  2011-11-29 13:54:01  hoersch#his.de
 * Conf.getOrgunitLidRequired()
 *
 * Revision 1.129  2011-11-23 16:30:50  paul#his.de
 * Verschiebung eines Confparams ins Unterpackage zulgx (for #58669)
 *
 * Revision 1.128  2011-11-22 15:08:01  d.scholz#his.de
 * Vorbelegung für StudySem. ergänzt (fixes #52691)
 *
 * Revision 1.127  2011-11-21 13:21:36  keunecke#his.de
 * rename new global configuration parameter to control the import of course of studies from sospos (fixes #58669)
 *
 * Revision 1.126  2011-11-21 12:45:38  keunecke#his.de
 * introduce new global configuration parameter to control the import of course of studies from sospos (fixes #58669)
 *
 * Revision 1.125  2011-11-14 16:05:15  hoersch#his.de
 * Wenn eine Orgunit über den globalen Konfigurationsschlüssel 'core.psv.self.own_university' als "eigene Hochschule' definiert ist, dann ist der Astat jetzt Pflichtfeld (# 57021, #57691)
 *
 * Revision 1.124  2011-11-11 12:49:29  wassmann#his.de
 * Liste clonen damit Aenderungen keinen Einfluss auf andere Ausgaben haben.
 *
 * Revision 1.123  2011-11-11 09:54:02  wassmann#his.de
 * HRM-Portlet zum Einstemplen (#57920)
 *
 * Revision 1.122  2011-11-10 12:16:01  paul#his.de
 * Konfiguration wieder gerade gezogen.
 *
 * Revision 1.121  2011-11-10 11:35:27  bolte#his.de
 * Folgende Parameter wieder eingefügt:
 * ENROLLMENT_ENTRANCE_QUALIFICATION_DATE
 * ENROLLMENT_NUMBER_REDIRECTED_TERMS
 * SEST_DOSV_WEBSERVICE_MAX_CHUNK_SIZE
 *
 * Revision 1.120  2011-11-10 11:01:45  bolte#his.de
 * Jetzt gehts wieder.
 *
 * Revision 1.116  2011-11-08 16:14:39  wassmann#his.de
 * Lesezeichenfunktion abschaltbar (#55788)
 *
 * Revision 1.115  2011-11-08 13:44:03  d.scholz#his.de
 * Sortierung der Conf.java Einträge sollte nun stabil sein + Neuer Eintrag (fixes #57258)
 *
 * Revision 1.114  2011-11-07 14:01:29  d.scholz#his.de
 * Neue Schlüssel (fixes #57235, #57312)
 *
 * Revision 1.113  2011-11-03 12:09:53  hoersch#his.de
 * neue Globale Konfigurations-Parameter
 *
 * Revision 1.112  2011-11-02 09:49:46  wassmann#his.de
 * Statt Login-Eingabefelder auch Link zu CAS (#56935)
 *
 * Revision 1.111  2011-11-01 12:40:08  paul#his.de
 * Allgemeine Segmentierungsgröße für DoSV Bewerbungen und Ranglisten.
 *
 * Revision 1.110  2011-11-01 11:13:41  herbrich#his.de
 * New global configuration key added to support hiding exams or events from study planner tree (fixes #56518)
 *
 * Revision 1.109  2011-11-01 11:09:20  herbrich#his.de
 * Added a degree whitelist in global configuration to limit selectable courses of study to those with predefined degrees only (fixes #56516)
 *
 * Revision 1.108  2011-10-27 08:37:38  d.scholz#his.de
 * XML-Export Format lässt sich nun konfig.
 *
 * Revision 1.107  2011-10-25 11:33:06  paul#his.de
 * Korrektur der Conf-Keys für den DoSV Konnektor.
 *
 * Revision 1.106  2011-10-24 12:21:06  schirmeister#his.de
 * Konfiguration angepasst/erweitert
 *
 * Revision 1.105  2011-10-24 11:22:13  schirmeister#his.de
 * Angefangen die alte Implementierung der hochschuleigenen Auswahl zu entfernen
 *
 * Revision 1.104  2011-10-19 08:56:25  paul#his.de
 * Unicode Zeichenersetzung für Sospos
 *
 * Revision 1.103  2011-10-06 09:28:52  m.kastner#his.de
 * Konfigurationsparameter für den Moodle 2.x Webservice angelegt
 *
 * Revision 1.102  2011-09-29 08:06:38  paul#his.de
 * Initialer Studienangebotsstatus aus globaler Konfiguration raus.
 *
 * Revision 1.101  2011-09-28 15:17:01  paul#his.de
 * Globale Config für DoSV Mails
 *
 * Revision 1.100  2011-09-28 09:26:48  paul#his.de
 * Fehlerkennzeichen in globaler config
 *
 * Revision 1.99  2011-09-20 16:23:08  kassner#his.de
 * #37759 – Task: FD Schnelleinschreibung Gasthörer. Übertragung aus dem Branch
 *
 * Revision 1.98  2011-09-20 11:58:41  paul#his.de
 * Uhrzeit für Bewerbungsfristen.
 *
 * Revision 1.97  2011-09-19 13:55:07  paul#his.de
 * Refactoring der globalen Konfiguration für DoSV
 *
 * Revision 1.96  2011-09-19 08:00:19  wassmann#his.de
 * #49265, #53575, #54014, #53196, #53687, #49095
 * - Portalswitcher: Wert im UserProfile speichern
 * - selectedId  nicht auswerten bei nicht persistenten Portlets
 * - Bei leerem Portal Reset anbieten
 * - Portlet aus Gruppe verschieben
 * - Navigationsmenue unter Studentisches Leben
 * - Portalmeldungen auch als E-Mail
 *
 * Revision 1.95  2011-09-15 08:34:24  bergemann#his.de
 * - Globaler Parameter zur Abbildung von Saeumnisgebuehren in aktiver Gebuehrenordnung (#53411)
 *
 * Revision 1.94  2011-09-14 11:21:28  wassmann#his.de
 * Fehler im Context einer Seite behoben: clientId und List (#51602)
 *
 * Revision 1.93  2011-09-12 12:47:25  jgrimm#werkstoffbit.de
 * added changes from branch: fixed unprecise description of alu key to select default user role
 *
 * Revision 1.92  2011-08-31 15:07:10  wagenmann#his.de
 * Neuer Parameter cm.exa.grading.showcourseofstudies, um die Darstellung der Studiengänge in der Notenverbuchung zu unterdrücken
 *
 * Revision 1.91  2011-08-26 10:28:07  kassner#his.de
 * #35193 – Account-Generierung bei Immatrikulation. Neuer Konfigurationsparameter zum Ansteuern der Generierung beim Speichern.
 *
 * Revision 1.90  2011-08-24 07:23:51  jgrimm#werkstoffbit.de
 * added settings for agreement retrieval
 *
 * Revision 1.89  2011-08-19 07:43:54  weyland#werkstoffbit.de
 * made selfregistration business contact data configurable (reordering of conf keys)
 *
 * Revision 1.88  2011-08-16 13:01:48  d.scholz#his.de
 * Vorbelegung geändert bzw implementiert (fixes #51762)
 *
 * Revision 1.87  2011-08-15 13:55:06  d.scholz#his.de
 * Vorbelegungen (fixes #51760)
 *
 * Revision 1.86  2011-08-15 12:29:04  d.scholz#his.de
 * Vorbelegungen (fixes #51754, #51753, #51644)
 *
 * Revision 1.85  2011-08-15 12:15:40  jgrimm#werkstoffbit.de
 * removed obsolete keys cm.alu.usermanagement.agreement.additional_agreement_available and cm.alu.usermanagement.agreement.general_terms_and_conditions_enabled
 *
 * Revision 1.84  2011-08-12 07:29:27  strube#his.de
 * Den Schalter cm.stu.enrollment.time_for_registrationnumber implementiert und in der Online-Imm ausgewertet.(fixes #51552)
 *
 * Revision 1.83  2011-08-09 13:44:29  strube#his.de
 * Globalen ConfParameter cm.stu.enrollment.number_of_addresses erstellt und ausgewertet (fixes #51395)
 *
 * Revision 1.82  2011-08-08 13:38:36  brummermann#his.de
 * merged changes
 *
 * Revision 1.79  2011-08-02 16:27:10  wassmann#his.de
 * Anzeige des Namens des Clusterkontotens (#49457)
 *
 * Revision 1.78  2011-08-01 10:07:29  weyland#werkstoffbit.de
 * key update
 *
 * Revision 1.77  2011-07-28 11:07:31  husmann#his.de
 * Maximale Anzahl von ausdruckbaren Bescheiden angelegt
 *
 * Revision 1.76  2011-07-27 14:15:25  hoersch#his.de
 * getBoolean mit nativem Datentyp
 *
 * Revision 1.75  2011-07-27 11:29:23  wilhelm#his.de
 * Statische Map, Fester Kartenausschnitt als Varianten für die CampusMap realisiert
 *
 * Revision 1.74  2011-07-25 15:10:02  wilhelm#his.de
 * Campus-Map Typ für mobiles Studierenden Cockpit hinzugefügt
 *
 * Revision 1.73  2011-07-20 14:12:10  wilhelm#his.de
 * MapType für mobiles Studierenden Cockpit hinzugefügt
 *
 * Revision 1.72  2011-07-19 11:39:47  wassmann#his.de
 * Neuer Test-Confkey fuer Manyselect
 *
 * Revision 1.71  2011-07-19 07:02:08  jgrimm#werkstoffbit.de
 * removed obsolete key cm.alu.usermanagement.selfregistration.agreement.written_agreement
 *
 * Revision 1.70  2011-07-18 15:51:24  kassner#his.de
 * #39564 – Anzeige von Fachsemestern als Ganzzahl möglich
 *
 * Revision 1.69  2011-07-15 07:34:01  strube#his.de
 * Labelaenderung und Aktivierung (fixes #49184)
 *
 * Revision 1.68  2011-07-13 12:44:17  jgrimm#werkstoffbit.de
 * added keys for alumni acquisition and metadata-type WWW
 *
 * Revision 1.67  2011-07-13 07:18:18  wassmann#his.de
 * Error beim DB-Nauaufbau vermeiden
 *
 * Revision 1.66  2011-07-08 10:53:24  paul#his.de
 * Neue DoSV-Parameter.
 *
 * Revision 1.65  2011-07-07 17:01:15  wassmann#his.de
 * Portalmeldungen als E-Mail versenden
 *
 * Revision 1.64  2011-07-07 08:31:59  paul#his.de
 * Konfig erweitert
 *
 * Revision 1.63  2011-07-05 08:42:15  bergemann#his.de
 * - Schalter zur Aktivierung der Karteikarte fuer Darlehensverwaltung
 *
 * Revision 1.62  2011-06-27 15:21:47  paul#his.de
 * Conf Konflikt behoben.
 *
 * Revision 1.60  2011-06-25 08:13:48  paul#his.de
 * DoSV-Konfiguration einzelner SAF.
 *
 * Revision 1.58  2011-06-23 10:26:45  paul#his.de
 * DoSVConfig erweitert.
 *
 * Revision 1.57  2011-06-23 10:13:25  paul#his.de
 * DoSVConfig erweitert.
 *
 * Revision 1.56  2011-06-22 13:48:28  paul#his.de
 * DoSVConfig erweitert.
 *
 * Revision 1.55  2011-06-22 13:20:39  schirmeister#his.de
 * Parameter hinzugefügt, um die Erfassung von Auswahlkriterien in der Online-Bewerbung zu aktivieren. Ist eine Referenz auf den Parameter der Sachbearbeiterfunktion.
 *
 * Revision 1.54  2011-06-20 09:56:33  paul#his.de
 * Neuer Konfigurationsparameter für DoSV. Weitere folgen.
 *
 * Revision 1.53  2011-06-20 08:45:34  binding#his.de
 * Schalter für Pflichtbelegung durchführen an Musikhochschulen
 *
 * Revision 1.52  2011-06-20 08:24:02  paul#his.de
 * Neuer Konfigurationsparameter für DoSV. Weitere folgen.
 *
 * Revision 1.51  2011-06-20 07:55:36  paul#his.de
 * Neuer Konfigurationsparameter für DoSV. Weitere folgen.
 *
 * Revision 1.50  2011-06-17 09:14:40  paul#his.de
 * Neuer Konfigurationsparameter für DoSV. Weitere folgen.
 *
 * Revision 1.49  2011-06-16 15:30:28  paul#his.de
 * Neuer Konfigurationsparameter für DoSV. Weitere folgen.
 *
 * Revision 1.48  2011-06-16 15:03:03  paul#his.de
 * Neuer Konfigurationsparameter für DoSV. Weitere folgen.
 *
 * Revision 1.47  2011-06-16 14:36:28  paul#his.de
 * Neuer Konfigurationsparameter für DoSV. Weitere folgen.
 *
 * Revision 1.46  2011-06-16 11:28:43  strube#his.de
 * Duplikatsprüfung von PSV-Identitymanagement in das STU-Management eingebaut.(fixes #44991, #46038, #47804)
 *
 * Revision 1.45  2011-06-15 13:16:50  schirmeister#his.de
 * bugfix
 *
 * Revision 1.44  2011-06-15 09:00:57  wassmann#his.de
 * Speichern der durchgefuehrten Updates der Gl. Konf.
 *
 * Revision 1.43  2011-06-14 15:48:16  schirmeister#his.de
 * Globale Konfiguration von APP an neue Struktur angepasst: Ranglistenanzeige. #30471
 *
 * Revision 1.42  2011-06-14 14:40:42  schirmeister#his.de
 * Globale Konfiguration von APP an neue Struktur angepasst: Annahme durch Immatrikulation. #30471
 *
 * Revision 1.41  2011-06-14 12:42:59  schirmeister#his.de
 * Globale Konfiguration von APP an neue Struktur angepasst: Annahme erforderlich. #30471
 *
 * Revision 1.40  2011-06-14 12:00:45  schirmeister#his.de
 * Globale Konfiguration von APP an neue Struktur angepasst: Wintersemesterende für die Wartezeitberechnung. #30471
 *
 * Revision 1.39  2011-06-14 11:15:43  schirmeister#his.de
 * Globale Konfiguration von APP an neue Struktur angepasst: Wintersemesterbeginn für die Wartezeitberechnung. #30471
 *
 * Revision 1.38  2011-06-14 09:35:48  schirmeister#his.de
 * Globale Konfiguration von APP an neue Struktur angepasst: Sommersemesterende für die Wartezeitberechnung. #30471
 *
 * Revision 1.37  2011-06-14 08:33:40  schirmeister#his.de
 * Globale Konfiguration von APP an neue Struktur angepasst: Sommersemesterbeginn für die Wartezeitberechnung. #30471
 *
 * Revision 1.36  2011-06-10 09:07:59  schirmeister#his.de
 * Globale Konfiguration von APP an neue Struktur angepasst: Wartezeitobergrenze. #30471
 *
 * Revision 1.35  2011-06-09 16:00:26  schirmeister#his.de
 * Globale Konfiguration von APP an neue Struktur angepasst: Vergabemethode. #30471
 *
 * Revision 1.34  2011-06-08 09:55:29  schirmeister#his.de
 * Globale Konfiguration von APP an neue Struktur angepasst: Bewerbungssemester. #30471
 *
 * Revision 1.33  2011-05-31 13:22:17  strube#his.de
 * Ausgewaehlte Registerkarten koennen ausgeblendet werden.(fixes #36795)
 *
 * Revision 1.32  2011-05-24 15:39:37  wilhelm#his.de
 * Timetable Viewtype für MSCP
 *
 * Revision 1.31  2011-05-23 09:20:17  jgrimm#werkstoffbit.de
 * made date format of employment history customizable
 *
 * Revision 1.30  2011-05-23 07:21:33  steuernagel#his.de
 * HZB-Datum für 'beruflich Qualifizierte' konfigurierbar
 *
 * Revision 1.29  2011-05-11 09:19:14  schirmeister#his.de
 * Auswertung des Applicationstatus per hiskey fixes #46429
 *
 * Revision 1.28  2011-05-05 15:53:00  wilhelm#his.de
 * Konfigurationsparameter für die Aktivierung der Browserweiche für das mobile Studierenden Cockpit hinzugefügt
 *
 * Revision 1.27  2011-05-03 15:07:46  d.scholz#his.de
 * Anzeige des Uniquenames als Prefix in SelectMenüs in STU abschaltbar gemacht
 *
 * Revision 1.26  2011-05-02 15:52:53  kassner#his.de
 * #38080 Online-Immatrikulation scheitert an fehlender Unit für examimport. ID auf UniqueName geändert.
 *
 * Revision 1.25  2011-05-02 10:46:12  weyland#werkstoffbit.de
 * added pending changes to alumni agreements (using flexible personal agreements)
 *
 * Revision 1.24  2011-04-18 15:51:13  kassner#his.de
 * Fehlende Enum-Wert für 'core.sys.externalapps.email.communigate.cliserver' nachgetragen. GGf bitte überprüfen.
 *
 * Revision 1.23  2011-04-18 14:28:29  kassner#his.de
 * (#37395) Rückgriff auf die zuletzt bearbeiteten Fälle. Ein neuer globale Paramter "cm.stu.recentsavedstudentssize"
 *
 * Revision 1.22  2011-04-13 16:58:37  wassmann#his.de
 * Log-Level angepasst
 *
 * Revision 1.21  2011-04-13 16:38:30  brummermann#his.de
 * added new configuration parameter to allow the definition of a CommuniGate CLI server that is distinct from the mail server
 *
 * Revision 1.20  2011-04-04 13:43:21  jgrimm#werkstoffbit.de
 * added new key for retrieval of alumni agreement
 *
 * Revision 1.19  2011-03-31 14:06:13  deuper#his.de
 * Unnoetige Abfrage nach ungueltigem Schema fuer Keys entfernt
 *
 * Revision 1.18  2011-03-31 13:36:05  deuper#his.de
 * Platzhalter fuer Javadoc richtig implementiert
 *
 * Revision 1.17  2011-03-31 09:57:22  deuper#his.de
 * Generierung der Enums in Conf.java ueber Test funktioniert, Formatierung und Javadoc korrekt
 *
 * Revision 1.16  2011-03-29 15:05:44  deuper#his.de
 * Automatisches Generieren aller Enums in Conf.java
 *
 * Revision 1.15  2011-03-25 11:05:14  deuper#his.de
 * Code-Block fuer Enums wird erzeugt und soll in Conf.java eingefuegt werden.
 * Vorherige Tests noetig...
 * Conf.java mit entsprechenden Block-Markern versehen.
 *
 * Revision 1.14  2011-03-24 15:26:32  deuper#his.de
 * Methode zum automatischen Generieren der Enum-Klassen in Conf.java
 *
 * Revision 1.13  2011-03-18 10:51:40  wassmann#his.de
 * String.valueOf nur durchfuehren, wenn der Wert nicht null ist (#44660)
 *
 * Revision 1.12  2011-03-16 15:14:24  wassmann#his.de
 * Einzelnen Parameter erneuertn, Teil 1 (#43198)
 *
 * Revision 1.11  2011-03-16 13:28:45  k.grabau#his.de
 * Methode isParameterValueMapSet nun public
 *
 * Revision 1.10  2011-03-15 15:23:58  wassmann#his.de
 * getString fuehrt jetzt ein valueOf durch und Methoden zum Holen von Objekten
 *
 * Revision 1.9  2011-02-23 10:47:06  wassmann#his.de
 * Fehlermeldung, wenn Confkey nicht im Cache vorhanden ist
 *
 * Revision 1.8  2011-02-22 08:02:11  jgrimm#werkstoffbit.de
 * migrated changes from branch 2011/02 to head
 *
 * Revision 1.7  2011-02-09 12:09:38  lustig#his.de
 * Laden aller globalen Konfigurationsparameter beschleunigt (valueList ist SortedSet statt List und kann deshalb EAGER gefetched werden). Sortorder von Long auf Integer umgestellt.
 *
 * Revision 1.6  2011-02-08 16:08:07  wassmann#his.de
 * Enums erneuert
 *
 * Revision 1.5  2011-02-08 14:18:23  wassmann#his.de
 * Enums erneuert
 *
 * Revision 1.4  2011-02-07 15:41:31  wassmann#his.de
 * Confkey vor der Verwendung aufbereiten
 *
 * Revision 1.3  2011-02-03 09:53:52  wassmann#his.de
 * Performance des Editors der Globalen Konfiguration optimiert
 *
 * Revision 1.2  2011-01-24 16:20:33  wassmann#his.de
 * Refactoring: Methoden jetzt ohne AS
 *
 * Revision 1.1  2011-01-24 12:57:04  wassmann#his.de
 * Neue Zugriffsmethoden auf die Globale Konfiguration: Statische Klasse Conf, Confkeys als Enum integriert, Parametertypen aufgeraumt, beispielhaft in PortalBean implementiert
 *
 */
package de.his.core.util.cs.sys.configuration;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;

import de.his.appserver.service.iface.cs.sys.configuration.GlobalConfigurationEnumSourceService;
import de.his.appserver.service.impl.cs.sys.configuration.GlobalConfigurationEditorServiceImpl;
import de.his.core.datatype.KeyEnum;
import de.his.core.util.EnsureState;
import de.his.core.webapp.qis.ConfigUtil;
import de.his.core.webapp.spring.SpringApplicationContext;

/**
 * Diese Util-Klasse dient dem Zugriff auf die Werte der Globalen Konfiguration.
 * Alle Werte werden gecacht und können über das Menü "Caches löschen" erneuert werden.
 * Der Zugriff auf die Methoden dieser Klasse kann in allen drei Schichten (bspw. DAO, Service, Controller) der HISinOne-Architektur erfolgen.
 *
 * Die statischen Methoden der Klasse delegieren an eine Conf-Instanz, die als Spring-Bean 'confCache' deklariert ist.
 * Wenn Testfälle abgearbeitet werden, können mehrere solche Beans vorhanden sein, über 'SpringApplicationContext' wird aber die
 * richtige gefunden (wird von BaseDaoTestCase aktuell gehalten).
 *
 * Seit 4.0 wird beim Löschen des Caches (invalidateAll) nicht gleich der ganze Inhalt wieder aufgebaut, sondern er sammelt sich mit der Zeit an.
 * Falls das für einen Anwendungsfall nicht optimal ist, kann mit 'suggestFetchAll' vorgeschlagen werden, alle Konfigurationsparameter auf einmal
 * zu laden. Das wird der Cache dann auch tun, wenn es nicht nach dem letzten 'invalidateAll' bereits geschehen ist.
 *
 * <br />
 * Der Inhalt der Enums ist generiert; nicht per Hand &auml;ndern!
 *
 * @author Wassmann
 * @version $Id: Conf.java,v 1.360.4.11 2013-12-04 11:39:17 wassmann#his.de Exp $
 */
public final class Conf implements ConfCache {
    /** Logger. */
    private static Logger logger = Logger.getLogger(Conf.class);

    /** Constant for a Value that has already been tried to get from the Provider but which could not be found */
    private static final Object KEY_NOT_FOUND = new Object();
    /** Constant for a Value that has already been fetched from the Provider and which was null */
    private static final Object KEY_IS_NULL = new Object();

    private static Conf instance = null;


    /** The provider of Configuration Properties */
    private ConfProvider provider = null;

    /** Cache für die berechneten Werte aus der Globalen Konfiguration. Der Wert NULL
     * wird immer in die Konstante 'KEY_IS_NULL' übersetzt */
    private final Map<String, Object> cache = new ConcurrentHashMap<String, Object>();

    /** Wann wurde der komplette Cache das letzte Mal neu aufgebaut? */
    private long lastFetchAllTimestamp = -1;

    /**
     * Prüft ob ein Value eines GlobalConfigurationEnumSourceService noch vorhanden ist
     *
     * @param beanName
     * @param value
     * @return boolean
     */
    public static boolean enumSourceContainsValue (String beanName, String value) {
        GlobalConfigurationEnumSourceService bean = GlobalConfigurationEditorServiceImpl.getEnumSourceBean(beanName);
        return bean.containsValue(value);
    }

    /**
     * Prüft ob Values eines GlobalConfigurationEnumSourceService noch vorhanden sind
     *
     * @param beanName
     * @param value
     * @return boolean
     */
    public static boolean enumSourceContainsValues (String beanName, List<String> value) {
        GlobalConfigurationEnumSourceService bean = GlobalConfigurationEditorServiceImpl.getEnumSourceBean(beanName);
        return bean.containsValues(value);
    }

    /**
     * Allows a ConfProvider to register for this ConfCache
     * @param newProvider
     */
    @Override
    public void registerConfProvider(ConfProvider newProvider) {
        if (provider == null) {
            provider = newProvider;
        } else {
            throw new IllegalStateException("There is already a ConfProvider registered!", new Throwable());
        }
    }

    /**
     * Allows a ConfProvider to unregister for this ConfCache
     * @param oldProvider
     */
    @Override
    public void unregisterConfProvider(ConfProvider oldProvider) {
        if (provider == oldProvider) {
            provider = null;
        } else {
            throw new IllegalStateException("The given ConfProvider was not registered before!", new Throwable());
        }
    }

    /**
     * @return true, if a ConfProvider has been set
     */
    public boolean hasConfProvider() {
        return provider != null;
    }

    /**
     * Event that informs this ConfCache, that the Property identified by the given key
     * has changed (updated or deleted) in a ConfProvider. The Key will be removed from the Cache as a result.
     * @param key
     */
    @Override
    public void invalidateProperty(String key) {
        cache.remove(prepareConfkey(key));
    }


    /**
     * Event that informs this ConfCache, that all Properties of a ConfProvider may have
     * changed. The Cache will be emptied as a result.
     */
    @Override
    public void invalidateAll() {
        cache.clear();
        lastFetchAllTimestamp = -1; // Wenn das nächste Mal ein FetchAll vorgeschlagen wird, soll es auch passieren!
    }


    /**
     * Event that informs this ConfCache, that it might be appropriate
     *  to fetch all Properties of the ConfParameter by calling getAllProperties()
     * The Cache may or may not do so (e.g. depending on environment settings).
     */
    @Override
    public void suggestFetchAll() {
        if (lastFetchAllTimestamp < 0) {
            doFetchAll();
        }
    }

    /**
     * Fetch all Properties of the current ConfProvider
     */
    private synchronized void doFetchAll() {
        long minInterval = 60 * 1000; // Mindestens eine Minute zwischen fetchAlls, wenn nicht zwischendurch invalidateAll aufgerufen wurde.
        if (new Date().getTime() - lastFetchAllTimestamp > minInterval) {
            if (provider != null) {
                for (Map.Entry<String, Object> entry : provider.getAllProperties().entrySet()) {
                    cache.put(entry.getKey(), entry.getValue() == null ? KEY_IS_NULL : entry.getValue());
                }
            }
            lastFetchAllTimestamp = new Date().getTime();
        }
    }

    /**
     * Holt ein Property aus dem Cache bzw. bei Bedarf vom Provider. Wenn der
     * Key beim Provider nicht bekannt ist, oder die Klasse des Werts nicht
     * der erwarteten Klasse entspricht, wird null zurückgegeben.
     *
     * @param confkey
     * @return property from cache or provider - null if unknown key or unexpected class
     */
    private Object getPropertyFiltered(String confkey, Class<?> expectedClass) {
        Object value = getPropertyRaw(confkey);

        if(value == KEY_NOT_FOUND) {
            logger.error("Der confkey " + confkey + " ist im Cache in der Globalen Konfiguration nicht bekannt.");
            value = null;
        }
        else if (value != null) {
            // Listen müssen immer explizit als solche angefordert werden (expectedClass = List)
            if (value instanceof List && !List.class.equals(expectedClass)) {
                logger.error("Der confkey " + confkey + " ist in der Globalen Konfiguration nur als Liste abrufbar!");
                value = null;
            } // andernfalls Klasse nur prüfen, wenn auch angegeben
            else if (expectedClass != null && !expectedClass.isAssignableFrom(value.getClass())) {
                logger.error("Die Confvalues des confkey " + confkey + " konnten nicht nach " + expectedClass.getSimpleName() + " umgewandelt werden!");
                value = null;
            }
        }

        return value;
    }


    /**
     * Holt ein Property aus dem Cache bzw. bei Bedarf vom Provider.
     * @param confkey
     * @return property from cache or from ConfProvider (caching it)
     */
    private Object getPropertyRaw(String confkey) {
        String normalizedConfkey = prepareConfkey(confkey);

        Object value = cache.get(normalizedConfkey);
        if (value == null) {
            if (provider != null) {
                try {
                    value = provider.getProperty(normalizedConfkey);
                } catch (KeyNotFoundException ex) {
                    value = KEY_NOT_FOUND;
                }

                cache.put(normalizedConfkey, value == null ? KEY_IS_NULL : value);
            }
            else {
                logger.error("Es wurde noch kein Provider für die Globale Konfiguration registriert!");
            }
        } else if (KEY_IS_NULL == value) {
            value = null;
        }
        return value;
    }

    /**
     * Bereitet einen Confkey so auf, dass er verwendet werden kann
     * @param confkey
     * @return String
     */
    private String prepareConfkey(String confkey) {
        if (confkey == null) {
            logger.debug("Der Confkey war null ...");
            return null;
        }
        return confkey.toLowerCase();
    }


    /**
     * Fügt dem Cache zu Testzwecken einige Werte hinzu
     * @param properties
     */
    public void addToCacheForTesting(Map<String, Object> properties) {
        for (Map.Entry<String, Object> entry : properties.entrySet()) {
            addToCacheForTesting(entry.getKey(), entry.getValue());
        }
    }

    /**
     * Fügt dem Cache zu Testzwecken einen Wert hinzu
     * @param key
     * @param value
     */
    public void addToCacheForTesting(String key, Object value) {
        cache.put(prepareConfkey(key), value == null ? KEY_IS_NULL : value);
    }


    /**
     * Ersetzt für einen Bestimmten Wert den Value neu. Sollte nur durch den ConfParam-Service aufgerufen werden, da hier der bereits berechnete und einzig gültige Wert Verwendung findet.
     *
     * @param confkey
     * @param value
     */
    public void setNewValueForConfkey(String confkey, Object value) {
        Object oldValue = getPropertyRaw(confkey);
        if (oldValue == KEY_NOT_FOUND) {
            logger.error("Der confkey " + confkey + " ist im Cache in der Globalen Konfiguration nicht bekannt.");
        } else {
            cache.put(prepareConfkey(confkey), value == null ? KEY_IS_NULL : value);
        }
    }


    /*
     * ======================================= Static ================================================
     */




    /**
     * @return ConfCache from current ApplicationContext
     */
    public static Conf getConfCache() {

        // if spring is available, use the cache from spring, which may vary based on the active context
        Conf temp = null;
        if (ConfigUtil.HISINONE_MODULE_ACTIVE && SpringApplicationContext.isApplicationContextAvailable()) {
            temp = (Conf) SpringApplicationContext.getBean("confCache");
        }

        // if spring is not available, use a singleton mock
        if (temp == null) {
            if (instance == null) {
                temp = new Conf();
                temp.registerConfProvider(new DummyConfProvider());
                instance = temp;
            } else {
                temp = instance;
            }
        }
        return temp;
    }

    /**
     * Prüft ob der Rückgabewert eine Liste ist
     *
     * @param confkey
     * @return boolean
     */
    public static boolean isConfparamInList(String confkey) {
        Object value = getConfCache().getPropertyRaw(confkey);
        return value != null && value instanceof List;
    }


    /**
     * Fallback für alle Listen für die es keine spezielle Implementierung gibt.
     * Wird eine typsichere Implementierung benötigt, dann bitte per HISZilla an Team SYS.
     *
     * @param confkey
     * @return List<String>
     */
    public static List<String> getList(String confkey) {
        try {
            @SuppressWarnings("unchecked")
            List<String> value = (List<String>) getConfCache().getPropertyFiltered(confkey, List.class);
            return value;
        } catch (Exception e) {
            logger.error("Die Confvalues des confkey " + confkey + " konnten nicht in eine List<String> umgewandelt werden!");
        }
        return null;
    }

    /**
     * Liefert eine String-Liste ohne Leer-Einträge zurück
     * @param confkey
     * @return List<String>
     */
    public static List<String> getListWithoutEmptyEntries(String confkey) {
        List<String> list = getList(confkey);
        if (list == null || list.isEmpty()) {
            return list;
        }
        List<String> list_ = new ArrayList<String>();
        list_.addAll(list);
        list_.removeAll(Collections.singleton(null));
        list_.removeAll(Collections.singleton(""));
        return list_;
    }


    /**
     * Nur für den Einsatz im Editor der Globalen Konfiguration bestimmt.
     *
     * @param confkey
     * @return List<String>
     */
    public static Object getListForGlobaleKonfigurationAndDebugOnly(String confkey) {
        Object value = getConfCache().getPropertyRaw(confkey);
        if(value == KEY_NOT_FOUND) {
            value = null;
        };
        return value;
    }


    //**************************************************************************************************************************************************
    //                      BigDecimal

    /**
     * @param confkey
     * @return BigDecimal
     */
    public static BigDecimal getBigDecimal(String confkey) {
        return (BigDecimal) getConfCache().getPropertyFiltered(confkey, BigDecimal.class);
    }

    /**
     * @param confkey
     * @param defaultValue
     * @return BigDecimal
     */
    public static BigDecimal getBigDecimal(String confkey, BigDecimal defaultValue) {
        BigDecimal bigDecimal = getBigDecimal(confkey);
        if (bigDecimal == null) {
            logger.debug("Return defaultValue (" + defaultValue + ") because Global Configurations returned NULL for confkey " + confkey);
            return defaultValue;
        }
        return bigDecimal;
    }


    //**************************************************************************************************************************************************
    //                      Boolean

    /**
     * @param confkey
     * @return Boolean
     */
    public static Boolean getBoolean(String confkey) {
        return (Boolean) getConfCache().getPropertyFiltered(confkey, Boolean.class);
    }

    /**
     * @param confkey
     * @return Boolean
     */
    public static Boolean getBoolean(Key confkey) {
        return getBoolean(confkey.getKey());
    }

    /**
     * @param confkey
     * @param defaultValue
     * @return value as Boolean
     */
    public static Boolean getBoolean(String confkey, Boolean defaultValue) {
        Boolean boolean1 = getBoolean(confkey);
        if (boolean1 == null) {
            logger.debug("Return defaultValue (" + defaultValue + ") because Global Configurations returned NULL for confkey " + confkey);
            return defaultValue;
        }
        return boolean1;
    }

    /**
     * @param confkey
     * @param defaultValue
     * @return value as Boolean
     */
    public static Boolean getBoolean(Key confkey, Boolean defaultValue) {
        return getBoolean(confkey.getKey(), defaultValue);
    }

    /**
     * @param confkey
     * @param defaultValue
     * @return value as Boolean
     */
    public static boolean getBoolean(String confkey, boolean defaultValue) {
        return getBoolean(confkey, Boolean.valueOf(defaultValue)).booleanValue();
    }

    /**
     * @param confkey
     * @param defaultValue
     * @return value as Boolean
     */
    public static boolean getBoolean(Key confkey, boolean defaultValue) {
        return getBoolean(confkey.getKey(), Boolean.valueOf(defaultValue)).booleanValue();
    }

    //**************************************************************************************************************************************************
    //              Color

    /**
     * @param confkey
     * @return color like #12345
     */
    public static String getColor(String confkey) {
        return (String) getConfCache().getPropertyFiltered(confkey, String.class);
    }

    /**
     * @param confkey
     * @param defaultValue
     * @return color like #12345
     */
    public static String getColor(String confkey, String defaultValue) {
        String color = getColor(confkey);
        if (color == null) {
            logger.debug("Return defaultValue (" + defaultValue + "), because Global Configuration returned NULL for confkey " + confkey);
            return defaultValue;
        }
        return color;
    }

    //**************************************************************************************************************************************************
    //          Date

    /**
     * @param confkey
     * @return Date
     */
    public static Date getDate(String confkey) {
        return (Date) getConfCache().getPropertyFiltered(confkey, Date.class);
    }

    /**
     * @param confkey
     * @param defaultValue
     * @return Date
     */
    public static Date getDate(String confkey, Date defaultValue) {
        Date date = getDate(confkey);
        if (date == null) {
            logger.debug("Return defaultValue (" + defaultValue + "), because Global Configuration returned NULL for confkey " + confkey);
            return defaultValue;
        }
        return date;
    }

    //**************************************************************************************************************************************************
    //          Integer

    /**
     * @param confkey
     * @return Integer
     */
    public static Integer getInteger(Key confkey) {
        return getInteger(confkey.getKey());
    }

    /**
     * @param confkey
     * @return Integer
     */
    public static Integer getInteger(String confkey) {
        return (Integer) getConfCache().getPropertyFiltered(confkey, Integer.class);
    }

    /**
     * @param confkey
     * @param defaultValue
     * @return value as Integer
     */
    public static Integer getInteger(Key confkey, int defaultValue) {
        return getInteger(confkey.getKey(), Integer.valueOf(defaultValue));
    }

    /**
     * @param confkey
     * @param defaultValue
     * @return value as Integer
     */
    public static Integer getInteger(String confkey, Integer defaultValue) {
        Integer integer = getInteger(confkey);
        if (integer == null) {
            logger.debug("Return defaultValue (" + defaultValue + "), because Global Configuration returned NULL for confkey " + confkey);
            return defaultValue;
        }
        return integer;
    }


    /**
     * @param confkey
     * @return List<String>
     */
    public static List<Integer> getIntegerList(String confkey) {
        try {
            @SuppressWarnings("unchecked")
            List<Integer> value = (List<Integer>) getConfCache().getPropertyFiltered(confkey, List.class);
            return value;
        } catch (Exception e) {
            logger.error("Die Confvalues des confkey " + confkey + " konnten nicht in eine List<Integer> umgewandelt werden!");
        }
        return null;
    }

    //**************************************************************************************************************************************************
    //              Long

    /**
     * @param confkey
     * @return Long
     */
    public static Long getLong(String confkey) {
        try {
            Object value = getConfCache().getPropertyFiltered(confkey, null);

            if(value instanceof String) {
                return Long.valueOf((String) value);
            }

            if (value != null) {
                return Long.valueOf(((Number) value).longValue()); // so können auch Integers als Long abgefragt werden.
            }
        } catch (Exception e) {
            logger.error("Die Confvalues des confkey " + confkey + " konnten nicht in einen Long umgewandelt werden!");
        }
        return null;
    }

    /**
     * @param confkey
     * @return Long
     */
    public static Long getLong(Key confkey) {
        return getLong(confkey.getKey());
    }
    /**
     * @param confkey
     * @param defaultValue
     * @return value as Long
     */
    public static Long getLong(String confkey, Long defaultValue) {
        Long long1 = getLong(confkey);
        if (long1 == null) {
            logger.debug("Return defaultValue (" + defaultValue + "), because Global Configuration returned NULL for confkey " + confkey);
            return defaultValue;
        }
        return long1;
    }

    /**
     * @param confkey
     * @param defaultValue
     * @return value as Long
     */
    public static Long getLong(Key confkey, Long defaultValue) {
        return getLong(confkey.getKey(), defaultValue);
    }

    //**************************************************************************************************************************************************
    //              Orgunit

    /**
     * Gibt die LID einer Orgunit zurück
     *
     * @param confkey
     * @return Long
     */
    public static Long getOrgunitLidRequired(Key confkey) {
        Long orgunitLid = getOrgunitLid(confkey.getKey());
        EnsureState.notNull(orgunitLid, "The confkey '" + confkey.getKey() + "' must be configured!");
        return orgunitLid;
    }

    /**
     * Gibt die LID einer Orgunit zurück
     *
     * @param confkey
     * @return Long
     */
    public static Long getOrgunitLid(Key confkey) {
        return getOrgunitLid(confkey.getKey());
    }

    /**
     * Gibt die LID einer Orgunit zurück
     *
     * @param confkey
     * @return Long
     */
    public static Long getOrgunitLid(String confkey) {
        return (Long) getConfCache().getPropertyFiltered(confkey, Long.class);
    }

    /**
     * Gibt die LID einer Orgunit zurück
     *
     * @param confkey
     * @param defaultValue
     * @return Long
     */
    public static Long getOrgunitLid(Key confkey, Long defaultValue) {
        return getOrgunitLid(confkey.getKey(), defaultValue);
    }

    /**
     * Gibt die LID einer Orgunit zurück
     *
     * @param confkey
     * @param defaultValue
     * @return Long
     */
    public static Long getOrgunitLid(String confkey, Long defaultValue) {
        Long lid = getOrgunitLid(confkey);
        if (lid == null) {
            logger.debug("Return defaultValue (" + defaultValue + "), because Global Configuration returned NULL for confkey " + confkey);
            return defaultValue;
        }
        return lid;
    }

    //**************************************************************************************************************************************************
    //          Password

    /**
     * @param confkey
     * @return String
     */
    public static String getPassword(String confkey) {
        return (String) getConfCache().getPropertyFiltered(confkey, String.class);
    }

    //**************************************************************************************************************************************************
    //          Object

    /**
     * @param confkey
     * @return Object
     */
    public static Object getObject(String confkey) {
        return getConfCache().getPropertyFiltered(confkey, null);
    }

    /**
     * @param confkey
     * @param defaultValue
     * @return Object
     */
    public static Object getObject(String confkey, Object defaultValue) {
        Object value = getObject(confkey);
        if (value == null) {
            logger.debug("Return defaultValue (" + defaultValue + "), because Global Configuration returned NULL for confkey " + confkey);
            return defaultValue;
        }
        return value;
    }


    //**************************************************************************************************************************************************
    //          String

    /**
     * @param confkey
     * @return String
     */
    public static String getString(Key confkey) {
        return getString(confkey.getKey());
    }

    /**
     * @param confkey
     * @return String
     */
    public static String getString(String confkey) {
        Object value = getConfCache().getPropertyFiltered(confkey, null);
        if (value != null) {
            return String.valueOf(value); // in String wandeln
        }
        return null;
    }

    /**
     * @param confkey
     * @param defaultValue
     * @return value as String
     */
    public static String getString(Key confkey, String defaultValue) {
        return getString(confkey.getKey(), defaultValue);
    }

    /**
     * @param confkey
     * @param defaultValue
     * @return value as String
     */
    public static String getString(String confkey, String defaultValue) {
        String string = getString(confkey);
        if (string == null) {
            logger.debug("Return defaultValue (" + defaultValue + "), because Global Configuration returned NULL for confkey " + confkey);
            return defaultValue;
        }
        return string;
    }

    //**************************************************************************************************************************************************
    //              Term

    /**
     * @param confkey
     * @return String  bspw. 2008#2#1 (Year#termCategory#termNumber)
     */
    public static String getTerm(String confkey) {
        return (String) getConfCache().getPropertyFiltered(confkey, String.class);
    }

    /**
     * Gibt ein Object vom Typ Term zurück.
     * Bspw.: Ein Semester / Trimester
     *
     * @param confkey
     * @param defaultValue bspw. 2008#2#1 (Year#termCategory#termNumber)
     * @return term  bspw. 2008#2#1 (Year#termCategory#termNumber)
     */
    public static String getTerm(String confkey, String defaultValue) {
        String term = getTerm(confkey);
        if (term == null) {
            logger.debug("Return defaultValue (" + defaultValue + "), because Global Configuration returned NULL for confkey " + confkey);
            return defaultValue;
        }
        return term;
    }

    //**************************************************************************************************************************************************
    //              Time

    /**
     * @param confkey
     * @return String
     */
    public static Date getTime(String confkey) {
        return (Date) getConfCache().getPropertyFiltered(confkey, Date.class);
    }

    /**
     * @param confkey
     * @param defaultValue
     * @return value as Date
     */
    public static Date getTime(String confkey, Date defaultValue) {
        Date time = getTime(confkey);
        if (time == null) {
            logger.debug("Return defaultValue (" + defaultValue + "), because Global Configuration returned NULL for confkey " + confkey);
            return defaultValue;
        }
        return time;
    }

    //**************************************************************************************************************************************************
    //              Validation

    //    /**
    //    /**
    //     * @param confkey
    //     * @return String
    //     */
    //    public static String getAsValidation(String confkey) {
    //        return (String) getPropertyInternal(confkey, String.class);
    //    }
    //
    //    /**
    //     * @param confkey
    //     * @param defaultValue
    //     * @return value as String
    //     */
    //    public static String getAsValidation(String confkey, String defaultValue) {
    //        String validation = getAsValidation(confkey);
    //        if (validation == null) {
    //            logger.debug("Return defaultValue (" + defaultValue + "), because Global Configuration returned NULL for confkey " + confkey);
    //            return defaultValue;
    //        }
    //        return validation;
    //    }


    /**
     * Muss Implementiert werden ...
     */
    public interface Key extends KeyEnum<String> {
        //Leer
    }




    // Alle Konstanten und Klassen werden automatisch erzeugt; bitte nicht manuell editieren!
    // siehe: GlobalConfigurationEditorServiceImpl.java

    /* AUTOCONF_BEGIN */
            /**
             * Segment: CM.
             *
             * <br />
             * Company: HIS
             */
            public static class CM {
                /**
                 * Produktbereich: ALU.
                 */
                public static enum ALU implements KeyEnum<String>, Key {
                    /**
                     * <p><strong>Zugewiesene Verwaltungseinheit.</strong></p>
                     * Confkey: cm.alu.ca.employer.application.assigned_orgunit<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: Dieser Verwaltungseinheit werden neue Stellenanbieterprofil-Antr&auml;ge zugewiesen.
                     */
                    CA_EMPLOYER_APPLICATION_ASSIGNED_ORGUNIT("cm.alu.ca.employer.application.assigned_orgunit"),
                    /**
                     * <p><strong>Rolle bei Annahme.</strong></p>
                     * Confkey: cm.alu.ca.employer.application.role_to_assign<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: Diese Rolle wird dem Antragsteller bei der Annahme des Stellenanbieterprofil-Antrags zugewiesen.
                     */
                    CA_EMPLOYER_APPLICATION_ROLE_TO_ASSIGN("cm.alu.ca.employer.application.role_to_assign"),
                    /**
                     * <p><strong>Dateierweiterungen.</strong></p>
                     * Confkey: cm.alu.ca.employer.companylogo.fileextensions<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Definiert die Dateierweiterungen, die f&uuml;r Firmenlogos verwendet werden k&ouml;nnen. Mehrere Dateierweiterungen k&ouml;nnen kommasepariert angegeben werden. Beispiel: &quot;jpg, gif, png&quot;. Sind keine Dateierweiterungen angebeben, werden standardm&auml;&szlig;ig folgende Erweiterungen angenommen: jpg, jpeg, png, gif
                     */
                    CA_EMPLOYER_COMPANYLOGO_FILEEXTENSIONS("cm.alu.ca.employer.companylogo.fileextensions"),
                    /**
                     * <p><strong>Maximale H&ouml;he.</strong></p>
                     * Confkey: cm.alu.ca.employer.companylogo.maxheight<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Definiert die maximale H&ouml;he eines Firmenlogos in Pixeln, in der dieses gespeichert wird. Achtung: Diese Einstellung ist unabh&auml;ngig von der eigentlichen Anzeigegr&ouml;&szlig;e.
                     */
                    CA_EMPLOYER_COMPANYLOGO_MAXHEIGHT("cm.alu.ca.employer.companylogo.maxheight"),
                    /**
                     * <p><strong>Maximale Breite.</strong></p>
                     * Confkey: cm.alu.ca.employer.companylogo.maxwidth<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Definiert die maximale Breite eines Firmenlogos in Pixeln, in der dieses gespeichert wird. Achtung: Diese Einstellung ist unabh&auml;ngig von der eigentlichen Anzeigegr&ouml;&szlig;e.
                     */
                    CA_EMPLOYER_COMPANYLOGO_MAXWIDTH("cm.alu.ca.employer.companylogo.maxwidth"),
                    /**
                     * <p><strong>Content Type.</strong></p>
                     * Confkey: cm.alu.ca.employer.companylogo.mimetypes<br/>
                     * ParameterType: MANYSELECT_SRC<br/>
                     * <br/>
                     * Info: Definiert die g&uuml;ltigen Content Typen f&uuml;r Firmenlogos. Sind keine Content Typen ausgew&auml;hlt, werden standardm&auml;&szlig;ig folgende Content Typen verwendet: image/gif, image/png, image/jpeg
                     */
                    CA_EMPLOYER_COMPANYLOGO_MIMETYPES("cm.alu.ca.employer.companylogo.mimetypes"),
                    /**
                     * <p><strong>Maximale Anzahl Kontaktdaten.</strong></p>
                     * Confkey: cm.alu.ca.employer.max_contact_data<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Definiert die maximale Anzahl von Kontaktdaten, die zu einem Stellenanbieter angegeben werden k&ouml;nnen.
                     */
                    CA_EMPLOYER_MAX_CONTACT_DATA("cm.alu.ca.employer.max_contact_data"),
                    /**
                     * <p><strong>Maximale Anzahl Kontaktpersonen.</strong></p>
                     * Confkey: cm.alu.ca.employer.max_contact_persons<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Definiert die maximale Anzahl von Kontaktpersonen, die zu einem Stellenanbieter angegeben werden k&ouml;nnen.
                     */
                    CA_EMPLOYER_MAX_CONTACT_PERSONS("cm.alu.ca.employer.max_contact_persons"),
                    /**
                     * <p><strong>Standardg&uuml;ltigkeitsdauer.</strong></p>
                     * Confkey: cm.alu.ca.joboffer.defaultvalidityperiod<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Definiert die Standardg&uuml;ltigkeitsdauer f&uuml;r neue Stellenangebote in Tagen. Neue Stellenangebote sind standardm&auml;&szlig;ig immer in der Zeit vom aktuellen Datum + dem hier eingestellten Wert g&uuml;ltig. Ist kein Wert definiert, wird das Maximum f&uuml;r das Ende des G&uuml;ltigkeitszeitraumes angenommen.
                     */
                    CA_JOBOFFER_DEFAULTVALIDITYPERIOD("cm.alu.ca.joboffer.defaultvalidityperiod"),
                    /**
                     * <p><strong>Maximale Anzahl Arbeitsorte.</strong></p>
                     * Confkey: cm.alu.ca.joboffer.max_places_of_work<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Definiert die maximale Anzahl von Arbeitsorten, die zu einem Stellenangebot angegeben werden k&ouml;nnen.
                     */
                    CA_JOBOFFER_MAX_PLACES_OF_WORK("cm.alu.ca.joboffer.max_places_of_work"),
                    /**
                     * <p><strong>Maximale G&uuml;ltigkeitsdauer.</strong></p>
                     * Confkey: cm.alu.ca.joboffer.maxvalidityperiod<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Dieser Schl&uuml;ssel gibt an, wie viele Tage ein Stellenangebot maximal g&uuml;ltig sein darf bezogen auf den Start des G&uuml;ltigkeitszeitraumes. Wird kein Wert angegeben, so ist die maximale G&uuml;ltigkeit nicht beschr&auml;nkt.
                     */
                    CA_JOBOFFER_MAXVALIDITYPERIOD("cm.alu.ca.joboffer.maxvalidityperiod"),
                    /**
                     * <p><strong>Ansprechpartner.</strong></p>
                     * Confkey: cm.alu.ca.system.contact.person<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Definiert den bzw. die Ansprechpartner im Career Service.
                     */
                    CA_SYSTEM_CONTACT_PERSON("cm.alu.ca.system.contact.person"),
                    /**
                     * <p><strong>Hochschulpartner-Organisationseinheit.</strong></p>
                     * Confkey: cm.alu.partner.candidatemanagement.partner_orgunit<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: Definiert die Organisationseinheit, die Hochschulpartnern zugewiesen wird, nachdem sie als Bewerber akzeptiert wurden.
                     */
                    PARTNER_CANDIDATEMANAGEMENT_PARTNER_ORGUNIT("cm.alu.partner.candidatemanagement.partner_orgunit"),
                    /**
                     * <p><strong>Hochschulpartner-Rolle.</strong></p>
                     * Confkey: cm.alu.partner.candidatemanagement.partner_role<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: Definiert die Rolle, die Hochschulpartnern zugewiesen wird, nachdem sie als Bewerber akzeptiert wurden.
                     */
                    PARTNER_CANDIDATEMANAGEMENT_PARTNER_ROLE("cm.alu.partner.candidatemanagement.partner_role"),
                    /**
                     * <p><strong>G&uuml;ltigkeit der Aktivierungs-E-Mail in Tagen.</strong></p>
                     * Confkey: cm.alu.partner.registration.activation.opt_in_timeout<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Definiert wie lange der in der Aktivierungs-E-Mail enthaltene Freischaltcode g&uuml;ltig ist.
                     */
                    PARTNER_REGISTRATION_ACTIVATION_OPT_IN_TIMEOUT("cm.alu.partner.registration.activation.opt_in_timeout"),
                    /**
                     * <p><strong>Bewerber-Organisationseinheit.</strong></p>
                     * Confkey: cm.alu.partner.registration.general.candidate_orgunit<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: Definiert die Organisationseinheit, die neuen Hochschulpartner-Bewerbern zugewiesen wird.
                     */
                    PARTNER_REGISTRATION_GENERAL_CANDIDATE_ORGUNIT("cm.alu.partner.registration.general.candidate_orgunit"),
                    /**
                     * <p><strong>Bewerber-Rolle.</strong></p>
                     * Confkey: cm.alu.partner.registration.general.candidate_role<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: Definiert die Rolle, die Hochschulpartner-Bewerbern zugewiesen wird.
                     */
                    PARTNER_REGISTRATION_GENERAL_CANDIDATE_ROLE("cm.alu.partner.registration.general.candidate_role"),
                    /**
                     * <p><strong>Ansprechpartner.</strong></p>
                     * Confkey: cm.alu.partner.system.contact.person<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Definiert den bzw. die Ansprechpartner f&uuml;r allgemeine Hochschulpartner.
                     */
                    PARTNER_SYSTEM_CONTACT_PERSON("cm.alu.partner.system.contact.person"),
                    /**
                     * <p><strong>Datumsformat f&uuml;r Studieng&auml;nge.</strong></p>
                     * Confkey: cm.alu.profile.educationdata.course_of_study_date_format<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Diese Einstellung legt fest, welches Datumsformat f&uuml;r Start- und Endedaten eines Studiengangs verwendet werden sollen. Es besteht die M&ouml;glichkeit zwischen 4 Varianten zu w&auml;hlen: Variante 1 beschreibt die Standardeingabe &uuml;ber ein Eingabeelement mit einem Datumsw&auml;hler. Variante 2 beschreibt die Eingabe mittels 3 Eingabeelementen f&uuml;r Tag, Monat und Jahr. Variante 3 beschreibt die Eingabe mittels 2 Eingabeelementen f&uuml;r Monat und Jahr. Variante 4 beschreibt die Eingabe mittels 1 Eingabeelement f&uuml;r das Jahr.
                     */
                    PROFILE_EDUCATIONDATA_COURSE_OF_STUDY_DATE_FORMAT("cm.alu.profile.educationdata.course_of_study_date_format"),
                    /**
                     * <p><strong>Maximale Studieng&auml;nge.</strong></p>
                     * Confkey: cm.alu.profile.educationdata.max_alumni_courses_of_study<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Maximale Anzahl von Fachrichtungen
                     */
                    PROFILE_EDUCATIONDATA_MAX_ALUMNI_COURSES_OF_STUDY("cm.alu.profile.educationdata.max_alumni_courses_of_study"),
                    /**
                     * <p><strong>Maximale F&auml;cher.</strong></p>
                     * Confkey: cm.alu.profile.educationdata.max_alumni_subjects<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Maximale Anzahl von F&auml;chern
                     */
                    PROFILE_EDUCATIONDATA_MAX_ALUMNI_SUBJECTS("cm.alu.profile.educationdata.max_alumni_subjects"),
                    /**
                     * <p><strong>Maximale E-Adressen.</strong></p>
                     * Confkey: cm.alu.profile.personaldata.max_electronic_addresses<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Maximale Anzahl von elektronischen Adressen
                     */
                    PROFILE_PERSONALDATA_MAX_ELECTRONIC_ADDRESSES("cm.alu.profile.personaldata.max_electronic_addresses"),
                    /**
                     * <p><strong>Maximale Postadressen.</strong></p>
                     * Confkey: cm.alu.profile.personaldata.max_post_addresses<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Maximale Anzahl von postalischen Adressen
                     */
                    PROFILE_PERSONALDATA_MAX_POST_ADDRESSES("cm.alu.profile.personaldata.max_post_addresses"),
                    /**
                     * <p><strong>Mindestalter.</strong></p>
                     * Confkey: cm.alu.profile.personaldata.minimum_age<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Mindestalter der Person (gemessen am angegebenen Geburtsdatum), das im Alumni-Profil angegeben werden muss.
                     */
                    PROFILE_PERSONALDATA_MINIMUM_AGE("cm.alu.profile.personaldata.minimum_age"),
                    /**
                     * <p><strong>Datumsformat f&uuml;r ehemalige Anstellungen.</strong></p>
                     * Confkey: cm.alu.profile.workexperiencedata.employee_function_date_format<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Diese Einstellung legt fest, welches Datumsformat f&uuml;r Start- und Endedaten einer ehemaligen Anstellung verwendet werden sollen. Es besteht die M&ouml;glichkeit zwischen 4 Varianten zu w&auml;hlen: Variante 1 beschreibt die Standardeingabe &uuml;ber ein Eingabeelement mit einem Datumsw&auml;hler. Variante 2 beschreibt die Eingabe mittels 3 Eingabeelementen f&uuml;r Tag, Monat und Jahr. Variante 3 beschreibt die Eingabe mittels 2 Eingabeelementen f&uuml;r Monat und Jahr. Variante 4 beschreibt die Eingabe mittels 1 Eingabeelement f&uuml;r das Jahr.
                     */
                    PROFILE_WORKEXPERIENCEDATA_EMPLOYEE_FUNCTION_DATE_FORMAT("cm.alu.profile.workexperiencedata.employee_function_date_format"),
                    /**
                     * <p><strong>Maximale Mitarbeiterfunktionen.</strong></p>
                     * Confkey: cm.alu.profile.workexperiencedata.max_employee_functions<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Maximale Anzahl von Mitarbeiterfunktionen
                     */
                    PROFILE_WORKEXPERIENCEDATA_MAX_EMPLOYEE_FUNCTIONS("cm.alu.profile.workexperiencedata.max_employee_functions"),
                    /**
                     * <p><strong>Limitierung f&uuml;r die Mehrfachverarbeitung von Datens&auml;tzen.</strong></p>
                     * Confkey: cm.alu.system.batch_processing.batch_size_limit<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Dieser Wert legt die maximale Anzahl der Datens&auml;tzen fest, welche von der Mehrfachverarbeitung verarbeitet werden k&ouml;nnen.
                     */
                    SYSTEM_BATCH_PROCESSING_BATCH_SIZE_LIMIT("cm.alu.system.batch_processing.batch_size_limit"),
                    /**
                     * <p><strong>Ansprechpartner / Verwaltungsstelle.</strong></p>
                     * Confkey: cm.alu.system.contact.person<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Ansprechpartner / Verwaltungsstelle
                     */
                    SYSTEM_CONTACT_PERSON("cm.alu.system.contact.person"),
                    /**
                     * <p><strong>Absenderadresse.</strong></p>
                     * Confkey: cm.alu.system.mail.mailfrom<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Die Absenderadresse von der aus automatisch generierte Mails des Alumni-Managements gesendet werden. Wird keine Adresse angegeben, wird der Wert den DispatcherProperties bezogen.
                     */
                    SYSTEM_MAIL_MAILFROM("cm.alu.system.mail.mailfrom"),
                    /**
                     * <p><strong>Server.</strong></p>
                     * Confkey: cm.alu.system.mail.smtp.host<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Adresse des Postausgangsservers. Wird keine Adresse angegeben, wird der Wert den DispatcherProperties bezogen.
                     */
                    SYSTEM_MAIL_SMTP_HOST("cm.alu.system.mail.smtp.host"),
                    /**
                     * <p><strong>Passwort.</strong></p>
                     * Confkey: cm.alu.system.mail.smtp.password<br/>
                     * ParameterType: PASSWORD_PLAINTEXT<br/>
                     * <br/>
                     * Info: Passwort das f&uuml;r die Authentifikation am Postausgangsserver verwendet werden soll.
                     */
                    SYSTEM_MAIL_SMTP_PASSWORD("cm.alu.system.mail.smtp.password"),
                    /**
                     * <p><strong>Port.</strong></p>
                     * Confkey: cm.alu.system.mail.smtp.port<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Port des Postausgangsservers. Der Port ist im Normalfall 25 (bzw. 465 bei einer SSL-Verbindung), inzwischen wird aber auch h&auml;ufig der Port 587 verwendet. Wird kein Port angegeben, wird der Wert 25 angenommen.
                     */
                    SYSTEM_MAIL_SMTP_PORT("cm.alu.system.mail.smtp.port"),
                    /**
                     * <p><strong>Erweiterte Einstellungen.</strong></p>
                     * Confkey: cm.alu.system.mail.smtp.properties<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Erweiterte SMTP-Einstellungen. Diese Einstellungen dienen der Definition zus&auml;tzlicher SMTP-Einstellungen wie &quot;mail.smtp.starttls.enable=true&quot; und &quot;mail.smtp.auth=true&quot; zur Aktivierung von TLS
                     */
                    SYSTEM_MAIL_SMTP_PROPERTIES("cm.alu.system.mail.smtp.properties"),
                    /**
                     * <p><strong>Benutzername.</strong></p>
                     * Confkey: cm.alu.system.mail.smtp.username<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Benutzername der f&uuml;r die Authentifikation am Postausgangsserver verwendet werden soll.
                     */
                    SYSTEM_MAIL_SMTP_USERNAME("cm.alu.system.mail.smtp.username"),
                    /**
                     * <p><strong>Benachrichtigung beim Akzeptieren eines Alumni-Bewerbers aktiviert.</strong></p>
                     * Confkey: cm.alu.system.notification.send_candidate_accepted_notification_enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Legt fest, ob ein Alumni-Bewerber benachrichtigt wird, sobald seine Bewerbung f&uuml;r das Alumni-Netzwerk akzeptiert wurde.
                     */
                    SYSTEM_NOTIFICATION_SEND_CANDIDATE_ACCEPTED_NOTIFICATION_ENABLED("cm.alu.system.notification.send_candidate_accepted_notification_enabled"),
                    /**
                     * <p><strong>Zus&auml;tzliche Personendaten.</strong></p>
                     * Confkey: cm.alu.usermanagement.acquisition.alumni.available_additional_person_data<br/>
                     * ParameterType: MANYSELECT<br/>
                     * <br/>
                     * Info: Selektion zus&auml;tzlicher Personendaten, die bei der &Uuml;bernahme exmatrikulierter Studierender &uuml;bernommen werden k&ouml;nnen. Der Vor- und Nachname, sowie das Geschlecht werden in jedem Fall &uuml;bernommen.
                     */
                    USERMANAGEMENT_ACQUISITION_ALUMNI_AVAILABLE_ADDITIONAL_PERSON_DATA("cm.alu.usermanagement.acquisition.alumni.available_additional_person_data"),
                    /**
                     * <p><strong>Minimales Exmatrikulationsdatum.</strong></p>
                     * Confkey: cm.alu.usermanagement.acquisition.alumni.disenrollment_minimum_date<br/>
                     * ParameterType: DATE<br/>
                     * <br/>
                     * Info: Es werden bei der &Uuml;bernahme keine Studenten &uuml;bernommen, deren Exmatrikulation vor dem angegebenen Datum stattfand. Wird ein solches Datum nicht ben&ouml;tigt, darf kein Wert angegeben werden.
                     */
                    USERMANAGEMENT_ACQUISITION_ALUMNI_DISENROLLMENT_MINIMUM_DATE("cm.alu.usermanagement.acquisition.alumni.disenrollment_minimum_date"),
                    /**
                     * <p><strong>G&uuml;ltigkeitsdauer.</strong></p>
                     * Confkey: cm.alu.usermanagement.agreement.management.activation.optin_timeout<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Anzahl der Tage, die ein Freischaltcode verwendet werden kann, um die Zustimmung zum Alumni-Verzeichnis zu geben.
                     */
                    USERMANAGEMENT_AGREEMENT_MANAGEMENT_ACTIVATION_OPTIN_TIMEOUT("cm.alu.usermanagement.agreement.management.activation.optin_timeout"),
                    /**
                     * <p><strong>Einwilligungsdokument aktivieren.</strong></p>
                     * Confkey: cm.alu.usermanagement.agreement.retrieval.agreement_document_enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Diese Einstellung legt fest, ob das Einwilligungsdokument zum Download zur Verf&uuml;gung gestellt wird.<br />&quot;JA&quot; bedeutet: das Einwilligungsdokument wird zum Download zur Verf&uuml;gung gestellt.<br />&quot;NEIN&quot;: das Einwilligungsdokument wird nicht zum Download zur Verf&uuml;gung gestellt.<br />Sollte dieser Parameter nicht gesetzt sein, wird standardm&auml;&szlig;ig das Einwilligungsdokument zum Download zur Verf&uuml;gung gestellt.
                     */
                    USERMANAGEMENT_AGREEMENT_RETRIEVAL_AGREEMENT_DOCUMENT_ENABLED("cm.alu.usermanagement.agreement.retrieval.agreement_document_enabled"),
                    /**
                     * <p><strong>Erstellen eines Zugangs.</strong></p>
                     * Confkey: cm.alu.usermanagement.agreement.retrieval.data.account.account_creation_option<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Soll die Erstellung eines Zugangs optional, obligatorisch oder deaktiviert sein?
                     */
                    USERMANAGEMENT_AGREEMENT_RETRIEVAL_DATA_ACCOUNT_ACCOUNT_CREATION_OPTION("cm.alu.usermanagement.agreement.retrieval.data.account.account_creation_option"),
                    /**
                     * <p><strong>Standardwert f&uuml;r die Erstellung eines Zugangs.</strong></p>
                     * Confkey: cm.alu.usermanagement.agreement.retrieval.data.account.create_account<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Ist diese Option aktiviert (TRUE), wird dem Alumni standardm&auml;&szlig;ig vorgeschlagen einen Zugang zu erstellen. Soll die Voreinstellung &quot;keinen Zugang erstellen&quot; sein, so muss diese Option deaktiviert (FALSE) werden.<br />Diese Option wird nur ausgewertet, wenn die Erstellung eines Zugangs optional ist.
                     */
                    USERMANAGEMENT_AGREEMENT_RETRIEVAL_DATA_ACCOUNT_CREATE_ACCOUNT("cm.alu.usermanagement.agreement.retrieval.data.account.create_account"),
                    /**
                     * <p><strong>Benutzerkennung generieren.</strong></p>
                     * Confkey: cm.alu.usermanagement.agreement.retrieval.data.account.generate_username<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll die Benutzerkennung generiert werden? Ist die Einstellung deaktiviert (FALSE) k&ouml;nnen Alumni die Benutzerkennung frei w&auml;hlen.
                     */
                    USERMANAGEMENT_AGREEMENT_RETRIEVAL_DATA_ACCOUNT_GENERATE_USERNAME("cm.alu.usermanagement.agreement.retrieval.data.account.generate_username"),
                    /**
                     * <p><strong>Private E-Mail-Adresse notwendig.</strong></p>
                     * Confkey: cm.alu.usermanagement.agreement.retrieval.data.personal_data.contact_data.private_email_address_required<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Muss mindestens eine private E-Mail-Adresse angegeben werden?
                     */
                    USERMANAGEMENT_AGREEMENT_RETRIEVAL_DATA_PERSONAL_DATA_CONTACT_DATA_PRIVATE_EMAIL_ADDRESS_REQUIRED("cm.alu.usermanagement.agreement.retrieval.data.personal_data.contact_data.private_email_address_required"),
                    /**
                     * <p><strong>Private Postadresse notwendig.</strong></p>
                     * Confkey: cm.alu.usermanagement.agreement.retrieval.data.personal_data.contact_data.private_postaddress_required<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Muss mindestens eine private Postadresse angegeben werden?
                     */
                    USERMANAGEMENT_AGREEMENT_RETRIEVAL_DATA_PERSONAL_DATA_CONTACT_DATA_PRIVATE_POSTADDRESS_REQUIRED("cm.alu.usermanagement.agreement.retrieval.data.personal_data.contact_data.private_postaddress_required"),
                    /**
                     * <p><strong>Aktiviert.</strong></p>
                     * Confkey: cm.alu.usermanagement.agreement.retrieval.data.reason_of_contact.enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Sollen die Gr&uuml;nde f&uuml;r den Beitritt in das Alumni-Netzwerk abfragen.
                     */
                    USERMANAGEMENT_AGREEMENT_RETRIEVAL_DATA_REASON_OF_CONTACT_ENABLED("cm.alu.usermanagement.agreement.retrieval.data.reason_of_contact.enabled"),
                    /**
                     * <p><strong>Verf&uuml;gbare Angebotskontexte.</strong></p>
                     * Confkey: cm.alu.usermanagement.agreement.retrieval.data.subscription.available_subscription_offer_contexts<br/>
                     * ParameterType: MANYSELECT_SRC<br/>
                     * <br/>
                     * Info: Die Auswahl bestimmt die Kontexte aus welchen Angebote w&auml;hrend des Datenabgleichs abonniert werden k&ouml;nnen.
                     */
                    USERMANAGEMENT_AGREEMENT_RETRIEVAL_DATA_SUBSCRIPTION_AVAILABLE_SUBSCRIPTION_OFFER_CONTEXTS("cm.alu.usermanagement.agreement.retrieval.data.subscription.available_subscription_offer_contexts"),
                    /**
                     * <p><strong>Aktiviert.</strong></p>
                     * Confkey: cm.alu.usermanagement.agreement.retrieval.data.subscription.enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll der Alumni seine Abonnements &auml;ndern k&ouml;nnen?
                     */
                    USERMANAGEMENT_AGREEMENT_RETRIEVAL_DATA_SUBSCRIPTION_ENABLED("cm.alu.usermanagement.agreement.retrieval.data.subscription.enabled"),
                    /**
                     * <p><strong>Aktivieren der automatischen Sperrung.</strong></p>
                     * Confkey: cm.alu.usermanagement.agreement.retrieval.locking.automatic_locking<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    USERMANAGEMENT_AGREEMENT_RETRIEVAL_LOCKING_AUTOMATIC_LOCKING("cm.alu.usermanagement.agreement.retrieval.locking.automatic_locking"),
                    /**
                     * <p><strong>Aktiviert.</strong></p>
                     * Confkey: cm.alu.usermanagement.agreement.retrieval.membership_termination.termination_enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll dem Alumni eine Hinweisbox angezeigt werden, die Ihn auf die M&ouml;glichkeit des Austritts hinweist?
                     */
                    USERMANAGEMENT_AGREEMENT_RETRIEVAL_MEMBERSHIP_TERMINATION_TERMINATION_ENABLED("cm.alu.usermanagement.agreement.retrieval.membership_termination.termination_enabled"),
                    /**
                     * <p><strong>Einwilligungsdokument erforderlich.</strong></p>
                     * Confkey: cm.alu.usermanagement.candidate.unlocking.agreement_document_required<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Definiert, ob das durch den Bewerber an die Hochschule &uuml;bermittelte Einwilligungsdokument zwingend als digitales Dokument beim Entsperren eines Bewerbers angegeben (hochgeladen) werden muss.
                     */
                    USERMANAGEMENT_CANDIDATE_UNLOCKING_AGREEMENT_DOCUMENT_REQUIRED("cm.alu.usermanagement.candidate.unlocking.agreement_document_required"),
                    /**
                     * <p><strong>Anzeige der urspr&uuml;nglichen Werte.</strong></p>
                     * Confkey: cm.alu.usermanagement.change_history.consider_old_values<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    USERMANAGEMENT_CHANGE_HISTORY_CONSIDER_OLD_VALUES("cm.alu.usermanagement.change_history.consider_old_values"),
                    /**
                     * <p><strong>Begrenzung der Eintr&auml;ge in Monaten.</strong></p>
                     * Confkey: cm.alu.usermanagement.change_history.maximum_size<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Maximalgr&ouml;&szlig;e der &Auml;nderungshistorie in Monaten. Wenn gesetzt, werden nur Eintr&auml;ge der &Auml;nderungshistorie angezeigt, die maximal die gesetzte Anzahl von Monaten in der Vergangenheit liegen.
                     */
                    USERMANAGEMENT_CHANGE_HISTORY_MAXIMUM_SIZE("cm.alu.usermanagement.change_history.maximum_size"),
                    /**
                     * <p><strong>Werteverlauf anzeigen.</strong></p>
                     * Confkey: cm.alu.usermanagement.change_history.show_values<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Definiert, ob urspr&uuml;ngliche und neue Werte in der &Auml;nderungshistorie angezeigt werden k&ouml;nnen. Falls &quot;Nein&quot; ausgew&auml;hlt wird, k&ouml;nnen keine ge&auml;nderten Werte angezeigt werden (z. B. welchen alten und/oder neuen Wert die neue Stra&szlig;e der Postanschrift besitzt). Es ist in diesem Falle lediglich m&ouml;glich, zu sehen, dass sich eine Eigenschaft ver&auml;ndert hat. Falls &quot;Ja&quot; ausgew&auml;hlt wird, werden ebenfalls die ge&auml;nderten Werte einer Eigenschaft angezeigt (z. B. der Wert der neuen Stra&szlig;e der Postanschrift ist &quot;Musterweg 18&quot;).<br />Hinweis: Diese Einstellung muss aktiv sein, damit urspr&uuml;nglichen Werte angezeigt werden k&ouml;nnen.
                     */
                    USERMANAGEMENT_CHANGE_HISTORY_SHOW_VALUES("cm.alu.usermanagement.change_history.show_values"),
                    /**
                     * <p><strong>Standard-Benutzerrolle.</strong></p>
                     * Confkey: cm.alu.usermanagement.default_user_role<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: Die durch diesen Schl&uuml;ssel festgelegte Rolle wird Alumni-Bewerbern beim Akzeptieren ihrer Bewerbung zugeteilt. Weiterhin wird diese Rolle importierten Alumni zugeteilt.<br />Ist mehr als eine Alumni-User-Rolle definiert, so ist die hier gew&auml;hlte Rolle au&szlig;erdem die Vorauswahl f&uuml;r den Assistenten zur &Uuml;bernahme exmatrikulierter Studierender.
                     */
                    USERMANAGEMENT_DEFAULT_USER_ROLE("cm.alu.usermanagement.default_user_role"),
                    /**
                     * <p><strong>Aktivierung der Listen von zuletzt angesehenen Mitgliedern und Bewerbern.</strong></p>
                     * Confkey: cm.alu.usermanagement.lru_list.enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    USERMANAGEMENT_LRU_LIST_ENABLED("cm.alu.usermanagement.lru_list.enabled"),
                    /**
                     * <p><strong>Auswahl der zu l&ouml;schenden Daten.</strong></p>
                     * Confkey: cm.alu.usermanagement.membership_termination.customizable<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Wenn aktiviert, k&ouml;nnen Alumni-Manager die Daten auszuw&auml;hlen, die bei der Beendigung der Mitgliedschaft im Alumni-Netzwerk gel&ouml;scht werden.
                     */
                    USERMANAGEMENT_MEMBERSHIP_TERMINATION_CUSTOMIZABLE("cm.alu.usermanagement.membership_termination.customizable"),
                    /**
                     * <p><strong>Angebotskontexte.</strong></p>
                     * Confkey: cm.alu.usermanagement.membership_termination.data.subscriptions.subscription_offer_contexts_to_remove<br/>
                     * ParameterType: MANYSELECT_SRC<br/>
                     * <br/>
                     * Info: Die Abonnements eines Miglieds von Angeboten mit den hier ausgew&auml;hlten Angebotskontexten werden beim Austritt gel&ouml;scht.
                     */
                    USERMANAGEMENT_MEMBERSHIP_TERMINATION_DATA_SUBSCRIPTIONS_SUBSCRIPTION_OFFER_CONTEXTS_TO_REMOVE("cm.alu.usermanagement.membership_termination.data.subscriptions.subscription_offer_contexts_to_remove"),
                    /**
                     * <p><strong>Alumni-Partner aktiviert.</strong></p>
                     * Confkey: cm.alu.usermanagement.partner.enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Zentrale Konfigurationseinstellung zur Aktivierung bzw. Deaktivierung von Prozessschritten und Handhabungen f&uuml;r Alumni-Partner in allen Prozessen sowie Ansichten des Alumni-Managements.<br />(Bitte beachten Sie bei der Deaktivierung von Alumni-Partnern, dass Daten von Hochschulpartnern, die bereits im System vorhanden sind, ggf. zuerst entfernt werden sollten. Dies ist mit dem Datenschutzbeauftragten der Hochschule abzustimmen.)
                     */
                    USERMANAGEMENT_PARTNER_ENABLED("cm.alu.usermanagement.partner.enabled"),
                    /**
                     * <p><strong>Benutzerkennung generieren.</strong></p>
                     * Confkey: cm.alu.usermanagement.partner.registration.account.generate_username<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll bei der Erstellung eines Accounts die Benutzerkennung generiert werden (true) oder nicht (false)?
                     */
                    USERMANAGEMENT_PARTNER_REGISTRATION_ACCOUNT_GENERATE_USERNAME("cm.alu.usermanagement.partner.registration.account.generate_username"),
                    /**
                     * <p><strong>Mit Account registrieren.</strong></p>
                     * Confkey: cm.alu.usermanagement.partner.registration.account.register_with_account_option<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: Einstellung f&uuml;r die Registrierungsm&ouml;glichkeit mit Account. Die Einstellung &quot;optional&quot; bedeutet, dass eine Registrierung mit Account m&ouml;glich ist, aber durch den Benutzer ausgelassen werden kann, &quot;obligatorisch&quot; bedeutet, dass die Registrierung mit Account immer durchgef&uuml;hrt werden muss. Die Einstellung &quot;nicht verf&uuml;gbar&quot; bedeutet, dass die Registrierung mit Account nicht zur Auswahl steht.
                     */
                    USERMANAGEMENT_PARTNER_REGISTRATION_ACCOUNT_REGISTER_WITH_ACCOUNT_OPTION("cm.alu.usermanagement.partner.registration.account.register_with_account_option"),
                    /**
                     * <p><strong>Registrierung mit Account.</strong></p>
                     * Confkey: cm.alu.usermanagement.partner.registration.account.register_with_account_selected<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Hier kann eingestellt werden, ob bei Optionaler Account-Erstellung, in der Voreinstellung ein Account erstellt wird (true) oder nicht (false).
                     */
                    USERMANAGEMENT_PARTNER_REGISTRATION_ACCOUNT_REGISTER_WITH_ACCOUNT_SELECTED("cm.alu.usermanagement.partner.registration.account.register_with_account_selected"),
                    /**
                     * <p><strong>Automatischer Opt-In.</strong></p>
                     * Confkey: cm.alu.usermanagement.partner.registration.activation.automatic_opt_in_enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll der Opt-In automatisch erfolgen (true) oder nicht (false)?
                     */
                    USERMANAGEMENT_PARTNER_REGISTRATION_ACTIVATION_AUTOMATIC_OPT_IN_ENABLED("cm.alu.usermanagement.partner.registration.activation.automatic_opt_in_enabled"),
                    /**
                     * <p><strong>Benachrichtigung bei automatischem Opt-In.</strong></p>
                     * Confkey: cm.alu.usermanagement.partner.registration.activation.automatic_opt_in_notification<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll eine Benachrichtigungs-E-Mail bei automatischem Opt-In versand werden (true) oder nicht (false)?
                     */
                    USERMANAGEMENT_PARTNER_REGISTRATION_ACTIVATION_AUTOMATIC_OPT_IN_NOTIFICATION("cm.alu.usermanagement.partner.registration.activation.automatic_opt_in_notification"),
                    /**
                     * <p><strong>Rolle bei automatischem Opt-In.</strong></p>
                     * Confkey: cm.alu.usermanagement.partner.registration.activation.default_candidate_role<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: Stellen Sie die Rolle ein, die bei automatischem Opt-In vergeben wird.
                     */
                    USERMANAGEMENT_PARTNER_REGISTRATION_ACTIVATION_DEFAULT_CANDIDATE_ROLE("cm.alu.usermanagement.partner.registration.activation.default_candidate_role"),
                    /**
                     * <p><strong>G&uuml;ltigkeit des Opt-Ins.</strong></p>
                     * Confkey: cm.alu.usermanagement.partner.registration.activation.opt_in_timeout<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Wie lange (in Tagen) soll eine Aktivierung nach Versand der Opt-In E-Mail m&ouml;glich sein?
                     */
                    USERMANAGEMENT_PARTNER_REGISTRATION_ACTIVATION_OPT_IN_TIMEOUT("cm.alu.usermanagement.partner.registration.activation.opt_in_timeout"),
                    /**
                     * <p><strong>Schriftliche Einwilligung anfordern.</strong></p>
                     * Confkey: cm.alu.usermanagement.partner.registration.agreement.agreement_document_enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll eine schriftliche Einwilligung angefordert werden (true) oder nicht (false)?
                     */
                    USERMANAGEMENT_PARTNER_REGISTRATION_AGREEMENT_AGREEMENT_DOCUMENT_ENABLED("cm.alu.usermanagement.partner.registration.agreement.agreement_document_enabled"),
                    /**
                     * <p><strong>Erforderliche Einwilligungen f&uuml;r Alumni-Partner.</strong></p>
                     * Confkey: cm.alu.usermanagement.partner.registration.agreement.required_agreements<br/>
                     * ParameterType: MANYSELECT_SRC<br/>
                     * <br/>
                     * Info: Liste von Einwilligungen, die in der Registrierung f&uuml;r Alumni-Partner als erforderlich markiert werden sollen.
                     */
                    USERMANAGEMENT_PARTNER_REGISTRATION_AGREEMENT_REQUIRED_AGREEMENTS("cm.alu.usermanagement.partner.registration.agreement.required_agreements"),
                    /**
                     * <p><strong>Gesch&auml;ftliche Kontaktdaten erfassen.</strong></p>
                     * Confkey: cm.alu.usermanagement.partner.registration.data.contact.business_contact_data_enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Sollen optional gesch&auml;ftliche Kontaktdaten erfasst werden (true) oder sollen diese nicht angegeben werden k&ouml;nnen (false)?
                     */
                    USERMANAGEMENT_PARTNER_REGISTRATION_DATA_CONTACT_BUSINESS_CONTACT_DATA_ENABLED("cm.alu.usermanagement.partner.registration.data.contact.business_contact_data_enabled"),
                    /**
                     * <p><strong>Messenger-Adressen verf&uuml;gbar.</strong></p>
                     * Confkey: cm.alu.usermanagement.partner.registration.data.contact.messenger_enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Sollen Messenger-Adressen (z.B. msn, icq, etc.) abgefragt werden (true) oder nicht (false)?
                     */
                    USERMANAGEMENT_PARTNER_REGISTRATION_DATA_CONTACT_MESSENGER_ENABLED("cm.alu.usermanagement.partner.registration.data.contact.messenger_enabled"),
                    /**
                     * <p><strong>Erfassen des beruflichen Werdegangs.</strong></p>
                     * Confkey: cm.alu.usermanagement.partner.registration.data.employment_history.enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll der Berufliche Werdegang bei der Registrierung erfasst werden (true) oder nicht (false).
                     */
                    USERMANAGEMENT_PARTNER_REGISTRATION_DATA_EMPLOYMENT_HISTORY_ENABLED("cm.alu.usermanagement.partner.registration.data.employment_history.enabled"),
                    /**
                     * <p><strong>Mindestalter.</strong></p>
                     * Confkey: cm.alu.usermanagement.partner.registration.data.personal_data.minimum_age<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Geben Sie das Mindestalter an, das f&uuml;r die Registrierung von Alumni-Partnern vorausgesetzt wird.
                     */
                    USERMANAGEMENT_PARTNER_REGISTRATION_DATA_PERSONAL_DATA_MINIMUM_AGE("cm.alu.usermanagement.partner.registration.data.personal_data.minimum_age"),
                    /**
                     * <p><strong>Kontaktgrund.</strong></p>
                     * Confkey: cm.alu.usermanagement.partner.registration.data.reason_of_contact.enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll der Kontaktgrund angegeben werden k&ouml;nnen (true) oder nicht (false)?
                     */
                    USERMANAGEMENT_PARTNER_REGISTRATION_DATA_REASON_OF_CONTACT_ENABLED("cm.alu.usermanagement.partner.registration.data.reason_of_contact.enabled"),
                    /**
                     * <p><strong>Interesse.</strong></p>
                     * Confkey: cm.alu.usermanagement.partner.registration.data.reason_of_interest.enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll abgefragt werden, wie der Benutzer auf das Alumni-Netzwerk aufmerksam wurde (true) oder nicht (false)?
                     */
                    USERMANAGEMENT_PARTNER_REGISTRATION_DATA_REASON_OF_INTEREST_ENABLED("cm.alu.usermanagement.partner.registration.data.reason_of_interest.enabled"),
                    /**
                     * <p><strong>Verf&uuml;gbare Angebotskontexte.</strong></p>
                     * Confkey: cm.alu.usermanagement.partner.registration.data.subscription.available_subscription_offer_contexts<br/>
                     * ParameterType: MANYSELECT_SRC<br/>
                     * <br/>
                     * Info: Die Auswahl bestimmt die Kontexte aus welchen Angebote w&auml;hrend der Registrierung abonniert werden k&ouml;nnen.
                     */
                    USERMANAGEMENT_PARTNER_REGISTRATION_DATA_SUBSCRIPTION_AVAILABLE_SUBSCRIPTION_OFFER_CONTEXTS("cm.alu.usermanagement.partner.registration.data.subscription.available_subscription_offer_contexts"),
                    /**
                     * <p><strong>Erfassen der Abonnements.</strong></p>
                     * Confkey: cm.alu.usermanagement.partner.registration.data.subscription.enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Sollen Abonnements erfasst werden (true) oder nicht (false)?
                     */
                    USERMANAGEMENT_PARTNER_REGISTRATION_DATA_SUBSCRIPTION_ENABLED("cm.alu.usermanagement.partner.registration.data.subscription.enabled"),
                    /**
                     * <p><strong>Zugewiesener Verwaltungsbereich.</strong></p>
                     * Confkey: cm.alu.usermanagement.partner.registration.default_orgunit<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: Geben Sie den zugewiesenen Verwaltungsbereich f&uuml;r neue Alumni-Partner an.
                     */
                    USERMANAGEMENT_PARTNER_REGISTRATION_DEFAULT_ORGUNIT("cm.alu.usermanagement.partner.registration.default_orgunit"),
                    /**
                     * <p><strong>Registrierung aktiviert.</strong></p>
                     * Confkey: cm.alu.usermanagement.partner.registration.enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Einstellung legt fest, ob sich Alumni-Partner registrieren k&ouml;nnen. &quot;JA&quot; bedeutet: die Registrierung als Hochschulpartner ist m&ouml;glich, &quot;NEIN&quot;, dass die Registrierung nicht m&ouml;glich ist. Sollte dieser Parameter nicht gesetzt sein, ist standardm&auml;&szlig;ig die Registrierung als Hochschulpartner m&ouml;glich.
                     */
                    USERMANAGEMENT_PARTNER_REGISTRATION_ENABLED("cm.alu.usermanagement.partner.registration.enabled"),
                    /**
                     * <p><strong>Aktivieren der automatischen Sperrung.</strong></p>
                     * Confkey: cm.alu.usermanagement.partner.registration.locking.automatic_locking<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    USERMANAGEMENT_PARTNER_REGISTRATION_LOCKING_AUTOMATIC_LOCKING("cm.alu.usermanagement.partner.registration.locking.automatic_locking"),
                    /**
                     * <p><strong>Aktivieren des automatischen Opt-Ins.</strong></p>
                     * Confkey: cm.alu.usermanagement.selfregistration.activation.automatic_optin<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Diese Einstellung definiert, ob bei der Registrierung f&uuml;r Ehemalige der Opt-In automatisch ausgef&uuml;hrt wird.
                     */
                    USERMANAGEMENT_SELFREGISTRATION_ACTIVATION_AUTOMATIC_OPTIN("cm.alu.usermanagement.selfregistration.activation.automatic_optin"),
                    /**
                     * <p><strong>Benachrichtigung bei automatischem Opt-In.</strong></p>
                     * Confkey: cm.alu.usermanagement.selfregistration.activation.automatic_optin_notification<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Diese Einstellung definiert, ob eine Benachrichtigung bei einem automatischem Opt-In gesendet werden soll.
                     */
                    USERMANAGEMENT_SELFREGISTRATION_ACTIVATION_AUTOMATIC_OPTIN_NOTIFICATION("cm.alu.usermanagement.selfregistration.activation.automatic_optin_notification"),
                    /**
                     * <p><strong>G&uuml;ltigkeit des Opt-Ins in Tagen.</strong></p>
                     * Confkey: cm.alu.usermanagement.selfregistration.activation.optin_timeout<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Maximale Zeit Tagen in der eine Aktivierung der Registrierung &uuml;ber den Opt-In-Link in der Registrierung-E-Mail g&uuml;ltig ist. Nach Ablauf der Zeit ist die Aktivierung nicht mehr m&ouml;glich. Die maximale Aktivierungszeit korrespondiert im Normalfall mit der Vorhaltezeit f&uuml;r nicht best&auml;tigte Registrierungen, die nach Ablauf der Zeit entfernt werden m&uuml;ssen.
                     */
                    USERMANAGEMENT_SELFREGISTRATION_ACTIVATION_OPTIN_TIMEOUT("cm.alu.usermanagement.selfregistration.activation.optin_timeout"),
                    /**
                     * <p><strong>Einwilligungsdokument aktivieren.</strong></p>
                     * Confkey: cm.alu.usermanagement.selfregistration.agreement.agreement_document_enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Diese Einstellung legt fest, ob das Einwilligungsdokument zum Download zur Verf&uuml;gung gestellt wird.<br />&quot;JA&quot; bedeutet: das Einwilligungsdokument wird zum Download zur Verf&uuml;gung gestellt.<br />&quot;NEIN&quot;: das Einwilligungsdokument wird nicht zum Download zur Verf&uuml;gung gestellt.<br />Sollte dieser Parameter nicht gesetzt sein, wird standardm&auml;&szlig;ig das Einwilligungsdokument zum Download zur Verf&uuml;gung gestellt.
                     */
                    USERMANAGEMENT_SELFREGISTRATION_AGREEMENT_AGREEMENT_DOCUMENT_ENABLED("cm.alu.usermanagement.selfregistration.agreement.agreement_document_enabled"),
                    /**
                     * <p><strong>Erforderliche Einwilligungen f&uuml;r ehemalige Studierende und Mitarbeiter.</strong></p>
                     * Confkey: cm.alu.usermanagement.selfregistration.agreement.required_agreements_students<br/>
                     * ParameterType: MANYSELECT_SRC<br/>
                     * <br/>
                     * Info: Liste von Einwilligungen, die in der Registrierung f&uuml;r Ehemalige als erforderlich markiert werden sollen.
                     */
                    USERMANAGEMENT_SELFREGISTRATION_AGREEMENT_REQUIRED_AGREEMENTS_STUDENTS("cm.alu.usermanagement.selfregistration.agreement.required_agreements_students"),
                    /**
                     * <p><strong>Selbstregistrierung f&uuml;r Hochschulmitarbeiter.</strong></p>
                     * Confkey: cm.alu.usermanagement.selfregistration.data.employee.enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Einstellung legt fest, ob sich Hochschulmitarbeiter registrieren k&ouml;nnen. &quot;JA&quot; bedeutet: die Registrierung als Hochschulmitarbeiter ist m&ouml;glich, &quot;NEIN&quot;, dass die Registrierung nicht m&ouml;glich ist. Sollte dieser Parameter nicht gesetzt sein, ist standardm&auml;&szlig;ig die Registrierung als Hochschulmitarbeiter m&ouml;glich.
                     */
                    USERMANAGEMENT_SELFREGISTRATION_DATA_EMPLOYEE_ENABLED("cm.alu.usermanagement.selfregistration.data.employee.enabled"),
                    /**
                     * <p><strong>Erfassen des beruflichen Werdegangs.</strong></p>
                     * Confkey: cm.alu.usermanagement.selfregistration.data.employment_history.enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Einstellung um die optionale Erfassung des beruflichen Werdegangs zu aktivieren. &quot;JA&quot; bedeutet, dass die Benutzer optional ihren beruflichen Werdegang eintragen k&ouml;nnen. &quot;NEIN&quot; bedeutet, dass diese Option nicht zur Verf&uuml;gung steht. Der Standardwert ist &quot;NEIN&quot;.
                     */
                    USERMANAGEMENT_SELFREGISTRATION_DATA_EMPLOYMENT_HISTORY_ENABLED("cm.alu.usermanagement.selfregistration.data.employment_history.enabled"),
                    /**
                     * <p><strong>Gesch&auml;ftliche Kontaktdaten erlauben.</strong></p>
                     * Confkey: cm.alu.usermanagement.selfregistration.data.personal_data.contact_data.business_contact_data_enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Erlaubt die Eingabe bzw. Verwendung von gesch&auml;ftlichen Kontaktdaten.
                     */
                    USERMANAGEMENT_SELFREGISTRATION_DATA_PERSONAL_DATA_CONTACT_DATA_BUSINESS_CONTACT_DATA_ENABLED("cm.alu.usermanagement.selfregistration.data.personal_data.contact_data.business_contact_data_enabled"),
                    /**
                     * <p><strong>Instantmessenger-Kontaktdaten erlauben.</strong></p>
                     * Confkey: cm.alu.usermanagement.selfregistration.data.personal_data.contact_data.im_addresses_enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: K&ouml;nnen Kontaktdaten zu Instant-Messengern angegeben werden? Diese Einstellung gilt sowohl f&uuml;r private als auch gesch&auml;ftliche Kontaktdaten.
                     */
                    USERMANAGEMENT_SELFREGISTRATION_DATA_PERSONAL_DATA_CONTACT_DATA_IM_ADDRESSES_ENABLED("cm.alu.usermanagement.selfregistration.data.personal_data.contact_data.im_addresses_enabled"),
                    /**
                     * <p><strong>Mindestalter.</strong></p>
                     * Confkey: cm.alu.usermanagement.selfregistration.data.personal_data.minimum_age<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Mindestalter der Person (gemessen am angegebenen Geburtsdatum), um sich selbst registrieren zu k&ouml;nnen.
                     */
                    USERMANAGEMENT_SELFREGISTRATION_DATA_PERSONAL_DATA_MINIMUM_AGE("cm.alu.usermanagement.selfregistration.data.personal_data.minimum_age"),
                    /**
                     * <p><strong>Kontaktgrund.</strong></p>
                     * Confkey: cm.alu.usermanagement.selfregistration.data.reason_of_contact.enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Legt fest, ob ein Kontaktgrund angegeben werden muss. Die Standardeinstellung ist &quot;JA&quot;.
                     */
                    USERMANAGEMENT_SELFREGISTRATION_DATA_REASON_OF_CONTACT_ENABLED("cm.alu.usermanagement.selfregistration.data.reason_of_contact.enabled"),
                    /**
                     * <p><strong>Interesse.</strong></p>
                     * Confkey: cm.alu.usermanagement.selfregistration.data.reason_of_interest.enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll abgefragt werden, wie der Benutzer auf das Alumni-Netzwerk aufmerksam wurde?
                     */
                    USERMANAGEMENT_SELFREGISTRATION_DATA_REASON_OF_INTEREST_ENABLED("cm.alu.usermanagement.selfregistration.data.reason_of_interest.enabled"),
                    /**
                     * <p><strong>Verf&uuml;gbare Angebotskontexte.</strong></p>
                     * Confkey: cm.alu.usermanagement.selfregistration.data.subscriptions.available_subscription_offer_contexts<br/>
                     * ParameterType: MANYSELECT_SRC<br/>
                     * <br/>
                     * Info: Die Auswahl bestimmt die Kontexte aus welchen Angebote w&auml;hrend der Registrierung abonniert werden k&ouml;nnen.
                     */
                    USERMANAGEMENT_SELFREGISTRATION_DATA_SUBSCRIPTIONS_AVAILABLE_SUBSCRIPTION_OFFER_CONTEXTS("cm.alu.usermanagement.selfregistration.data.subscriptions.available_subscription_offer_contexts"),
                    /**
                     * <p><strong>Auswahl von Angeboten.</strong></p>
                     * Confkey: cm.alu.usermanagement.selfregistration.data.subscriptions.enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    USERMANAGEMENT_SELFREGISTRATION_DATA_SUBSCRIPTIONS_ENABLED("cm.alu.usermanagement.selfregistration.data.subscriptions.enabled"),
                    /**
                     * <p><strong>Benutzerkennung generieren.</strong></p>
                     * Confkey: cm.alu.usermanagement.selfregistration.generate_username<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll die Benutzerkennung bei der Selbstregistrierung generiert werden, oder sollen Personen die Benutzerkennung frei w&auml;hlen d&uuml;rfen?<br />Um den Generator zu verwenden muss die Einstellung 'true' gew&auml;hlt werden.
                     */
                    USERMANAGEMENT_SELFREGISTRATION_GENERATE_USERNAME("cm.alu.usermanagement.selfregistration.generate_username"),
                    /**
                     * <p><strong>Aktivieren der automatischen Sperrung.</strong></p>
                     * Confkey: cm.alu.usermanagement.selfregistration.locking.automatic_locking<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    USERMANAGEMENT_SELFREGISTRATION_LOCKING_AUTOMATIC_LOCKING("cm.alu.usermanagement.selfregistration.locking.automatic_locking"),
                    /**
                     * <p><strong>Standardeinstellung f&uuml;r die optionale Registrierung mit Account.</strong></p>
                     * Confkey: cm.alu.usermanagement.selfregistration.optional_register_with_account_selected<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Definiert die Standardeinstellung, ob eine Registrierung mit Account ausgew&auml;hlt sein soll, falls eine optionale Registrierung mit Account konfiguriert ist. Hierbei bedeutet &quot;JA&quot;, dass die Registrierung mit Account bereits ausgew&auml;hlt ist. &quot;NEIN&quot; bedeutet, dass eine Registrierung mit Account noch von einem Benutzer explizit ausgew&auml;hlt werden muss, falls dieser dies m&ouml;chte.
                     */
                    USERMANAGEMENT_SELFREGISTRATION_OPTIONAL_REGISTER_WITH_ACCOUNT_SELECTED("cm.alu.usermanagement.selfregistration.optional_register_with_account_selected"),
                    /**
                     * <p><strong>Mit Account registrieren.</strong></p>
                     * Confkey: cm.alu.usermanagement.selfregistration.register_with_account_option<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Einstellung f&uuml;r die Registrierungsm&ouml;glichkeit mit Account. Der Konfigurationsparameter kann die Werte &quot;OPTIONAL&quot;, &quot;MANDATORY&quot; oder &quot;NOT_AVAILABLE&quot; enthalten. &quot;OPTIONAL&quot; bedeutet, dass eine Registrierung mit Account m&ouml;glich ist, aber durch den Benutzer ausgelassen werden kann. &quot;MANDATORY&quot; bedeutet, dass die Registrierung mit Account immer durchgef&uuml;hrt werden muss. &quot;NOT_AVAILABLE&quot; bedeutet, dass die Registrierung mit Account nicht zur Auswahl steht.
                     */
                    USERMANAGEMENT_SELFREGISTRATION_REGISTER_WITH_ACCOUNT_OPTION("cm.alu.usermanagement.selfregistration.register_with_account_option"),
                    /**
                     * <p><strong>Striktes, dezentrales Alumni-Management.</strong></p>
                     * Confkey: cm.alu.usermanagement.strict_decentralization<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Definiert, ob das dezentrale Alumni-Mangement strikt oder lax durchgef&uuml;hrt werden soll. Strikt bedeutet, dass ein Alumni-Manager keine Alumni sehen darf, die ihm nicht zur Verwaltung zugeordnet sind. Im Gegensatz dazu bedeutet eine nicht strikte Handhabung, dass ein Alumni-Manager zwar Alumni sehen darf, die ihm nicht zur Verwaltung zugeordnet sind, diese aber dennoch nicht bearbeiten kann.
                     */
                    USERMANAGEMENT_STRICT_DECENTRALIZATION("cm.alu.usermanagement.strict_decentralization"),
                    /**
                     * <p><strong>Benutzerkennung generieren.</strong></p>
                     * Confkey: cm.alu.usermanagement.student.registration.account.generate_username<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll bei der Erstellung eines Accounts die Benutzerkennung generiert werden (true) oder nicht (false)?
                     */
                    USERMANAGEMENT_STUDENT_REGISTRATION_ACCOUNT_GENERATE_USERNAME("cm.alu.usermanagement.student.registration.account.generate_username"),
                    /**
                     * <p><strong>Mit Account registrieren.</strong></p>
                     * Confkey: cm.alu.usermanagement.student.registration.account.register_with_account_option<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: Einstellung f&uuml;r die Registrierungsm&ouml;glichkeit mit Account. Die Einstellung &quot;optional&quot; bedeutet, dass eine Registrierung mit Account m&ouml;glich ist, aber durch den Benutzer ausgelassen werden kann, &quot;obligatorisch&quot; bedeutet, dass die Registrierung mit Account immer durchgef&uuml;hrt werden muss. Die Einstellung &quot;nicht verf&uuml;gbar&quot; bedeutet, dass die Registrierung mit Account nicht zur Auswahl steht.
                     */
                    USERMANAGEMENT_STUDENT_REGISTRATION_ACCOUNT_REGISTER_WITH_ACCOUNT_OPTION("cm.alu.usermanagement.student.registration.account.register_with_account_option"),
                    /**
                     * <p><strong>Registrierung mit Account.</strong></p>
                     * Confkey: cm.alu.usermanagement.student.registration.account.register_with_account_selected<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Hier kann eingestellt werden, ob bei Optionaler Account-Erstellung, in der Voreinstellung ein Account erstellt wird (true) oder nicht (false).
                     */
                    USERMANAGEMENT_STUDENT_REGISTRATION_ACCOUNT_REGISTER_WITH_ACCOUNT_SELECTED("cm.alu.usermanagement.student.registration.account.register_with_account_selected"),
                    /**
                     * <p><strong>Automatischer Opt-In.</strong></p>
                     * Confkey: cm.alu.usermanagement.student.registration.activation.automatic_opt_in_enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll der Opt-In automatisch erfolgen (true) oder nicht (false)?
                     */
                    USERMANAGEMENT_STUDENT_REGISTRATION_ACTIVATION_AUTOMATIC_OPT_IN_ENABLED("cm.alu.usermanagement.student.registration.activation.automatic_opt_in_enabled"),
                    /**
                     * <p><strong>Benachrichtigung bei automatischem Opt-In.</strong></p>
                     * Confkey: cm.alu.usermanagement.student.registration.activation.automatic_opt_in_notification<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll eine Benachrichtigungs-E-Mail bei automatischem Opt-In versand werden (true) oder nicht (false)?
                     */
                    USERMANAGEMENT_STUDENT_REGISTRATION_ACTIVATION_AUTOMATIC_OPT_IN_NOTIFICATION("cm.alu.usermanagement.student.registration.activation.automatic_opt_in_notification"),
                    /**
                     * <p><strong>Rolle bei automatischem Opt-In.</strong></p>
                     * Confkey: cm.alu.usermanagement.student.registration.activation.default_candidate_role<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: Stellen Sie die Rolle ein, die bei automatischem Opt-In vergeben wird.
                     */
                    USERMANAGEMENT_STUDENT_REGISTRATION_ACTIVATION_DEFAULT_CANDIDATE_ROLE("cm.alu.usermanagement.student.registration.activation.default_candidate_role"),
                    /**
                     * <p><strong>G&uuml;ltigkeit des Opt-Ins.</strong></p>
                     * Confkey: cm.alu.usermanagement.student.registration.activation.opt_in_timeout<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Wie lange (in Tagen) soll eine Aktivierung nach Versand der Opt-In E-Mail m&ouml;glich sein?
                     */
                    USERMANAGEMENT_STUDENT_REGISTRATION_ACTIVATION_OPT_IN_TIMEOUT("cm.alu.usermanagement.student.registration.activation.opt_in_timeout"),
                    /**
                     * <p><strong>Schriftliche Einwilligung anfordern.</strong></p>
                     * Confkey: cm.alu.usermanagement.student.registration.agreement.agreement_document_enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll eine schriftliche Einwilligung angefordert werden (true) oder nicht (false)?
                     */
                    USERMANAGEMENT_STUDENT_REGISTRATION_AGREEMENT_AGREEMENT_DOCUMENT_ENABLED("cm.alu.usermanagement.student.registration.agreement.agreement_document_enabled"),
                    /**
                     * <p><strong>Erforderliche Einwilligungen f&uuml;r Studierende.</strong></p>
                     * Confkey: cm.alu.usermanagement.student.registration.agreement.required_agreements<br/>
                     * ParameterType: MANYSELECT_SRC<br/>
                     * <br/>
                     * Info: W&auml;hlen Sie die Zustimmungen, die in der Registrierung als erforderlich markiert werden sollen.
                     */
                    USERMANAGEMENT_STUDENT_REGISTRATION_AGREEMENT_REQUIRED_AGREEMENTS("cm.alu.usermanagement.student.registration.agreement.required_agreements"),
                    /**
                     * <p><strong>Gr&uuml;nde eines erfolgreichen Abschlusses.</strong></p>
                     * Confkey: cm.alu.usermanagement.student.registration.data.alumni_degree_program.reasons_of_finishing<br/>
                     * ParameterType: MANYSELECT_SRC<br/>
                     * <br/>
                     * Info: W&auml;hlen Sie die Gr&uuml;nde f&uuml;r die Beendigung eines Studiums, die einen erfolgreichen Abschluss kennzeichnen.
                     */
                    USERMANAGEMENT_STUDENT_REGISTRATION_DATA_ALUMNI_DEGREE_PROGRAM_REASONS_OF_FINISHING("cm.alu.usermanagement.student.registration.data.alumni_degree_program.reasons_of_finishing"),
                    /**
                     * <p><strong>Gesch&auml;ftliche Kontaktdaten erlauben.</strong></p>
                     * Confkey: cm.alu.usermanagement.student.registration.data.contact.business_contact_data_enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Erlaubt die Eingabe bzw. Verwendung von gesch&auml;ftlichen Kontaktdaten.
                     */
                    USERMANAGEMENT_STUDENT_REGISTRATION_DATA_CONTACT_BUSINESS_CONTACT_DATA_ENABLED("cm.alu.usermanagement.student.registration.data.contact.business_contact_data_enabled"),
                    /**
                     * <p><strong>Messenger-Adressen verf&uuml;gbar.</strong></p>
                     * Confkey: cm.alu.usermanagement.student.registration.data.contact.messenger_enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Sollen Messenger-Adressen (z.B. msn, icq, etc.) abgefragt werden (true) oder nicht (false)?
                     */
                    USERMANAGEMENT_STUDENT_REGISTRATION_DATA_CONTACT_MESSENGER_ENABLED("cm.alu.usermanagement.student.registration.data.contact.messenger_enabled"),
                    /**
                     * <p><strong>Private E-Mail-Adresse obligatorisch?.</strong></p>
                     * Confkey: cm.alu.usermanagement.student.registration.data.contact.private_emailaddress_required<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    USERMANAGEMENT_STUDENT_REGISTRATION_DATA_CONTACT_PRIVATE_EMAILADDRESS_REQUIRED("cm.alu.usermanagement.student.registration.data.contact.private_emailaddress_required"),
                    /**
                     * <p><strong>Private Postadresse obligatorisch?.</strong></p>
                     * Confkey: cm.alu.usermanagement.student.registration.data.contact.private_postaddress_required<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    USERMANAGEMENT_STUDENT_REGISTRATION_DATA_CONTACT_PRIVATE_POSTADDRESS_REQUIRED("cm.alu.usermanagement.student.registration.data.contact.private_postaddress_required"),
                    /**
                     * <p><strong>Erfassen des beruflichen Werdegangs.</strong></p>
                     * Confkey: cm.alu.usermanagement.student.registration.data.employment_history.enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll der Berufliche Werdegang bei der Registrierung erfasst werden (true) oder nicht (false).
                     */
                    USERMANAGEMENT_STUDENT_REGISTRATION_DATA_EMPLOYMENT_HISTORY_ENABLED("cm.alu.usermanagement.student.registration.data.employment_history.enabled"),
                    /**
                     * <p><strong>Mindestalter.</strong></p>
                     * Confkey: cm.alu.usermanagement.student.registration.data.personal_data.minimum_age<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Geben Sie das Mindestalter an, das f&uuml;r die Registrierung von Studierenden vorausgesetzt wird.
                     */
                    USERMANAGEMENT_STUDENT_REGISTRATION_DATA_PERSONAL_DATA_MINIMUM_AGE("cm.alu.usermanagement.student.registration.data.personal_data.minimum_age"),
                    /**
                     * <p><strong>Kontaktgrund.</strong></p>
                     * Confkey: cm.alu.usermanagement.student.registration.data.reason_of_contact.enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll der Kontaktgrund angegeben werden k&ouml;nnen (true) oder nicht (false)?
                     */
                    USERMANAGEMENT_STUDENT_REGISTRATION_DATA_REASON_OF_CONTACT_ENABLED("cm.alu.usermanagement.student.registration.data.reason_of_contact.enabled"),
                    /**
                     * <p><strong>Interesse.</strong></p>
                     * Confkey: cm.alu.usermanagement.student.registration.data.reason_of_interest.enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll abgefragt werden, wie der Benutzer auf das Alumni-Netzwerk aufmerksam wurde (true) oder nicht (false)?
                     */
                    USERMANAGEMENT_STUDENT_REGISTRATION_DATA_REASON_OF_INTEREST_ENABLED("cm.alu.usermanagement.student.registration.data.reason_of_interest.enabled"),
                    /**
                     * <p><strong>Verf&uuml;gbare Angebotskontexte.</strong></p>
                     * Confkey: cm.alu.usermanagement.student.registration.data.subscription.available_subscription_offer_contexts<br/>
                     * ParameterType: MANYSELECT_SRC<br/>
                     * <br/>
                     * Info: Die Auswahl bestimmt die Kontexte aus welchen Angebote w&auml;hrend der Registrierung abonniert werden k&ouml;nnen.
                     */
                    USERMANAGEMENT_STUDENT_REGISTRATION_DATA_SUBSCRIPTION_AVAILABLE_SUBSCRIPTION_OFFER_CONTEXTS("cm.alu.usermanagement.student.registration.data.subscription.available_subscription_offer_contexts"),
                    /**
                     * <p><strong>Erfassen der Abonnements.</strong></p>
                     * Confkey: cm.alu.usermanagement.student.registration.data.subscription.enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Sollen Abonnements erfasst werden (true) oder nicht (false)?
                     */
                    USERMANAGEMENT_STUDENT_REGISTRATION_DATA_SUBSCRIPTION_ENABLED("cm.alu.usermanagement.student.registration.data.subscription.enabled"),
                    /**
                     * <p><strong>Zugewiesener Verwaltungsbereich.</strong></p>
                     * Confkey: cm.alu.usermanagement.student.registration.default_orgunit<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: Geben Sie den zugewiesenen Verwaltungsbereich Alumni-Interessenten an, die &uuml;ber die Registrierung f&uuml;r Studierende ins Alumni-Management kommen. ACHTUNG: Ist der automatische Opt-In aktiviert, werden die Interessenten direkt zu Bewerbern. Der oder die zugewiesenen Verwaltungsbereiche werden in diesem Fall aus dem ehemaligen Studium berechnet.
                     */
                    USERMANAGEMENT_STUDENT_REGISTRATION_DEFAULT_ORGUNIT("cm.alu.usermanagement.student.registration.default_orgunit"),
                    /**
                     * <p><strong>Registrierung f&uuml;r Studierende Aktiviert.</strong></p>
                     * Confkey: cm.alu.usermanagement.student.registration.enabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Zentrale Konfigurationseinstellung zur Aktivierung bzw. Deaktivierung der Registrierung f&uuml;r Studierende.
                     */
                    USERMANAGEMENT_STUDENT_REGISTRATION_ENABLED("cm.alu.usermanagement.student.registration.enabled"),
                    /**
                     * <p><strong>Aktivieren der automatischen Sperrung.</strong></p>
                     * Confkey: cm.alu.usermanagement.student.registration.locking.automatic_locking<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    USERMANAGEMENT_STUDENT_REGISTRATION_LOCKING_AUTOMATIC_LOCKING("cm.alu.usermanagement.student.registration.locking.automatic_locking")
                    ;
            
            
                    /** The key. */
                    private final String key;
            
                    /**
                     * Constructor taking the global configuration parameter key.
                     */
                    private ALU(String key) {
                        this.key = key;
                    }
            
                    @Override
                    public String getKey() {
                         return this.key;
                    }
                }
            
                /**
                 * Produktbereich: APP.
                 */
                public static enum APP implements KeyEnum<String>, Key {
                    /**
                     * <p><strong>Art der Annahme eines Platzangebotes (zulassungsbeschr&auml;nkte Studieng&auml;nge).</strong></p>
                     * Confkey: cm.app.allocation.acceptance_process<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Regelt, auf welche Art und Weise ein Bewerber ein Zulassungsangebot annehmen soll und ob Annahme und Immatrikulation online (&uuml;ber HISinOne) oder durch Sachbearbeiter realisiert sind.
                     */
                    ALLOCATION_ACCEPTANCE_PROCESS("cm.app.allocation.acceptance_process"),
                    /**
                     * <p><strong>Antragszust&auml;nde, die Studienpl&auml;tze blockieren.</strong></p>
                     * Confkey: cm.app.allocation.condition_for_occupied_places<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Geben Sie Zust&auml;nde f&uuml;r Antragsf&auml;cher an, die sich im Nachr&uuml;ckverfahren kapazit&auml;tsmindernd auswirken sollen.
                     */
                    ALLOCATION_CONDITION_FOR_OCCUPIED_PLACES("cm.app.allocation.condition_for_occupied_places"),
                    /**
                     * <p><strong>Maximale Anzahl druckbarer Bescheide.</strong></p>
                     * Confkey: cm.app.allocation.max_number_of_outputrequests<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Bei Ausgabe von Bescheiden im Massendruck wird auf die hier angegebene Zahl begrenzt. Wenn es mehr Bescheide zu drucken gibt als die Obergrenze, dann werden beim ersten Aufruf nur so viele Bescheide gedruckt, wie die Obergrenze hergibt. Beim zweiten Aufruf werden die beim ersten Aufruf bereits gedruckten Bescheide nicht mehr abgefragt und es wird nur noch die Restmenge gedruckt. Der zweite Schritt muss solange wiederholt werden, bis alle Bescheide gedruckt sind.
                     */
                    ALLOCATION_MAX_NUMBER_OF_OUTPUTREQUESTS("cm.app.allocation.max_number_of_outputrequests"),
                    /**
                     * <p><strong>Anzeige der gel&ouml;schten Ranglisteneintr&auml;ge.</strong></p>
                     * Confkey: cm.app.allocation.rankingdisplaydeleted<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: 
                     */
                    ALLOCATION_RANKINGDISPLAYDELETED("cm.app.allocation.rankingdisplaydeleted"),
                    /**
                     * <p><strong>Altersgrenze in Jahren.</strong></p>
                     * Confkey: cm.app.application.agecheck.age<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: 
                     */
                    APPLICATION_AGECHECK_AGE("cm.app.application.agecheck.age"),
                    /**
                     * <p><strong>Fehlende Unterlage automatisch setzen.</strong></p>
                     * Confkey: cm.app.application.agecheck.missingdata<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Die durch diesen Automatismus anzulegende fehlende Unterlage muss in Tabelle k_zulmissingdata zwingend mit dem uniquename = 'Altersgrenze' definiert sein!
                     */
                    APPLICATION_AGECHECK_MISSINGDATA("cm.app.application.agecheck.missingdata"),
                    /**
                     * <p><strong>Bearbeitungsstatus bei denen die Bearbeitung als abgeschlossen gilt.</strong></p>
                     * Confkey: cm.app.application.application_status_processed<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: Es wird der hiskey ausgewertet
                     */
                    APPLICATION_APPLICATION_STATUS_PROCESSED("cm.app.application.application_status_processed"),
                    /**
                     * <p><strong>Unit (Kategorie) der Leistung &quot;Berufsausbildung&quot;.</strong></p>
                     * Confkey: cm.app.application.apprenticeship.unit_id<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: Unit (Kategorie) der Leistung &quot;Berufsausbildung&quot;
                     */
                    APPLICATION_APPRENTICESHIP_UNIT_ID("cm.app.application.apprenticeship.unit_id"),
                    /**
                     * <p><strong>Frage, ob eine (Teil-)Pr&uuml;fung endg&uuml;ltig nicht bestanden wurde.</strong></p>
                     * Confkey: cm.app.application.asknotpasseddegree<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: In der Onlinebewerbung wird der Bewerber gefragt, ob er eine (Teil-)Pr&uuml;fung des gew&auml;hlten Studienfachs an einer anderen Hochschule bereits endg&uuml;ltig nicht bestanden hat.
                     */
                    APPLICATION_ASKNOTPASSEDDEGREE("cm.app.application.asknotpasseddegree"),
                    /**
                     * <p><strong>Anzeigetext f&uuml;r Studienfach.</strong></p>
                     * Confkey: cm.app.application.course_of_study_text<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: 
                     */
                    APPLICATION_COURSE_OF_STUDY_TEXT("cm.app.application.course_of_study_text"),
                    /**
                     * <p><strong>Standardbewerbungssemester f&uuml;r die Online-Bewerbung.</strong></p>
                     * Confkey: cm.app.application.default_application_term_online_application<br/>
                     * ParameterType: TERM<br/>
                     * <br/>
                     * Info: Standardbewerbungssemester f&uuml;r die Vorbelegung in der Online-Bewerbung. Konfiguration nur erforderlich bei &uuml;berlappenden Bewerbungszeitr&auml;umen f&uuml;r unterschiedliche Bewerbungssemester. F&uuml;r '''Wintersemester '''2019/2020 beispielsweise 2019#2#2
                     */
                    APPLICATION_DEFAULT_APPLICATION_TERM_ONLINE_APPLICATION("cm.app.application.default_application_term_online_application"),
                    /**
                     * <p><strong>Dokumentenmanagement aktiviert.</strong></p>
                     * Confkey: cm.app.application.dmsenabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Ist dieser Schalter aktiviert, so steht den Bewerbern in der Onlinebewerbung die M&ouml;glichkeit zur Verf&uuml;gung, Dokumente (Dateien) hochzuladen, die dann vom Bewerber-Manager eingesehen werden k&ouml;nnen.
                     */
                    APPLICATION_DMSENABLED("cm.app.application.dmsenabled"),
                    /**
                     * <p><strong>E-Mail-Adresse editierbar.</strong></p>
                     * Confkey: cm.app.application.edit_email<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Der Bewerber kann E-Mail-Adressen neu erstellen, bearbeiten, l&ouml;schen und als APP-Korrespondenzadresse ausw&auml;hlen.
                     */
                    APPLICATION_EDIT_EMAIL("cm.app.application.edit_email"),
                    /**
                     * <p><strong>Maximale Anzahl Hilfsantr&auml;ge.</strong></p>
                     * Confkey: cm.app.application.max_additional_priorized_requests<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Gibt an, wieviele Hilfsantr&auml;ge ein Bewerber zu seinem Hauptantrag stellen kann. &Uuml;ber das Zulassungspaket kann konfiguriert werden, ob F&auml;cher gemeinsam als Haupt-/Hilfsantr&auml;ge abgegeben werden.
                     */
                    APPLICATION_MAX_ADDITIONAL_PRIORIZED_REQUESTS("cm.app.application.max_additional_priorized_requests"),
                    /**
                     * <p><strong>max Fachsemester.</strong></p>
                     * Confkey: cm.app.application.max_terms<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: maximale Anzahl von Fachsemestern
                     */
                    APPLICATION_MAX_TERMS("cm.app.application.max_terms"),
                    /**
                     * <p><strong>Unit (Kategorie)  der Leistung &quot;Messzahl Zweitstudienbewerber&quot;.</strong></p>
                     * Confkey: cm.app.application.measurementseconddegree.unitid<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: ID der Unit, mit der Leistungen f&uuml;r die Messzahl Zweitstudienbewerber markiert werden. Siehe dazu auch in der Dokumentation unter: HISinOne-Kern -&gt; Infrastruktur -&gt; Hochschulspezifische Konfiguration -&gt; Globale Konfiguration -&gt; Auswahl einer ID
                     */
                    APPLICATION_MEASUREMENTSECONDDEGREE_UNITID("cm.app.application.measurementseconddegree.unitid"),
                    /**
                     * <p><strong>Nachweis Nachteilsausgleich Wartezeit automatisch setzen.</strong></p>
                     * Confkey: cm.app.application.missingdata.compensation_on_waiting_period<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Bei Aktivierung dieses Konfigurationsschalters wird bei HZBs mit Antrag Nachteilsausgleich der Warteizeit die fehlende Unterlage mit der hiskey_id 3 (Nachweis Nachteilsausgleich Wartezeit) automatisch zugeordnet.
                     */
                    APPLICATION_MISSINGDATA_COMPENSATION_ON_WAITING_PERIOD("cm.app.application.missingdata.compensation_on_waiting_period"),
                    /**
                     * <p><strong>Nachweis Ber&uuml;cksichtigung als H&auml;rtefall automatisch setzen.</strong></p>
                     * Confkey: cm.app.application.missingdata.consideration_as_hardship_case<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Bei Aktivierung dieses Konfigurationsschalters wird den F&auml;chern f&uuml;r die ein Antrag auf Ber&uuml;cksichtigung als H&auml;rtefall vorliegt die fehlende Unterlage mit der hiskey_id 4 (H&auml;rtefallantrag) automatisch zugeordnet.
                     */
                    APPLICATION_MISSINGDATA_CONSIDERATION_AS_HARDSHIP_CASE("cm.app.application.missingdata.consideration_as_hardship_case"),
                    /**
                     * <p><strong>Nachweis Ber&uuml;cksichtigung als Spitzensportler automatisch setzen.</strong></p>
                     * Confkey: cm.app.application.missingdata.consideration_as_top_athlete<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Bei Aktivierung dieses Konfigurationsschalters wird den F&auml;chern f&uuml;r die ein Antrag auf Ber&uuml;cksichtigung als Spitzensportler vorliegt die fehlende Unterlage mit der hiskey_id 5 (Nachweis Spitzensportler) automatisch zugeordnet.
                     */
                    APPLICATION_MISSINGDATA_CONSIDERATION_AS_TOP_ATHLETE("cm.app.application.missingdata.consideration_as_top_athlete"),
                    /**
                     * <p><strong>Nachweis Ber&uuml;cksichtigung Musikpr&uuml;fung automatisch setzen.</strong></p>
                     * Confkey: cm.app.application.missingdata.consideration_of_music_exam<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Bei Aktivierung dieses Konfigurationsschalters wird den F&auml;chern f&uuml;r die ein Antrag auf Ber&uuml;cksichtigung einer Musikpr&uuml;fung vorliegt die fehlende Unterlage mit der hiskey_id 6 (Nachweis Musikpr&uuml;fung) automatisch zugeordnet.
                     */
                    APPLICATION_MISSINGDATA_CONSIDERATION_OF_MUSIC_EXAM("cm.app.application.missingdata.consideration_of_music_exam"),
                    /**
                     * <p><strong>Nachweis Qualifikation &uuml;ber berufliche Bildung automatisch setzen.</strong></p>
                     * Confkey: cm.app.application.missingdata.qualification_by_profession<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Bei Aktivierung dieses Konfigurationsschalters wird bei HZBs mit Qualifikation &uuml;ber berufliche Bildung die fehlende Unterlage mit der hiskey_id 8 (Nachweis Qualifikation &uuml;ber berufliche Bildung) automatisch zugeordnet.
                     */
                    APPLICATION_MISSINGDATA_QUALIFICATION_BY_PROFESSION("cm.app.application.missingdata.qualification_by_profession"),
                    /**
                     * <p><strong>Nachweis Zweitstudium automatisch setzen.</strong></p>
                     * Confkey: cm.app.application.missingdata.second_degree<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Bei Aktivierung dieses Konfigurationsschalters wird bei Antr&auml;gen auf ein Zweitstudium die fehlende Unterlage mit der hiskey_id 7 (Nachweis Zweitstudium) automatisch zugeordnet.
                     */
                    APPLICATION_MISSINGDATA_SECOND_DEGREE("cm.app.application.missingdata.second_degree"),
                    /**
                     * <p><strong>Nachweis Nachteilsausgleich Note automatisch setzen.</strong></p>
                     * Confkey: cm.app.application.missingdata.set_compensation_on_grade<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Bei Aktivierung dieses Konfigurationsschalters wird bei HZBs mit Antrag auf Nachteilsausgleich der Note die fehlende Unterlage mit der hiskey_id 2 (Nachweis Nachteilsausgleich Note) automatisch zugeordnet.
                     */
                    APPLICATION_MISSINGDATA_SET_COMPENSATION_ON_GRADE("cm.app.application.missingdata.set_compensation_on_grade"),
                    /**
                     * <p><strong>Nachweis bevorzugte Zulassung automatisch setzen.</strong></p>
                     * Confkey: cm.app.application.missingdata.setprivilegemissingdata<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Bei Aktivierung dieses Konfigurationsschalters wird den F&auml;chern f&uuml;r die ein Antrag auf bevorzugte Zulassung vorliegt die fehlende Unterlage mit der hiskey_id 1 (Nachweis bevorzugte Zulassung)  automatisch zugeordnet.
                     */
                    APPLICATION_MISSINGDATA_SETPRIVILEGEMISSINGDATA("cm.app.application.missingdata.setprivilegemissingdata"),
                    /**
                     * <p><strong>Funktion &quot;Angebot zur&uuml;ckstellen&quot; deaktivert?.</strong></p>
                     * Confkey: cm.app.application.postpone_request_disabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Wenn dieser Schalter gesetzt ist, wird in der Onlinebewerbung der Button &quot;Angebot zur&uuml;ckstellen&quot; nicht angezeigt.
                     */
                    APPLICATION_POSTPONE_REQUEST_DISABLED("cm.app.application.postpone_request_disabled"),
                    /**
                     * <p><strong>Antrag zur Bewerbung.</strong></p>
                     * Confkey: cm.app.application.reports.appcontrolpageapplication<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll der Antrag zur Bewerbung in der Online-Bewerbung druckbar sein?
                     */
                    APPLICATION_REPORTS_APPCONTROLPAGEAPPLICATION("cm.app.application.reports.appcontrolpageapplication"),
                    /**
                     * <p><strong>Zulassungsbescheid.</strong></p>
                     * Confkey: cm.app.application.reports.approvaldocument<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Zulassungsbescheide im Portal des Bewerbers
                     */
                    APPLICATION_REPORTS_APPROVALDOCUMENT("cm.app.application.reports.approvaldocument"),
                    /**
                     * <p><strong>Ablehnungsbescheid.</strong></p>
                     * Confkey: cm.app.application.reports.refusaldocument<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Ablehnungsbescheide im Portal des Bewerbers
                     */
                    APPLICATION_REPORTS_REFUSALDOCUMENT("cm.app.application.reports.refusaldocument"),
                    /**
                     * <p><strong>Funktion &quot;Platz zur&uuml;ckgeben&quot; deaktiviert?.</strong></p>
                     * Confkey: cm.app.application.return_admitted_request_disabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Wenn dieser Schalter gesetzt ist, wird in der Onlinebewerbung der Button &quot;Platz zur&uuml;ckgeben&quot; nicht angezeigt.
                     */
                    APPLICATION_RETURN_ADMITTED_REQUEST_DISABLED("cm.app.application.return_admitted_request_disabled"),
                    /**
                     * <p><strong>Status-Spalte in Leistungsdaten anzeigen.</strong></p>
                     * Confkey: cm.app.application.show_selectioncriteria_status<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Von diesem Schalter h&auml;ngt ab, ob f&uuml;r Bewerber bei den Leistungsdaten die Status-Spalte sichtbar ist.
                     */
                    APPLICATION_SHOW_SELECTIONCRITERIA_STATUS("cm.app.application.show_selectioncriteria_status"),
                    /**
                     * <p><strong>aktiv.</strong></p>
                     * Confkey: cm.app.application.simpleheadmissiontype.activ<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Es werden in der Online-Bewerbung keine HZB-Arten zur Auswahl angeboten, sondern nur, ob die HZB im In- oder Ausland erworben wurde.
                     */
                    APPLICATION_SIMPLEHEADMISSIONTYPE_ACTIV("cm.app.application.simpleheadmissiontype.activ"),
                    /**
                     * <p><strong>Entrance Qualification Type f&uuml;r ausl&auml;ndische HZB.</strong></p>
                     * Confkey: cm.app.application.simpleheadmissiontype.ids.abroad<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: Entrance Qualification Type wird f&uuml;r ausl&auml;ndische Bewerber gesetzt, wenn cm.app.application.simpleheadmissiontype.activ 'true' ist.
                     */
                    APPLICATION_SIMPLEHEADMISSIONTYPE_IDS_ABROAD("cm.app.application.simpleheadmissiontype.ids.abroad"),
                    /**
                     * <p><strong>Entrance Qualification Type f&uuml;r beruflich Qualifizierte.</strong></p>
                     * Confkey: cm.app.application.simpleheadmissiontype.ids.apprenticeship<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: Entrance Qualification Type wird f&uuml;r beruflich qualifizierte Bewerber gesetzt, wenn cm.app.application.simpleheadmissiontype.activ 'true' ist.
                     */
                    APPLICATION_SIMPLEHEADMISSIONTYPE_IDS_APPRENTICESHIP("cm.app.application.simpleheadmissiontype.ids.apprenticeship"),
                    /**
                     * <p><strong>Entrance Qualification Type f&uuml;r deutsche HZB.</strong></p>
                     * Confkey: cm.app.application.simpleheadmissiontype.ids.germany<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: Entrance Qualification Type wird f&uuml;r deutsche Bewerber gesetzt, wenn cm.app.application.simpleheadmissiontype.activ 'true' ist.
                     */
                    APPLICATION_SIMPLEHEADMISSIONTYPE_IDS_GERMANY("cm.app.application.simpleheadmissiontype.ids.germany"),
                    /**
                     * <p><strong>Erfassung nur einer HZB.</strong></p>
                     * Confkey: cm.app.application.single_entrance_qualification<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll in der Online-Bewerbung nur eine HZB erfasst werden? True: Der Bewerber kann nur eine HZB erfassen - False: Der Bewerber kann mehrere HZBs erfassen. In der Sachbearbeitung k&ouml;nnen unabh&auml;ngig von dieser Einstellung mehrere HZBs erfasst werden.
                     */
                    APPLICATION_SINGLE_ENTRANCE_QUALIFICATION("cm.app.application.single_entrance_qualification"),
                    /**
                     * <p><strong>Einfache Erfassung h&ouml;herer Fachsemester.</strong></p>
                     * Confkey: cm.app.application.studysemester_simple<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Bei allen Fachsemestern gr&ouml;&szlig;er eins wird statt des Semesters der Text &quot;H&ouml;heres Fachsemester&quot; angezeigt.
                     */
                    APPLICATION_STUDYSEMESTER_SIMPLE("cm.app.application.studysemester_simple"),
                    /**
                     * <p><strong>Antrag auf Verbesserung der Note.</strong></p>
                     * Confkey: cm.app.application.visiblefieldsets.amendment.amendmentgradevisible<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Kann in der Online-Bewerbung oder Sachbearbeiterfunktion ein Antrag auf Verbesserung der Note (Nachteilsausgleich Note) gestellt bzw. bearbeitet werden?
                     */
                    APPLICATION_VISIBLEFIELDSETS_AMENDMENT_AMENDMENTGRADEVISIBLE("cm.app.application.visiblefieldsets.amendment.amendmentgradevisible"),
                    /**
                     * <p><strong>Antrag auf Verbesserung der Wartezeit.</strong></p>
                     * Confkey: cm.app.application.visiblefieldsets.amendment.amendmentqueuetimevisible<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Kann in der Online-Bewerbung oder Sachbearbeiterfunktion ein Antrag auf Verbesserung der Wartezeit (Nachteilsausgleich Wartezeit) gestellt bzw. bearbeitet werden?
                     */
                    APPLICATION_VISIBLEFIELDSETS_AMENDMENT_AMENDMENTQUEUETIMEVISIBLE("cm.app.application.visiblefieldsets.amendment.amendmentqueuetimevisible"),
                    /**
                     * <p><strong>Fieldset Verbesserung der Wartezeit durch Berufsausbildung.</strong></p>
                     * Confkey: cm.app.application.visiblefieldsets.amendment.apprenticeshipqueuetime<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll das Fieldset Verbesserung der Wartezeit durch Berufsausbildung angezeigt werden?
                     */
                    APPLICATION_VISIBLEFIELDSETS_AMENDMENT_APPRENTICESHIPQUEUETIME("cm.app.application.visiblefieldsets.amendment.apprenticeshipqueuetime"),
                    /**
                     * <p><strong>fachbezogene Berufsausbildung.</strong></p>
                     * Confkey: cm.app.application.visiblefieldsets.amendment.entrancequalificationapprenticeship<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Die Auswahlbox &quot;Erworben in &quot; wird um den Eintrag &quot;Hochschulzugang (ohne Abitur) f&uuml;r in der berufl. Bildung Qualifizierte&quot; erweitert. Bei der Wahl dieses Eintrages wird als HZB-Art der unter &quot;cm.app.application.simpleheadmissiontype.ids.apprenticeship&quot; ausgew&auml;hlte Entrance Qualification Type verwendet.
                     */
                    APPLICATION_VISIBLEFIELDSETS_AMENDMENT_ENTRANCEQUALIFICATIONAPPRENTICESHIP("cm.app.application.visiblefieldsets.amendment.entrancequalificationapprenticeship"),
                    /**
                     * <p><strong>Fachbezogene Berufsausbildung ohne Datum und ohne Note.</strong></p>
                     * Confkey: cm.app.application.visiblefieldsets.amendment.entrancequalificationapprenticeship_simple<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Ist dieser Schalter aktiviert, so werden in der Onlinebewerbung bei der Erfassung einer HZB vom Typ &quot;Berufl. Qualif. ohne HZB&quot; die Felder Datum und Note nicht angezeigt. Damit diese Konfiguration relevant wird, m&uuml;ssen auch die Konfigurationsschalter &quot;fachbezogene Berufsausbildung&quot; (cm.app.application.visiblefieldsets.amendment.entrancequalificationapprenticeship) und cm.app.application.simpleheadmissiontype.activ aktiviert sein.
                     */
                    APPLICATION_VISIBLEFIELDSETS_AMENDMENT_ENTRANCEQUALIFICATIONAPPRENTICESHIP_SIMPLE("cm.app.application.visiblefieldsets.amendment.entrancequalificationapprenticeship_simple"),
                    /**
                     * <p><strong>Fieldset H&auml;rtefallantrag.</strong></p>
                     * Confkey: cm.app.application.visiblefieldsets.amendment.hardship<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Ist das Fieldset H&auml;rtefallantrag sichtbar?
                     */
                    APPLICATION_VISIBLEFIELDSETS_AMENDMENT_HARDSHIP("cm.app.application.visiblefieldsets.amendment.hardship"),
                    /**
                     * <p><strong>Fieldset Eignungspr&uuml;fung Musik.</strong></p>
                     * Confkey: cm.app.application.visiblefieldsets.amendment.musicexam<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll das Fieldset Eignungspr&uuml;fung Musik sichtbar sein?
                     */
                    APPLICATION_VISIBLEFIELDSETS_AMENDMENT_MUSICEXAM("cm.app.application.visiblefieldsets.amendment.musicexam"),
                    /**
                     * <p><strong>Fieldset Antrag auf bevorzugte Zulassung.</strong></p>
                     * Confkey: cm.app.application.visiblefieldsets.amendment.preferred<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Ist das Fieldset Antrag auf bevorzugte Zulassung sichtbar?
                     */
                    APPLICATION_VISIBLEFIELDSETS_AMENDMENT_PREFERRED("cm.app.application.visiblefieldsets.amendment.preferred"),
                    /**
                     * <p><strong>Sollen f&uuml;r Zweitstudium nur die Zusatzantr&auml;ge 'H&auml;rtefall' und 'Dienst' angezeigt werden?.</strong></p>
                     * Confkey: cm.app.application.visiblefieldsets.amendment.seconddegreehiding<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    APPLICATION_VISIBLEFIELDSETS_AMENDMENT_SECONDDEGREEHIDING("cm.app.application.visiblefieldsets.amendment.seconddegreehiding"),
                    /**
                     * <p><strong>Soll das Fieldset 'besondere HZB' angezeigt werden?.</strong></p>
                     * Confkey: cm.app.application.visiblefieldsets.amendment.specialheadmissiontype<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    APPLICATION_VISIBLEFIELDSETS_AMENDMENT_SPECIALHEADMISSIONTYPE("cm.app.application.visiblefieldsets.amendment.specialheadmissiontype"),
                    /**
                     * <p><strong>Fieldset Spitzensportler.</strong></p>
                     * Confkey: cm.app.application.visiblefieldsets.amendment.topathlete<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll das Fieldset Spitzensportler sichtbar sein?
                     */
                    APPLICATION_VISIBLEFIELDSETS_AMENDMENT_TOPATHLETE("cm.app.application.visiblefieldsets.amendment.topathlete"),
                    /**
                     * <p><strong>Abfrage der Studienvergangenheit.</strong></p>
                     * Confkey: cm.app.application.visiblefieldsets.career<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll die Studienvergangenheit abgefragt werden?
                     */
                    APPLICATION_VISIBLEFIELDSETS_CAREER("cm.app.application.visiblefieldsets.career"),
                    /**
                     * <p><strong>Angaben zur Hochschulreife.</strong></p>
                     * Confkey: cm.app.application.visiblefieldsets.entrancequalification<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll die Hochschulreife (HZB) abgefragt werden?
                     */
                    APPLICATION_VISIBLEFIELDSETS_ENTRANCEQUALIFICATION("cm.app.application.visiblefieldsets.entrancequalification"),
                    /**
                     * <p><strong>Angaben zur Krankenversicherung.</strong></p>
                     * Confkey: cm.app.application.visiblefieldsets.healthinsurance<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Sollen Angaben zur Krankenversicherung vom Bewerber erfragt werden?
                     */
                    APPLICATION_VISIBLEFIELDSETS_HEALTHINSURANCE("cm.app.application.visiblefieldsets.healthinsurance"),
                    /**
                     * <p><strong>Frage nach Antrag als Zweith&ouml;rer.</strong></p>
                     * Confkey: cm.app.application.visiblefieldsets.request_as_visiting_student<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Der Bewerber wird gefragt, ob er zeitgleich an einer anderen Hochschule studiert und hier einen Antrag als Zweith&ouml;rer stellen m&ouml;chte?
                     */
                    APPLICATION_VISIBLEFIELDSETS_REQUEST_AS_VISITING_STUDENT("cm.app.application.visiblefieldsets.request_as_visiting_student"),
                    /**
                     * <p><strong>einfache Erfassung der Berufsausbildung.</strong></p>
                     * Confkey: cm.app.apprenticeship.simple<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Erfassen der Berufsausbildung als einfaches Ja/Nein Feld
                     */
                    APPRENTICESHIP_SIMPLE("cm.app.apprenticeship.simple"),
                    /**
                     * <p><strong>Ist der Tab 'Frei definierbare Eingabefelder' sichtbar?.</strong></p>
                     * Confkey: cm.app.bb.visibletab.additional_application_data<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    BB_VISIBLETAB_ADDITIONAL_APPLICATION_DATA("cm.app.bb.visibletab.additional_application_data"),
                    /**
                     * <p><strong>Zusatzantr&auml;ge.</strong></p>
                     * Confkey: cm.app.bb.visibletab.amendments<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Ist der Tab Zusatzantr&auml;ge sichtbar?
                     */
                    BB_VISIBLETAB_AMENDMENTS("cm.app.bb.visibletab.amendments"),
                    /**
                     * <p><strong>Bescheide.</strong></p>
                     * Confkey: cm.app.bb.visibletab.reportstab<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Ist der Tab Bescheide sichtbar?
                     */
                    BB_VISIBLETAB_REPORTSTAB("cm.app.bb.visibletab.reportstab"),
                    /**
                     * <p><strong>Vergabemethode.</strong></p>
                     * Confkey: cm.app.common.allocation_mode<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Art und Weise, wie Pl&auml;tze vergeben werden. M&ouml;gliche Werte: MAIN, PARALLEL. MAIN bewirkt, dass zwischen Haupt- und Hilfsantr&auml;gen unterschieden wird. PARALLEL bewirkt, das die Antr&auml;ge gleichberechtigt behandelt werden.
                     */
                    COMMON_ALLOCATION_MODE("cm.app.common.allocation_mode"),
                    /**
                     * <p><strong>Beginn.</strong></p>
                     * Confkey: cm.app.common.queue_time.first_term.from<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Semesterbeginn im Format &quot;dd,mm&quot; f&uuml;r die Berechnung der Wartezeit.
                     */
                    COMMON_QUEUE_TIME_FIRST_TERM_FROM("cm.app.common.queue_time.first_term.from"),
                    /**
                     * <p><strong>Wartezeitobergrenze.</strong></p>
                     * Confkey: cm.app.common.queue_time.max_queuetime<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Maximale Anzahl an Semestern f&uuml;r die Wartezeit
                     */
                    COMMON_QUEUE_TIME_MAX_QUEUETIME("cm.app.common.queue_time.max_queuetime"),
                    /**
                     * <p><strong>Beginn.</strong></p>
                     * Confkey: cm.app.common.queue_time.second_term.from<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Semesterbeginn im Format &quot;dd,mm&quot; f&uuml;r die Berechnung der Wartezeit.
                     */
                    COMMON_QUEUE_TIME_SECOND_TERM_FROM("cm.app.common.queue_time.second_term.from"),
                    /**
                     * <p><strong>Teilzulassung ist erlaubt.</strong></p>
                     * Confkey: cm.app.common.teilzulassung_erlaubt<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Gibt an, ob, falls keine Bewerbung des Bewerbers zulassungsf&auml;hig sein sollte, auch eine Zulassung f&uuml;r eine nicht zulassungsf&auml;hige Teilmenge der Studienf&auml;cher (Teilzulassung) ausgesprochen werden kann. Wenn nicht angegeben, ist keine Teilzulassung erlaubt.
                     */
                    COMMON_TEILZULASSUNG_ERLAUBT("cm.app.common.teilzulassung_erlaubt"),
                    /**
                     * <p><strong>Semesterer&ouml;ffnung.</strong></p>
                     * Confkey: cm.app.dates.term.beginning<br/>
                     * ParameterType: DATE<br/>
                     * <br/>
                     * Info: Datum, an dem das Semester er&ouml;ffnet wird.
                     */
                    DATES_TERM_BEGINNING("cm.app.dates.term.beginning"),
                    /**
                     * <p><strong>Zus&auml;tzliche Informationen zum Fach.</strong></p>
                     * Confkey: cm.app.edit.costree.additionalinfo<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: 
                     */
                    EDIT_COSTREE_ADDITIONALINFO("cm.app.edit.costree.additionalinfo"),
                    /**
                     * <p><strong>Standardbewerbungssemester f&uuml;r Bewerbungen bearbeiten.</strong></p>
                     * Confkey: cm.app.edit.default_application_term_edit_application<br/>
                     * ParameterType: TERM<br/>
                     * <br/>
                     * Info: Standardbewerbungssemester f&uuml;r die Vorbelegung in Bewerbungen bearbeiten. F&uuml;r Wintersemester 2019/2020 beispielsweise 2019#2#2
                     */
                    EDIT_DEFAULT_APPLICATION_TERM_EDIT_APPLICATION("cm.app.edit.default_application_term_edit_application"),
                    /**
                     * <p><strong>Zuordnungen pr&uuml;fen.</strong></p>
                     * Confkey: cm.app.edit.eq.assignment_check<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Beim Speichern wird gepr&uuml;ft, ob jedem Fach eine HZB zugeordnet ist. Sollte eine Zuornung fehlen und nur eine HZB vorhanden sein, so wird diese automatisch zugeordnet, andernfalls eine Warnung ausgegeben.
                     */
                    EDIT_EQ_ASSIGNMENT_CHECK("cm.app.edit.eq.assignment_check"),
                    /**
                     * <p><strong>HZB-Arten die f&uuml;r Auswahlordnungen nicht ber&uuml;cksichtigt werden.</strong></p>
                     * Confkey: cm.app.edit.eq.entrance_qualification_type.no_assignment_to_entrance_exam<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Amtliche Statistikschl&uuml;ssel (kommasepariert) von HZB-Arten die bei der Zuordnung der HZB zu Auswahlordnungen nicht ber&uuml;cksichtigt werden
                     */
                    EDIT_EQ_ENTRANCE_QUALIFICATION_TYPE_NO_ASSIGNMENT_TO_ENTRANCE_EXAM("cm.app.edit.eq.entrance_qualification_type.no_assignment_to_entrance_exam"),
                    /**
                     * <p><strong>Land verpflichtend?.</strong></p>
                     * Confkey: cm.app.edit.eq.mandatory_fields.domestic.country<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    EDIT_EQ_MANDATORY_FIELDS_DOMESTIC_COUNTRY("cm.app.edit.eq.mandatory_fields.domestic.country"),
                    /**
                     * <p><strong>Datum ist Pflichtangabe?.</strong></p>
                     * Confkey: cm.app.edit.eq.mandatory_fields.domestic.date<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    EDIT_EQ_MANDATORY_FIELDS_DOMESTIC_DATE("cm.app.edit.eq.mandatory_fields.domestic.date"),
                    /**
                     * <p><strong>Landkreis verpflichtend?.</strong></p>
                     * Confkey: cm.app.edit.eq.mandatory_fields.domestic.district<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    EDIT_EQ_MANDATORY_FIELDS_DOMESTIC_DISTRICT("cm.app.edit.eq.mandatory_fields.domestic.district"),
                    /**
                     * <p><strong>Note verpflichtend?.</strong></p>
                     * Confkey: cm.app.edit.eq.mandatory_fields.domestic.grade<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    EDIT_EQ_MANDATORY_FIELDS_DOMESTIC_GRADE("cm.app.edit.eq.mandatory_fields.domestic.grade"),
                    /**
                     * <p><strong>Land verpflichtend?.</strong></p>
                     * Confkey: cm.app.edit.eq.mandatory_fields.foreign.country<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    EDIT_EQ_MANDATORY_FIELDS_FOREIGN_COUNTRY("cm.app.edit.eq.mandatory_fields.foreign.country"),
                    /**
                     * <p><strong>Datum verpflichtend?.</strong></p>
                     * Confkey: cm.app.edit.eq.mandatory_fields.foreign.date<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    EDIT_EQ_MANDATORY_FIELDS_FOREIGN_DATE("cm.app.edit.eq.mandatory_fields.foreign.date"),
                    /**
                     * <p><strong>Landkreis verpflichtend?.</strong></p>
                     * Confkey: cm.app.edit.eq.mandatory_fields.foreign.district<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    EDIT_EQ_MANDATORY_FIELDS_FOREIGN_DISTRICT("cm.app.edit.eq.mandatory_fields.foreign.district"),
                    /**
                     * <p><strong>Note verpflichtend?.</strong></p>
                     * Confkey: cm.app.edit.eq.mandatory_fields.foreign.grade<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    EDIT_EQ_MANDATORY_FIELDS_FOREIGN_GRADE("cm.app.edit.eq.mandatory_fields.foreign.grade"),
                    /**
                     * <p><strong>Land verpflichtend?.</strong></p>
                     * Confkey: cm.app.edit.eq.mandatory_fields.special.country<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    EDIT_EQ_MANDATORY_FIELDS_SPECIAL_COUNTRY("cm.app.edit.eq.mandatory_fields.special.country"),
                    /**
                     * <p><strong>Datum verpflichtend?.</strong></p>
                     * Confkey: cm.app.edit.eq.mandatory_fields.special.date<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    EDIT_EQ_MANDATORY_FIELDS_SPECIAL_DATE("cm.app.edit.eq.mandatory_fields.special.date"),
                    /**
                     * <p><strong>Landkreis verpflichtend?.</strong></p>
                     * Confkey: cm.app.edit.eq.mandatory_fields.special.district<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    EDIT_EQ_MANDATORY_FIELDS_SPECIAL_DISTRICT("cm.app.edit.eq.mandatory_fields.special.district"),
                    /**
                     * <p><strong>Note verpflichtend?.</strong></p>
                     * Confkey: cm.app.edit.eq.mandatory_fields.special.grade<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    EDIT_EQ_MANDATORY_FIELDS_SPECIAL_GRADE("cm.app.edit.eq.mandatory_fields.special.grade"),
                    /**
                     * <p><strong>Ziel-Antragsstatus f&uuml;r Bewerbung Posteingang.</strong></p>
                     * Confkey: cm.app.edit.requestinbox_target_requeststatus<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: Antragsstatus, in den eingegangene Antr&auml;ge mit Hilfe der Funktion &quot;Bewerbung Posteingang&quot; versetzt werden sollen.
                     */
                    EDIT_REQUESTINBOX_TARGET_REQUESTSTATUS("cm.app.edit.requestinbox_target_requeststatus"),
                    /**
                     * <p><strong>Aktiv.</strong></p>
                     * Confkey: cm.app.edit.selection_criteria.active<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Aktiviert die Hochschuleigene Auswahl in der Online-Bewerbung und der Sachbearbeiterfunktion
                     */
                    EDIT_SELECTION_CRITERIA_ACTIVE("cm.app.edit.selection_criteria.active"),
                    /**
                     * <p><strong>Konfiguration der im Baum angezeigten Spalten.</strong></p>
                     * Confkey: cm.app.edit.selection_criteria.configuration.columns<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Konfiguration der im Baum zus&auml;tzlich zu Titel, Bewertung, Bewertungsart, Status und Vermerk angezeigten Spalten.
                     */
                    EDIT_SELECTION_CRITERIA_CONFIGURATION_COLUMNS("cm.app.edit.selection_criteria.configuration.columns"),
                    /**
                     * <p><strong>Status der Aufnahmepr&uuml;fung einblenden.</strong></p>
                     * Confkey: cm.app.edit.selection_criteria.configuration.entrance_exam_status<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Falls aktiv, wird in der Bewerbungsbearbeitung auf der Seite Hochschuleigene Auswahl das FieldSet zum Status der Aufnahmepr&uuml;fung eingeblendet.
                     */
                    EDIT_SELECTION_CRITERIA_CONFIGURATION_ENTRANCE_EXAM_STATUS("cm.app.edit.selection_criteria.configuration.entrance_exam_status"),
                    /**
                     * <p><strong>Benutzung der neuen Sachbearbeitung f&uuml;r Online-Bewerber.</strong></p>
                     * Confkey: cm.app.edit.use_new_application_processing<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Umschalten zwischen neuer und alter Bewerbungs-Sachbearbeitung. Das Einstellen von TRUE bewirkt, dass die neue Sachbearbeitungsmasken genutzt werden. FALSE aktiviert die alte Sachbearbeitung
                     */
                    EDIT_USE_NEW_APPLICATION_PROCESSING("cm.app.edit.use_new_application_processing"),
                    /**
                     * <p><strong>Validierung der Fachsemester-Einschr&auml;nkungen f&uuml;r Bewerbung/Einschreibung.</strong></p>
                     * Confkey: cm.app.edit.validate_studysemesterrestrictions<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Validierung der Fachsemester-Einschr&auml;nkungen f&uuml;r Bewerbung/Einschreibung in der Sachbearbeitefunktion
                     */
                    EDIT_VALIDATE_STUDYSEMESTERRESTRICTIONS("cm.app.edit.validate_studysemesterrestrictions"),                  
                    /**
                     * <p><strong>EntranceQualificationType, der f&uuml;r besondere HZB gesetzt werden soll.</strong></p>
                     * Confkey: cm.app.headmissiontype.specialheadmissiontypeid<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: ACHTUNG: Der gew&auml;hlte EntranceQualificationType muss in der Untermenge der HZB-Arten, die einem Bewerber in der Onlinebewerbung zur Auswahl stehen, enthalten sein.
                     */
                    HEADMISSIONTYPE_SPECIALHEADMISSIONTYPEID("cm.app.headmissiontype.specialheadmissiontypeid"),
                    /**
                     * <p><strong>Untermenge von HZB-Arten.</strong></p>
                     * Confkey: cm.app.headmissiontype.subset<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: HZB-Arten, die einem Bewerber in der Online-Bewerbung zur Auswahl stehen (Statistik-Schl&uuml;ssel).
                     */
                    HEADMISSIONTYPE_SUBSET("cm.app.headmissiontype.subset"),
                    /**
                     * <p><strong>Auskunft (1).</strong></p>
                     * Confkey: cm.app.person.info1<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: Auskunftsperson (1) f&uuml;r Bewerber
                     */
                    PERSON_INFO1("cm.app.person.info1"),
                    /**
                     * <p><strong>Auskunft (2).</strong></p>
                     * Confkey: cm.app.person.info2<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: Auskunftsperson (2) f&uuml;r Bewerber
                     */
                    PERSON_INFO2("cm.app.person.info2"),
                    /**
                     * <p><strong>Max. Antr&auml;ge.</strong></p>
                     * Confkey: cm.app.requests.number_of_requests.administration<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Maximale Anzahl an Antr&auml;gen, die ein Bewerber in der Online-Bewerbung abgeben darf. Unabh&auml;ngig von dieser Anzahl darf der Bewerber beliebig viele Antr&auml;ge im Status in Vorbereitung oder zur&uuml;ckgezogen anlegen. Falls &uuml;ber Zulassungspakete die Verwendung von Haupt-/Hilfsantr&auml;gen konfiguriert ist, wird die Gruppe von abgegebenen Haupt-/Hilfsantr&auml;gen f&uuml;r die Z&auml;hlung der Antr&auml;ge als ein einziger Antrag ber&uuml;cksichtigt (Hauptantrag + Hilfsantrag + 2 Parallelantr&auml;ge = 3 abgegebene Antr&auml;ge).
                     */
                    REQUESTS_NUMBER_OF_REQUESTS_ADMINISTRATION("cm.app.requests.number_of_requests.administration"),
                    /**
                     * <p><strong>einfache Erfassung des geleisteten Dienstes.</strong></p>
                     * Confkey: cm.app.service.simple<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Erfassen des geleisteten Dienstes als einfaches Ja/Nein Feld
                     */
                    SERVICE_SIMPLE("cm.app.service.simple"),
                    /**
                     * <p><strong>Teilnahme am Serviceverfahren f&uuml;r Hochschulzulassung.</strong></p>
                     * Confkey: cm.app.sest.active<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Aktivieren Sie bitte diesen Schalter, falls Sie am Serviceverfahren f&uuml;r Hochschulzulassung teilnehmen m&ouml;chten.
                     */
                    SEST_ACTIVE("cm.app.sest.active"),
                    /**
                     * <p><strong>Bewerbungsort.</strong></p>
                     * Confkey: cm.app.sest.bewerbungsort<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Ort, an dem eine Bewerbung f&uuml;r dieses Studienangebot abgegeben werden kann.
                     */
                    SEST_BEWERBUNGSORT("cm.app.sest.bewerbungsort"),
                    /**
                     * <p><strong>Servicestellen-Client Typ.</strong></p>
                     * Confkey: cm.app.sest.dosv.client_type<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Hier wird festgelegt, welche Art des Servicestellen-Clients f&uuml;r den Datenaustausch mit der Servicestelle verwendet werden soll. Entweder WebService oder keine Verbindung (nur manuell &uuml;ber WebGUI).
                     */
                    SEST_DOSV_CLIENT_TYPE("cm.app.sest.dosv.client_type"),
                    /**
                     * <p><strong>Zeitplan f&uuml;r das Nachladen von Stammdaten zu eingehenden Bewerbungen von der Servicestelle zur Hochschule.</strong></p>
                     * Confkey: cm.app.sest.dosv.jobs.dediziertebewerberdatenjobtrigger<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Zeitplan f&uuml;r das Nachladen von Stammdaten zu eingehenden Bewerbungen von der Servicestelle zur Hochschule in Form einer cron-expression (siehe http://www.quartz-scheduler.org/docs/tutorials/crontrigger.html)
                     */
                    SEST_DOSV_JOBS_DEDIZIERTEBEWERBERDATENJOBTRIGGER("cm.app.sest.dosv.jobs.dediziertebewerberdatenjobtrigger"),
                    /**
                     * <p><strong>Zeitplan f&uuml;r die &Uuml;bertragung ge&auml;nderter Bewerbungen von der Hochschule zur Servicestelle.</strong></p>
                     * Confkey: cm.app.sest.dosv.jobs.geaendertebewerbungenhssestjobtrigger<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Zeitplan f&uuml;r die &Uuml;bertragung ge&auml;nderter Bewerbungen von der Hochschule zur Servicestelle in Form einer cron-expression. (siehe http://www.quartz-scheduler.org/docs/tutorials/crontrigger.html)
                     */
                    SEST_DOSV_JOBS_GEAENDERTEBEWERBUNGENHSSESTJOBTRIGGER("cm.app.sest.dosv.jobs.geaendertebewerbungenhssestjobtrigger"),
                    /**
                     * <p><strong>Zeitplan f&uuml;r die &Uuml;bertragung neuer Bewerbungen von der Hochschule zur Servicestelle.</strong></p>
                     * Confkey: cm.app.sest.dosv.jobs.neuebewerbungenhssestjobtrigger<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Zeitplan f&uuml;r die &Uuml;bertragung neuer Bewerbungen von der Hochschule zur Servicestelle in Form einer cron-expression. (siehe http://www.quartz-scheduler.org/docs/tutorials/crontrigger.html)
                     */
                    SEST_DOSV_JOBS_NEUEBEWERBUNGENHSSESTJOBTRIGGER("cm.app.sest.dosv.jobs.neuebewerbungenhssestjobtrigger"),
                    /**
                     * <p><strong>Zeitplan f&uuml;r den Abgleich von Bewerbungen und Stammdaten zwischen der Servicestelle und Hochschule.</strong></p>
                     * Confkey: cm.app.sest.dosv.jobs.prozessorientierterbewerbungjobtrigger<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Zeitplan f&uuml;r den Abgleich von Bewerbungen und Stammdaten zwischen der Servicestelle und Hochschule in Form einer cron-expression (siehe http://www.quartz-scheduler.org/docs/tutorials/crontrigger.html)
                     */
                    SEST_DOSV_JOBS_PROZESSORIENTIERTERBEWERBUNGJOBTRIGGER("cm.app.sest.dosv.jobs.prozessorientierterbewerbungjobtrigger"),
                    /**
                     * <p><strong>Zeitplan f&uuml;r das Entfernen von veralteten Protokollen.</strong></p>
                     * Confkey: cm.app.sest.dosv.jobs.removestaleprotocolsjobtrigger<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Zeitplan f&uuml;r das Entfernen von veralteten Protokollen in Form einer cron-expression. (siehe http://www.quartz-scheduler.org/docs/tutorials/crontrigger.html)
                     */
                    SEST_DOSV_JOBS_REMOVESTALEPROTOCOLSJOBTRIGGER("cm.app.sest.dosv.jobs.removestaleprotocolsjobtrigger"),
                    /**
                     * <p><strong>Zeitplan f&uuml;r die Entfernung von Bewerberautorisierungsnummern, die nicht mehr ben&ouml;tigt werden.</strong></p>
                     * Confkey: cm.app.sest.dosv.jobs.removeunusedbanjobtrigger<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Zeitplan f&uuml;r die Entfernung von Bewerberautorisierungsnummern, die nicht mehr ben&ouml;tigt werden in Form einer cron-expression (siehe http://www.quartz-scheduler.org/docs/tutorials/crontrigger.html)
                     */
                    SEST_DOSV_JOBS_REMOVEUNUSEDBANJOBTRIGGER("cm.app.sest.dosv.jobs.removeunusedbanjobtrigger"),
                    /**
                     * <p><strong>Zeitplan f&uuml;r den Versand von Protokollmails.</strong></p>
                     * Confkey: cm.app.sest.dosv.jobs.sendprotocolmailsjobtrigger<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Zeitplan f&uuml;r den Versand von Protokollmailsin Form einer cron-expression. (siehe http://www.quartz-scheduler.org/docs/tutorials/crontrigger.html)
                     */
                    SEST_DOSV_JOBS_SENDPROTOCOLMAILSJOBTRIGGER("cm.app.sest.dosv.jobs.sendprotocolmailsjobtrigger"),
                    /**
                     * <p><strong>Zeitplan f&uuml;r die &Uuml;bertragung Stammdaten von der Servicestelle zur Hochschule.</strong></p>
                     * Confkey: cm.app.sest.dosv.jobs.stammdatenjobtrigger<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Zeitplan f&uuml;r die &Uuml;bertragung Stammdaten von der Servicestelle zur Hochschule in Form einer cron-expression (siehe http://www.quartz-scheduler.org/docs/tutorials/crontrigger.html)
                     */
                    SEST_DOSV_JOBS_STAMMDATENJOBTRIGGER("cm.app.sest.dosv.jobs.stammdatenjobtrigger"),
                    /**
                     * <p><strong>E-Mail Adressen der Bewerber Manager.</strong></p>
                     * Confkey: cm.app.sest.dosv.mail.bewerber_manager_mail_adressen<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Mehrere E-Mail Adressen k&ouml;nnen kommasepariert eingegeben werden. Wenn dieses Feld leer ist, ist die E-Mail Versendefunktion deaktiviert.
                     */
                    SEST_DOSV_MAIL_BEWERBER_MANAGER_MAIL_ADRESSEN("cm.app.sest.dosv.mail.bewerber_manager_mail_adressen"),
                    /**
                     * <p><strong>Absender E-Mail Adresse.</strong></p>
                     * Confkey: cm.app.sest.dosv.mail.from_mail_adresse<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: 
                     */
                    SEST_DOSV_MAIL_FROM_MAIL_ADRESSE("cm.app.sest.dosv.mail.from_mail_adresse"),
                    /**
                     * <p><strong>SMTP Host.</strong></p>
                     * Confkey: cm.app.sest.dosv.mail.smtp_host<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: 
                     */
                    SEST_DOSV_MAIL_SMTP_HOST("cm.app.sest.dosv.mail.smtp_host"),
                    /**
                     * <p><strong>SMTP Passwort.</strong></p>
                     * Confkey: cm.app.sest.dosv.mail.smtp_password<br/>
                     * ParameterType: PASSWORD_PLAINTEXT<br/>
                     * <br/>
                     * Info: 
                     */
                    SEST_DOSV_MAIL_SMTP_PASSWORD("cm.app.sest.dosv.mail.smtp_password"),
                    /**
                     * <p><strong>SMTP Port.</strong></p>
                     * Confkey: cm.app.sest.dosv.mail.smtp_port<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: 
                     */
                    SEST_DOSV_MAIL_SMTP_PORT("cm.app.sest.dosv.mail.smtp_port"),
                    /**
                     * <p><strong>SMTP User.</strong></p>
                     * Confkey: cm.app.sest.dosv.mail.smtp_user<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: 
                     */
                    SEST_DOSV_MAIL_SMTP_USER("cm.app.sest.dosv.mail.smtp_user"),
                    /**
                     * <p><strong>Segmentierungsgr&ouml;&szlig;e f&uuml;r Datens&auml;tze bei der Webservice&uuml;bertragung.</strong></p>
                     * Confkey: cm.app.sest.dosv.webservice.max_chunk_size<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Segmentierungsgr&ouml;&szlig;e f&uuml;r Datens&auml;tze bei der Bewerbungs- und Ranglisten&uuml;bertragung mit Webservice.
                     */
                    SEST_DOSV_WEBSERVICE_MAX_CHUNK_SIZE("cm.app.sest.dosv.webservice.max_chunk_size"),
                    /**
                     * <p><strong>Webservice-Passwort.</strong></p>
                     * Confkey: cm.app.sest.dosv.webservice.password<br/>
                     * ParameterType: PASSWORD_PLAINTEXT<br/>
                     * <br/>
                     * Info: Passwort f&uuml;r die Webservice-Schnittstelle. IInformation wird von hochschulstart.de zur Verf&uuml;gung gestellt. Das Passwort muss plaintext hinterlegt werden. Dieses wird bei der &Uuml;bertragung zur Servicestelle per HTTPS gesichert.
                     */
                    SEST_DOSV_WEBSERVICE_PASSWORD("cm.app.sest.dosv.webservice.password"),
                    /**
                     * <p><strong>Proxy Authentifizierung.</strong></p>
                     * Confkey: cm.app.sest.dosv.webservice.proxyauth<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Schaltet die Proxy Authentifizierung ein oder aus. Die Authentifizierungsdaten werden aus der DispatcherProperties.txt gelesen (HTTP_PROXY_HOST, HTTP_PROXY_PORT, HTTP_PROXY_USERNAME und HTTP_PROXY_PASSWORD).
                     */
                    SEST_DOSV_WEBSERVICE_PROXYAUTH("cm.app.sest.dosv.webservice.proxyauth"),
                    /**
                     * <p><strong>Webservice Timeout.</strong></p>
                     * Confkey: cm.app.sest.dosv.webservice.timeout<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Beinhaltet den Timeout f&uuml;r den Webservice in Millisekunden.
                     */
                    SEST_DOSV_WEBSERVICE_TIMEOUT("cm.app.sest.dosv.webservice.timeout"),
                    /**
                     * <p><strong>Webservice-Url.</strong></p>
                     * Confkey: cm.app.sest.dosv.webservice.url<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Die Webservice-URL der Servicestelle wird von hochschulstart.de zur Verf&uuml;gung gestellt. Die URL muss mit https:// beginnen und mit einem abschlie&szlig;enden Schr&auml;gstrich enden. Beispiel: https://servicestellenserver/hochschule/webservice/2/
                     */
                    SEST_DOSV_WEBSERVICE_URL("cm.app.sest.dosv.webservice.url"),
                    /**
                     * <p><strong>Webservice-User.</strong></p>
                     * Confkey: cm.app.sest.dosv.webservice.user<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Benutzername f&uuml;r die Webservice-Schnittstelle. Information wird von hochschulstart.de zur Verf&uuml;gung gestellt.
                     */
                    SEST_DOSV_WEBSERVICE_USER("cm.app.sest.dosv.webservice.user"),
                    /**
                     * <p><strong>Erfassung der HZB-ID.</strong></p>
                     * Confkey: cm.app.sest.entrance_qualification_id<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Gibt an, ob die HZB-ID der Servicestelle in der Online-Bewerbung erfasst werden soll.
                     */
                    SEST_ENTRANCE_QUALIFICATION_ID("cm.app.sest.entrance_qualification_id"),
                    /**
                     * <p><strong>Hochschuleigene Kriterien &uuml;bertragen.</strong></p>
                     * Confkey: cm.app.sest.hochschuleigene_kriterien_uebertragen<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Gibt an, ob die hochschuleigenen Kriterien an die Servicestelle &uuml;bertragen werden sollen.
                     */
                    SEST_HOCHSCHULEIGENE_KRITERIEN_UEBERTRAGEN("cm.app.sest.hochschuleigene_kriterien_uebertragen"),
                    /**
                     * <p><strong>Hochschulnummer.</strong></p>
                     * Confkey: cm.app.sest.hochschulnummer<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Wenn hier ein Wert gesetzt ist, so wird dieser Wert f&uuml;r die Hochschulnummer bei der DoSV-Daten&uuml;bertragung verwendet. Ist dieser Wert<br />         nicht gesetzt, so wird bei der Daten&uuml;bertragung die Hochschulnummer aus der Datenbank verwendet.
                     */
                    SEST_HOCHSCHULNUMMER("cm.app.sest.hochschulnummer"),
                    /**
                     * <p><strong>HZB-Pr&uuml;fung gew&uuml;nscht.</strong></p>
                     * Confkey: cm.app.sest.hzbpruefung_gewuenscht<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Gibt an, ob die Hochschule f&uuml;r Bewerbungen auf dieses Studienangebot, die Echtheitspr&uuml;fung zugeordneter HZBen durchdie Servicestelle benutzen m&ouml;chte; hierzu wird der Bewerber aufgefordert einerseits auch bei einer dezentralen Bewerbung eine HZB-Zuordnung vorzunehmen und andererseits f&uuml;r jede zugeordnete HZB eine beglaubigte Kopie an die Servicestelle zu senden.
                     */
                    SEST_HZBPRUEFUNG_GEWUENSCHT("cm.app.sest.hzbpruefung_gewuenscht"),
                    /**
                     * <p><strong>URL zum Bewerberportal der Servicestelle.</strong></p>
                     * Confkey: cm.app.sest.portalurl<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Die URL zum Bewerberportal der Servicestelle
                     */
                    SEST_PORTALURL("cm.app.sest.portalurl"),
                    /**
                     * <p><strong>Jahr des Serviceverfahrens.</strong></p>
                     * Confkey: cm.app.sest.serviceverfahren.jahr<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Dies ist der Default-Wert f&uuml;r das Jahr des Serviceverfahrens und gilt f&uuml;r alle SAFs, wenn diese keine expliziten Werte gesetzt haben.
                     */
                    SEST_SERVICEVERFAHREN_JAHR("cm.app.sest.serviceverfahren.jahr"),
                    /**
                     * <p><strong>Bewerbungen und Bewerberstammdaten Serviceverfahren Jahr.</strong></p>
                     * Confkey: cm.app.sest.serviceverfahren.saf.bewerbungen_und_bewerberstammdaten_jahr<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Das Jahr des Serviceverfahrens f&uuml;r die SAFs zur &Uuml;bertragung von Bewerbungen und Bewerberstammdaten.
                     */
                    SEST_SERVICEVERFAHREN_SAF_BEWERBUNGEN_UND_BEWERBERSTAMMDATEN_JAHR("cm.app.sest.serviceverfahren.saf.bewerbungen_und_bewerberstammdaten_jahr"),
                    /**
                     * <p><strong>Bewerbungen und Bewerberstammdaten Serviceverfahren Semester.</strong></p>
                     * Confkey: cm.app.sest.serviceverfahren.saf.bewerbungen_und_bewerberstammdaten_semester<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Das Semester des Serviceverfahrens f&uuml;r die SAFs zur &Uuml;bertragung von Bewerbungen und Bewerberstammdaten.
                     */
                    SEST_SERVICEVERFAHREN_SAF_BEWERBUNGEN_UND_BEWERBERSTAMMDATEN_SEMESTER("cm.app.sest.serviceverfahren.saf.bewerbungen_und_bewerberstammdaten_semester"),
                    /**
                     * <p><strong>Bewerbungen und Bewerberstammdaten Vermittlungsprozess Typ.</strong></p>
                     * Confkey: cm.app.sest.serviceverfahren.saf.bewerbungen_und_bewerberstammdaten_vermittlungsprozess_typ<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Der Typ des Vermittlungsprozesses f&uuml;r die SAFs zur &Uuml;bertragung von Bewerbungen und Bewerberstammdaten.
                     */
                    SEST_SERVICEVERFAHREN_SAF_BEWERBUNGEN_UND_BEWERBERSTAMMDATEN_VERMITTLUNGSPROZESS_TYP("cm.app.sest.serviceverfahren.saf.bewerbungen_und_bewerberstammdaten_vermittlungsprozess_typ"),
                    /**
                     * <p><strong>Ranglisten Serviceverfahren Jahr.</strong></p>
                     * Confkey: cm.app.sest.serviceverfahren.saf.ranglisten_jahr<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Das Jahr des Serviceverfahrens f&uuml;r die SAFs zur &Uuml;bertragung von Ranglisten.
                     */
                    SEST_SERVICEVERFAHREN_SAF_RANGLISTEN_JAHR("cm.app.sest.serviceverfahren.saf.ranglisten_jahr"),
                    /**
                     * <p><strong>Ranglisten Serviceverfahren Semester.</strong></p>
                     * Confkey: cm.app.sest.serviceverfahren.saf.ranglisten_semester<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Das Semester des Serviceverfahrens f&uuml;r die SAFs zur &Uuml;bertragung von Ranglisten.
                     */
                    SEST_SERVICEVERFAHREN_SAF_RANGLISTEN_SEMESTER("cm.app.sest.serviceverfahren.saf.ranglisten_semester"),
                    /**
                     * <p><strong>Ranglisten Vermittlungsprozess Typ.</strong></p>
                     * Confkey: cm.app.sest.serviceverfahren.saf.ranglisten_vermittlungsprozess_typ<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Der Typ des Vermittlungsprozesses f&uuml;r die SAFs zur &Uuml;bertragung von Ranglisten.
                     */
                    SEST_SERVICEVERFAHREN_SAF_RANGLISTEN_VERMITTLUNGSPROZESS_TYP("cm.app.sest.serviceverfahren.saf.ranglisten_vermittlungsprozess_typ"),
                    /**
                     * <p><strong>Studienangebote Serviceverfahren Jahr.</strong></p>
                     * Confkey: cm.app.sest.serviceverfahren.saf.studienangebote_jahr<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Das Jahr des Serviceverfahrens f&uuml;r die SAFs zur &Uuml;bertragung von Studienangeboten.
                     */
                    SEST_SERVICEVERFAHREN_SAF_STUDIENANGEBOTE_JAHR("cm.app.sest.serviceverfahren.saf.studienangebote_jahr"),
                    /**
                     * <p><strong>Studienangebote Serviceverfahren Semester.</strong></p>
                     * Confkey: cm.app.sest.serviceverfahren.saf.studienangebote_semester<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Das Semester des Serviceverfahrens f&uuml;r die SAFs zur &Uuml;bertragung von Studienangeboten.
                     */
                    SEST_SERVICEVERFAHREN_SAF_STUDIENANGEBOTE_SEMESTER("cm.app.sest.serviceverfahren.saf.studienangebote_semester"),
                    /**
                     * <p><strong>Studienangebote Vermittlungsprozess Typ.</strong></p>
                     * Confkey: cm.app.sest.serviceverfahren.saf.studienangebote_vermittlungsprozess_typ<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Der Typ des Vermittlungsprozesses f&uuml;r die SAFs zur &Uuml;bertragung von Studienangeboten.
                     */
                    SEST_SERVICEVERFAHREN_SAF_STUDIENANGEBOTE_VERMITTLUNGSPROZESS_TYP("cm.app.sest.serviceverfahren.saf.studienangebote_vermittlungsprozess_typ"),
                    /**
                     * <p><strong>Semester.</strong></p>
                     * Confkey: cm.app.sest.serviceverfahren.semester<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Semester des Serviceverfahrens. Dieser Wert ist der Default-Wert f&uuml;r alle SAFs, falls diese keine expliziten Werte gesetzt haben.
                     */
                    SEST_SERVICEVERFAHREN_SEMESTER("cm.app.sest.serviceverfahren.semester"),
                    /**
                     * <p><strong>Vermittlungsprozess Typ.</strong></p>
                     * Confkey: cm.app.sest.serviceverfahren.vermittlungsprozess_typ<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Der Typ des Vermittlungsprozesses. Dieser Wert ist Default-Wert f&uuml;r alle SAFs.
                     */
                    SEST_SERVICEVERFAHREN_VERMITTLUNGSPROZESS_TYP("cm.app.sest.serviceverfahren.vermittlungsprozess_typ"),
                    /**
                     * <p><strong>URL des Hochschulbewerbungsportals.</strong></p>
                     * Confkey: cm.app.sest.url_hs_bewerbungsportal<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Gibt die URL zum Bewerbungsportal der Hochschule an.
                     */
                    SEST_URL_HS_BEWERBUNGSPORTAL("cm.app.sest.url_hs_bewerbungsportal"),
                    /**
                     * <p><strong>URL zu den Zulassungskriterien.</strong></p>
                     * Confkey: cm.app.sest.url_zulassungskriterium<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Gibt die URL zu den Zulassungskriterien der Hochschule an.
                     */
                    SEST_URL_ZULASSUNGSKRITERIUM("cm.app.sest.url_zulassungskriterium"),
                    /**
                     * <p><strong>Serviceverfahren Art.</strong></p>
                     * Confkey: cm.app.sest.verfahren_type<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Gibt an, ob ein dezentrales oder zentrales DoS-Verfahren verwendet werden soll.
                     */
                    SEST_VERFAHREN_TYPE("cm.app.sest.verfahren_type"),
                    /**
                     * <p><strong>Versandart von R&uuml;ckstellungsbescheiden.</strong></p>
                     * Confkey: cm.app.sest.versandtart_rueckstellungsbescheid<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Art, auf die R&uuml;ckstellungsbescheide versandt werden.
                     */
                    SEST_VERSANDTART_RUECKSTELLUNGSBESCHEID("cm.app.sest.versandtart_rueckstellungsbescheid"),
                    /**
                     * <p><strong>Versandart von Zulassungsbescheiden.</strong></p>
                     * Confkey: cm.app.sest.versandtart_zulassungsbescheid<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Art, auf die Zulassungsbescheide f&uuml;r Studienangebote versandt werden.
                     */
                    SEST_VERSANDTART_ZULASSUNGSBESCHEID("cm.app.sest.versandtart_zulassungsbescheid"),
                    /**
                     * <p><strong>Beschreibung der Zulassungskriterien..</strong></p>
                     * Confkey: cm.app.sest.zulassungskriterium_text<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Beschreibung der Zulassungskriterien f&uuml;r das Clearing Verfahren.
                     */
                    SEST_ZULASSUNGSKRITERIUM_TEXT("cm.app.sest.zulassungskriterium_text")
                    ;
            
            
                    /** The key. */
                    private final String key;
            
                    /**
                     * Constructor taking the global configuration parameter key.
                     */
                    private APP(String key) {
                        this.key = key;
                    }
            
                    @Override
                    public String getKey() {
                         return this.key;
                    }
                }
            
                /**
                 * Produktbereich: EXA.
                 */
                public static enum EXA implements KeyEnum<String>, Key {
                    /**
                     * <p><strong>14-t&auml;glich.</strong></p>
                     * Confkey: cm.exa.course.colors.rhythm.quantity_14_hisrule_1<br/>
                     * ParameterType: COLOR<br/>
                     * <br/>
                     * Info: 
                     */
                    COURSE_COLORS_RHYTHM_QUANTITY_14_HISRULE_1("cm.exa.course.colors.rhythm.quantity_14_hisrule_1"),
                    /**
                     * <p><strong>gerade Woche.</strong></p>
                     * Confkey: cm.exa.course.colors.rhythm.quantity_14_hisrule_6<br/>
                     * ParameterType: COLOR<br/>
                     * <br/>
                     * Info: Quantity 14 und Hisrule 6
                     */
                    COURSE_COLORS_RHYTHM_QUANTITY_14_HISRULE_6("cm.exa.course.colors.rhythm.quantity_14_hisrule_6"),
                    /**
                     * <p><strong>ungerade Woche.</strong></p>
                     * Confkey: cm.exa.course.colors.rhythm.quantity_14_hisrule_7<br/>
                     * ParameterType: COLOR<br/>
                     * <br/>
                     * Info: Quantity 14 und Hisrule 7
                     */
                    COURSE_COLORS_RHYTHM_QUANTITY_14_HISRULE_7("cm.exa.course.colors.rhythm.quantity_14_hisrule_7"),
                    /**
                     * <p><strong>Blockveranstaltung + Sa und So.</strong></p>
                     * Confkey: cm.exa.course.colors.rhythm.quantity_1_hisrule_1<br/>
                     * ParameterType: COLOR<br/>
                     * <br/>
                     * Info: 
                     */
                    COURSE_COLORS_RHYTHM_QUANTITY_1_HISRULE_1("cm.exa.course.colors.rhythm.quantity_1_hisrule_1"),
                    /**
                     * <p><strong>jeder 1. Wochentag im Monat.</strong></p>
                     * Confkey: cm.exa.course.colors.rhythm.quantity_1_hisrule_2<br/>
                     * ParameterType: COLOR<br/>
                     * <br/>
                     * Info: Quantity 1 und Hisrule 2
                     */
                    COURSE_COLORS_RHYTHM_QUANTITY_1_HISRULE_2("cm.exa.course.colors.rhythm.quantity_1_hisrule_2"),
                    /**
                     * <p><strong>Einzeltermin.</strong></p>
                     * Confkey: cm.exa.course.colors.rhythm.quantity_1_hisrule_3<br/>
                     * ParameterType: COLOR<br/>
                     * <br/>
                     * Info: Quantity 1 und Hisrule 3
                     */
                    COURSE_COLORS_RHYTHM_QUANTITY_1_HISRULE_3("cm.exa.course.colors.rhythm.quantity_1_hisrule_3"),
                    /**
                     * <p><strong>Blockveranstaltung + Sa.</strong></p>
                     * Confkey: cm.exa.course.colors.rhythm.quantity_1_hisrule_4<br/>
                     * ParameterType: COLOR<br/>
                     * <br/>
                     * Info: 
                     */
                    COURSE_COLORS_RHYTHM_QUANTITY_1_HISRULE_4("cm.exa.course.colors.rhythm.quantity_1_hisrule_4"),
                    /**
                     * <p><strong>Blockveranstaltung.</strong></p>
                     * Confkey: cm.exa.course.colors.rhythm.quantity_1_hisrule_5<br/>
                     * ParameterType: COLOR<br/>
                     * <br/>
                     * Info: 
                     */
                    COURSE_COLORS_RHYTHM_QUANTITY_1_HISRULE_5("cm.exa.course.colors.rhythm.quantity_1_hisrule_5"),
                    /**
                     * <p><strong>dreiw&ouml;chentlich.</strong></p>
                     * Confkey: cm.exa.course.colors.rhythm.quantity_21_hisrule_1<br/>
                     * ParameterType: COLOR<br/>
                     * <br/>
                     * Info: Quantity 21 und Hisrule 1
                     */
                    COURSE_COLORS_RHYTHM_QUANTITY_21_HISRULE_1("cm.exa.course.colors.rhythm.quantity_21_hisrule_1"),
                    /**
                     * <p><strong>vierw&ouml;chentlich.</strong></p>
                     * Confkey: cm.exa.course.colors.rhythm.quantity_28_hisrule_1<br/>
                     * ParameterType: COLOR<br/>
                     * <br/>
                     * Info: Quantity 28 und Hisrule 1
                     */
                    COURSE_COLORS_RHYTHM_QUANTITY_28_HISRULE_1("cm.exa.course.colors.rhythm.quantity_28_hisrule_1"),
                    /**
                     * <p><strong>jeder 2. Wochentag im Monat.</strong></p>
                     * Confkey: cm.exa.course.colors.rhythm.quantity_2_hisrule_2<br/>
                     * ParameterType: COLOR<br/>
                     * <br/>
                     * Info: Quantity 2 und Hisrule 2
                     */
                    COURSE_COLORS_RHYTHM_QUANTITY_2_HISRULE_2("cm.exa.course.colors.rhythm.quantity_2_hisrule_2"),
                    /**
                     * <p><strong>jeder 3. Wochentag im Monat.</strong></p>
                     * Confkey: cm.exa.course.colors.rhythm.quantity_3_hisrule_2<br/>
                     * ParameterType: COLOR<br/>
                     * <br/>
                     * Info: Quantity 3 und Hisrule 2
                     */
                    COURSE_COLORS_RHYTHM_QUANTITY_3_HISRULE_2("cm.exa.course.colors.rhythm.quantity_3_hisrule_2"),
                    /**
                     * <p><strong>jeder 4. Wochentag im Monat.</strong></p>
                     * Confkey: cm.exa.course.colors.rhythm.quantity_4_hisrule_2<br/>
                     * ParameterType: COLOR<br/>
                     * <br/>
                     * Info: Quantity 4 und Hisrule 2
                     */
                    COURSE_COLORS_RHYTHM_QUANTITY_4_HISRULE_2("cm.exa.course.colors.rhythm.quantity_4_hisrule_2"),
                    /**
                     * <p><strong>w&ouml;chentlich.</strong></p>
                     * Confkey: cm.exa.course.colors.rhythm.quantity_7_hisrule_1<br/>
                     * ParameterType: COLOR<br/>
                     * <br/>
                     * Info: 
                     */
                    COURSE_COLORS_RHYTHM_QUANTITY_7_HISRULE_1("cm.exa.course.colors.rhythm.quantity_7_hisrule_1"),
                    /**
                     * <p><strong>Von.</strong></p>
                     * Confkey: cm.exa.course.term_from<br/>
                     * ParameterType: TERM<br/>
                     * <br/>
                     * Info: Veranstaltungen Zeitabschnittauswahl
                     */
                    COURSE_TERM_FROM("cm.exa.course.term_from"),
                    /**
                     * <p><strong>Bis.</strong></p>
                     * Confkey: cm.exa.course.term_to<br/>
                     * ParameterType: TERM<br/>
                     * <br/>
                     * Info: Veranstaltungen Zeitabschnittauswahl
                     */
                    COURSE_TERM_TO("cm.exa.course.term_to"),
                    /**
                     * <p><strong>Aktivierung der Auswertung der neuen Studiengangsstruktur.</strong></p>
                     * Confkey: cm.exa.curricula.studies.active<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    CURRICULA_STUDIES_ACTIVE("cm.exa.curricula.studies.active"),
                    /**
                     * <p><strong>Unterschiedliche Abschl&uuml;sse f&uuml;r verschiedene Studiengangkombinationen.</strong></p>
                     * Confkey: cm.exa.curricula.studies.allows_different_degrees_for_course_of_study_combinations<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Erlaubt das Anlegen von unterschiedlichen Abschl&uuml;ssen f&uuml;r verschiedene Studiengangkombinationen, z.B Teilstudiengang A in Verbindung mit Teilstudiengang B ergibt einen Bachelor of Science, A und C dagegen einen Bachelor of Arts.
                     */
                    CURRICULA_STUDIES_ALLOWS_DIFFERENT_DEGREES_FOR_COURSE_OF_STUDY_COMBINATIONS("cm.exa.curricula.studies.allows_different_degrees_for_course_of_study_combinations"),
                    /**
                     * <p><strong>Studiengangsvarianten f&uuml;r Teilstudieng&auml;nge anlegen.</strong></p>
                     * Confkey: cm.exa.curricula.studies.create_variation<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Erlaubt das Anlegen von Studiengangsvarianten f&uuml;r Teilstudieng&auml;nge wenn sich Pr&uuml;fungsordnungen/Modulhandb&uuml;cher je nach gew&auml;hlter Teilstudienganskombination unterscheiden. Dadurch ist es m&ouml;glich Teilstudieng&auml;nge mit der gleichen Merkmalskombination als Varianten anzulegen.
                     */
                    CURRICULA_STUDIES_CREATE_VARIATION("cm.exa.curricula.studies.create_variation"),
                    /**
                     * <p><strong>Deaktivierte L&ouml;schenbuttons in Ergebnisliste.</strong></p>
                     * Confkey: cm.exa.curricula.studies.show_delete_messages_in_list<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll beim Laden der Ergebnisliste von Studieng&auml;ngen sofort gepr&uuml;ft werden ob ein Studiengang l&ouml;schbar ist?(Langsamer - X wird ausgegraut und Verkn&uuml;pfungen angezeigt)
                     */
                    CURRICULA_STUDIES_SHOW_DELETE_MESSAGES_IN_LIST("cm.exa.curricula.studies.show_delete_messages_in_list"),
                    /**
                     * <p><strong>Konfiguration des Services f&uuml;r Mehrfachstudieng&auml;nge.</strong></p>
                     * Confkey: cm.exa.curricula.studies.study_combinations_service<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Geben Sie hier die vollst&auml;ndige URL zum Service an.
                     */
                    CURRICULA_STUDIES_STUDY_COMBINATIONS_SERVICE("cm.exa.curricula.studies.study_combinations_service"),
                    /**
                     * <p><strong>Studiengangshierarchie f&uuml;r den Bereich ALU.</strong></p>
                     * Confkey: cm.exa.curricula.studies.usage.alu<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Uniquename des Einstiegs-/Wurzelknotens der ALU-Studiengangshierarchie
                     */
                    CURRICULA_STUDIES_USAGE_ALU("cm.exa.curricula.studies.usage.alu"),
                    /**
                     * <p><strong>Studiengangshierarchie f&uuml;r den Bereich APP.</strong></p>
                     * Confkey: cm.exa.curricula.studies.usage.app<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Uniquename des Einstiegs-/Wurzelknotens der APP-Studiengangshierarchie
                     */
                    CURRICULA_STUDIES_USAGE_APP("cm.exa.curricula.studies.usage.app"),
                    /**
                     * <p><strong>Automatische Generierung von Veranstaltungsnummern.</strong></p>
                     * Confkey: cm.exa.curricula.unit.generate_event_number<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Schaltet die automatische Generierung von Nummern beim Anlegen von Veranstaltungsplatzhaltern ein. Die eingetragene Zahl legt den Startwert fest. Die 0 oder ein leeres Feld schaltet die Generierung aus.
                     */
                    CURRICULA_UNIT_GENERATE_EVENT_NUMBER("cm.exa.curricula.unit.generate_event_number"),
                    /**
                     * <p><strong>Deaktivierte L&ouml;schenbuttons in Ergebnisliste.</strong></p>
                     * Confkey: cm.exa.curricula.unit.show_delete_messages_in_list<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll beim Laden der Ergebnisliste von PO-Elementen sofort gepr&uuml;ft werden ob ein PO-Element l&ouml;schbar ist?(Langsamer - X wird ausgegraut und Verkn&uuml;pfungen angezeigt
                     */
                    CURRICULA_UNIT_SHOW_DELETE_MESSAGES_IN_LIST("cm.exa.curricula.unit.show_delete_messages_in_list"),
                    /**
                     * <p><strong>Deaktivierte L&ouml;schenbuttons in Strukturbaum.</strong></p>
                     * Confkey: cm.exa.curricula.unit.show_delete_messages_in_tree<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll beim Laden des Strukturbaums von PO-Elementen sofort gepr&uuml;ft werden ob ein PO-Element l&ouml;schbar ist?(Langsamer - X wird ausgegraut und Verkn&uuml;pfungen angezeigt
                     */
                    CURRICULA_UNIT_SHOW_DELETE_MESSAGES_IN_TREE("cm.exa.curricula.unit.show_delete_messages_in_tree"),
                    /**
                     * <p><strong>Verbuchung einer Abmeldung von einer zugelassenen Pr&uuml;fung oder Veranstaltung.</strong></p>
                     * Confkey: cm.exa.enrollment.studyplanner.cancelation<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Sofern eine Pr&uuml;fung oder Veranstaltung zugelassen ist, kann sich der Student selbst abmelden oder abgemeldet werden. Dieser Schalter gibt vor, in welcher Form die Daten gespeichert oder gel&ouml;scht werden.
                     */
                    ENROLLMENT_STUDYPLANNER_CANCELATION("cm.exa.enrollment.studyplanner.cancelation"),
                    /**
                     * <p><strong>Selektierbare Abschl&uuml;sse.</strong></p>
                     * Confkey: cm.exa.enrollment.studyplanner.degree_whitelist<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Positivliste von Abschlussk&uuml;rzeln. Ist diese Liste nicht leer, werden bei der Studiengangauswahl durch Studenten im Studienplaner nur genau die Studieng&auml;nge zur Auswahl angeboten, die zu einem der hier gelisteten Abschl&uuml;sse f&uuml;hren. Eine leere Liste erlaubt die Auswahl aller Studieng&auml;nge unabh&auml;ngig von deren Abschluss.
                     */
                    ENROLLMENT_STUDYPLANNER_DEGREE_WHITELIST("cm.exa.enrollment.studyplanner.degree_whitelist"),
                    /**
                     * <p><strong>Versteckte Elemente.</strong></p>
                     * Confkey: cm.exa.enrollment.studyplanner.hide_elementtypes<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: F&uuml;r gew&ouml;hnlich werden im Studienplaner sowohl Veranstaltungen als auch Pr&uuml;fungen angezeigt. Falls ein Elementtyp nicht im Baum erscheinen soll, kann hier die Anzeige deaktiviert werden.
                     */
                    ENROLLMENT_STUDYPLANNER_HIDE_ELEMENTTYPES("cm.exa.enrollment.studyplanner.hide_elementtypes"),
                    /**
                     * <p><strong>Studienplaner f&uuml;r nicht r&uuml;ckgemeldete Studieng&auml;nge verwenden.</strong></p>
                     * Confkey: cm.exa.enrollment.studyplanner.show_oldcourseofstudy<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Sofern ein Student mehrere Studieng&auml;nge studiert, kann festgelegt werden, ob er den Studienplaner f&uuml;r alle oder nur f&uuml;r aktuelle, d.h. f&uuml;r zuletzt r&uuml;ckgemeldete Studieng&auml;nge aufrufen darf
                     */
                    ENROLLMENT_STUDYPLANNER_SHOW_OLDCOURSEOFSTUDY("cm.exa.enrollment.studyplanner.show_oldcourseofstudy"),
                    /**
                     * <p><strong>Studiensemesterbezogene Anzeige.</strong></p>
                     * Confkey: cm.exa.enrollment.studyplanner.show_studysemester<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Der Studienplaner wird mit / ohne studiensemesterbezogene Anzeige genutzt.
                     */
                    ENROLLMENT_STUDYPLANNER_SHOW_STUDYSEMESTER("cm.exa.enrollment.studyplanner.show_studysemester"),
                    /**
                     * <p><strong>&Uuml;berpr&uuml;fung von Studiengangkonflikten.</strong></p>
                     * Confkey: cm.exa.eventprocess.course.checksudycourseconflict<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll beim Speichern einer Veranstaltung diese auf Konflikte mit anderen Veranstaltungen des selben Studiengangs gepr&uuml;ft werden?
                     */
                    EVENTPROCESS_COURSE_CHECKSUDYCOURSECONFLICT("cm.exa.eventprocess.course.checksudycourseconflict"),
                    /**
                     * <p><strong>Konflikt&uuml;berpr&uuml;fung f&uuml;r Pr&uuml;fungstermine.</strong></p>
                     * Confkey: cm.exa.eventprocess.roomconflictcheckforexaminations<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll eine Raum-Konflikt&uuml;berpr&uuml;fung f&uuml;r Pr&uuml;fungstermine stattfinden?
                     */
                    EVENTPROCESS_ROOMCONFLICTCHECKFOREXAMINATIONS("cm.exa.eventprocess.roomconflictcheckforexaminations"),
                    /**
                     * <p><strong>Anzahl der zuletzt bearbeiteten F&auml;lle.</strong></p>
                     * Confkey: cm.exa.examplan.recentsavedstudentssize<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Anzahl der zuletzt bearbeiteten F&auml;lle
                     */
                    EXAMPLAN_RECENTSAVEDSTUDENTSSIZE("cm.exa.examplan.recentsavedstudentssize"),
                    /**
                     * <p><strong>Verfahren der Notenfreigabe.</strong></p>
                     * Confkey: cm.exa.grading.disclosure_of_grades<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: 
                     */
                    GRADING_DISCLOSURE_OF_GRADES("cm.exa.grading.disclosure_of_grades"),
                    /**
                     * <p><strong>Ex/Import Spalten.</strong></p>
                     * Confkey: cm.exa.grading.eximport.csv.columns<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Spalten f&uuml;r den CSV Ex/Import
                     */
                    GRADING_EXIMPORT_CSV_COLUMNS("cm.exa.grading.eximport.csv.columns"),
                    /**
                     * <p><strong>Separator.</strong></p>
                     * Confkey: cm.exa.grading.eximport.csv.separator<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Separator f&uuml;r CSV Ex/Import
                     */
                    GRADING_EXIMPORT_CSV_SEPARATOR("cm.exa.grading.eximport.csv.separator"),
                    /**
                     * <p><strong>Spalten.</strong></p>
                     * Confkey: cm.exa.grading.eximport.excel.columns<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Ex/Import-Optionen f&uuml;r Excel
                     */
                    GRADING_EXIMPORT_EXCEL_COLUMNS("cm.exa.grading.eximport.excel.columns"),
                    /**
                     * <p><strong>Kopf.</strong></p>
                     * Confkey: cm.exa.grading.eximport.excel.exportheader<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: exportheader f&uuml;r Ex/Import-Optionen f&uuml;r Excel
                     */
                    GRADING_EXIMPORT_EXCEL_EXPORTHEADER("cm.exa.grading.eximport.excel.exportheader"),
                    /**
                     * <p><strong>Leere Bewertungen importieren.</strong></p>
                     * Confkey: cm.exa.grading.eximport.import_empty_grades<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Wird dieser Parameter eingeschaltet (true), dann werden auch leere Bewertungen importiert und dadurch ggf. vorhandene Bewertungen gel&ouml;scht
                     */
                    GRADING_EXIMPORT_IMPORT_EMPTY_GRADES("cm.exa.grading.eximport.import_empty_grades"),
                    /**
                     * <p><strong>Anzahl Zeilen.</strong></p>
                     * Confkey: cm.exa.grading.new_entry_count<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Anzahl leerer Zeilen in der Leistungsnacherfassung
                     */
                    GRADING_NEW_ENTRY_COUNT("cm.exa.grading.new_entry_count"),
                    /**
                     * <p><strong>Studieng&auml;nge anzeigen.</strong></p>
                     * Confkey: cm.exa.grading.showcourseofstudies<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Konfiguriert, ob die Studieng&auml;nge von Studierenden in der Leistungsbearbeitung und -nacherfassung angezeigt werden
                     */
                    GRADING_SHOWCOURSEOFSTUDIES("cm.exa.grading.showcourseofstudies"),
                    /**
                     * <p><strong>Standardg&uuml;ltigkeitsdauer.</strong></p>
                     * Confkey: cm.exa.internship.joboffer.defaultvalidityperiod<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Definiert die Standardg&uuml;ltigkeitsdauer f&uuml;r neue Praktikumsstellen in Tagen. Neue Praktikumsstellen sind standardm&auml;&szlig;ig immer in der Zeit vom aktuellen Datum + dem hier eingestellten Wert g&uuml;ltig. Ist kein Wert definiert, wird das Maximum f&uuml;r das Ende des G&uuml;ltigkeitszeitraumes angenommen.
                     */
                    INTERNSHIP_JOBOFFER_DEFAULTVALIDITYPERIOD("cm.exa.internship.joboffer.defaultvalidityperiod"),
                    /**
                     * <p><strong>Mindestanzahl an Leistungen.</strong></p>
                     * Confkey: cm.exa.report.ectscohort.min_examplans<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Wieviele Leistungen mu&szlig; eine Kohorte mindestens enthalten, damit sie gespeichert werden kann
                     */
                    REPORT_ECTSCOHORT_MIN_EXAMPLANS("cm.exa.report.ectscohort.min_examplans"),
                    /**
                     * <p><strong>Reports f&uuml;r EXA-Sachbearbeiter.</strong></p>
                     * Confkey: cm.exa.reports.reports_for_staff<br/>
                     * ParameterType: MANYSELECT_SRC<br/>
                     * <br/>
                     * Info: Reports f&uuml;r EXA-Sachbearbeiter
                     */
                    REPORTS_REPORTS_FOR_STAFF("cm.exa.reports.reports_for_staff"),
                    /**
                     * <p><strong>Bescheide f&uuml;r einen Studenten.</strong></p>
                     * Confkey: cm.exa.reports.reports_for_student<br/>
                     * ParameterType: MANYSELECT_SRC<br/>
                     * <br/>
                     * Info: Studentische Bescheide aus EXA f&uuml;r einen Studenten zum Selbstausdruck. Die Bescheide werden dem Studenten unter dem Men&uuml;punkt &quot;Meine Berichte&quot; angeboten.
                     */
                    REPORTS_REPORTS_FOR_STUDENT("cm.exa.reports.reports_for_student"),
                    /**
                     * <p><strong>Endzeit der Buchungsmaske.</strong></p>
                     * Confkey: cm.exa.rvs.default_bookingmask_endtime<br/>
                     * ParameterType: TIME<br/>
                     * <br/>
                     * Info: Endzeit der Buchungsmaske
                     */
                    RVS_DEFAULT_BOOKINGMASK_ENDTIME("cm.exa.rvs.default_bookingmask_endtime"),
                    /**
                     * <p><strong>Startzeit der Buchungsmaske.</strong></p>
                     * Confkey: cm.exa.rvs.default_bookingmask_starttime<br/>
                     * ParameterType: TIME<br/>
                     * <br/>
                     * Info: Startzeit der Buchungsmaske
                     */
                    RVS_DEFAULT_BOOKINGMASK_STARTTIME("cm.exa.rvs.default_bookingmask_starttime"),
                    /**
                     * <p><strong>Standard Buchungdauer in Minuten.</strong></p>
                     * Confkey: cm.exa.rvs.default_bookingtime_interval<br/>
                     * ParameterType: LONG<br/>
                     * <br/>
                     * Info: Standard Buchungdauer in Minuten
                     */
                    RVS_DEFAULT_BOOKINGTIME_INTERVAL("cm.exa.rvs.default_bookingtime_interval"),
                    /**
                     * <p><strong>Max. Turnus.</strong></p>
                     * Confkey: cm.exa.termtakeover.max_turnus<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Max. Wert f&uuml;r die turnusmaessige Semesteruebernahme
                     */
                    TERMTAKEOVER_MAX_TURNUS("cm.exa.termtakeover.max_turnus"),
                    /**
                     * <p><strong>Akademische Zeitangabe.</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.dates.academictime<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Akademische Zeitangabe
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_DATES_ACADEMICTIME("cm.exa.timetable.individualtimetable.content.dates.academictime"),
                    /**
                     * <p><strong>Datum von / bis.</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.dates.dates<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Datum von / bis
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_DATES_DATES("cm.exa.timetable.individualtimetable.content.dates.dates"),
                    /**
                     * <p><strong>Bemerkung zum Termin.</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.dates.notice<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Bemerkung zum Termin
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_DATES_NOTICE("cm.exa.timetable.individualtimetable.content.dates.notice"),
                    /**
                     * <p><strong>Rhythmus (Standardtext).</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.dates.rhythmdefaulttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Rhythmus (Standardtext)
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_DATES_RHYTHMDEFAULTTEXT("cm.exa.timetable.individualtimetable.content.dates.rhythmdefaulttext"),
                    /**
                     * <p><strong>Rhythmus (Langtext).</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.dates.rhythmlongtext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Rhythmus (Langtext)
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_DATES_RHYTHMLONGTEXT("cm.exa.timetable.individualtimetable.content.dates.rhythmlongtext"),
                    /**
                     * <p><strong>Rhythmus (Kurztext).</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.dates.rhythmshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Rhythmus (Kurztext)
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_DATES_RHYTHMSHORTTEXT("cm.exa.timetable.individualtimetable.content.dates.rhythmshorttext"),
                    /**
                     * <p><strong>Uhrzeit von / bis.</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.dates.time<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Uhrzeit von / bis
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_DATES_TIME("cm.exa.timetable.individualtimetable.content.dates.time"),
                    /**
                     * <p><strong>Wochentag.</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.dates.weekday<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Wochentag
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_DATES_WEEKDAY("cm.exa.timetable.individualtimetable.content.dates.weekday"),
                    /**
                     * <p><strong>Nummer.</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.event.elementnr<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Veranstaltungs oder Pr&uuml;fungsnummer
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_EVENT_ELEMENTNR("cm.exa.timetable.individualtimetable.content.event.elementnr"),
                    /**
                     * <p><strong>Veranstaltungsart.</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.event.eventtypedefaulttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Veranstaltungsart (Standardtext)
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_EVENT_EVENTTYPEDEFAULTTEXT("cm.exa.timetable.individualtimetable.content.event.eventtypedefaulttext"),
                    /**
                     * <p><strong>Veranstaltungsart.</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.event.eventtypelongtext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Veranstaltungsart (Langtext)
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_EVENT_EVENTTYPELONGTEXT("cm.exa.timetable.individualtimetable.content.event.eventtypelongtext"),
                    /**
                     * <p><strong>Veranstaltungsart.</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.event.eventtypeshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Veranstaltungsart (Kurztext)
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_EVENT_EVENTTYPESHORTTEXT("cm.exa.timetable.individualtimetable.content.event.eventtypeshorttext"),
                    /**
                     * <p><strong>Link zu den Details.</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.event.linktoeventdetails<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Link zu den Details
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_EVENT_LINKTOEVENTDETAILS("cm.exa.timetable.individualtimetable.content.event.linktoeventdetails"),
                    /**
                     * <p><strong>Parallelgruppe.</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.event.parallelgroupshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Parallelgruppe (Kurztext)
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_EVENT_PARALLELGROUPSHORTTEXT("cm.exa.timetable.individualtimetable.content.event.parallelgroupshorttext"),
                    /**
                     * <p><strong>Kommentar.</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.event.unitcomment<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Kommentar der Unit
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_EVENT_UNITCOMMENT("cm.exa.timetable.individualtimetable.content.event.unitcomment"),
                    /**
                     * <p><strong>Veranstaltungstitel.</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.event.unitdefaulttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Veranstaltungstitel (Standardtext)
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_EVENT_UNITDEFAULTTEXT("cm.exa.timetable.individualtimetable.content.event.unitdefaulttext"),
                    /**
                     * <p><strong>Veranstaltungstitel.</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.event.unitlongtext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Veranstaltungstitel (Langtext)
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_EVENT_UNITLONGTEXT("cm.exa.timetable.individualtimetable.content.event.unitlongtext"),
                    /**
                     * <p><strong>Kurzkommentar.</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.event.unitshortcomment<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Kurzkommentar der Unit
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_EVENT_UNITSHORTCOMMENT("cm.exa.timetable.individualtimetable.content.event.unitshortcomment"),
                    /**
                     * <p><strong>Veranstaltungstitel.</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.event.unitshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Veranstaltungstitel (Kurztext)
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_EVENT_UNITSHORTTEXT("cm.exa.timetable.individualtimetable.content.event.unitshorttext"),
                    /**
                     * <p><strong>Name.</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.person.instructor.instructor_stringrepresentationforgui<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: StringRepresentationForGui
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_PERSON_INSTRUCTOR_INSTRUCTOR_STRINGREPRESENTATIONFORGUI("cm.exa.timetable.individualtimetable.content.person.instructor.instructor_stringrepresentationforgui"),
                    /**
                     * <p><strong>Name.</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.person.personplanelement.personplanelement_stringrepresentationforgui<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: StringRepresentationForGui
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_PERSON_PERSONPLANELEMENT_PERSONPLANELEMENT_STRINGREPRESENTATIONFORGUI("cm.exa.timetable.individualtimetable.content.person.personplanelement.personplanelement_stringrepresentationforgui"),
                    /**
                     * <p><strong>Geb&auml;ude (Standardtext).</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.room.buildingdefaulttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Standardtext des Geb&auml;ude
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_ROOM_BUILDINGDEFAULTTEXT("cm.exa.timetable.individualtimetable.content.room.buildingdefaulttext"),
                    /**
                     * <p><strong>Geb&auml;ude (Langtext).</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.room.buildinglongtext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Langtext des Geb&auml;ude
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_ROOM_BUILDINGLONGTEXT("cm.exa.timetable.individualtimetable.content.room.buildinglongtext"),
                    /**
                     * <p><strong>Geb&auml;ude (Kurztext).</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.room.buildingshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Kurztext des Geb&auml;ude
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_ROOM_BUILDINGSHORTTEXT("cm.exa.timetable.individualtimetable.content.room.buildingshorttext"),
                    /**
                     * <p><strong>Standort (Standardtext).</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.room.campusdefaulttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Standort (Standardtext)
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_ROOM_CAMPUSDEFAULTTEXT("cm.exa.timetable.individualtimetable.content.room.campusdefaulttext"),
                    /**
                     * <p><strong>Standort (Langtext).</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.room.campuslongtext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Standort (Langtext)
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_ROOM_CAMPUSLONGTEXT("cm.exa.timetable.individualtimetable.content.room.campuslongtext"),
                    /**
                     * <p><strong>Standort (Kurztext).</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.room.campusshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Standort (Kurztext)
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_ROOM_CAMPUSSHORTTEXT("cm.exa.timetable.individualtimetable.content.room.campusshorttext"),
                    /**
                     * <p><strong>Etage (Standardtext).</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.room.floordefaulttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Standardtext der Etage
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_ROOM_FLOORDEFAULTTEXT("cm.exa.timetable.individualtimetable.content.room.floordefaulttext"),
                    /**
                     * <p><strong>Etage (Langtext).</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.room.floorlongtext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Langtext der Etage
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_ROOM_FLOORLONGTEXT("cm.exa.timetable.individualtimetable.content.room.floorlongtext"),
                    /**
                     * <p><strong>Etage (Kurztext).</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.room.floorshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Kurztext der Etage
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_ROOM_FLOORSHORTTEXT("cm.exa.timetable.individualtimetable.content.room.floorshorttext"),
                    /**
                     * <p><strong>Link zum Raumbelegungsplan.</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.room.linktoroomdetails<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Link zum Raumbelegungsplan
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_ROOM_LINKTOROOMDETAILS("cm.exa.timetable.individualtimetable.content.room.linktoroomdetails"),
                    /**
                     * <p><strong>Raum (Standardtext).</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.room.roomdefaulttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Standardtext des Raums
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_ROOM_ROOMDEFAULTTEXT("cm.exa.timetable.individualtimetable.content.room.roomdefaulttext"),
                    /**
                     * <p><strong>Raum (Langtext).</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.room.roomlongtext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Langtext des Raums
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_ROOM_ROOMLONGTEXT("cm.exa.timetable.individualtimetable.content.room.roomlongtext"),
                    /**
                     * <p><strong>Raum (Kurztext).</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.content.room.roomshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Kurztext des Raums
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_CONTENT_ROOM_ROOMSHORTTEXT("cm.exa.timetable.individualtimetable.content.room.roomshorttext"),
                    /**
                     * <p><strong>Plan- / Listenansicht.</strong></p>
                     * Confkey: cm.exa.timetable.individualtimetable.viewtype<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Soll beim pers&ouml;nlichen Stundenplan initial eine Plan- oder Listenansicht angezeigt werden?
                     */
                    TIMETABLE_INDIVIDUALTIMETABLE_VIEWTYPE("cm.exa.timetable.individualtimetable.viewtype"),
                    /**
                     * <p><strong>Akademische Zeitangabe.</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.dates.academictime<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Akademische Zeitangabe
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_DATES_ACADEMICTIME("cm.exa.timetable.lecturerschedule.content.dates.academictime"),
                    /**
                     * <p><strong>Datum von / bis.</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.dates.dates<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Datum von / bis
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_DATES_DATES("cm.exa.timetable.lecturerschedule.content.dates.dates"),
                    /**
                     * <p><strong>Bemerkung zum Termin.</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.dates.notice<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Bemerkung zum Termin
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_DATES_NOTICE("cm.exa.timetable.lecturerschedule.content.dates.notice"),
                    /**
                     * <p><strong>Rhythmus (Standardtext).</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.dates.rhythmdefaulttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Rhythmus (Standardtext)
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_DATES_RHYTHMDEFAULTTEXT("cm.exa.timetable.lecturerschedule.content.dates.rhythmdefaulttext"),
                    /**
                     * <p><strong>Rhythmus (Langtext).</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.dates.rhythmlongtext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Rhythmus (Langtext)
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_DATES_RHYTHMLONGTEXT("cm.exa.timetable.lecturerschedule.content.dates.rhythmlongtext"),
                    /**
                     * <p><strong>Rhythmus (Kurztext).</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.dates.rhythmshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Rhythmus (Kurztext)
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_DATES_RHYTHMSHORTTEXT("cm.exa.timetable.lecturerschedule.content.dates.rhythmshorttext"),
                    /**
                     * <p><strong>Uhrzeit von / bis.</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.dates.time<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Uhrzeit von / bis
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_DATES_TIME("cm.exa.timetable.lecturerschedule.content.dates.time"),
                    /**
                     * <p><strong>Wochentag.</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.dates.weekday<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Wochentag
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_DATES_WEEKDAY("cm.exa.timetable.lecturerschedule.content.dates.weekday"),
                    /**
                     * <p><strong>Nummer.</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.event.elementnr<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Veranstaltungs oder Pr&uuml;fungsnummer
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_EVENT_ELEMENTNR("cm.exa.timetable.lecturerschedule.content.event.elementnr"),
                    /**
                     * <p><strong>Veranstaltungsart.</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.event.eventtypedefaulttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Veranstaltungsart (Standardtext)
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_EVENT_EVENTTYPEDEFAULTTEXT("cm.exa.timetable.lecturerschedule.content.event.eventtypedefaulttext"),
                    /**
                     * <p><strong>Veranstaltungsart.</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.event.eventtypelongtext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Veranstaltungsart (Langtext)
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_EVENT_EVENTTYPELONGTEXT("cm.exa.timetable.lecturerschedule.content.event.eventtypelongtext"),
                    /**
                     * <p><strong>Veranstaltungsart.</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.event.eventtypeshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Veranstaltungsart (Kurztext)
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_EVENT_EVENTTYPESHORTTEXT("cm.exa.timetable.lecturerschedule.content.event.eventtypeshorttext"),
                    /**
                     * <p><strong>Link zu den Details.</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.event.linktoeventdetails<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Link zu den Details
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_EVENT_LINKTOEVENTDETAILS("cm.exa.timetable.lecturerschedule.content.event.linktoeventdetails"),
                    /**
                     * <p><strong>Parallelgruppe.</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.event.parallelgroupshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Parallelgruppe (Kurztext)
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_EVENT_PARALLELGROUPSHORTTEXT("cm.exa.timetable.lecturerschedule.content.event.parallelgroupshorttext"),
                    /**
                     * <p><strong>Kommentar.</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.event.unitcomment<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Kommentar der Unit
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_EVENT_UNITCOMMENT("cm.exa.timetable.lecturerschedule.content.event.unitcomment"),
                    /**
                     * <p><strong>Veranstaltungstitel.</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.event.unitdefaulttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Veranstaltungstitel (Standardtext)
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_EVENT_UNITDEFAULTTEXT("cm.exa.timetable.lecturerschedule.content.event.unitdefaulttext"),
                    /**
                     * <p><strong>Veranstaltungstitel.</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.event.unitlongtext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Veranstaltungstitel (Langtext)
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_EVENT_UNITLONGTEXT("cm.exa.timetable.lecturerschedule.content.event.unitlongtext"),
                    /**
                     * <p><strong>Kurzkommentar.</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.event.unitshortcomment<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Kurzkommentar der Unit
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_EVENT_UNITSHORTCOMMENT("cm.exa.timetable.lecturerschedule.content.event.unitshortcomment"),
                    /**
                     * <p><strong>Veranstaltungstitel.</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.event.unitshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Veranstaltungstitel (Kurztext)
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_EVENT_UNITSHORTTEXT("cm.exa.timetable.lecturerschedule.content.event.unitshorttext"),
                    /**
                     * <p><strong>Name.</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.person.instructor.instructor_stringrepresentationforgui<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: StringRepresentationForGui
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_PERSON_INSTRUCTOR_INSTRUCTOR_STRINGREPRESENTATIONFORGUI("cm.exa.timetable.lecturerschedule.content.person.instructor.instructor_stringrepresentationforgui"),
                    /**
                     * <p><strong>Name.</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.person.personplanelement.personplanelement_stringrepresentationforgui<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: StringRepresentationForGui
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_PERSON_PERSONPLANELEMENT_PERSONPLANELEMENT_STRINGREPRESENTATIONFORGUI("cm.exa.timetable.lecturerschedule.content.person.personplanelement.personplanelement_stringrepresentationforgui"),
                    /**
                     * <p><strong>Geb&auml;ude (Standardtext).</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.room.buildingdefaulttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Standardtext des Geb&auml;ude
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_ROOM_BUILDINGDEFAULTTEXT("cm.exa.timetable.lecturerschedule.content.room.buildingdefaulttext"),
                    /**
                     * <p><strong>Geb&auml;ude (Langtext).</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.room.buildinglongtext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Langtext des Geb&auml;ude
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_ROOM_BUILDINGLONGTEXT("cm.exa.timetable.lecturerschedule.content.room.buildinglongtext"),
                    /**
                     * <p><strong>Geb&auml;ude (Kurztext).</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.room.buildingshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Kurztext des Geb&auml;ude
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_ROOM_BUILDINGSHORTTEXT("cm.exa.timetable.lecturerschedule.content.room.buildingshorttext"),
                    /**
                     * <p><strong>Standort (Standardtext).</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.room.campusdefaulttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Standort (Standardtext)
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_ROOM_CAMPUSDEFAULTTEXT("cm.exa.timetable.lecturerschedule.content.room.campusdefaulttext"),
                    /**
                     * <p><strong>Standort (Langtext).</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.room.campuslongtext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Standort (Langtext)
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_ROOM_CAMPUSLONGTEXT("cm.exa.timetable.lecturerschedule.content.room.campuslongtext"),
                    /**
                     * <p><strong>Standort (Kurztext).</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.room.campusshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Standort (Kurztext)
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_ROOM_CAMPUSSHORTTEXT("cm.exa.timetable.lecturerschedule.content.room.campusshorttext"),
                    /**
                     * <p><strong>Etage (Standardtext).</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.room.floordefaulttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Standardtext der Etage
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_ROOM_FLOORDEFAULTTEXT("cm.exa.timetable.lecturerschedule.content.room.floordefaulttext"),
                    /**
                     * <p><strong>Etage (Langtext).</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.room.floorlongtext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Langtext der Etage
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_ROOM_FLOORLONGTEXT("cm.exa.timetable.lecturerschedule.content.room.floorlongtext"),
                    /**
                     * <p><strong>Etage (Kurztext).</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.room.floorshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Kurztext der Etage
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_ROOM_FLOORSHORTTEXT("cm.exa.timetable.lecturerschedule.content.room.floorshorttext"),
                    /**
                     * <p><strong>Link zum Raumbelegungsplan.</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.room.linktoroomdetails<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Link zum Raumbelegungsplan
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_ROOM_LINKTOROOMDETAILS("cm.exa.timetable.lecturerschedule.content.room.linktoroomdetails"),
                    /**
                     * <p><strong>Raum (Standardtext).</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.room.roomdefaulttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Standardtext des Raums
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_ROOM_ROOMDEFAULTTEXT("cm.exa.timetable.lecturerschedule.content.room.roomdefaulttext"),
                    /**
                     * <p><strong>Raum (Langtext).</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.room.roomlongtext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Langtext des Raums
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_ROOM_ROOMLONGTEXT("cm.exa.timetable.lecturerschedule.content.room.roomlongtext"),
                    /**
                     * <p><strong>Raum (Kurztext).</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.content.room.roomshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Kurztext des Raums
                     */
                    TIMETABLE_LECTURERSCHEDULE_CONTENT_ROOM_ROOMSHORTTEXT("cm.exa.timetable.lecturerschedule.content.room.roomshorttext"),
                    /**
                     * <p><strong>Plan- / Listenansicht.</strong></p>
                     * Confkey: cm.exa.timetable.lecturerschedule.viewtype<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Soll bei den Dozentenpl&auml;nen initial eine Plan- oder Listenansicht angezeigt werden?
                     */
                    TIMETABLE_LECTURERSCHEDULE_VIEWTYPE("cm.exa.timetable.lecturerschedule.viewtype"),
                    /**
                     * <p><strong>Breite von Terminbl&ouml;cken im PDF-Plan.</strong></p>
                     * Confkey: cm.exa.timetable.pdf.blockwidth<br/>
                     * ParameterType: BIGDECIMAL<br/>
                     * <br/>
                     * Info: Wie Breit (in Prozent) darf ein TerminBlock im PDF-Plan sein, ohne dass der Inhalt in eine externe Legende ausgelagert wird.
                     */
                    TIMETABLE_PDF_BLOCKWIDTH("cm.exa.timetable.pdf.blockwidth"),
                    /**
                     * <p><strong>Akademische Zeitangabe.</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.dates.academictime<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Akademische Zeitangabe
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_DATES_ACADEMICTIME("cm.exa.timetable.roomreservationschedule.content.dates.academictime"),
                    /**
                     * <p><strong>Datum von / bis.</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.dates.dates<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Datum von / bis
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_DATES_DATES("cm.exa.timetable.roomreservationschedule.content.dates.dates"),
                    /**
                     * <p><strong>Bemerkung zum Termin.</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.dates.notice<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Bemerkung zum Termin
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_DATES_NOTICE("cm.exa.timetable.roomreservationschedule.content.dates.notice"),
                    /**
                     * <p><strong>Rhythmus (Standardtext).</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.dates.rhythmdefaulttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Rhythmus (Standardtext)
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_DATES_RHYTHMDEFAULTTEXT("cm.exa.timetable.roomreservationschedule.content.dates.rhythmdefaulttext"),
                    /**
                     * <p><strong>Rhythmus (Langtext).</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.dates.rhythmlongtext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Rhythmus (Langtext)
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_DATES_RHYTHMLONGTEXT("cm.exa.timetable.roomreservationschedule.content.dates.rhythmlongtext"),
                    /**
                     * <p><strong>Rhythmus (Kurztext).</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.dates.rhythmshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Rhythmus (Kurztext)
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_DATES_RHYTHMSHORTTEXT("cm.exa.timetable.roomreservationschedule.content.dates.rhythmshorttext"),
                    /**
                     * <p><strong>Uhrzeit von / bis.</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.dates.time<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Uhrzeit von / bis
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_DATES_TIME("cm.exa.timetable.roomreservationschedule.content.dates.time"),
                    /**
                     * <p><strong>Wochentag.</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.dates.weekday<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Wochentag
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_DATES_WEEKDAY("cm.exa.timetable.roomreservationschedule.content.dates.weekday"),
                    /**
                     * <p><strong>Nummer.</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.event.elementnr<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Veranstaltungs oder Pr&uuml;fungsnummer
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_EVENT_ELEMENTNR("cm.exa.timetable.roomreservationschedule.content.event.elementnr"),
                    /**
                     * <p><strong>Veranstaltungsart.</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.event.eventtypedefaulttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Veranstaltungsart (Standardtext)
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_EVENT_EVENTTYPEDEFAULTTEXT("cm.exa.timetable.roomreservationschedule.content.event.eventtypedefaulttext"),
                    /**
                     * <p><strong>Veranstaltungsart.</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.event.eventtypelongtext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Veranstaltungsart (Langtext)
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_EVENT_EVENTTYPELONGTEXT("cm.exa.timetable.roomreservationschedule.content.event.eventtypelongtext"),
                    /**
                     * <p><strong>Veranstaltungsart.</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.event.eventtypeshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Veranstaltungsart (Kurztext)
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_EVENT_EVENTTYPESHORTTEXT("cm.exa.timetable.roomreservationschedule.content.event.eventtypeshorttext"),
                    /**
                     * <p><strong>Link zu den Details.</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.event.linktoeventdetails<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Link zu den Details
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_EVENT_LINKTOEVENTDETAILS("cm.exa.timetable.roomreservationschedule.content.event.linktoeventdetails"),
                    /**
                     * <p><strong>Parallelgruppe.</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.event.parallelgroupshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Parallelgruppe (Kurztext)
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_EVENT_PARALLELGROUPSHORTTEXT("cm.exa.timetable.roomreservationschedule.content.event.parallelgroupshorttext"),
                    /**
                     * <p><strong>Kommentar.</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.event.unitcomment<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Kommentar der Unit
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_EVENT_UNITCOMMENT("cm.exa.timetable.roomreservationschedule.content.event.unitcomment"),
                    /**
                     * <p><strong>Veranstaltungstitel.</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.event.unitdefaulttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Veranstaltungstitel (Standardtext)
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_EVENT_UNITDEFAULTTEXT("cm.exa.timetable.roomreservationschedule.content.event.unitdefaulttext"),
                    /**
                     * <p><strong>Veranstaltungstitel.</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.event.unitlongtext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Veranstaltungstitel (Langtext)
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_EVENT_UNITLONGTEXT("cm.exa.timetable.roomreservationschedule.content.event.unitlongtext"),
                    /**
                     * <p><strong>Kurzkommentar.</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.event.unitshortcomment<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Kurzkommentar der Unit
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_EVENT_UNITSHORTCOMMENT("cm.exa.timetable.roomreservationschedule.content.event.unitshortcomment"),
                    /**
                     * <p><strong>Veranstaltungstitel.</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.event.unitshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Veranstaltungstitel (Kurztext)
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_EVENT_UNITSHORTTEXT("cm.exa.timetable.roomreservationschedule.content.event.unitshorttext"),
                    /**
                     * <p><strong>Name.</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.person.instructor.instructor_stringrepresentationforgui<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: StringRepresentationForGui
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_PERSON_INSTRUCTOR_INSTRUCTOR_STRINGREPRESENTATIONFORGUI("cm.exa.timetable.roomreservationschedule.content.person.instructor.instructor_stringrepresentationforgui"),
                    /**
                     * <p><strong>Name.</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.person.personplanelement.personplanelement_stringrepresentationforgui<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: StringRepresentationForGui
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_PERSON_PERSONPLANELEMENT_PERSONPLANELEMENT_STRINGREPRESENTATIONFORGUI("cm.exa.timetable.roomreservationschedule.content.person.personplanelement.personplanelement_stringrepresentationforgui"),
                    /**
                     * <p><strong>Geb&auml;ude (Standardtext).</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.room.buildingdefaulttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Standardtext des Geb&auml;ude
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_ROOM_BUILDINGDEFAULTTEXT("cm.exa.timetable.roomreservationschedule.content.room.buildingdefaulttext"),
                    /**
                     * <p><strong>Geb&auml;ude (Langtext).</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.room.buildinglongtext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Langtext des Geb&auml;ude
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_ROOM_BUILDINGLONGTEXT("cm.exa.timetable.roomreservationschedule.content.room.buildinglongtext"),
                    /**
                     * <p><strong>Geb&auml;ude (Kurztext).</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.room.buildingshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Kurztext des Geb&auml;ude
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_ROOM_BUILDINGSHORTTEXT("cm.exa.timetable.roomreservationschedule.content.room.buildingshorttext"),
                    /**
                     * <p><strong>Standort (Standardtext).</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.room.campusdefaulttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Standort (Standardtext)
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_ROOM_CAMPUSDEFAULTTEXT("cm.exa.timetable.roomreservationschedule.content.room.campusdefaulttext"),
                    /**
                     * <p><strong>Standort (Langtext).</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.room.campuslongtext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Standort (Langtext)
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_ROOM_CAMPUSLONGTEXT("cm.exa.timetable.roomreservationschedule.content.room.campuslongtext"),
                    /**
                     * <p><strong>Standort (Kurztext).</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.room.campusshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Standort (Kurztext)
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_ROOM_CAMPUSSHORTTEXT("cm.exa.timetable.roomreservationschedule.content.room.campusshorttext"),
                    /**
                     * <p><strong>Etage (Standardtext).</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.room.floordefaulttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Standardtext der Etage
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_ROOM_FLOORDEFAULTTEXT("cm.exa.timetable.roomreservationschedule.content.room.floordefaulttext"),
                    /**
                     * <p><strong>Etage (Langtext).</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.room.floorlongtext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Langtext der Etage
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_ROOM_FLOORLONGTEXT("cm.exa.timetable.roomreservationschedule.content.room.floorlongtext"),
                    /**
                     * <p><strong>Etage (Kurztext).</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.room.floorshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Kurztext der Etage
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_ROOM_FLOORSHORTTEXT("cm.exa.timetable.roomreservationschedule.content.room.floorshorttext"),
                    /**
                     * <p><strong>Link zum Raumbelegungsplan.</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.room.linktoroomdetails<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Link zum Raumbelegungsplan
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_ROOM_LINKTOROOMDETAILS("cm.exa.timetable.roomreservationschedule.content.room.linktoroomdetails"),
                    /**
                     * <p><strong>Raum (Standardtext).</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.room.roomdefaulttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Standardtext des Raums
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_ROOM_ROOMDEFAULTTEXT("cm.exa.timetable.roomreservationschedule.content.room.roomdefaulttext"),
                    /**
                     * <p><strong>Raum (Langtext).</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.room.roomlongtext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Langtext des Raums
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_ROOM_ROOMLONGTEXT("cm.exa.timetable.roomreservationschedule.content.room.roomlongtext"),
                    /**
                     * <p><strong>Raum (Kurztext).</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.content.room.roomshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Kurztext des Raums
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_CONTENT_ROOM_ROOMSHORTTEXT("cm.exa.timetable.roomreservationschedule.content.room.roomshorttext"),
                    /**
                     * <p><strong>Plan- / Listenansicht.</strong></p>
                     * Confkey: cm.exa.timetable.roomreservationschedule.viewtype<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Soll bei den Raumbelegungspl&auml;nen initial eine Plan- oder Listenansicht angezeigt werden?
                     */
                    TIMETABLE_ROOMRESERVATIONSCHEDULE_VIEWTYPE("cm.exa.timetable.roomreservationschedule.viewtype"),
                    /**
                     * <p><strong>Akademische Zeitangabe.</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.dates.academictime<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Akademische Zeitangabe
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_DATES_ACADEMICTIME("cm.exa.timetable.studycourseschedule.content.dates.academictime"),
                    /**
                     * <p><strong>Datum von / bis.</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.dates.dates<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Datum von / bis
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_DATES_DATES("cm.exa.timetable.studycourseschedule.content.dates.dates"),
                    /**
                     * <p><strong>Bemerkung zum Termin.</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.dates.notice<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Bemerkung zum Termin
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_DATES_NOTICE("cm.exa.timetable.studycourseschedule.content.dates.notice"),
                    /**
                     * <p><strong>Rhythmus (Standardtext).</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.dates.rhythmdefaulttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Rhythmus (Standardtext)
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_DATES_RHYTHMDEFAULTTEXT("cm.exa.timetable.studycourseschedule.content.dates.rhythmdefaulttext"),
                    /**
                     * <p><strong>Rhythmus (Langtext).</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.dates.rhythmlongtext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Rhythmus (Langtext)
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_DATES_RHYTHMLONGTEXT("cm.exa.timetable.studycourseschedule.content.dates.rhythmlongtext"),
                    /**
                     * <p><strong>Rhythmus (Kurztext).</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.dates.rhythmshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Rhythmus (Kurztext)
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_DATES_RHYTHMSHORTTEXT("cm.exa.timetable.studycourseschedule.content.dates.rhythmshorttext"),
                    /**
                     * <p><strong>Uhrzeit von / bis.</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.dates.time<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Uhrzeit von / bis
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_DATES_TIME("cm.exa.timetable.studycourseschedule.content.dates.time"),
                    /**
                     * <p><strong>Wochentag.</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.dates.weekday<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Wochentag
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_DATES_WEEKDAY("cm.exa.timetable.studycourseschedule.content.dates.weekday"),
                    /**
                     * <p><strong>Nummer.</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.event.elementnr<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Veranstaltungs oder Pr&uuml;fungsnummer
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_EVENT_ELEMENTNR("cm.exa.timetable.studycourseschedule.content.event.elementnr"),
                    /**
                     * <p><strong>Veranstaltungsart.</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.event.eventtypedefaulttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Veranstaltungsart (Standardtext)
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_EVENT_EVENTTYPEDEFAULTTEXT("cm.exa.timetable.studycourseschedule.content.event.eventtypedefaulttext"),
                    /**
                     * <p><strong>Veranstaltungsart.</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.event.eventtypelongtext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Veranstaltungsart (Langtext)
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_EVENT_EVENTTYPELONGTEXT("cm.exa.timetable.studycourseschedule.content.event.eventtypelongtext"),
                    /**
                     * <p><strong>Veranstaltungsart.</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.event.eventtypeshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Veranstaltungsart (Kurztext)
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_EVENT_EVENTTYPESHORTTEXT("cm.exa.timetable.studycourseschedule.content.event.eventtypeshorttext"),
                    /**
                     * <p><strong>Link zu den Details.</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.event.linktoeventdetails<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Link zu den Details
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_EVENT_LINKTOEVENTDETAILS("cm.exa.timetable.studycourseschedule.content.event.linktoeventdetails"),
                    /**
                     * <p><strong>Parallelgruppe.</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.event.parallelgroupshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Parallelgruppe (Kurztext)
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_EVENT_PARALLELGROUPSHORTTEXT("cm.exa.timetable.studycourseschedule.content.event.parallelgroupshorttext"),
                    /**
                     * <p><strong>Kommentar.</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.event.unitcomment<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Kommentar der Unit
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_EVENT_UNITCOMMENT("cm.exa.timetable.studycourseschedule.content.event.unitcomment"),
                    /**
                     * <p><strong>Veranstaltungstitel.</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.event.unitdefaulttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Veranstaltungstitel (Standardtext)
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_EVENT_UNITDEFAULTTEXT("cm.exa.timetable.studycourseschedule.content.event.unitdefaulttext"),
                    /**
                     * <p><strong>Veranstaltungstitel.</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.event.unitlongtext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Veranstaltungstitel (Langtext)
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_EVENT_UNITLONGTEXT("cm.exa.timetable.studycourseschedule.content.event.unitlongtext"),
                    /**
                     * <p><strong>Kurzkommentar.</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.event.unitshortcomment<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Kurzkommentar der Unit
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_EVENT_UNITSHORTCOMMENT("cm.exa.timetable.studycourseschedule.content.event.unitshortcomment"),
                    /**
                     * <p><strong>Veranstaltungstitel.</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.event.unitshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Veranstaltungstitel (Kurztext)
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_EVENT_UNITSHORTTEXT("cm.exa.timetable.studycourseschedule.content.event.unitshorttext"),
                    /**
                     * <p><strong>Name.</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.person.instructor.instructor_stringrepresentationforgui<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: StringRepresentationForGui
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_PERSON_INSTRUCTOR_INSTRUCTOR_STRINGREPRESENTATIONFORGUI("cm.exa.timetable.studycourseschedule.content.person.instructor.instructor_stringrepresentationforgui"),
                    /**
                     * <p><strong>Name.</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.person.personplanelement.personplanelement_stringrepresentationforgui<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: StringRepresentationForGui
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_PERSON_PERSONPLANELEMENT_PERSONPLANELEMENT_STRINGREPRESENTATIONFORGUI("cm.exa.timetable.studycourseschedule.content.person.personplanelement.personplanelement_stringrepresentationforgui"),
                    /**
                     * <p><strong>Geb&auml;ude (Standardtext).</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.room.buildingdefaulttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Standardtext des Geb&auml;ude
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_ROOM_BUILDINGDEFAULTTEXT("cm.exa.timetable.studycourseschedule.content.room.buildingdefaulttext"),
                    /**
                     * <p><strong>Geb&auml;ude (Langtext).</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.room.buildinglongtext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Langtext des Geb&auml;ude
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_ROOM_BUILDINGLONGTEXT("cm.exa.timetable.studycourseschedule.content.room.buildinglongtext"),
                    /**
                     * <p><strong>Geb&auml;ude (Kurztext).</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.room.buildingshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Kurztext des Geb&auml;ude
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_ROOM_BUILDINGSHORTTEXT("cm.exa.timetable.studycourseschedule.content.room.buildingshorttext"),
                    /**
                     * <p><strong>Standort (Standardtext).</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.room.campusdefaulttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Standort (Standardtext)
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_ROOM_CAMPUSDEFAULTTEXT("cm.exa.timetable.studycourseschedule.content.room.campusdefaulttext"),
                    /**
                     * <p><strong>Standort (Langtext).</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.room.campuslongtext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Standort (Langtext)
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_ROOM_CAMPUSLONGTEXT("cm.exa.timetable.studycourseschedule.content.room.campuslongtext"),
                    /**
                     * <p><strong>Standort (Kurztext).</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.room.campusshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Standort (Kurztext)
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_ROOM_CAMPUSSHORTTEXT("cm.exa.timetable.studycourseschedule.content.room.campusshorttext"),
                    /**
                     * <p><strong>Etage (Standardtext).</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.room.floordefaulttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Standardtext der Etage
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_ROOM_FLOORDEFAULTTEXT("cm.exa.timetable.studycourseschedule.content.room.floordefaulttext"),
                    /**
                     * <p><strong>Etage (Langtext).</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.room.floorlongtext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Langtext der Etage
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_ROOM_FLOORLONGTEXT("cm.exa.timetable.studycourseschedule.content.room.floorlongtext"),
                    /**
                     * <p><strong>Etage (Kurztext).</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.room.floorshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Kurztext der Etage
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_ROOM_FLOORSHORTTEXT("cm.exa.timetable.studycourseschedule.content.room.floorshorttext"),
                    /**
                     * <p><strong>Link zum Raumbelegungsplan.</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.room.linktoroomdetails<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Link zum Raumbelegungsplan
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_ROOM_LINKTOROOMDETAILS("cm.exa.timetable.studycourseschedule.content.room.linktoroomdetails"),
                    /**
                     * <p><strong>Raum (Standardtext).</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.room.roomdefaulttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Standardtext des Raums
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_ROOM_ROOMDEFAULTTEXT("cm.exa.timetable.studycourseschedule.content.room.roomdefaulttext"),
                    /**
                     * <p><strong>Raum (Langtext).</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.room.roomlongtext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Langtext des Raums
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_ROOM_ROOMLONGTEXT("cm.exa.timetable.studycourseschedule.content.room.roomlongtext"),
                    /**
                     * <p><strong>Raum (Kurztext).</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.content.room.roomshorttext<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Kurztext des Raums
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_CONTENT_ROOM_ROOMSHORTTEXT("cm.exa.timetable.studycourseschedule.content.room.roomshorttext"),
                    /**
                     * <p><strong>Soll ein Link zum Tagungsplan angeziegt werden?.</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.symposium.active<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_SYMPOSIUM_ACTIVE("cm.exa.timetable.studycourseschedule.symposium.active"),
                    /**
                     * <p><strong>Id des Studiengangs.</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.symposium.id<br/>
                     * ParameterType: LONG<br/>
                     * <br/>
                     * Info: Die Datenbank-id des Studiengangs, der per Direktlink aufgerufen werden soll. Siehe dazu auch in der Dokumentation unter: HISinOne-Kern -&gt; Infrastruktur -&gt; Hochschulspezifische Konfiguration -&gt; Globale Konfiguration -&gt; Auswahl einer ID
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_SYMPOSIUM_ID("cm.exa.timetable.studycourseschedule.symposium.id"),
                    /**
                     * <p><strong>Beschreibungstext.</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.symposium.linkdescription<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Beschreibungstext f&uuml;r den Link zum Tagungsplan
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_SYMPOSIUM_LINKDESCRIPTION("cm.exa.timetable.studycourseschedule.symposium.linkdescription"),
                    /**
                     * <p><strong>Link-Text.</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.symposium.linktext<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Text, der als Link angezeigt werden soll (z. B. Tagungsplan)
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_SYMPOSIUM_LINKTEXT("cm.exa.timetable.studycourseschedule.symposium.linktext"),
                    /**
                     * <p><strong>Plan- / Listenansicht.</strong></p>
                     * Confkey: cm.exa.timetable.studycourseschedule.viewtype<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Soll bei den Studiengangpl&auml;nen initial eine Plan- oder Listenansicht angezeigt werden?
                     */
                    TIMETABLE_STUDYCOURSESCHEDULE_VIEWTYPE("cm.exa.timetable.studycourseschedule.viewtype"),
                    /**
                     * <p><strong>Datum von.</strong></p>
                     * Confkey: cm.exa.timetable.timeperiod.from<br/>
                     * ParameterType: DATE<br/>
                     * <br/>
                     * Info: Das Datum, mit dem die Pl&auml;ne defaultm&auml;&szlig;ig beginnen sollen.
                     */
                    TIMETABLE_TIMEPERIOD_FROM("cm.exa.timetable.timeperiod.from"),
                    /**
                     * <p><strong>Datum bis.</strong></p>
                     * Confkey: cm.exa.timetable.timeperiod.to<br/>
                     * ParameterType: DATE<br/>
                     * <br/>
                     * Info: Das Datum, mit dem die Pl&auml;ne defaultm&auml;&szlig;ig enden sollen.
                     */
                    TIMETABLE_TIMEPERIOD_TO("cm.exa.timetable.timeperiod.to"),
                    /**
                     * <p><strong>Uhrzeit von.</strong></p>
                     * Confkey: cm.exa.timetable.times.time_from<br/>
                     * ParameterType: TIME<br/>
                     * <br/>
                     * Info: Startuhrzeit im Plan
                     */
                    TIMETABLE_TIMES_TIME_FROM("cm.exa.timetable.times.time_from"),
                    /**
                     * <p><strong>Uhrzeit bis.</strong></p>
                     * Confkey: cm.exa.timetable.times.time_to<br/>
                     * ParameterType: TIME<br/>
                     * <br/>
                     * Info: Enduhrzeit im Plan
                     */
                    TIMETABLE_TIMES_TIME_TO("cm.exa.timetable.times.time_to"),
                    /**
                     * <p><strong>Gr&ouml;&szlig;e der anzuzeigenden Zeitbl&ouml;cke im Plan.</strong></p>
                     * Confkey: cm.exa.timetable.times.timelineduration<br/>
                     * ParameterType: TIME<br/>
                     * <br/>
                     * Info: Die Zeitbl&ouml;cke in den Pl&auml;nen werden durch horizontale Linien voneinander getrennt. Hier kann festgelegt werden, in welchen Zeitintervallen diese Linien eingezeichnet werden sollen.
                     */
                    TIMETABLE_TIMES_TIMELINEDURATION("cm.exa.timetable.times.timelineduration"),
                    /**
                     * <p><strong>Plan- / Listenansicht.</strong></p>
                     * Confkey: cm.exa.timetable.viewtype<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Soll initial eine Plan- oder Listenansicht angezeigt werden?
                     */
                    TIMETABLE_VIEWTYPE("cm.exa.timetable.viewtype"),
                    /**
                     * <p><strong>Abgleich des empfohlenen Semesters im Soll-Ist-Vergleich.</strong></p>
                     * Confkey: cm.exa.unit.check_recommended_semester<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Insbesondere im Studienplaner werden Module, Pr&uuml;fungen und Veranstaltungen aus dem empfohlenen Semester angezeigt. Damit ist normalerweise das Fachsemester des Studenten gemeint. Sollte die Hochschule mit Lehrplansemestern arbeiten, kann dies hier umgestellt werden.
                     */
                    UNIT_CHECK_RECOMMENDED_SEMESTER("cm.exa.unit.check_recommended_semester"),
                    /**
                     * <p><strong>Externe Abschlusspr&uuml;fungen.</strong></p>
                     * Confkey: cm.exa.unit.examimport<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Externe Abschlusspr&uuml;fungen, beinhaltet einen UniqueNamen aus Tabelle unit.
                     */
                    UNIT_EXAMIMPORT("cm.exa.unit.examimport")
                    ;
            
            
                    /** The key. */
                    private final String key;
            
                    /**
                     * Constructor taking the global configuration parameter key.
                     */
                    private EXA(String key) {
                        this.key = key;
                    }
            
                    @Override
                    public String getKey() {
                         return this.key;
                    }
                }
            
                /**
                 * Produktbereich: STU.
                 */
                public static enum STU implements KeyEnum<String>, Key {
                    /**
                     * <p><strong>Addresstag.</strong></p>
                     * Confkey: cm.stu.default.contact_details.addresstag<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Anschriftenkennzeichen (Heimat, Semester, &hellip;), beinhaltet den uniquename aus Tabelle k_addresstag.
                     */
                    DEFAULT_CONTACT_DETAILS_ADDRESSTAG("cm.stu.default.contact_details.addresstag"),
                    /**
                     * <p><strong>Land.</strong></p>
                     * Confkey: cm.stu.default.contact_details.country<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Staatenk&uuml;rzel der  Anschrift, beinhaltet den uniquename aus Tabelle country.
                     */
                    DEFAULT_CONTACT_DETAILS_COUNTRY("cm.stu.default.contact_details.country"),
                    /**
                     * <p><strong>Heimatkreis (Land).</strong></p>
                     * Confkey: cm.stu.default.contact_details.home_country<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Vorbesetzung von Heimatkreis, beinhaltet den uniquename aus Tabelle country.
                     */
                    DEFAULT_CONTACT_DETAILS_HOME_COUNTRY("cm.stu.default.contact_details.home_country"),
                    /**
                     * <p><strong>Heimatkreis (Landkreis).</strong></p>
                     * Confkey: cm.stu.default.contact_details.home_district<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Vorbesetzung von Heimatkreis, beinhaltet den uniquename aus Tabelle district.
                     */
                    DEFAULT_CONTACT_DETAILS_HOME_DISTRICT("cm.stu.default.contact_details.home_district"),
                    /**
                     * <p><strong>Land.</strong></p>
                     * Confkey: cm.stu.default.entrance_qualification.country<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: 
                     */
                    DEFAULT_ENTRANCE_QUALIFICATION_COUNTRY("cm.stu.default.entrance_qualification.country"),
                    /**
                     * <p><strong>Art.</strong></p>
                     * Confkey: cm.stu.default.entrance_qualification.type<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Art der Hochschulzugangsberechtigung (Abitur, Begabtenpr&uuml;fung, &hellip;), beinhaltet den uniquename aus Tabelle entrance_qualification_type.
                     */
                    DEFAULT_ENTRANCE_QUALIFICATION_TYPE("cm.stu.default.entrance_qualification.type"),
                    /**
                     * <p><strong>Chipkartentype.</strong></p>
                     * Confkey: cm.stu.default.guestauditor.chipcard.chipcard_type<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: 
                     */
                    DEFAULT_GUESTAUDITOR_CHIPCARD_CHIPCARD_TYPE("cm.stu.default.guestauditor.chipcard.chipcard_type"),
                    /**
                     * <p><strong>Schl&uuml;ssel des Studiengangs f&uuml;r Gasth&ouml;rer.</strong></p>
                     * Confkey: cm.stu.default.guestauditor.course_of_study_for_guestauditor<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Mit diesem Schalter kann eingestellt werden, welcher Studienganssatz (CourseOfStudy) f&uuml;r Gasth&ouml;rer vorbelegt werden wird.
                     */
                    DEFAULT_GUESTAUDITOR_COURSE_OF_STUDY_FOR_GUESTAUDITOR("cm.stu.default.guestauditor.course_of_study_for_guestauditor"),
                    /**
                     * <p><strong>Schl&uuml;ssel des Studiengangs f&uuml;r kleine Zweith&ouml;rer.</strong></p>
                     * Confkey: cm.stu.default.guestauditor.course_of_study_for_minorvisitingstudent<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Mit diesem Schalter kann eingestellt werden, welcher Studienganssatz (CourseOfStudy) f&uuml;r  kleine Zweith&ouml;rer vorbelegt werden wird.
                     */
                    DEFAULT_GUESTAUDITOR_COURSE_OF_STUDY_FOR_MINORVISITINGSTUDENT("cm.stu.default.guestauditor.course_of_study_for_minorvisitingstudent"),
                    /**
                     * <p><strong>Schl&uuml;ssel des Studiengangs f&uuml;r besondere Gasth&ouml;rer.</strong></p>
                     * Confkey: cm.stu.default.guestauditor.course_of_study_for_spezialguestauditor<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Mit diesem Schalter kann eingestellt werden, welcher Studienganssatz (CourseOfStudy) f&uuml;r besondere Gasth&ouml;rer vorbelegt werden wird.
                     */
                    DEFAULT_GUESTAUDITOR_COURSE_OF_STUDY_FOR_SPEZIALGUESTAUDITOR("cm.stu.default.guestauditor.course_of_study_for_spezialguestauditor"),
                    /**
                     * <p><strong>Versicherungsstatus.</strong></p>
                     * Confkey: cm.stu.default.guestauditor.health_insurance.insurance_status<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: 
                     */
                    DEFAULT_GUESTAUDITOR_HEALTH_INSURANCE_INSURANCE_STATUS("cm.stu.default.guestauditor.health_insurance.insurance_status"),
                    /**
                     * <p><strong>Versicherungsstatus.</strong></p>
                     * Confkey: cm.stu.default.health_insurance.insurance_status<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Versicherungsstatus (pflichtig oder befreit), beinhaltet den uniquename aus Tabelle k_insurant_status.
                     */
                    DEFAULT_HEALTH_INSURANCE_INSURANCE_STATUS("cm.stu.default.health_insurance.insurance_status"),
                    /**
                     * <p><strong>Nummer des BAf&ouml;G-Amtes.</strong></p>
                     * Confkey: cm.stu.default.loan.agency<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: BAf&ouml;g-Amt der HS, 3-stelliger numerischer Wert
                     */
                    DEFAULT_LOAN_AGENCY("cm.stu.default.loan.agency"),
                    /**
                     * <p><strong>Bundesland.</strong></p>
                     * Confkey: cm.stu.default.loan.federal_state<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: BAf&ouml;g-Bundesland der HS, beinhaltet den uniquename aus Tabelle k_federal_state.
                     */
                    DEFAULT_LOAN_FEDERAL_STATE("cm.stu.default.loan.federal_state"),
                    /**
                     * <p><strong>Studienform.</strong></p>
                     * Confkey: cm.stu.default.overview.form_of_studies<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Studienform (Erststudium, Zweitstudium, &hellip;), beinhaltet den uniquename aus Tabelle k_form_of_studies.
                     */
                    DEFAULT_OVERVIEW_FORM_OF_STUDIES("cm.stu.default.overview.form_of_studies"),
                    /**
                     * <p><strong>Staatsangeh&ouml;rigkeit.</strong></p>
                     * Confkey: cm.stu.default.overview.nationality<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: 1. Staatsangeh&ouml;rigkeit,  beinhaltet den uniquename aus Tabelle country.
                     */
                    DEFAULT_OVERVIEW_NATIONALITY("cm.stu.default.overview.nationality"),
                    /**
                     * <p><strong>Fachsemester.</strong></p>
                     * Confkey: cm.stu.default.overview.studysemester<br/>
                     * ParameterType: BIGDECIMAL<br/>
                     * <br/>
                     * Info: 
                     */
                    DEFAULT_OVERVIEW_STUDYSEMESTER("cm.stu.default.overview.studysemester"),
                    /**
                     * <p><strong>Anzeige von Fachsemestern als Ganzzahl.</strong></p>
                     * Confkey: cm.stu.degreeprogramprogress.studysemester_integer<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Mit diesem Schalter kann die Anzeige und Erfassung von Fachsemester ohne Komma eingestellt werden.
                     */
                    DEGREEPROGRAMPROGRESS_STUDYSEMESTER_INTEGER("cm.stu.degreeprogramprogress.studysemester_integer"),
                    /**
                     * <p><strong>Account beim Speichern der Einschreibung f&uuml;r Gasth&ouml;rer generieren.</strong></p>
                     * Confkey: cm.stu.enrollment.account.generateaccountifnotexistonsaveauditor<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Account beim Speichern der Einschreibung f&uuml;r Gasth&ouml;rer generieren
                     */
                    ENROLLMENT_ACCOUNT_GENERATEACCOUNTIFNOTEXISTONSAVEAUDITOR("cm.stu.enrollment.account.generateaccountifnotexistonsaveauditor"),
                    /**
                     * <p><strong>Account beim Speichern der Immatrikulation generieren.</strong></p>
                     * Confkey: cm.stu.enrollment.account.generateaccountifnotexistonsavestudent<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Account beim Speichern der Immatrikulation generieren
                     */
                    ENROLLMENT_ACCOUNT_GENERATEACCOUNTIFNOTEXISTONSAVESTUDENT("cm.stu.enrollment.account.generateaccountifnotexistonsavestudent"),
                    /**
                     * <p><strong>Matrikelnummer vorbelegen.</strong></p>
                     * Confkey: cm.stu.enrollment.automatically_generated_registrationnumber<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll die Matrikelnummer bei der Immatrikulation automatisch vorbelegt werden?
                     */
                    ENROLLMENT_AUTOMATICALLY_GENERATED_REGISTRATIONNUMBER("cm.stu.enrollment.automatically_generated_registrationnumber"),
                    /**
                     * <p><strong>Immatrikulationsdatum.</strong></p>
                     * Confkey: cm.stu.enrollment.date<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Die Bestimmung des Immatrikulationsdatums verl&auml;uft an den Hochschulen unterschiedlich. Unterschiedliche Vorbelegungen sind daher m&ouml;glich. 0 - Tagesdatum, 1 - Datum Semesterbeginn, 2 - Datum Vorlesungsbeginn, 3 - Datum Semesterbeginn, falls Tagesdatum &lt;= Datum Semesterbeginn und Tagesdatum, falls &gt; Semesterbeginn, 99 - keine Vorbelegung
                     */
                    ENROLLMENT_DATE("cm.stu.enrollment.date"),
                    /**
                     * <p><strong>aktiv.</strong></p>
                     * Confkey: cm.stu.enrollment.duplicity_check.duplicity_check_active<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ENROLLMENT_DUPLICITY_CHECK_DUPLICITY_CHECK_ACTIVE("cm.stu.enrollment.duplicity_check.duplicity_check_active"),
                    /**
                     * <p><strong>Zeitpunkt HZB als Datum.</strong></p>
                     * Confkey: cm.stu.enrollment.entrance_qualification_date<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Zeitpunkt HZB als Datum erfassen?
                     */
                    ENROLLMENT_ENTRANCE_QUALIFICATION_DATE("cm.stu.enrollment.entrance_qualification_date"),
                    /**
                     * <p><strong>max. Anzahl von Adressen in der Studentenverwaltung.</strong></p>
                     * Confkey: cm.stu.enrollment.number_of_addresses<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: max. Anzahl von Adressen in der Studentenverwaltung
                     */
                    ENROLLMENT_NUMBER_OF_ADDRESSES("cm.stu.enrollment.number_of_addresses"),
                    /**
                     * <p><strong>max. Anzahl Abschl&uuml;sse.</strong></p>
                     * Confkey: cm.stu.enrollment.number_of_degree<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: max. Anzahl Abschl&uuml;sse
                     */
                    ENROLLMENT_NUMBER_OF_DEGREE("cm.stu.enrollment.number_of_degree"),
                    /**
                     * <p><strong>max. Anzahl F&auml;cher pro Abschluss.</strong></p>
                     * Confkey: cm.stu.enrollment.number_of_subject<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: max. Anzahl F&auml;cher pro Abschluss
                     */
                    ENROLLMENT_NUMBER_OF_SUBJECT("cm.stu.enrollment.number_of_subject"),
                    /**
                     * <p><strong>R&uuml;ckwirkende Einschreibsemester.</strong></p>
                     * Confkey: cm.stu.enrollment.number_redirected_terms<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Anzahl der Semester, f&uuml;r die eine r&uuml;ckwirkende Einschreibung m&ouml;glich sein soll.
                     */
                    ENROLLMENT_NUMBER_REDIRECTED_TERMS("cm.stu.enrollment.number_redirected_terms"),
                    /**
                     * <p><strong>Aktivierung der Assistenten-Seite: Heimat/Semesterkreises.</strong></p>
                     * Confkey: cm.stu.enrollment.online.active_datapage.district<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ENROLLMENT_ONLINE_ACTIVE_DATAPAGE_DISTRICT("cm.stu.enrollment.online.active_datapage.district"),
                    /**
                     * <p><strong>Aktivierung der Assistenten-Seite: externen Pr&uuml;fungen.</strong></p>
                     * Confkey: cm.stu.enrollment.online.active_datapage.exam_import<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ENROLLMENT_ONLINE_ACTIVE_DATAPAGE_EXAM_IMPORT("cm.stu.enrollment.online.active_datapage.exam_import"),
                    /**
                     * <p><strong>Aktivierung der Assistenten-Seite: Geb&uuml;hren.</strong></p>
                     * Confkey: cm.stu.enrollment.online.active_datapage.fees<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ENROLLMENT_ONLINE_ACTIVE_DATAPAGE_FEES("cm.stu.enrollment.online.active_datapage.fees"),
                    /**
                     * <p><strong>Aktivierung der Assistenten-Seite: Krankenversicherung.</strong></p>
                     * Confkey: cm.stu.enrollment.online.active_datapage.health_insurance<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ENROLLMENT_ONLINE_ACTIVE_DATAPAGE_HEALTH_INSURANCE("cm.stu.enrollment.online.active_datapage.health_insurance"),
                    /**
                     * <p><strong>Aktivierung der Assistenten-Seite: BaF&ouml;G.</strong></p>
                     * Confkey: cm.stu.enrollment.online.active_datapage.loan_request<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ENROLLMENT_ONLINE_ACTIVE_DATAPAGE_LOAN_REQUEST("cm.stu.enrollment.online.active_datapage.loan_request"),
                    /**
                     * <p><strong>Aktivierung der Assistenten-Seite: Personenattribute.</strong></p>
                     * Confkey: cm.stu.enrollment.online.active_datapage.person_attributes<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ENROLLMENT_ONLINE_ACTIVE_DATAPAGE_PERSON_ATTRIBUTES("cm.stu.enrollment.online.active_datapage.person_attributes"),
                    /**
                     * <p><strong>Aktivierung der Assistenten-Seite: Bild.</strong></p>
                     * Confkey: cm.stu.enrollment.online.active_datapage.picture<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ENROLLMENT_ONLINE_ACTIVE_DATAPAGE_PICTURE("cm.stu.enrollment.online.active_datapage.picture"),
                    /**
                     * <p><strong>Aktivierung der Assistenten-Seite: Beruf und Praxis.</strong></p>
                     * Confkey: cm.stu.enrollment.online.active_datapage.prof_experience<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ENROLLMENT_ONLINE_ACTIVE_DATAPAGE_PROF_EXPERIENCE("cm.stu.enrollment.online.active_datapage.prof_experience"),
                    /**
                     * <p><strong>Aktivierung der Assistenten-Seite: Auslandsstudium.</strong></p>
                     * Confkey: cm.stu.enrollment.online.active_datapage.study_abroad<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ENROLLMENT_ONLINE_ACTIVE_DATAPAGE_STUDY_ABROAD("cm.stu.enrollment.online.active_datapage.study_abroad"),
                    /**
                     * <p><strong>Aktivierung der Assistenten-Seite: Studienvergangenheit II.</strong></p>
                     * Confkey: cm.stu.enrollment.online.active_datapage.study_history<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ENROLLMENT_ONLINE_ACTIVE_DATAPAGE_STUDY_HISTORY("cm.stu.enrollment.online.active_datapage.study_history"),
                    /**
                     * <p><strong>Aktivierung der Assistenten-Seite: aktuellen Studien.</strong></p>
                     * Confkey: cm.stu.enrollment.online.active_datapage.study_parallel<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ENROLLMENT_ONLINE_ACTIVE_DATAPAGE_STUDY_PARALLEL("cm.stu.enrollment.online.active_datapage.study_parallel"),
                    /**
                     * <p><strong>Aktiviert die Geb&uuml;hrenberechnung (Rechnungserstellung).</strong></p>
                     * Confkey: cm.stu.enrollment.online.fee_calculation.active<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ENROLLMENT_ONLINE_FEE_CALCULATION_ACTIVE("cm.stu.enrollment.online.fee_calculation.active"),
                    /**
                     * <p><strong>Aktiviert einmaligen Lastschriftauftrag.</strong></p>
                     * Confkey: cm.stu.enrollment.online.singular_debit_order.active<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Aktiviert die Funktion des einmaligen Lastschriftauftrages bei der Online-Immatrikulation
                     */
                    ENROLLMENT_ONLINE_SINGULAR_DEBIT_ORDER_ACTIVE("cm.stu.enrollment.online.singular_debit_order.active"),
                    /**
                     * <p><strong>Chipkarte in der Bewerber&uuml;bernahme.</strong></p>
                     * Confkey: cm.stu.enrollment.overview.active_fieldset.chipcard<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ENROLLMENT_OVERVIEW_ACTIVE_FIELDSET_CHIPCARD("cm.stu.enrollment.overview.active_fieldset.chipcard"),
                    /**
                     * <p><strong>Personattribute in der Bewerber&uuml;bernahme.</strong></p>
                     * Confkey: cm.stu.enrollment.overview.active_fieldset.personattributes<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ENROLLMENT_OVERVIEW_ACTIVE_FIELDSET_PERSONATTRIBUTES("cm.stu.enrollment.overview.active_fieldset.personattributes"),
                    /**
                     * <p><strong>Bemerkungsfeld des Bewerbers als Hinweis bei Immatrikulation anzeigen.</strong></p>
                     * Confkey: cm.stu.enrollment.show_application_remark<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Der Inhalt des Bemerkungsfeldes vom Bewerber wird bei der Bewerber-&Uuml;bernahme als Hinweis angezeigt.
                     */
                    ENROLLMENT_SHOW_APPLICATION_REMARK("cm.stu.enrollment.show_application_remark"),
                    /**
                     * <p><strong>Zeitpunkt der Matrikelnummervergabe.</strong></p>
                     * Confkey: cm.stu.enrollment.time_for_registrationnumber<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: 1: bei der Online-Immatrikulation<br />2: bei den Immatrikulation-Sachbearbeiterfunktionen
                     */
                    ENROLLMENT_TIME_FOR_REGISTRATIONNUMBER("cm.stu.enrollment.time_for_registrationnumber"),
                    /**
                     * <p><strong>Pr&uuml;fungsfristenkontrolle.</strong></p>
                     * Confkey: cm.stu.examination.check_time_limit<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    EXAMINATION_CHECK_TIME_LIMIT("cm.stu.examination.check_time_limit"),
                    /**
                     * <p><strong>Pr&uuml;fungsfristentoleranz.</strong></p>
                     * Confkey: cm.stu.examination.time_limit_tolerance<br/>
                     * ParameterType: BIGDECIMAL<br/>
                     * <br/>
                     * Info: 
                     */
                    EXAMINATION_TIME_LIMIT_TOLERANCE("cm.stu.examination.time_limit_tolerance"),
                    /**
                     * <p><strong>Clearing nur bei kompletter Zahlung.</strong></p>
                     * Confkey: cm.stu.fee.clearing_complete_payment_fee<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Bestimmt, ob ein Clearing nur bei kompletter Zahlung aller obligatorischen Geb&uuml;hren m&ouml;glich ist oder nicht.
                     */
                    FEE_CLEARING_COMPLETE_PAYMENT_FEE("cm.stu.fee.clearing_complete_payment_fee"),
                    /**
                     * <p><strong>Aktiviert die Forderungsverwaltung in der integrierten Finanzbuchhaltung.</strong></p>
                     * Confkey: cm.stu.fee.fia.active<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Studentische Debitoren und deren Forderungen werden mit Hilfe der integrierten Finanzbuchhaltung verwaltet
                     */
                    FEE_FIA_ACTIVE("cm.stu.fee.fia.active"),
                    /**
                     * <p><strong>Format der Kontoausz&uuml;ge.</strong></p>
                     * Confkey: cm.stu.fee.fia.bankfileformat<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: CSV Formate m&uuml;ssen spezifiziert werden.
                     */
                    FEE_FIA_BANKFILEFORMAT("cm.stu.fee.fia.bankfileformat"),
                    /**
                     * <p><strong>Unterzahlung in der Massenbuchung ist erlaubt.</strong></p>
                     * Confkey: cm.stu.fee.fia.bulkposting.underpayment<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Definiert, ob bei der Massenbuchung (Sichere Matching-Ergebnisse) eine Unterzahlung erlaubt ist
                     */
                    FEE_FIA_BULKPOSTING_UNDERPAYMENT("cm.stu.fee.fia.bulkposting.underpayment"),
                    /**
                     * <p><strong>Gl&auml;ubiger ID (SEPA) f&uuml;r die Lastschriften aus dem studentischen Bereich.</strong></p>
                     * Confkey: cm.stu.fee.fia.creditoridentification<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: Hier muss bei Aktivierung der SEPA-Verarbeitung in HisInOne konfiguriert werden, welche (im System vorab erfasste!) Gl&auml;ubiger ID f&uuml;r den studentischen Bereich verwendet wird.
                     */
                    FEE_FIA_CREDITORIDENTIFICATION("cm.stu.fee.fia.creditoridentification"),
                    /**
                     * <p><strong>Verbindlichkeiten exportieren.</strong></p>
                     * Confkey: cm.stu.fee.fia.export_liabilities<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Verbindlichkeiten exportieren
                     */
                    FEE_FIA_EXPORT_LIABILITIES("cm.stu.fee.fia.export_liabilities"),
                    /**
                     * <p><strong>SEPA-Verarbeitung aktiv.</strong></p>
                     * Confkey: cm.stu.fee.fia.sepa_active<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: &Uuml;ber diesen Schalter wird festgelegt, ob das Forderungsmanagement im SEPA-Modus arbeitet. Das bedeutet, das in den Masken IBAN und BIC angezeigt und verarbeitet werden und bei der Kommunikation mit dem Geldinstitut die entsprechenden SEPA-Dateiformate verwendet werden. Achtung: Dieser Schalter darf nicht wieder r&uuml;ckg&auml;ngig gemacht werden, da alle Bankverbindung im aktivierten SEPA-Modus keine Kontonummer und BLZ mehr enthalten, was im Nicht-SEPA-Modus jedoch Pflichtangaben sind. Achten Sie unbedingt darauf, dass alle noch im Nicht-SEPA-Modus erstellten Last-/Gutschriften exportiert sind, bevor Sie den SEPA-Modus aktivieren. Diese k&ouml;nnen im SEPA-Modus nicht mehr korrekt verarbeitet werden!
                     */
                    FEE_FIA_SEPA_ACTIVE("cm.stu.fee.fia.sepa_active"),
                    /**
                     * <p><strong>Ziffer Zusatzleistungen.</strong></p>
                     * Confkey: cm.stu.fee.numberrange.facultative_prefix<br/>
                     * ParameterType: LONG<br/>
                     * <br/>
                     * Info: Anfangsziffer der Nummernkreise f&uuml;r fakultative Geb&uuml;hren zur Bildung der globalen Rangnummer von Zusatzleistungen.
                     */
                    FEE_NUMBERRANGE_FACULTATIVE_PREFIX("cm.stu.fee.numberrange.facultative_prefix"),
                    /**
                     * <p><strong>Ziffern L&auml;nge.</strong></p>
                     * Confkey: cm.stu.fee.numberrange.number_of_digits_feeset<br/>
                     * ParameterType: LONG<br/>
                     * <br/>
                     * Info: L&auml;nge der Ziffern f&uuml;r die Nummernkreise der Geb&uuml;hrensets zur Bildung der globalen Rangnummern von Forderungen.
                     */
                    FEE_NUMBERRANGE_NUMBER_OF_DIGITS_FEESET("cm.stu.fee.numberrange.number_of_digits_feeset"),
                    /**
                     * <p><strong>Ziffer Forderungen.</strong></p>
                     * Confkey: cm.stu.fee.numberrange.obligatory_prefix<br/>
                     * ParameterType: LONG<br/>
                     * <br/>
                     * Info: Anfangsziffer der Nummernkreise f&uuml;r obligatorische Geb&uuml;hren zur Bildung der globalen Rangnummern von Forderungen.
                     */
                    FEE_NUMBERRANGE_OBLIGATORY_PREFIX("cm.stu.fee.numberrange.obligatory_prefix"),
                    /**
                     * <p><strong>Alumnimanagement.</strong></p>
                     * Confkey: cm.stu.fee.productareas.alternative_name_alu<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Alternativer Name f&uuml;r Alumnimanagement (ALU), der im Verwendungszweck f&uuml;r Zahlungen ausgewertet wird.
                     */
                    FEE_PRODUCTAREAS_ALTERNATIVE_NAME_ALU("cm.stu.fee.productareas.alternative_name_alu"),
                    /**
                     * <p><strong>Bewerbermanagement.</strong></p>
                     * Confkey: cm.stu.fee.productareas.alternative_name_app<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Alternativer Name f&uuml;r Bewerbung und Zulassung (APP), der im Verwendungszweck f&uuml;r Zahlungen ausgewertet wird.
                     */
                    FEE_PRODUCTAREAS_ALTERNATIVE_NAME_APP("cm.stu.fee.productareas.alternative_name_app"),
                    /**
                     * <p><strong>Pr&uuml;fungsmanagement.</strong></p>
                     * Confkey: cm.stu.fee.productareas.alternative_name_exa<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Alternativer Name f&uuml;r Pr&uuml;fungs- und Veranstaltungsmanagement (EXA), der im Verwendungszweck f&uuml;r Zahlungen ausgewertet wird.
                     */
                    FEE_PRODUCTAREAS_ALTERNATIVE_NAME_EXA("cm.stu.fee.productareas.alternative_name_exa"),
                    /**
                     * <p><strong>Studierendenmanagement.</strong></p>
                     * Confkey: cm.stu.fee.productareas.alternative_name_stu<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Alternativer Name f&uuml;r Studierendendenverwaltung (STU), der im Verwendungszweck f&uuml;r Zahlungen ausgewertet wird.
                     */
                    FEE_PRODUCTAREAS_ALTERNATIVE_NAME_STU("cm.stu.fee.productareas.alternative_name_stu"),
                    /**
                     * <p><strong>S&auml;umnisgeb&uuml;hren bei Geb&uuml;hrenbefreiung stornieren.</strong></p>
                     * Confkey: cm.stu.fee.storno_late_payment_fee<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Bestimmt, ob einmal in Rechnung gestellte S&auml;umnisgeb&uuml;hren, bei einer r&uuml;ckwirkenden Befreiung aller f&uuml;r die S&auml;umnisgeb&uuml;hr relevanten Geb&uuml;hren, storniert werden oder nicht.
                     */
                    FEE_STORNO_LATE_PAYMENT_FEE("cm.stu.fee.storno_late_payment_fee"),
                    /**
                     * <p><strong>Alter.</strong></p>
                     * Confkey: cm.stu.fee.study_contribution.loan.conditions.age<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: Bedingung zum Alter
                     */
                    FEE_STUDY_CONTRIBUTION_LOAN_CONDITIONS_AGE("cm.stu.fee.study_contribution.loan.conditions.age"),
                    /**
                     * <p><strong>Ausland.</strong></p>
                     * Confkey: cm.stu.fee.study_contribution.loan.conditions.foreign_countries<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: Bedingung zu Ausland
                     */
                    FEE_STUDY_CONTRIBUTION_LOAN_CONDITIONS_FOREIGN_COUNTRIES("cm.stu.fee.study_contribution.loan.conditions.foreign_countries"),
                    /**
                     * <p><strong>Studienform.</strong></p>
                     * Confkey: cm.stu.fee.study_contribution.loan.conditions.form_of_study<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: Bedingung zur Studienform
                     */
                    FEE_STUDY_CONTRIBUTION_LOAN_CONDITIONS_FORM_OF_STUDY("cm.stu.fee.study_contribution.loan.conditions.form_of_study"),
                    /**
                     * <p><strong>Semester.</strong></p>
                     * Confkey: cm.stu.fee.study_contribution.loan.conditions.semester<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: Bedingung zur Semesterzahl
                     */
                    FEE_STUDY_CONTRIBUTION_LOAN_CONDITIONS_SEMESTER("cm.stu.fee.study_contribution.loan.conditions.semester"),
                    /**
                     * <p><strong>Antrag gestellt wirkt wie Studienbeitrag/-geb&uuml;hr gezahlt.</strong></p>
                     * Confkey: cm.stu.fee.study_contribution.loan.fee_paid<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Ist diese Option aktiviert, so wird bei der Pr&uuml;fung ob genug bezahlt wurde, ein gestellter Darlehensantrag so gewertet, als w&auml;re der/die zugeh&ouml;rige Studienbeitrag/-geb&uuml;hr vollst&auml;ndig ausgeglichen.
                     */
                    FEE_STUDY_CONTRIBUTION_LOAN_FEE_PAID("cm.stu.fee.study_contribution.loan.fee_paid"),
                    /**
                     * <p><strong>Relevante Bearbeitungsstatus f&uuml;r Darlehensantr&auml;ge.</strong></p>
                     * Confkey: cm.stu.kfw.kfwexport.relevant_request_processing_statuses<br/>
                     * ParameterType: MANYSELECT_SRC<br/>
                     * <br/>
                     * Info: Relevante Bearbeitungsstatus zur Kennzeichnung von g&uuml;ltigen, sich auswirkenden Darlehensantr&auml;gen. Nur Antr&auml;ge, die einen der angegebenen Bearbeitungsstatus besitzen, werden f&uuml;r die Meldung von Studienbescheinigungen an die KfW ber&uuml;cksichtigt.
                     */
                    KFW_KFWEXPORT_RELEVANT_REQUEST_PROCESSING_STATUSES("cm.stu.kfw.kfwexport.relevant_request_processing_statuses"),
                    /**
                     * <p><strong>KfW Gesch&auml;ftspartnernummer der Hochschule.</strong></p>
                     * Confkey: cm.stu.kfw.kfwexport.university_business_partner_number<br/>
                     * ParameterType: LONG<br/>
                     * <br/>
                     * Info: Mandantennummer der Hochschule bei der KfW. Der Wert muss gr&ouml;&szlig;er 0 sein. Der Maximalwert ist 9999999999.
                     */
                    KFW_KFWEXPORT_UNIVERSITY_BUSINESS_PARTNER_NUMBER("cm.stu.kfw.kfwexport.university_business_partner_number"),
                    /**
                     * <p><strong>Hochschulreferenz des Nachrichtenpakets.</strong></p>
                     * Confkey: cm.stu.kfw.kfwexport.university_message_reference<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Hochschulreferenz des Nachrichtenpakets an die KfW. Der Inhalt kann von der Hochschule frei gew&auml;hlt werden.<br />Der Wert darf maximal aus 45 Zeichen bestehen.<br />Beispiel: Name der XML-Datei auf dem Hochschulrechner.
                     */
                    KFW_KFWEXPORT_UNIVERSITY_MESSAGE_REFERENCE("cm.stu.kfw.kfwexport.university_message_reference"),
                    /**
                     * <p><strong>Maximale Verbindungszeit.</strong></p>
                     * Confkey: cm.stu.kfw.kfwexport.webservice.connection_timeout<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Maximale Zeit in Millisekunden, den der Verbindungsaufbau zum Webservice der KfW dauern darf. Wird diese Zeit &uuml;berschritten, so wird der Verbindungsaufbau abgebrochen.<br />Der Maximalwert dieser Einstellung ist 900000 (= 15 Minuten). Der Minimalwert ist 1000 (= 1 Sekunde).
                     */
                    KFW_KFWEXPORT_WEBSERVICE_CONNECTION_TIMEOUT("cm.stu.kfw.kfwexport.webservice.connection_timeout"),
                    /**
                     * <p><strong>Standard-Passwort.</strong></p>
                     * Confkey: cm.stu.kfw.kfwexport.webservice.default_password<br/>
                     * ParameterType: PASSWORD_PLAINTEXT<br/>
                     * <br/>
                     * Info: Passwort, das f&uuml;r die Authentifizierung des Verfahrensusers durch den Webservice der KfW als Vorbelegung verwendet werden soll. Wird das Standard-Passwort nicht gesetzt, so muss das Passwort bei jeder Meldung an die KfW manuell angegeben werden.
                     */
                    KFW_KFWEXPORT_WEBSERVICE_DEFAULT_PASSWORD("cm.stu.kfw.kfwexport.webservice.default_password"),
                    /**
                     * <p><strong>Standard-Benutzername.</strong></p>
                     * Confkey: cm.stu.kfw.kfwexport.webservice.default_username<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Benutzername der f&uuml;r die Authentifizierung des Verfahrensusers durch den Webservice der KfW als Vorbelegung verwendet werden soll. Der Benutzername setzt sich in Normalfall aus der von den &quot;DHSzuKfW&quot;-Administratoren vergebenen User-ID des Verfahrensusers gefolgt von drei Unterstrichen und der KfW-Gesch&auml;ftspartnernummer der Hochschule zusammen.<br />Format: USERID___MANDANT (Beisiel: &quot;USR1234___12345678&quot;)
                     */
                    KFW_KFWEXPORT_WEBSERVICE_DEFAULT_USERNAME("cm.stu.kfw.kfwexport.webservice.default_username"),
                    /**
                     * <p><strong>Webservice-URL.</strong></p>
                     * Confkey: cm.stu.kfw.kfwexport.webservice.url<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Die Webservice-URL des &quot;DHSzuKfW-Verfahrens&quot; der KfW f&uuml;r die Meldung von Studienbescheinigungen.
                     */
                    KFW_KFWEXPORT_WEBSERVICE_URL("cm.stu.kfw.kfwexport.webservice.url"),
                    /**
                     * <p><strong>Praktikum.</strong></p>
                     * Confkey: cm.stu.professional_experience.pe_internship<br/>
                     * ParameterType: LONG<br/>
                     * <br/>
                     * Info: Praktikum
                     */
                    PROFESSIONAL_EXPERIENCE_PE_INTERNSHIP("cm.stu.professional_experience.pe_internship"),
                    /**
                     * <p><strong>Anzahl der zuletzt gespeicherten F&auml;lle.</strong></p>
                     * Confkey: cm.stu.recentsavedstudentssize<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Stellt die L&auml;nge der Liste der zuletzt bearbeiteten F&auml;lle auf eine bestimmten Wert ein. Defaultm&auml;&szlig;ig werden 10 F&auml;lle in der Liste angezeigt.
                     */
                    RECENTSAVEDSTUDENTSSIZE("cm.stu.recentsavedstudentssize"),
                    /**
                     * <p><strong>F&uuml;llverhalten f.d. Gesch&auml;ftspartnernummer.</strong></p>
                     * Confkey: cm.stu.registrationnumber_to_businesspartner<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Dieser Schl&uuml;ssel beschreibt das Verhalten beim automatischen Eintragen der Gesch&auml;ftspartnernummer zur Unterst&uuml;tzung des automatischen Matchings bei Zahlungseing&auml;ngen. 1 = &Uuml;bertragung der Bewerbernummer beim Speichern des Bewerbers als vorl&auml;ufiger Student. 2 = &Uuml;bertragung der Matrikelnummer beim Speichern als vorl&auml;ufiger Student.
                     */
                    REGISTRATIONNUMBER_TO_BUSINESSPARTNER("cm.stu.registrationnumber_to_businesspartner"),
                    /**
                     * <p><strong>Bescheid-Kennzeichen f&uuml;r Exmatrikulation.</strong></p>
                     * Confkey: cm.stu.reports.bsa.dissenroll<br/>
                     * ParameterType: MANYSELECT_SRC<br/>
                     * <br/>
                     * Info: Bescheidanforderungen, die bei der Exmatrikulation angelegt werden sollten.
                     */
                    REPORTS_BSA_DISSENROLL("cm.stu.reports.bsa.dissenroll"),
                    /**
                     * <p><strong>Bescheid-Kennzeichen f&uuml;r Immatrikulation.</strong></p>
                     * Confkey: cm.stu.reports.bsa.enrollment<br/>
                     * ParameterType: MANYSELECT_SRC<br/>
                     * <br/>
                     * Info: Bescheidanforderungen, die bei der Immatrikulation angelegt werden sollten.
                     */
                    REPORTS_BSA_ENROLLMENT("cm.stu.reports.bsa.enrollment"),
                    /**
                     * <p><strong>Bescheid-Kennzeichen f&uuml;r Beurlaubung.</strong></p>
                     * Confkey: cm.stu.reports.bsa.leave_of_absence<br/>
                     * ParameterType: MANYSELECT_SRC<br/>
                     * <br/>
                     * Info: Bescheidanforderungen, die bei der Beurlaubung angelegt werden sollten.
                     */
                    REPORTS_BSA_LEAVE_OF_ABSENCE("cm.stu.reports.bsa.leave_of_absence"),
                    /**
                     * <p><strong>Bescheid-Kennzeichen f&uuml;r R&uuml;ckmeldung.</strong></p>
                     * Confkey: cm.stu.reports.bsa.reregistration<br/>
                     * ParameterType: MANYSELECT_SRC<br/>
                     * <br/>
                     * Info: Bescheidanforderungen, die bei der R&uuml;ckmeldung angelegt werden sollten.
                     */
                    REPORTS_BSA_REREGISTRATION("cm.stu.reports.bsa.reregistration"),
                    /**
                     * <p><strong>Studentische Bescheide mit Anforderung f&uuml;r einen Studenten.</strong></p>
                     * Confkey: cm.stu.reports.bsa_reports_for_students<br/>
                     * ParameterType: MANYSELECT_SRC<br/>
                     * <br/>
                     * Info: Enth&auml;lt die Bescheidanforderungsjobs, die einem Studenten zur Verf&uuml;gung stehen sollen. Steuert auch, welche Bescheidanforderungen f&uuml;r den Studenten sichtbar sein sollen. Pro Bescheidart sollte h&ouml;chstens ein Job ausgew&auml;hlt werden.
                     */
                    REPORTS_BSA_REPORTS_FOR_STUDENTS("cm.stu.reports.bsa_reports_for_students"),
                    /**
                     * <p><strong>Berichte im Schnellzugriff f&uuml;r STU-Sachbearbeiter.</strong></p>
                     * Confkey: cm.stu.reports.fast_reports_for_staff<br/>
                     * ParameterType: MANYSELECT_SRC<br/>
                     * <br/>
                     * Info: Die hier eingetragenen Berichte werden bereits auf der &Uuml;bersichtsseite von 'Studierenden bearbeiten' angezeigt.
                     */
                    REPORTS_FAST_REPORTS_FOR_STAFF("cm.stu.reports.fast_reports_for_staff"),
                    /**
                     * <p><strong>Max. Anzahl zur&uuml;ckliegender Semester f&uuml;r STU-Berichte.</strong></p>
                     * Confkey: cm.stu.reports.periodlimit<br/>
                     * ParameterType: LONG<br/>
                     * <br/>
                     * Info: Wie viele Semester der Vergangenheit sollen maximal f&uuml;r studentische Berichte angeboten werden?
                     */
                    REPORTS_PERIODLIMIT("cm.stu.reports.periodlimit"),
                    /**
                     * <p><strong>Studentische Bescheide f&uuml;r einen Studenten.</strong></p>
                     * Confkey: cm.stu.reports.reports_for_student<br/>
                     * ParameterType: MANYSELECT_SRC<br/>
                     * <br/>
                     * Info: Studentische Bescheide f&uuml;r einen Studenten zum Selbstausdruck. Die Bescheide werden dem Studenten unter dem Men&uuml;punkt &quot;Meine Berichte&quot; angeboten.
                     */
                    REPORTS_REPORTS_FOR_STUDENT("cm.stu.reports.reports_for_student"),
                    /**
                     * <p><strong>Obligatorische Geb&uuml;hren nicht ausgeglichen.</strong></p>
                     * Confkey: cm.stu.reregistration.not_pay_enough<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Steuert wie bei der automatischen R&uuml;ckmeldung verfahren wird, wenn der aktuelle Fall die obligatorischen und damit r&uuml;ckmelderelevanten Geb&uuml;hren f&uuml;r das R&uuml;ckmeldesemester nicht komplett bezahlt hat.
                     */
                    REREGISTRATION_NOT_PAY_ENOUGH("cm.stu.reregistration.not_pay_enough"),
                    /**
                     * <p><strong>Aktiviert generelle Einzugserm&auml;chtigung.</strong></p>
                     * Confkey: cm.stu.reregistration.online.direct_debiting_authorisation.active<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Aktiviert die Funktion der generellen Einzugserm&auml;chtigung bei der Online-R&uuml;ckmeldung
                     */
                    REREGISTRATION_ONLINE_DIRECT_DEBITING_AUTHORISATION_ACTIVE("cm.stu.reregistration.online.direct_debiting_authorisation.active"),
                    /**
                     * <p><strong>Aktiviert einmaligen Lastschriftauftrag.</strong></p>
                     * Confkey: cm.stu.reregistration.online.singular_debit_order.active<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Aktiviert die Funktion des einmaligen Lastschriftauftrages bei der Online-R&uuml;ckmeldung
                     */
                    REREGISTRATION_ONLINE_SINGULAR_DEBIT_ORDER_ACTIVE("cm.stu.reregistration.online.singular_debit_order.active"),
                    /**
                     * <p><strong>Lastschriftauftrag als 'gezahlt' werten.</strong></p>
                     * Confkey: cm.stu.reregistration.online.singular_debit_order.considered_as_paid<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Ein online eingegebener, einmaliger Lastschriftauftrag wird innerhalb der R&uuml;ckmeldung gewertet, als h&auml;tte der Fall die obligatorischen Geb&uuml;hren f&uuml;r das R&uuml;ckmeldesemester bezahlt. Infolge dessen wird er im Anschluss sofort r&uuml;ckgemeldet.
                     */
                    REREGISTRATION_ONLINE_SINGULAR_DEBIT_ORDER_CONSIDERED_AS_PAID("cm.stu.reregistration.online.singular_debit_order.considered_as_paid"),
                    /**
                     * <p><strong>Toleranzbetrag f&uuml;r Geb&uuml;hrenpr&uuml;fung.</strong></p>
                     * Confkey: cm.stu.reregistration.tolerance_amount<br/>
                     * ParameterType: BIGDECIMAL<br/>
                     * <br/>
                     * Info: Maximalbetrag der bei den r&uuml;ckmelderelevanten Geb&uuml;hren zur R&uuml;ckmeldung fehlen darf.
                     */
                    REREGISTRATION_TOLERANCE_AMOUNT("cm.stu.reregistration.tolerance_amount"),
                    /**
                     * <p><strong>Uniquename als Prefix in SelectMen&uuml;s anzeigen.</strong></p>
                     * Confkey: cm.stu.show_uniquename_in_selectmenus<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Uniquename als Prefix in SelectMen&uuml;s anzeigen; Sortierung wird auch auf Uniquename ge&auml;ndert.
                     */
                    SHOW_UNIQUENAME_IN_SELECTMENUS("cm.stu.show_uniquename_in_selectmenus"),
                    /**
                     * <p><strong>Aktivierung der Registerkarte: Account.</strong></p>
                     * Confkey: cm.stu.staff.active_tabs.account<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    STAFF_ACTIVE_TABS_ACCOUNT("cm.stu.staff.active_tabs.account"),
                    /**
                     * <p><strong>Aktivierung der Registerkarte: BAf&ouml;G.</strong></p>
                     * Confkey: cm.stu.staff.active_tabs.bafoeg<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    STAFF_ACTIVE_TABS_BAFOEG("cm.stu.staff.active_tabs.bafoeg"),
                    /**
                     * <p><strong>Aktivierung der Registerkarte: Chipkarte.</strong></p>
                     * Confkey: cm.stu.staff.active_tabs.chipcard<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    STAFF_ACTIVE_TABS_CHIPCARD("cm.stu.staff.active_tabs.chipcard"),
                    /**
                     * <p><strong>Aktivierung der Registerkarte: HZB.</strong></p>
                     * Confkey: cm.stu.staff.active_tabs.entrance_qualification<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    STAFF_ACTIVE_TABS_ENTRANCE_QUALIFICATION("cm.stu.staff.active_tabs.entrance_qualification"),
                    /**
                     * <p><strong>Aktivierung der Registerkarte: Wiedervorlagen.</strong></p>
                     * Confkey: cm.stu.staff.active_tabs.followup<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    STAFF_ACTIVE_TABS_FOLLOWUP("cm.stu.staff.active_tabs.followup"),
                    /**
                     * <p><strong>Aktivierung der Registerkarte: Sperren.</strong></p>
                     * Confkey: cm.stu.staff.active_tabs.locking<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    STAFF_ACTIVE_TABS_LOCKING("cm.stu.staff.active_tabs.locking"),
                    /**
                     * <p><strong>Aktivierung der Registerkarte: Einzureichende Unterlagen.</strong></p>
                     * Confkey: cm.stu.staff.active_tabs.missing_documents<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    STAFF_ACTIVE_TABS_MISSING_DOCUMENTS("cm.stu.staff.active_tabs.missing_documents"),
                    /**
                     * <p><strong>Aktivierung der Registerkarte: Personenattribute.</strong></p>
                     * Confkey: cm.stu.staff.active_tabs.personattributes<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    STAFF_ACTIVE_TABS_PERSONATTRIBUTES("cm.stu.staff.active_tabs.personattributes"),
                    /**
                     * <p><strong>Aktivierung der Registerkarte: Bild.</strong></p>
                     * Confkey: cm.stu.staff.active_tabs.picture<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    STAFF_ACTIVE_TABS_PICTURE("cm.stu.staff.active_tabs.picture"),
                    /**
                     * <p><strong>Aktivierung der Registerkarte: Pin Tan.</strong></p>
                     * Confkey: cm.stu.staff.active_tabs.pin_tan<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    STAFF_ACTIVE_TABS_PIN_TAN("cm.stu.staff.active_tabs.pin_tan"),
                    /**
                     * <p><strong>Aktivierung der Registerkarte: Darlehen.</strong></p>
                     * Confkey: cm.stu.staff.active_tabs.request_for_loan<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    STAFF_ACTIVE_TABS_REQUEST_FOR_LOAN("cm.stu.staff.active_tabs.request_for_loan"),
                    /**
                     * <p><strong>Aktivierung der Registerkarte: Studienkonto.</strong></p>
                     * Confkey: cm.stu.staff.active_tabs.study_account<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    STAFF_ACTIVE_TABS_STUDY_ACCOUNT("cm.stu.staff.active_tabs.study_account"),
                    /**
                     * <p><strong>Chipkarte erstellen.</strong></p>
                     * Confkey: cm.stu.staff.create_chipcard_by_initialisation<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Schalter, ob bei der Neuerfassung oder dem Aufruf eines Kunden der Studierendenverwaltung eine Studierenden-Chipkarte angelegt werden soll, wenn noch keine existiert.
                     */
                    STAFF_CREATE_CHIPCARD_BY_INITIALISATION("cm.stu.staff.create_chipcard_by_initialisation"),
                    /**
                     * <p><strong>Aktivierung der Registerkarte f&uuml;r Gasth&ouml;rer: Account.</strong></p>
                     * Confkey: cm.stu.staff.guestauditor.active_tabs.account<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    STAFF_GUESTAUDITOR_ACTIVE_TABS_ACCOUNT("cm.stu.staff.guestauditor.active_tabs.account"),
                    /**
                     * <p><strong>Aktivierung der Registerkarte f&uuml;r Gasth&ouml;rer: Chipkarte.</strong></p>
                     * Confkey: cm.stu.staff.guestauditor.active_tabs.chipcard<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    STAFF_GUESTAUDITOR_ACTIVE_TABS_CHIPCARD("cm.stu.staff.guestauditor.active_tabs.chipcard"),
                    /**
                     * <p><strong>Aktivierung der Registerkarte: HZB.</strong></p>
                     * Confkey: cm.stu.staff.guestauditor.active_tabs.entrance_qualification<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    STAFF_GUESTAUDITOR_ACTIVE_TABS_ENTRANCE_QUALIFICATION("cm.stu.staff.guestauditor.active_tabs.entrance_qualification"),
                    /**
                     * <p><strong>Aktivierung der Registerkarte f&uuml;r Gasth&ouml;rer: Fr&uuml;heres Studium.</strong></p>
                     * Confkey: cm.stu.staff.guestauditor.active_tabs.external_studies<br/>
                     * ParameterType: MANYSELECT<br/>
                     * <br/>
                     * Info: 
                     */
                    STAFF_GUESTAUDITOR_ACTIVE_TABS_EXTERNAL_STUDIES("cm.stu.staff.guestauditor.active_tabs.external_studies"),
                    /**
                     * <p><strong>Aktivierung der Registerkarte f&uuml;r Gasth&ouml;rer: Wiedervorlagen.</strong></p>
                     * Confkey: cm.stu.staff.guestauditor.active_tabs.followup<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    STAFF_GUESTAUDITOR_ACTIVE_TABS_FOLLOWUP("cm.stu.staff.guestauditor.active_tabs.followup"),
                    /**
                     * <p><strong>Aktivierung der Registerkarte f&uuml;r Gasth&ouml;rer: Personenattribute.</strong></p>
                     * Confkey: cm.stu.staff.guestauditor.active_tabs.personattributes<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    STAFF_GUESTAUDITOR_ACTIVE_TABS_PERSONATTRIBUTES("cm.stu.staff.guestauditor.active_tabs.personattributes"),
                    /**
                     * <p><strong>Chipkarte f&uuml;r Gasth&ouml;rer erstellen.</strong></p>
                     * Confkey: cm.stu.staff.guestauditor.create_chipcard_by_initialisation<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    STAFF_GUESTAUDITOR_CREATE_CHIPCARD_BY_INITIALISATION("cm.stu.staff.guestauditor.create_chipcard_by_initialisation"),
                    /**
                     * <p><strong>Pflichtbelegung durchf&uuml;hren f&uuml;r Musikhochschulen.</strong></p>
                     * Confkey: cm.stu.studentcompulsoryallocationcollegeofmusic<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: In der Bearbeitungsmaske der Studierenden (unter Studierenden-Management &gt; Studierende &gt; Studierendendaten bearbeiten) wird neben den Buttons f&uuml;r Beurlauben, R&uuml;ckmelden und Exmatrikulieren noch ein weiterer Button mit der Bezeichnung &quot;Pflichtbelegung durchf&uuml;hren&quot; eingeblendet. Diese Pflichtbelegung wird nur f&uuml;r Musikhochschulen verwendet, um damit alle Unterrichtsanspr&uuml;che des Studenten f&uuml;r Einzel- und Kleingruppenunterrichte f&uuml;r das gesamte Studium als Leistungen mit dem Status PP (=Pr&uuml;fungsplan) anzulegen.
                     */
                    STUDENTCOMPULSORYALLOCATIONCOLLEGEOFMUSIC("cm.stu.studentcompulsoryallocationcollegeofmusic"),
                    /**
                     * <p><strong>Anzahl der angebotenen &quot;Sperrung-Jahre&quot;.</strong></p>
                     * Confkey: cm.stu.studentfunctionlock.number_of_offered_lock_years<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Anzahl der Jahre, die &uuml;ber eine Klappbox angeboten werden sollen
                     */
                    STUDENTFUNCTIONLOCK_NUMBER_OF_OFFERED_LOCK_YEARS("cm.stu.studentfunctionlock.number_of_offered_lock_years"),
                    /**
                     * <p><strong>Studienkonto berechnen.</strong></p>
                     * Confkey: cm.stu.study_account.calculate<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Ist der Parameter aktiviert, so wird beim &Ouml;ffnen eines Studierenden f&uuml;r diesen Fall ein Studienkonto berechnet.
                     */
                    STUDY_ACCOUNT_CALCULATE("cm.stu.study_account.calculate"),
                    /**
                     * <p><strong>Studienkonto l&ouml;schen.</strong></p>
                     * Confkey: cm.stu.study_account.conditions.study_account_delete<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: Pr&uuml;ft, unter welchen Bedingungen f&uuml;r Studierende ein vorhandenes Studienkonto gel&ouml;scht wird.
                     */
                    STUDY_ACCOUNT_CONDITIONS_STUDY_ACCOUNT_DELETE("cm.stu.study_account.conditions.study_account_delete"),
                    /**
                     * <p><strong>Studienkonto befreit.</strong></p>
                     * Confkey: cm.stu.study_account.conditions.study_account_exempt<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: Pr&uuml;ft, ob ein Studierender aufgrund besonderer Tatbest&auml;nde grunds&auml;tzlich vom Studienkonto befreit wir.
                     */
                    STUDY_ACCOUNT_CONDITIONS_STUDY_ACCOUNT_EXEMPT("cm.stu.study_account.conditions.study_account_exempt"),
                    /**
                     * <p><strong>Studienkonto vorhanden.</strong></p>
                     * Confkey: cm.stu.study_account.conditions.study_account_exists<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: Pr&uuml;ft, ob f&uuml;r einen Studierenden grunds&auml;tzlich ein Studienkonto vorhanden sein soll oder nicht.
                     */
                    STUDY_ACCOUNT_CONDITIONS_STUDY_ACCOUNT_EXISTS("cm.stu.study_account.conditions.study_account_exists"),
                    /**
                     * <p><strong>Maximale Regelstudienzeit.</strong></p>
                     * Confkey: cm.stu.study_account.double_degree_program.maximum<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Ist dieser Parameter aktiviert, so wird bei einem Doppelstudium und aktivierter Option 'alle F&auml;cher ber&uuml;cksichtigen', zur Berechnung des Studienkontenguthabens die maximale Regelstudienzeit ber&uuml;cksichtigt.
                     */
                    STUDY_ACCOUNT_DOUBLE_DEGREE_PROGRAM_MAXIMUM("cm.stu.study_account.double_degree_program.maximum"),
                    /**
                     * <p><strong>Nur Hauptfach oder alle F&auml;cher ber&uuml;cksichtigen.</strong></p>
                     * Confkey: cm.stu.study_account.double_degree_program.only_major_subject<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Ist dieser Parameter aktiviert, so wird f&uuml;r den Fall eines Doppelstudiums bei der Neu-Berechnung des Guthabens eines Studienkontos nur das Hauptfach zur Bestimmung der Regelstudienzeit herangezogen. Ist der Parameter ausgeschaltet, so werden alle F&auml;cher zur Bestimmung der Regelstudienzeit ber&uuml;cksichtigt.
                     */
                    STUDY_ACCOUNT_DOUBLE_DEGREE_PROGRAM_ONLY_MAJOR_SUBJECT("cm.stu.study_account.double_degree_program.only_major_subject"),
                    /**
                     * <p><strong>Wirkung Urlaubssemester.</strong></p>
                     * Confkey: cm.stu.study_account.leavesemester.effect<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Mit diesem Parameter wird festgelegt, wie sich ein Urlaubssemester auf ein vorhandenes Studienkonto auswirken soll.
                     */
                    STUDY_ACCOUNT_LEAVESEMESTER_EFFECT("cm.stu.study_account.leavesemester.effect"),
                    /**
                     * <p><strong>Negative Werte anzeigen.</strong></p>
                     * Confkey: cm.stu.study_account.show_numbers_less_then_zero<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Ergibt z.B. die Berechnung des aktuellen Studienguthabens einen Wert der kleiner als Null ist, so wird dieser Wert als negative Zahl angezeigt, wenn der Schalter auf 'true' steht.
                     */
                    STUDY_ACCOUNT_SHOW_NUMBERS_LESS_THEN_ZERO("cm.stu.study_account.show_numbers_less_then_zero"),
                    /**
                     * <p><strong>Toleranzsemester.</strong></p>
                     * Confkey: cm.stu.study_account.tolerance_semeseter<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Anzahl der Toleranzsemester zur Bestimmung des Guthabens
                     */
                    STUDY_ACCOUNT_TOLERANCE_SEMESETER("cm.stu.study_account.tolerance_semeseter"),
                    /**
                     * <p><strong>kleine Zweith&ouml;rer.</strong></p>
                     * Confkey: cm.stu.visiblefunctions.guestauditor.minorvisitingstudent<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Ist die Erfassung und Bearbeitung von kleinen Zweith&ouml;rer sichtbar?
                     */
                    VISIBLEFUNCTIONS_GUESTAUDITOR_MINORVISITINGSTUDENT("cm.stu.visiblefunctions.guestauditor.minorvisitingstudent"),
                    /**
                     * <p><strong>besondere Gasth&ouml;rer.</strong></p>
                     * Confkey: cm.stu.visiblefunctions.guestauditor.specialguestauditor<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Ist die Erfassung und Bearbeitung von besonderen Gasth&ouml;rer sichtbar?
                     */
                    VISIBLEFUNCTIONS_GUESTAUDITOR_SPECIALGUESTAUDITOR("cm.stu.visiblefunctions.guestauditor.specialguestauditor")
                    ;
            
            
                    /** The key. */
                    private final String key;
            
                    /**
                     * Constructor taking the global configuration parameter key.
                     */
                    private STU(String key) {
                        this.key = key;
                    }
            
                    @Override
                    public String getKey() {
                         return this.key;
                    }
                }
            
            }
        
            /**
             * Segment: CS.
             *
             * <br />
             * Company: HIS
             */
            public static class CS {
                /**
                 * Produktbereich: BI.
                 */
                public static enum BI implements KeyEnum<String>, Key {
                    /**
                     * <p><strong>Liste der BI-Komponenten, die nicht anzuzeigen sind.</strong></p>
                     * Confkey: core.bi.components.hidden<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Liste aller Komponenten, die in der Komponentenverwaltung nicht zur Installation oder zum Upgrade zur Auswahl stehen sollen.
                     */
                    COMPONENTS_HIDDEN("core.bi.components.hidden"),
                    /**
                     * <p><strong>Natives Laden der Daten mit psql (falls vorhanden)..</strong></p>
                     * Confkey: core.bi.components.use_psql<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Wenn auf dem Serversystem. auf dem HISinOne installiert ist, im Pfad f&uuml;r die ausf&uuml;hrbaren Programme psql zu finden ist, so wir dieses zum Laden der Daten in der BI verwendet.
                     */
                    COMPONENTS_USE_PSQL("core.bi.components.use_psql"),
                    /**
                     * <p><strong>Datenquelle f&uuml;r &quot;Daten der Lehre&quot;.</strong></p>
                     * Confkey: core.bi.datasource.student_allocation<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Definition der Datenquelle f&uuml;r den Bereich &quot;Daten der Lehre&quot;. Fachfallzuordnung, F&auml;cher, Abschl&uuml;sse...
                     */
                    DATASOURCE_STUDENT_ALLOCATION("core.bi.datasource.student_allocation"),
                    /**
                     * <p><strong>Definiert die Anzeige der Campus-Map.</strong></p>
                     * Confkey: core.bi.mobile.campustype<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Es gibt zwei M&ouml;glichkeiten die Campus-Map darzustellen. Als statische Grafik oder dynamisch aus GoogleMaps/OpenStreetMap in Form eines fest gew&auml;hlten Ausschnittes.
                     */
                    MOBILE_CAMPUSTYPE("core.bi.mobile.campustype"),
                    /**
                     * <p><strong>Ansicht des mobilen Stundenplanes.</strong></p>
                     * Confkey: core.bi.mobile.individual_timetable_viewtype<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Definiert die Standardansicht des mobilen Stundenplanes
                     */
                    MOBILE_INDIVIDUAL_TIMETABLE_VIEWTYPE("core.bi.mobile.individual_timetable_viewtype"),
                    /**
                     * <p><strong>Welcher Kartentyp wird bei der Ansicht des Campusplans gew&auml;hlt?.</strong></p>
                     * Confkey: core.bi.mobile.maptype<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Dieser Schl&uuml;ssel definiert, welcher Kartentyp bei der Anzeige des Campusplans gew&auml;hlt wird (GoogleMaps/OpenStreetMap).
                     */
                    MOBILE_MAPTYPE("core.bi.mobile.maptype"),
                    /**
                     * <p><strong>Aktivierung des mobilen Studierenden Cockpit.</strong></p>
                     * Confkey: core.bi.mobile.mobileversion<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Aktiviert die Browserweiche f&uuml;r das mobile Studierenden Cockpit
                     */
                    MOBILE_MOBILEVERSION("core.bi.mobile.mobileversion"),
                    /**
                     * <p><strong>X-Koordinate f&uuml;r die Darstellung eines festen Kartenausschnittes.</strong></p>
                     * Confkey: core.bi.mobile.static_campus_map_x<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Definiert die X-Koordinate zur Darstellung eines festen Kartenausschnittes mit GoogleMaps oder OpenStreetMap.
                     */
                    MOBILE_STATIC_CAMPUS_MAP_X("core.bi.mobile.static_campus_map_x"),
                    /**
                     * <p><strong>Y-Koordinate f&uuml;r die Darstellung eines festen Kartenausschnittes.</strong></p>
                     * Confkey: core.bi.mobile.static_campus_map_y<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Definiert die Y-Koordinate zur Darstellung eines festen Kartenausschnittes mit GoogleMaps oder OpenStreetMap.
                     */
                    MOBILE_STATIC_CAMPUS_MAP_Y("core.bi.mobile.static_campus_map_y")
                    ;
            
            
                    /** The key. */
                    private final String key;
            
                    /**
                     * Constructor taking the global configuration parameter key.
                     */
                    private BI(String key) {
                        this.key = key;
                    }
            
                    @Override
                    public String getKey() {
                         return this.key;
                    }
                }
            
                /**
                 * Produktbereich: COM.
                 */
                public static enum COM implements KeyEnum<String>, Key {
                    /**
                     * <p><strong>Maximale E-Adressen.</strong></p>
                     * Confkey: core.com.profile.contact_data.max_eaddresses<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Maximale Anzahl von elektronischen Adressen
                     */
                    PROFILE_CONTACT_DATA_MAX_EADDRESSES("core.com.profile.contact_data.max_eaddresses"),
                    /**
                     * <p><strong>Maximale Postadressen.</strong></p>
                     * Confkey: core.com.profile.contact_data.max_postaddresses<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Maximale Anzahl von postalischen Adressen
                     */
                    PROFILE_CONTACT_DATA_MAX_POSTADDRESSES("core.com.profile.contact_data.max_postaddresses"),
                    /**
                     * <p><strong>E-Mail-Adressen erforderlich f&uuml;r.</strong></p>
                     * Confkey: core.com.profile.contact_data.required_email_addresstags<br/>
                     * ParameterType: MANYSELECT<br/>
                     * <br/>
                     * Info: Adressarten f&uuml;r die mindestens eine E-Mail-Adresse angegeben werden muss.
                     */
                    PROFILE_CONTACT_DATA_REQUIRED_EMAIL_ADDRESSTAGS("core.com.profile.contact_data.required_email_addresstags"),
                    /**
                     * <p><strong>Postanschriften erforderlich f&uuml;r.</strong></p>
                     * Confkey: core.com.profile.contact_data.required_postaddress_addresstags<br/>
                     * ParameterType: MANYSELECT<br/>
                     * <br/>
                     * Info: Adressarten f&uuml;r die mindestens eine postalische Anschrift angegeben werden muss.
                     */
                    PROFILE_CONTACT_DATA_REQUIRED_POSTADDRESS_ADDRESSTAGS("core.com.profile.contact_data.required_postaddress_addresstags"),
                    /**
                     * <p><strong>Verwendete Adressarten.</strong></p>
                     * Confkey: core.com.profile.contact_data.used_addresstags<br/>
                     * ParameterType: MANYSELECT<br/>
                     * <br/>
                     * Info: Adressarten, die im Zentralen HISinOne-Profil verwendet werden sollen
                     */
                    PROFILE_CONTACT_DATA_USED_ADDRESSTAGS("core.com.profile.contact_data.used_addresstags"),
                    /**
                     * <p><strong>Datumsformat f&uuml;r berufliche Werdeg&auml;nge.</strong></p>
                     * Confkey: core.com.profile.employment_history_data.date_format<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Diese Einstellung legt fest, welches Datumsformat f&uuml;r Beginn- und Endedaten einer Stelle des beruflichen Werdegangs verwendet werden sollen. Es besteht die M&ouml;glichkeit zwischen 4 Varianten zu w&auml;hlen: Variante 1 beschreibt die Standardeingabe &uuml;ber ein Eingabeelement mit einem Datumsw&auml;hler. Variante 2 beschreibt die Eingabe mittels 3 Eingabeelementen f&uuml;r Tag, Monat und Jahr. Variante 3 beschreibt die Eingabe mittels 2 Eingabeelementen f&uuml;r Monat und Jahr. Variante 4 beschreibt die Eingabe mittels 1 Eingabeelement f&uuml;r das Jahr.
                     */
                    PROFILE_EMPLOYMENT_HISTORY_DATA_DATE_FORMAT("core.com.profile.employment_history_data.date_format"),
                    /**
                     * <p><strong>Maximale Eintr&auml;ge des beruflichen Werdegang.</strong></p>
                     * Confkey: core.com.profile.employment_history_data.max_employment_histories<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Maximale Anzahl von Eintr&auml;gen des beruflichen Werdegang
                     */
                    PROFILE_EMPLOYMENT_HISTORY_DATA_MAX_EMPLOYMENT_HISTORIES("core.com.profile.employment_history_data.max_employment_histories"),
                    /**
                     * <p><strong>Minimales Alter.</strong></p>
                     * Confkey: core.com.profile.person_main_data.minimum_age<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Die Anzahl der Jahre, die mindestens seit dem Geburtsdatum einer Person vergangen sein m&uuml;ssen.
                     */
                    PROFILE_PERSON_MAIN_DATA_MINIMUM_AGE("core.com.profile.person_main_data.minimum_age"),
                    /**
                     * <p><strong>H&ouml;he des Bildes.</strong></p>
                     * Confkey: core.com.profile.picture.height<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: H&ouml;he des Profilbildes in Pixeln
                     */
                    PROFILE_PICTURE_HEIGHT("core.com.profile.picture.height"),
                    /**
                     * <p><strong>Breite des Bildes.</strong></p>
                     * Confkey: core.com.profile.picture.width<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Breite des Profilbildes in Pixeln
                     */
                    PROFILE_PICTURE_WIDTH("core.com.profile.picture.width"),
                    /**
                     * <p><strong>Ansprechpartner/Verwaltungsstelle.</strong></p>
                     * Confkey: core.com.system.contact.person<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: 
                     */
                    SYSTEM_CONTACT_PERSON("core.com.system.contact.person")
                    ;
            
            
                    /** The key. */
                    private final String key;
            
                    /**
                     * Constructor taking the global configuration parameter key.
                     */
                    private COM(String key) {
                        this.key = key;
                    }
            
                    @Override
                    public String getKey() {
                         return this.key;
                    }
                }
            
                /**
                 * Produktbereich: PSV.
                 */
                public static enum PSV implements KeyEnum<String>, Key {
                    /**
                     * <p><strong>Zutrittskontrolle wird verwendet.</strong></p>
                     * Confkey: core.psv.accesscontrol.accessenabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Zutrittskontrolle wird verwendet
                     */
                    ACCESSCONTROL_ACCESSENABLED("core.psv.accesscontrol.accessenabled"),
                    /**
                     * <p><strong>Account beim Speichern generieren.</strong></p>
                     * Confkey: core.psv.account.generateaccountifnotexistonsaveperson<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Account beim Speichern generieren
                     */
                    ACCOUNT_GENERATEACCOUNTIFNOTEXISTONSAVEPERSON("core.psv.account.generateaccountifnotexistonsaveperson"),
                    /**
                     * <p><strong>Passwortl&auml;nge f&uuml;r generierte Initalpassw&ouml;rter.</strong></p>
                     * Confkey: core.psv.account.initial_password_length<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Minimale Passwortl&auml;nge bei generierten Initialpassw&ouml;rtern.
                     */
                    ACCOUNT_INITIAL_PASSWORD_LENGTH("core.psv.account.initial_password_length"),
                    /**
                     * <p><strong>Verl&auml;ngerungszeitraum f&uuml;r Studentenaccounts nach Exmatrikulation.</strong></p>
                     * Confkey: core.psv.account.lifecycle.numberofmonthlimit<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Zeitraum der Verl&auml;ngerung eines Studentenaccounts nach Exmatrikulation in Monaten
                     */
                    ACCOUNT_LIFECYCLE_NUMBEROFMONTHLIMIT("core.psv.account.lifecycle.numberofmonthlimit"),
                    /**
                     * <p><strong>Absenderadresse f&uuml;r die Funktion Passwortreset.</strong></p>
                     * Confkey: core.psv.account.noreplyemailaddress<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Absenderadresse f&uuml;r Best&auml;tigungsmail, die die Funktion Passwortreset verschickt, z. B. no-reply@his.de.
                     */
                    ACCOUNT_NOREPLYEMAILADDRESS("core.psv.account.noreplyemailaddress"),
                    /**
                     * <p><strong>Passwort-Blacklist.</strong></p>
                     * Confkey: core.psv.account.password_blacklist<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Definieren Sie Begriffe, die nicht als Passwort verwendet werden d&uuml;rfen. Geben pro Zeile einen Begriff an.
                     */
                    ACCOUNT_PASSWORD_BLACKLIST("core.psv.account.password_blacklist"),
                    /**
                     * <p><strong>Angepasste Passwort-Constraint-Klasse.</strong></p>
                     * Confkey: core.psv.account.password_custom_constraint_class<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Wenn Sie eine eigene Passwort-Policy erstellt haben, geben Sie hier den vollst&auml;ndigen Klassennamen der Passwort-Policy-Klasse an.
                     */
                    ACCOUNT_PASSWORD_CUSTOM_CONSTRAINT_CLASS("core.psv.account.password_custom_constraint_class"),
                    /**
                     * <p><strong>Hash-Verfahren.</strong></p>
                     * Confkey: core.psv.account.password_hash_type<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Das Hashverfahren f&uuml;r die Passwortverschl&uuml;sselung (H1: MD5, H2: Bcrypt, H5: Sha256Crypt, H6: Sha512Crypt)
                     */
                    ACCOUNT_PASSWORD_HASH_TYPE("core.psv.account.password_hash_type"),
                    /**
                     * <p><strong>Maximall&auml;nge eines Passworts.</strong></p>
                     * Confkey: core.psv.account.password_maximum_length<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Geben Sie die Maximall&auml;nge eines Passworts an. Diese Angabe ist optional.
                     */
                    ACCOUNT_PASSWORD_MAXIMUM_LENGTH("core.psv.account.password_maximum_length"),
                    /**
                     * <p><strong>Minimale Passwortl&auml;nge.</strong></p>
                     * Confkey: core.psv.account.password_minimum_length<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Minimale Passwortl&auml;nge, bei Selbstregistrierung und Passwort&auml;nderungsfunktion.
                     */
                    ACCOUNT_PASSWORD_MINIMUM_LENGTH("core.psv.account.password_minimum_length"),
                    /**
                     * <p><strong>Regul&auml;rer Ausdruck f&uuml;r Passw&ouml;rter.</strong></p>
                     * Confkey: core.psv.account.password_regex<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Geben Sie einen Regul&auml;ren Ausdruck an, gegen den Passw&ouml;rter gepr&uuml;ft werden. Diese Angabe ist optional.
                     */
                    ACCOUNT_PASSWORD_REGEX("core.psv.account.password_regex"),
                    /**
                     * <p><strong>Passwort Reset aktivieren.</strong></p>
                     * Confkey: core.psv.account.password_reset<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll die HISinOne Passwort-Reset-Funktion f&uuml;r Bewerber und Studenten aktiviert werden. Hinweis: Administratoren oder Sachbearbeiter bekommen aus Sicherheitsgr&uuml;nden diese Funktion generell nicht angeboten.
                     */
                    ACCOUNT_PASSWORD_RESET("core.psv.account.password_reset"),
                    /**
                     * <p><strong>passwordgenerator.</strong></p>
                     * Confkey: core.psv.account.passwordgenerator<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Welche Strategie soll f&uuml;r das Erzeugen des Initialpasswortes benutzt werden?
                     */
                    ACCOUNT_PASSWORDGENERATOR("core.psv.account.passwordgenerator"),
                    /**
                     * <p><strong>Begrenzung der L&auml;nge des Benutzernames.</strong></p>
                     * Confkey: core.psv.account.trimmUsernameAfter8Digits<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Sollen Benutzernamen beim Generieren auf 8 Stellen begrenzt werden?
                     */
                    ACCOUNT_TRIMMUSERNAMEAFTER8DIGITS("core.psv.account.trimmUsernameAfter8Digits"),
                    /**
                     * <p><strong>Accountname Generatorstrategie.</strong></p>
                     * Confkey: core.psv.account.usernamegenerator<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Welche Generatorstrategie soll verwendet werden, um Accountnamen zu generieren?
                     */
                    ACCOUNT_USERNAMEGENERATOR("core.psv.account.usernamegenerator"),
                    /**
                     * <p><strong>Initiale Kartennummer.</strong></p>
                     * Confkey: core.psv.chipcard.initialcardnumber<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Die Kartennummer, die bei der Anlage von Chipkarten generiert wird, ist gr&ouml;&szlig;er als die angegebene Nummer.
                     */
                    CHIPCARD_INITIALCARDNUMBER("core.psv.chipcard.initialcardnumber"),
                    /**
                     * <p><strong>Verwaltung von Chipkarten zu Orgunits.</strong></p>
                     * Confkey: core.psv.chipcard.orgunitchipcard<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Gibt es unpersonalisierte Chipkarten, die nur einer Organisationseinheit, z. B. FB Mathematik, zugeordnet werden?
                     */
                    CHIPCARD_ORGUNITCHIPCARD("core.psv.chipcard.orgunitchipcard"),
                    /**
                     * <p><strong>Angabe der Chipkartentyp-Id f&uuml;r Orgunits.</strong></p>
                     * Confkey: core.psv.chipcard.orgunittypeid<br/>
                     * ParameterType: LONG<br/>
                     * <br/>
                     * Info: Da die Chipkartentypen hochschulspezifisch angelegt werden k&ouml;nnen, muss hier die ID des korrekten Typs aus der Schl&uuml;sseltabelle k_chipcardtype hinterlegt werden.  Siehe dazu auch in der Dokumentation unter: HISinOne-Kern -&gt; Infrastruktur -&gt; Hochschulspezifische Konfiguration -&gt; Globale Konfiguration -&gt; Auswahl einer ID
                     */
                    CHIPCARD_ORGUNITTYPEID("core.psv.chipcard.orgunittypeid"),
                    /**
                     * <p><strong>Ermittlung von geographischen Koordinaten mittels map.google.</strong></p>
                     * Confkey: core.psv.facility.geographicdata.googlemap<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Der Link wird f&uuml;r das Ermitteln von geographischen Koordinaten aus der Adresse ben&ouml;tigt.<br />Das Ermittlungssystem ist map.google. <br />Wichtig: Es soll eine Lizenz von Google der Hochschule vorliegen!
                     */
                    FACILITY_GEOGRAPHICDATA_GOOGLEMAP("core.psv.facility.geographicdata.googlemap"),
                    /**
                     * <p><strong>Ermittlung von geographischen Koordinaten mittels OpenStreetMap.</strong></p>
                     * Confkey: core.psv.facility.geographicdata.openstreetmap<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Der Link wird f&uuml;r das Ermitteln von geographischen Koordinaten aus der Adresse ben&ouml;tigt.<br />Das Ermittlungssystem ist OpenStreetMap. OpenStreetMap ist lizenzfrei.
                     */
                    FACILITY_GEOGRAPHICDATA_OPENSTREETMAP("core.psv.facility.geographicdata.openstreetmap"),
                    /**
                     * <p><strong>Schlusselknoten f&uuml;r die Geb&auml;ude und R&auml;umen Verwaltung (Campus, Standort, Geb&auml;ude).</strong></p>
                     * Confkey: core.psv.facility.keynode<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: es wird als die erste Ebene im Geb&auml;ude-R&auml;ume bearbeiten - Baum benutzt
                     */
                    FACILITY_KEYNODE("core.psv.facility.keynode"),
                    /**
                     * <p><strong>Addresssuche aktivieren.</strong></p>
                     * Confkey: core.psv.idmanagement.matching.addresssearch.active<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Adresssuche aktivieren
                     */
                    IDMANAGEMENT_MATCHING_ADDRESSSEARCH_ACTIVE("core.psv.idmanagement.matching.addresssearch.active"),
                    /**
                     * <p><strong>Adresstags (home, semester, privat).</strong></p>
                     * Confkey: core.psv.idmanagement.matching.addresssearch.addresstags<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Adresstags (home, semester, privat)
                     */
                    IDMANAGEMENT_MATCHING_ADDRESSSEARCH_ADDRESSTAGS("core.psv.idmanagement.matching.addresssearch.addresstags"),
                    /**
                     * <p><strong>Adresstypen (email, postaddress,..).</strong></p>
                     * Confkey: core.psv.idmanagement.matching.addresssearch.addresstypes<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Adresstypen (email, postaddress,..)
                     */
                    IDMANAGEMENT_MATCHING_ADDRESSSEARCH_ADDRESSTYPES("core.psv.idmanagement.matching.addresssearch.addresstypes"),
                    /**
                     * <p><strong>Suche nach Personenmerkmalen aktivieren.</strong></p>
                     * Confkey: core.psv.idmanagement.matching.personattributesearch.active<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Suche nach Personenmerkmalen aktivieren
                     */
                    IDMANAGEMENT_MATCHING_PERSONATTRIBUTESEARCH_ACTIVE("core.psv.idmanagement.matching.personattributesearch.active"),
                    /**
                     * <p><strong>Personenattribute f&uuml;r die Suche.</strong></p>
                     * Confkey: core.psv.idmanagement.matching.personattributesearch.personattributes<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Personenattribute f&uuml;r die Suche
                     */
                    IDMANAGEMENT_MATCHING_PERSONATTRIBUTESEARCH_PERSONATTRIBUTES("core.psv.idmanagement.matching.personattributesearch.personattributes"),
                    /**
                     * <p><strong>Phonetische Suche aktivieren.</strong></p>
                     * Confkey: core.psv.idmanagement.matching.phoneticsearch.active<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Phonetische Suche aktivieren
                     */
                    IDMANAGEMENT_MATCHING_PHONETICSEARCH_ACTIVE("core.psv.idmanagement.matching.phoneticsearch.active"),
                    /**
                     * <p><strong>Algorithmus f&uuml;r phonetische Suche.</strong></p>
                     * Confkey: core.psv.idmanagement.matching.phoneticsearch.algorithm<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Algorithmus f&uuml;r phonetische Suche
                     */
                    IDMANAGEMENT_MATCHING_PHONETICSEARCH_ALGORITHM("core.psv.idmanagement.matching.phoneticsearch.algorithm"),
                    /**
                     * <p><strong>Personenattribute f&uuml;r phonetische Suche.</strong></p>
                     * Confkey: core.psv.idmanagement.matching.phoneticsearch.personattributes<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Personenattribute f&uuml;r phonetische Suche
                     */
                    IDMANAGEMENT_MATCHING_PHONETICSEARCH_PERSONATTRIBUTES("core.psv.idmanagement.matching.phoneticsearch.personattributes"),
                    /**
                     * <p><strong>Autmatische Wahrscheinlichkeitspr&uuml;fung.</strong></p>
                     * Confkey: core.psv.idmanagement.matching.probabilitycheckactive<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Beim der Funktion &quot;Suche nach doppelten Personeneintr&auml;gen&quot; werden wom&ouml;glich viele Treffer gefunden, die offensichtlich nichts miteinander zu tun haben. Durch aktivieren dieser Funktion wird die automatische Wahrscheinlichkeitspr&uuml;fung aktiviert und die vermuteten Treffer reduziert.
                     */
                    IDMANAGEMENT_MATCHING_PROBABILITYCHECKACTIVE("core.psv.idmanagement.matching.probabilitycheckactive"),
                    /**
                     * <p><strong>Schwellenwert.</strong></p>
                     * Confkey: core.psv.idmanagement.matching.probabilitythrehold<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Beim bewerten der Treffer bei der Dublettensuche wird der folgende Schwellenwert benutzt. Dabei sind Werte zwischen 0.0 und 2.0 w&auml;hlbar (mit Kommastellen, getrennt durch &quot;.&quot;). Je geringer der Wert, desto unwahrscheinlicher ist es, dass zwei &quot;Treffer&quot; ein und dieselbe Person sind.
                     */
                    IDMANAGEMENT_MATCHING_PROBABILITYTHREHOLD("core.psv.idmanagement.matching.probabilitythrehold"),
                    /**
                     * <p><strong>Nur Personen mit gleicher Rolle ber&uuml;cksichtigen.</strong></p>
                     * Confkey: core.psv.idmanagement.matching.rolematch<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Beim Suchen werden nur Personen ber&uuml;cksichtigt, die die gleiche Rolle haben.
                     */
                    IDMANAGEMENT_MATCHING_ROLEMATCH("core.psv.idmanagement.matching.rolematch"),
                    /**
                     * <p><strong>Blob.</strong></p>
                     * Confkey: core.psv.idmanagement.picture.blob<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Angabe, ob das Foto als Blob-Feld gespeichert wird
                     */
                    IDMANAGEMENT_PICTURE_BLOB("core.psv.idmanagement.picture.blob"),
                    /**
                     * <p><strong>Maximale Dateigr&ouml;&szlig;e.</strong></p>
                     * Confkey: core.psv.idmanagement.picture.file_size_limit<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Maximale Dateigr&ouml;&szlig;e
                     */
                    IDMANAGEMENT_PICTURE_FILE_SIZE_LIMIT("core.psv.idmanagement.picture.file_size_limit"),
                    /**
                     * <p><strong>Bilderverzeichnis.</strong></p>
                     * Confkey: core.psv.idmanagement.picture.path<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Verzeichnis, in dem die Bilder zu Personen abgelegt werden.
                     */
                    IDMANAGEMENT_PICTURE_PATH("core.psv.idmanagement.picture.path"),
                    /**
                     * <p><strong>tempor&auml;res Bilderverzeichnis.</strong></p>
                     * Confkey: core.psv.idmanagement.picture.tmp_path<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Verzeichnis, in dem die Bilder beim hochladen tempor&auml;r gespeichert werden.
                     */
                    IDMANAGEMENT_PICTURE_TMP_PATH("core.psv.idmanagement.picture.tmp_path"),
                    /**
                     * <p><strong>G&uuml;ltige Bildertypen.</strong></p>
                     * Confkey: core.psv.idmanagement.picture.valid_file_types<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: G&uuml;ltige Bildertypen
                     */
                    IDMANAGEMENT_PICTURE_VALID_FILE_TYPES("core.psv.idmanagement.picture.valid_file_types"),
                    /**
                     * <p><strong>Ldap-Export aktivieren.</strong></p>
                     * Confkey: core.psv.interface.ldap.active<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll ein Ldap-Export durchgef&uuml;hrt werden? (Nach &Auml;nderung ist ein Neustart n&ouml;tig!)
                     */
                    INTERFACE_LDAP_ACTIVE("core.psv.interface.ldap.active"),
                    /**
                     * <p><strong>LDAP-Schema.</strong></p>
                     * Confkey: core.psv.interface.ldap.schema<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Welches LDAP-Schema soll bef&uuml;llt werden?
                     */
                    INTERFACE_LDAP_SCHEMA("core.psv.interface.ldap.schema"),
                    /**
                     * <p><strong>Anzahl der TANs ab der der Benutzer aufgefordert wird, eine neue TAN-Liste zu generieren.</strong></p>
                     * Confkey: core.psv.itan.block_user_min_tans_left<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_BLOCK_USER_MIN_TANS_LEFT("core.psv.itan.block_user_min_tans_left"),
                    /**
                     * <p><strong>Anzahl der Fehlversuche eines Benutzers.</strong></p>
                     * Confkey: core.psv.itan.max_failed_attempts<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_MAX_FAILED_ATTEMPTS("core.psv.itan.max_failed_attempts"),
                    /**
                     * <p><strong>Rollen.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_by_planelement_close.role_ids<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_BY_PLANELEMENT_CLOSE_ROLE_IDS("core.psv.itan.secure_assessment_by_planelement_close.role_ids"),
                    /**
                     * <p><strong>Abfrage aktivieren.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_by_planelement_close.should_query<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_BY_PLANELEMENT_CLOSE_SHOULD_QUERY("core.psv.itan.secure_assessment_by_planelement_close.should_query"),
                    /**
                     * <p><strong>Rollen.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_by_planelement_disclose.role_ids<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_BY_PLANELEMENT_DISCLOSE_ROLE_IDS("core.psv.itan.secure_assessment_by_planelement_disclose.role_ids"),
                    /**
                     * <p><strong>Abfrage aktivieren.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_by_planelement_disclose.should_query<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_BY_PLANELEMENT_DISCLOSE_SHOULD_QUERY("core.psv.itan.secure_assessment_by_planelement_disclose.should_query"),
                    /**
                     * <p><strong>Rollen.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_by_planelement_disclose_preliminarily.role_ids<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_BY_PLANELEMENT_DISCLOSE_PRELIMINARILY_ROLE_IDS("core.psv.itan.secure_assessment_by_planelement_disclose_preliminarily.role_ids"),
                    /**
                     * <p><strong>Abfrage aktivieren.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_by_planelement_disclose_preliminarily.should_query<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_BY_PLANELEMENT_DISCLOSE_PRELIMINARILY_SHOULD_QUERY("core.psv.itan.secure_assessment_by_planelement_disclose_preliminarily.should_query"),
                    /**
                     * <p><strong>Rollen.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_by_planelement_export.role_ids<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_BY_PLANELEMENT_EXPORT_ROLE_IDS("core.psv.itan.secure_assessment_by_planelement_export.role_ids"),
                    /**
                     * <p><strong>Abfrage aktivieren.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_by_planelement_export.should_query<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_BY_PLANELEMENT_EXPORT_SHOULD_QUERY("core.psv.itan.secure_assessment_by_planelement_export.should_query"),
                    /**
                     * <p><strong>Rollen.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_by_planelement_open.role_ids<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_BY_PLANELEMENT_OPEN_ROLE_IDS("core.psv.itan.secure_assessment_by_planelement_open.role_ids"),
                    /**
                     * <p><strong>Abfrage aktivieren.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_by_planelement_open.should_query<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_BY_PLANELEMENT_OPEN_SHOULD_QUERY("core.psv.itan.secure_assessment_by_planelement_open.should_query"),
                    /**
                     * <p><strong>Rollen.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_by_planelement_revoke_disclosure.role_ids<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_BY_PLANELEMENT_REVOKE_DISCLOSURE_ROLE_IDS("core.psv.itan.secure_assessment_by_planelement_revoke_disclosure.role_ids"),
                    /**
                     * <p><strong>Abfrage aktivieren.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_by_planelement_revoke_disclosure.should_query<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_BY_PLANELEMENT_REVOKE_DISCLOSURE_SHOULD_QUERY("core.psv.itan.secure_assessment_by_planelement_revoke_disclosure.should_query"),
                    /**
                     * <p><strong>Rollen.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_by_planelement_save.role_ids<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_BY_PLANELEMENT_SAVE_ROLE_IDS("core.psv.itan.secure_assessment_by_planelement_save.role_ids"),
                    /**
                     * <p><strong>Abfrage aktivieren.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_by_planelement_save.should_query<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_BY_PLANELEMENT_SAVE_SHOULD_QUERY("core.psv.itan.secure_assessment_by_planelement_save.should_query"),
                    /**
                     * <p><strong>Rollen.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_by_planelement_supplements_save.role_ids<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_BY_PLANELEMENT_SUPPLEMENTS_SAVE_ROLE_IDS("core.psv.itan.secure_assessment_by_planelement_supplements_save.role_ids"),
                    /**
                     * <p><strong>Abfrage aktivieren.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_by_planelement_supplements_save.should_query<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_BY_PLANELEMENT_SUPPLEMENTS_SAVE_SHOULD_QUERY("core.psv.itan.secure_assessment_by_planelement_supplements_save.should_query"),
                    /**
                     * <p><strong>Rollen.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_by_unit_close.role_ids<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_BY_UNIT_CLOSE_ROLE_IDS("core.psv.itan.secure_assessment_by_unit_close.role_ids"),
                    /**
                     * <p><strong>Abfrage aktivieren.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_by_unit_close.should_query<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_BY_UNIT_CLOSE_SHOULD_QUERY("core.psv.itan.secure_assessment_by_unit_close.should_query"),
                    /**
                     * <p><strong>Rollen.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_by_unit_disclose.role_ids<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_BY_UNIT_DISCLOSE_ROLE_IDS("core.psv.itan.secure_assessment_by_unit_disclose.role_ids"),
                    /**
                     * <p><strong>Abfrage aktivieren.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_by_unit_disclose.should_query<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_BY_UNIT_DISCLOSE_SHOULD_QUERY("core.psv.itan.secure_assessment_by_unit_disclose.should_query"),
                    /**
                     * <p><strong>Rollen.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_by_unit_disclose_preliminarily.role_ids<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_BY_UNIT_DISCLOSE_PRELIMINARILY_ROLE_IDS("core.psv.itan.secure_assessment_by_unit_disclose_preliminarily.role_ids"),
                    /**
                     * <p><strong>Abfrage aktivieren.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_by_unit_disclose_preliminarily.should_query<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_BY_UNIT_DISCLOSE_PRELIMINARILY_SHOULD_QUERY("core.psv.itan.secure_assessment_by_unit_disclose_preliminarily.should_query"),
                    /**
                     * <p><strong>Rollen.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_by_unit_export.role_ids<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_BY_UNIT_EXPORT_ROLE_IDS("core.psv.itan.secure_assessment_by_unit_export.role_ids"),
                    /**
                     * <p><strong>Abfrage aktivieren.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_by_unit_export.should_query<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_BY_UNIT_EXPORT_SHOULD_QUERY("core.psv.itan.secure_assessment_by_unit_export.should_query"),
                    /**
                     * <p><strong>Rollen.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_by_unit_open.role_ids<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_BY_UNIT_OPEN_ROLE_IDS("core.psv.itan.secure_assessment_by_unit_open.role_ids"),
                    /**
                     * <p><strong>Abfrage aktivieren.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_by_unit_open.should_query<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_BY_UNIT_OPEN_SHOULD_QUERY("core.psv.itan.secure_assessment_by_unit_open.should_query"),
                    /**
                     * <p><strong>Rollen.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_by_unit_revoke_disclosure.role_ids<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_BY_UNIT_REVOKE_DISCLOSURE_ROLE_IDS("core.psv.itan.secure_assessment_by_unit_revoke_disclosure.role_ids"),
                    /**
                     * <p><strong>Abfrage aktivieren.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_by_unit_revoke_disclosure.should_query<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_BY_UNIT_REVOKE_DISCLOSURE_SHOULD_QUERY("core.psv.itan.secure_assessment_by_unit_revoke_disclosure.should_query"),
                    /**
                     * <p><strong>Rollen.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_by_unit_save.role_ids<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_BY_UNIT_SAVE_ROLE_IDS("core.psv.itan.secure_assessment_by_unit_save.role_ids"),
                    /**
                     * <p><strong>Abfrage aktivieren.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_by_unit_save.should_query<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_BY_UNIT_SAVE_SHOULD_QUERY("core.psv.itan.secure_assessment_by_unit_save.should_query"),
                    /**
                     * <p><strong>Rollen.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_detail_save.role_ids<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_DETAIL_SAVE_ROLE_IDS("core.psv.itan.secure_assessment_detail_save.role_ids"),
                    /**
                     * <p><strong>Abfrage aktivieren.</strong></p>
                     * Confkey: core.psv.itan.secure_assessment_detail_save.should_query<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ASSESSMENT_DETAIL_SAVE_SHOULD_QUERY("core.psv.itan.secure_assessment_detail_save.should_query"),
                    /**
                     * <p><strong>Soll die Funktion 'Lastschriftauftrag erteilen/&auml;ndern' abgesichert werden.</strong></p>
                     * Confkey: core.psv.itan.secure_direct_debit_edit.should_query<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_DIRECT_DEBIT_EDIT_SHOULD_QUERY("core.psv.itan.secure_direct_debit_edit.should_query"),
                    /**
                     * <p><strong>Rollen-Ids, die abgesichert werden.</strong></p>
                     * Confkey: core.psv.itan.secure_edit_bank_account.role_ids<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_EDIT_BANK_ACCOUNT_ROLE_IDS("core.psv.itan.secure_edit_bank_account.role_ids"),
                    /**
                     * <p><strong>Soll die Funktion 'Bankkonto bearbeiten' abgesichert werden.</strong></p>
                     * Confkey: core.psv.itan.secure_edit_bank_account.should_query<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_EDIT_BANK_ACCOUNT_SHOULD_QUERY("core.psv.itan.secure_edit_bank_account.should_query"),
                    /**
                     * <p><strong>Rollen-Ids, die abgesichert werden.</strong></p>
                     * Confkey: core.psv.itan.secure_edit_person_data.role_ids<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_EDIT_PERSON_DATA_ROLE_IDS("core.psv.itan.secure_edit_person_data.role_ids"),
                    /**
                     * <p><strong>Soll die Funktion 'pers&ouml;nliche Daten bearbeiten' abgesichert werden.</strong></p>
                     * Confkey: core.psv.itan.secure_edit_person_data.should_query<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_EDIT_PERSON_DATA_SHOULD_QUERY("core.psv.itan.secure_edit_person_data.should_query"),
                    /**
                     * <p><strong>Soll die Funktion 'Mandat anlegen' abgesichert werden.</strong></p>
                     * Confkey: core.psv.itan.secure_mandate_save.should_query<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_MANDATE_SAVE_SHOULD_QUERY("core.psv.itan.secure_mandate_save.should_query"),
                    /**
                     * <p><strong>Soll die Funktion 'Online-R&uuml;ckmeldung' abgesichert werden.</strong></p>
                     * Confkey: core.psv.itan.secure_online_reregistration.should_query<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_SECURE_ONLINE_REREGISTRATION_SHOULD_QUERY("core.psv.itan.secure_online_reregistration.should_query"),
                    /**
                     * <p><strong>L&auml;nge einer einzelnen TAN.</strong></p>
                     * Confkey: core.psv.itan.tan_length<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_TAN_LENGTH("core.psv.itan.tan_length"),
                    /**
                     * <p><strong>Anzahl der TANs auf einer Liste.</strong></p>
                     * Confkey: core.psv.itan.tans_per_list<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_TANS_PER_LIST("core.psv.itan.tans_per_list"),
                    /**
                     * <p><strong>Anzahl der TANs ab der eine Warnung ausgegeben wird.</strong></p>
                     * Confkey: core.psv.itan.warn_user_min_tans_left<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: 
                     */
                    ITAN_WARN_USER_MIN_TANS_LEFT("core.psv.itan.warn_user_min_tans_left"),
                    /**
                     * <p><strong>Nur internationale Kontoverbindungen zulassen.</strong></p>
                     * Confkey: core.psv.person.bankaccount.use_only_iban<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Es sollen nur Kontoverbindungen im internationalen Format angelegt werden k&ouml;nnen.
                     */
                    PERSON_BANKACCOUNT_USE_ONLY_IBAN("core.psv.person.bankaccount.use_only_iban"),
                    /**
                     * <p><strong>Gesch&auml;ftliche Personendaten.</strong></p>
                     * Confkey: core.psv.person.businesspersonattributes<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Personendaten sind sehr sensible Daten. Um Funktionen wie  z. b. ein Personalhandbuch erstellen zu k&ouml;nnen, ist es notwendig, bestimmte Personendaten anzuzeigen. Diese werden mit Hilfe dieses Schl&uuml;ssels definiert. Sinnvoll sind alle Daten, die man auch auf einer Visitenkarte finden w&uuml;rde.
                     */
                    PERSON_BUSINESSPERSONATTRIBUTES("core.psv.person.businesspersonattributes"),
                    /**
                     * <p><strong>Eigene Hochschule.</strong></p>
                     * Confkey: core.psv.self.own_university<br/>
                     * ParameterType: ORGUNIT<br/>
                     * <br/>
                     * Info: In der Organisationseinheiten-Struktur (neu angelegt oder aus der Migration) gibt es eine Einrichtung &quot;Hochschule&quot;. Diese muss hier angegeben werden und wird bspw. f&uuml;r Rollen und Rechte Auswertungen verwendet. I.d.R. ist dies nicht das Wurzelelement ihres Organisationsbaumes.
                     */
                    SELF_OWN_UNIVERSITY("core.psv.self.own_university"),
                    /**
                     * <p><strong>Default-Land.</strong></p>
                     * Confkey: core.psv.selfregistration.defaultcountryuniquename<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Vorbelegung eines Landes f&uuml;r die Selbstregistrierung
                     */
                    SELFREGISTRATION_DEFAULTCOUNTRYUNIQUENAME("core.psv.selfregistration.defaultcountryuniquename"),
                    /**
                     * <p><strong>Benutzernamen generieren.</strong></p>
                     * Confkey: core.psv.selfregistration.generate_username<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll der Benutzername generiert oder vom Bewerber selbst ausgew&auml;hlt werden?
                     */
                    SELFREGISTRATION_GENERATE_USERNAME("core.psv.selfregistration.generate_username"),
                    /**
                     * <p><strong>Server.</strong></p>
                     * Confkey: core.psv.selfregistration.mail.smtp.host<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Adresse des Postausgangsservers f&uuml;r die Selbstregistrierung. Wird keine Adresse angegeben, wird der Wert den DispatcherProperties bezogen.
                     */
                    SELFREGISTRATION_MAIL_SMTP_HOST("core.psv.selfregistration.mail.smtp.host"),
                    /**
                     * <p><strong>Password.</strong></p>
                     * Confkey: core.psv.selfregistration.mail.smtp.password<br/>
                     * ParameterType: PASSWORD_PLAINTEXT<br/>
                     * <br/>
                     * Info: Passwort das f&uuml;r die Authentifikation am Postausgangsserver verwendet werden soll.
                     */
                    SELFREGISTRATION_MAIL_SMTP_PASSWORD("core.psv.selfregistration.mail.smtp.password"),
                    /**
                     * <p><strong>Port.</strong></p>
                     * Confkey: core.psv.selfregistration.mail.smtp.port<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Port des Postausgangsservers. Der Port ist im Normalfall 25 (bzw. 465 bei einer SSL-Verbindung), inzwischen wird aber auch h&auml;ufig der Port 587 verwendet. Wird kein Port angegeben, wird der Wert 25 angenommen.
                     */
                    SELFREGISTRATION_MAIL_SMTP_PORT("core.psv.selfregistration.mail.smtp.port"),
                    /**
                     * <p><strong>Erweiterte Einstellungen.</strong></p>
                     * Confkey: core.psv.selfregistration.mail.smtp.properties<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Erweiterte SMTP-Einstellungen. Diese Einstellungen dienen der Definition zus&auml;tzlicher SMTP-Einstellungen wie &quot;mail.smtp.starttls.enable=true&quot; und &quot;mail.smtp.auth=true&quot; zur Aktivierung von TLS
                     */
                    SELFREGISTRATION_MAIL_SMTP_PROPERTIES("core.psv.selfregistration.mail.smtp.properties"),
                    /**
                     * <p><strong>Benutzername.</strong></p>
                     * Confkey: core.psv.selfregistration.mail.smtp.username<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Benutzername der f&uuml;r die Authentifikation am Postausgangsserver verwendet werden soll.
                     */
                    SELFREGISTRATION_MAIL_SMTP_USERNAME("core.psv.selfregistration.mail.smtp.username"),
                    /**
                     * <p><strong>Absenderadresse f&uuml;r Best&auml;tigungsmail.</strong></p>
                     * Confkey: core.psv.selfregistration.noreplyemailaddress<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Absenderadresse f&uuml;r Best&auml;tigungsmail, z. B. no-reply@his.de.
                     */
                    SELFREGISTRATION_NOREPLYEMAILADDRESS("core.psv.selfregistration.noreplyemailaddress"),
                    /**
                     * <p><strong>Abfragedialog &quot;bereits registriert&quot; einblenden.</strong></p>
                     * Confkey: core.psv.selfregistration.show_already_register_question<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll vor der Selbstregistrierung der Interessent gefragt werden, ob er bereits registriert ist?
                     */
                    SELFREGISTRATION_SHOW_ALREADY_REGISTER_QUESTION("core.psv.selfregistration.show_already_register_question"),
                    /**
                     * <p><strong>E-Mail-Adresse f&uuml;r Support.</strong></p>
                     * Confkey: core.psv.selfregistration.supportemailaddress<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: E-Mail-Adresse bei Fehler w&auml;hrend der Selbstregistrierung
                     */
                    SELFREGISTRATION_SUPPORTEMAILADDRESS("core.psv.selfregistration.supportemailaddress")
                    ;
            
            
                    /** The key. */
                    private final String key;
            
                    /**
                     * Constructor taking the global configuration parameter key.
                     */
                    private PSV(String key) {
                        this.key = key;
                    }
            
                    @Override
                    public String getKey() {
                         return this.key;
                    }
                }
            
                /**
                 * Produktbereich: SYS.
                 */
                public static enum SYS implements KeyEnum<String>, Key {
                    /**
                     * <p><strong>Aktionen.</strong></p>
                     * Confkey: core.sys.administration.applog.actions<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: String bestehend aus: c = Create, u = Update, d = Delete, r = Read, bei diesen Aktionen wird protokolliert
                     */
                    ADMINISTRATION_APPLOG_ACTIONS("core.sys.administration.applog.actions"),
                    /**
                     * <p><strong>Name des Clusternodes anzeigen.</strong></p>
                     * Confkey: core.sys.administration.cluster.show_node_name<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll der Name des Knotens und der Name des Clusters immer unten rechts auf der Seite angezeigt werden?
                     */
                    ADMINISTRATION_CLUSTER_SHOW_NODE_NAME("core.sys.administration.cluster.show_node_name"),
                    /**
                     * <p><strong>Servername.</strong></p>
                     * Confkey: core.sys.administration.configurationcenter.servername<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Servername f&uuml;r den Konfigurationscenter-Server
                     */
                    ADMINISTRATION_CONFIGURATIONCENTER_SERVERNAME("core.sys.administration.configurationcenter.servername"),
                    /**
                     * <p><strong>Serverport.</strong></p>
                     * Confkey: core.sys.administration.configurationcenter.serverport<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Port auf dem der Konfigurationscenter-Server erreichtbar ist
                     */
                    ADMINISTRATION_CONFIGURATIONCENTER_SERVERPORT("core.sys.administration.configurationcenter.serverport"),
                    /**
                     * <p><strong>Serverprotokoll.</strong></p>
                     * Confkey: core.sys.administration.configurationcenter.serverprotokoll<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Protokoll f&uuml;r den Server des Konfigurationscenters
                     */
                    ADMINISTRATION_CONFIGURATIONCENTER_SERVERPROTOKOLL("core.sys.administration.configurationcenter.serverprotokoll"),
                    /**
                     * <p><strong>Konfiguration der Produktbereiche starten.</strong></p>
                     * Confkey: core.sys.administration.start_configuration<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Wird nur intern verwendet. Ist der Wert true, so wird das System erstmalig nach Durchf&uuml;hrung des Setup-Assistenten gestartet.
                     */
                    ADMINISTRATION_START_CONFIGURATION("core.sys.administration.start_configuration"),
                    /**
                     * <p><strong>Speicherort der Collectd RRDs.</strong></p>
                     * Confkey: core.sys.administration.system_monitor.collectd_path<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Diese Einstellung legt fest, wo sich die RRDs von Collectd befinden
                     */
                    ADMINISTRATION_SYSTEM_MONITOR_COLLECTD_PATH("core.sys.administration.system_monitor.collectd_path"),
                    /**
                     * <p><strong>H&ouml;he des Graphen.</strong></p>
                     * Confkey: core.sys.administration.system_monitor.height<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Diese Einstellung legt fest, wie hoch (in Pixel) ein erstellter Graph werden darf
                     */
                    ADMINISTRATION_SYSTEM_MONITOR_HEIGHT("core.sys.administration.system_monitor.height"),
                    /**
                     * <p><strong>Pfad zum RRDTool.</strong></p>
                     * Confkey: core.sys.administration.system_monitor.rrdtool<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Diese Einstellung legt fest, wo sich RRDTool befindet
                     */
                    ADMINISTRATION_SYSTEM_MONITOR_RRDTOOL("core.sys.administration.system_monitor.rrdtool"),
                    /**
                     * <p><strong>Breite des Graphen.</strong></p>
                     * Confkey: core.sys.administration.system_monitor.width<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Diese Einstellung legt fest, wie breit (in Pixel) ein erstellter Graph werden darf
                     */
                    ADMINISTRATION_SYSTEM_MONITOR_WIDTH("core.sys.administration.system_monitor.width"),
                    /**
                     * <p><strong>Login-Link zu einem Authentifizierungssystem.</strong></p>
                     * Confkey: core.sys.authentication.authentication_system_login_link<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Statt der Eingabefelder f&uuml;r Benutzername und Passwort kann auch ein Link zu einem Authentifizierungssystem, bspw. CAS, angezeigt werden. Der Link k&ouml;nnte wie folgt aussehen: https://www.tu-irgendwas.de/cas/login?service=http%3A%2F%2Fqis.exmaple.com/qisserver/rds%3Fstate%3Duser%26type%3D1
                     */
                    AUTHENTICATION_AUTHENTICATION_SYSTEM_LOGIN_LINK("core.sys.authentication.authentication_system_login_link"),
                    /**
                     * <p><strong>Logout-Link zu einem Authentifizierungssystem.</strong></p>
                     * Confkey: core.sys.authentication.authentication_system_logout_link<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Der Link zum Abmelden wird ersetzt, um bspw. CAS abzumelden. Dieser k&ouml;nnte wie folgt aussehen: https://www.tu-irgendwas.de/cas/logout?service=http%3A%2F%2Fqis.exmaple.com/qisserver/rds%3Fstate=user%26type=4%26category=auth.logout
                     */
                    AUTHENTICATION_AUTHENTICATION_SYSTEM_LOGOUT_LINK("core.sys.authentication.authentication_system_logout_link"),
                    /**
                     * <p><strong>URLs die als Grafiken eingebunden werden.</strong></p>
                     * Confkey: core.sys.authentication.logout_images<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Diese URLs werden als Grafiken (img) eingebunden um eine Fremdanwendung aufzurufen, bspw. f&uuml;r einen CAS-Logout. Die Grafiken werden eingebunden, wenn der Nutzer nicht angemeldet und die Nutzersession neu ist. Beispiel: http://localhost/qisserver/rds?state=portalTest
                     */
                    AUTHENTICATION_LOGOUT_IMAGES("core.sys.authentication.logout_images"),
                    /**
                     * <p><strong>Anmeldemaske.</strong></p>
                     * Confkey: core.sys.authentication.userinterface<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Welche Authentifizierungsverfahren werden in der Benutzeroberfl&auml;che angeboten?
                     */
                    AUTHENTICATION_USERINTERFACE("core.sys.authentication.userinterface"),
                    /**
                     * <p><strong>Pr&auml;fixsuche.</strong></p>
                     * Confkey: core.sys.customizing.genericsearch.prefixsearchenabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Bei Aktivierung des Schalters, wird bei Suchen in der Datenbank &uuml;ber die generische Suche nur nach einem Pr&auml;fix wie &quot;a%&quot; gesucht anstatt standardm&auml;&szlig;ig &quot;%a%&quot;. Bei aktivierter Pr&auml;fixsuche ist das alte Standardverhalten durch Verwendung von Wildcards weiterhin verf&uuml;gbar.
                     */
                    CUSTOMIZING_GENERICSEARCH_PREFIXSEARCHENABLED("core.sys.customizing.genericsearch.prefixsearchenabled"),
                    /**
                     * <p><strong>Portalsprachen.</strong></p>
                     * Confkey: core.sys.customizing.language.portal_languages<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Alle zul&auml;ssigen Sprachen im Portal
                     */
                    CUSTOMIZING_LANGUAGE_PORTAL_LANGUAGES("core.sys.customizing.language.portal_languages"),
                    /**
                     * <p><strong>&Uuml;bersetzungssprachen.</strong></p>
                     * Confkey: core.sys.customizing.language.translation_languages<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Alle &Uuml;bersetzungssprachen
                     */
                    CUSTOMIZING_LANGUAGE_TRANSLATION_LANGUAGES("core.sys.customizing.language.translation_languages"),
                    /**
                     * <p><strong>Passw&ouml;rter merken.</strong></p>
                     * Confkey: core.sys.customizing.portal.autocomplete_password<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll der Browser sich die Passw&ouml;rter der Anwender merken k&ouml;nnen? Achten Sie darauf, dass diese Einstellungen mit den Sicherheitsrichtlinien Ihrer Hochschule &uuml;bereinstimmen muss.
                     */
                    CUSTOMIZING_PORTAL_AUTOCOMPLETE_PASSWORD("core.sys.customizing.portal.autocomplete_password"),
                    /**
                     * <p><strong>Default &Uuml;berschrift/Titel der Seite.</strong></p>
                     * Confkey: core.sys.customizing.portal.default_title<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Sollte es einmal dazu kommen, dass die &Uuml;berschrift einer Seite nicht automatisch bestimmt werden kann, so wird dieser Text angezeigt. Er ist auch Teil des Browser-Titels. Dieser setzt sich aus zwei Teilen zusammen. Der vordere Teil w&auml;re dieser Text. Der hintere Teil ist immer der Name des Portals/Ihres Systems (I18n: cs.sys.portal.name)
                     */
                    CUSTOMIZING_PORTAL_DEFAULT_TITLE("core.sys.customizing.portal.default_title"),
                    /**
                     * <p><strong>Kr&uuml;melpfad ausblenden.</strong></p>
                     * Confkey: core.sys.customizing.portal.disable_breadcrumb<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Bei True wird der Kr&uuml;melpfad nicht mehr angezeigt. Diese Einstellung wird von HIS ausdr&uuml;cklich nicht empfohlen.
                     */
                    CUSTOMIZING_PORTAL_DISABLE_BREADCRUMB("core.sys.customizing.portal.disable_breadcrumb"),
                    /**
                     * <p><strong>Login Statuszeile ausblenden.</strong></p>
                     * Confkey: core.sys.customizing.portal.disable_loginstatus<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Bei True, wird die Zeile ausgeblendet. Dies wird von HIS ausdr&uuml;cklich nicht empfohlen.
                     */
                    CUSTOMIZING_PORTAL_DISABLE_LOGINSTATUS("core.sys.customizing.portal.disable_loginstatus"),
                    /**
                     * <p><strong>Connection Timeout.</strong></p>
                     * Confkey: core.sys.customizing.portal.feeds.connection_timeout<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Abbruch nach Ablauf der angegeben Zeit in Millisekunden.
                     */
                    CUSTOMIZING_PORTAL_FEEDS_CONNECTION_TIMEOUT("core.sys.customizing.portal.feeds.connection_timeout"),
                    /**
                     * <p><strong>Feeds publizieren.</strong></p>
                     * Confkey: core.sys.customizing.portal.feeds.publish<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Diese Feeds werden dem Browser angeboten und k&ouml;nnen vom Nutzer direkt entgegen genommen werden. Erst nach dem Abmelden werden &Auml;nderungen beim Nutzer sichtbar.
                     */
                    CUSTOMIZING_PORTAL_FEEDS_PUBLISH("core.sys.customizing.portal.feeds.publish"),
                    /**
                     * <p><strong>Read Timeout.</strong></p>
                     * Confkey: core.sys.customizing.portal.feeds.read_timeout<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Abbruch nach Ablauf der angegeben Zeit in Millisekunden.
                     */
                    CUSTOMIZING_PORTAL_FEEDS_READ_TIMEOUT("core.sys.customizing.portal.feeds.read_timeout"),
                    /**
                     * <p><strong>Feed Cache Timeout.</strong></p>
                     * Confkey: core.sys.customizing.portal.feeds.refresh_time<br/>
                     * ParameterType: LONG<br/>
                     * <br/>
                     * Info: Zeit in Millisekunden bis zur Aktualisierung eines Feeds. Wenn kein Wert gesetzt wird sind es 15 Minute.
                     */
                    CUSTOMIZING_PORTAL_FEEDS_REFRESH_TIME("core.sys.customizing.portal.feeds.refresh_time"),
                    /**
                     * <p><strong>Feeds auf Untrusted-Domain anzeigen.</strong></p>
                     * Confkey: core.sys.customizing.portal.feeds.render_on_untrusted_domain<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Sollen Feeds auf der Untrusted-Domain angezeigt werden? Diese Sicherheitsma&szlig;nahme wird von HIS empfohlen. Dies f&uuml;hrt aber dazu, dass die H&ouml;he der Feeds auf der Oberfl&auml;che nicht mehr bzw. nicht mehr so gut berechnet werden kann. Damit diese Einstellung funktioniert muss eine Untrusted-Domain in der Globalen Konfiguration konfiguriert werden.
                     */
                    CUSTOMIZING_PORTAL_FEEDS_RENDER_ON_UNTRUSTED_DOMAIN("core.sys.customizing.portal.feeds.render_on_untrusted_domain"),
                    /**
                     * <p><strong>Feststehende Kopf- und Fu&szlig;zeile.</strong></p>
                     * Confkey: core.sys.customizing.portal.fixed_header_and_footer<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Schaltet die feststehende Kopf- und Fu&szlig;zeile ein. Das bedeutet, dass nur der Inhaltsbereich scrollbar ist. Die Kopf- und Fu&szlig;zeile bleibt immer eingeblendet.
                     */
                    CUSTOMIZING_PORTAL_FIXED_HEADER_AND_FOOTER("core.sys.customizing.portal.fixed_header_and_footer"),
                    /**
                     * <p><strong>Portalmeldungen einschalten.</strong></p>
                     * Confkey: core.sys.customizing.portal.messages.active<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Aktiviert die Portalmeldungen f&uuml;r HISinOne
                     */
                    CUSTOMIZING_PORTAL_MESSAGES_ACTIVE("core.sys.customizing.portal.messages.active"),
                    /**
                     * <p><strong>Zeit wie lange der Cache g&uuml;ltig ist.</strong></p>
                     * Confkey: core.sys.customizing.portal.messages.cache_time<br/>
                     * ParameterType: LONG<br/>
                     * <br/>
                     * Info: Portalmeldungen werden in einem Cache gespeichert um die Datenbank zu entlasten. Sie werden per Default jede Minute neugeladen. Zeitangabe in Millisekunden.
                     */
                    CUSTOMIZING_PORTAL_MESSAGES_CACHE_TIME("core.sys.customizing.portal.messages.cache_time"),
                    /**
                     * <p><strong>Absenderadresse f&uuml;r Portalmeldungen.</strong></p>
                     * Confkey: core.sys.customizing.portal.messages.mail.noreplyemailaddress<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Absenderadresse f&uuml;r Portalmeldungen, z. B. no-reply@his.de.
                     */
                    CUSTOMIZING_PORTAL_MESSAGES_MAIL_NOREPLYEMAILADDRESS("core.sys.customizing.portal.messages.mail.noreplyemailaddress"),
                    /**
                     * <p><strong>Server.</strong></p>
                     * Confkey: core.sys.customizing.portal.messages.mail.smtp.host<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Adresse des Postausgangsservers f&uuml;r die Selbstregistrierung. Wird keine Adresse angegeben, wird der Wert den DispatcherProperties bezogen.
                     */
                    CUSTOMIZING_PORTAL_MESSAGES_MAIL_SMTP_HOST("core.sys.customizing.portal.messages.mail.smtp.host"),
                    /**
                     * <p><strong>Password.</strong></p>
                     * Confkey: core.sys.customizing.portal.messages.mail.smtp.password<br/>
                     * ParameterType: PASSWORD_PLAINTEXT<br/>
                     * <br/>
                     * Info: Passwort das f&uuml;r die Authentifikation am Postausgangsserver verwendet werden soll.
                     */
                    CUSTOMIZING_PORTAL_MESSAGES_MAIL_SMTP_PASSWORD("core.sys.customizing.portal.messages.mail.smtp.password"),
                    /**
                     * <p><strong>Port.</strong></p>
                     * Confkey: core.sys.customizing.portal.messages.mail.smtp.port<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Port des Postausgangsservers. Der Port ist im Normalfall 25 (bzw. 465 bei einer SSL-Verbindung), inzwischen wird aber auch h&auml;ufig der Port 587 verwendet. Wird kein Port angegeben, wird der Wert 25 angenommen.
                     */
                    CUSTOMIZING_PORTAL_MESSAGES_MAIL_SMTP_PORT("core.sys.customizing.portal.messages.mail.smtp.port"),
                    /**
                     * <p><strong>Erweiterte Einstellungen.</strong></p>
                     * Confkey: core.sys.customizing.portal.messages.mail.smtp.properties<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Erweiterte SMTP-Einstellungen. Diese Einstellungen dienen der Definition zus&auml;tzlicher SMTP-Einstellungen wie &quot;mail.smtp.starttls.enable=true&quot; und &quot;mail.smtp.auth=true&quot; zur Aktivierung von TLS
                     */
                    CUSTOMIZING_PORTAL_MESSAGES_MAIL_SMTP_PROPERTIES("core.sys.customizing.portal.messages.mail.smtp.properties"),
                    /**
                     * <p><strong>Benutzername.</strong></p>
                     * Confkey: core.sys.customizing.portal.messages.mail.smtp.username<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Benutzername der f&uuml;r die Authentifikation am Postausgangsserver verwendet werden soll.
                     */
                    CUSTOMIZING_PORTAL_MESSAGES_MAIL_SMTP_USERNAME("core.sys.customizing.portal.messages.mail.smtp.username"),
                    /**
                     * <p><strong>Portalmeldungen nur an Personen mit Account senden.</strong></p>
                     * Confkey: core.sys.customizing.portal.messages.onlymessagestopersonswithaccounts<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Personen ohne Account k&ouml;nnen sich nicht in HISinOne-Anmelden und daher auch die Meldungen nicht lesen. Oft werden Portalmeldungen auch als E-Mail versendet. Ein Anwender k&ouml;nnte daher etwas irritiert sein.
                     */
                    CUSTOMIZING_PORTAL_MESSAGES_ONLYMESSAGESTOPERSONSWITHACCOUNTS("core.sys.customizing.portal.messages.onlymessagestopersonswithaccounts"),
                    /**
                     * <p><strong>Zeitangabe, wie alt Portalmeldungen werden d&uuml;rfen.</strong></p>
                     * Confkey: core.sys.customizing.portal.messages.timetolife<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Wie weit in der Vergangenheit werden Portalmeldungen noch in der Datenbank abgefragt. Zeitangabe in Minuten.
                     */
                    CUSTOMIZING_PORTAL_MESSAGES_TIMETOLIFE("core.sys.customizing.portal.messages.timetolife"),
                    /**
                     * <p><strong>Navigationsmen&uuml; einklappen.</strong></p>
                     * Confkey: core.sys.customizing.portal.personalized.hide_navigation_menu<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll das linke Navigationsmen&uuml; standardm&auml;&szlig;ig eingeklappt sein.
                     */
                    CUSTOMIZING_PORTAL_PERSONALIZED_HIDE_NAVIGATION_MENU("core.sys.customizing.portal.personalized.hide_navigation_menu"),
                    /**
                     * <p><strong>Alternativer Link des Hochschullogos.</strong></p>
                     * Confkey: core.sys.customizing.portal.personalized.logo_href<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Beim Klick auf das Logo wird im Standard die HISinOne-Startseite aufgerufen. Hier k&ouml;nnen Sie eine alternative Web-Adresse angeben, die aufgerufen werden soll. Achtung diese Seite &ouml;ffnet sich im selben Fenster wie HISinOne (_top). Beginnen Sie die URL mit 'http://', bspw. 'http://www.uni-hildesheim.de'.
                     */
                    CUSTOMIZING_PORTAL_PERSONALIZED_LOGO_HREF("core.sys.customizing.portal.personalized.logo_href"),
                    /**
                     * <p><strong>Anzahl der gleichen Portlets pro Tab.</strong></p>
                     * Confkey: core.sys.customizing.portal.personalized.max_equal_portlets_for_tab<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Bestimmt wie oft das gleiche Portlet auf einem Tab eingef&uuml;gt werden kann.
                     */
                    CUSTOMIZING_PORTAL_PERSONALIZED_MAX_EQUAL_PORTLETS_FOR_TAB("core.sys.customizing.portal.personalized.max_equal_portlets_for_tab"),
                    /**
                     * <p><strong>Maximale Anzahl Portlets pro Tab.</strong></p>
                     * Confkey: core.sys.customizing.portal.personalized.max_portlets_for_tab<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Gibt die maximale Anzahl von Portlets die auf einem Tab liegen d&uuml;rfen an.
                     */
                    CUSTOMIZING_PORTAL_PERSONALIZED_MAX_PORTLETS_FOR_TAB("core.sys.customizing.portal.personalized.max_portlets_for_tab"),
                    /**
                     * <p><strong>Maximale Anzahl der Tabs.</strong></p>
                     * Confkey: core.sys.customizing.portal.personalized.maxtabs<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Die maximale Anzahl der Tabs pro Nutzer bzw. Account
                     */
                    CUSTOMIZING_PORTAL_PERSONALIZED_MAXTABS("core.sys.customizing.portal.personalized.maxtabs"),
                    /**
                     * <p><strong>Anzeige von Informationstexten im DropDown Men&uuml;.</strong></p>
                     * Confkey: core.sys.customizing.portal.personalized.show_menu_informations<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Bei false werden keine Informationstexte mehr angezeigt. Das Men&uuml; wird dadurch kompakter.
                     */
                    CUSTOMIZING_PORTAL_PERSONALIZED_SHOW_MENU_INFORMATIONS("core.sys.customizing.portal.personalized.show_menu_informations"),
                    /**
                     * <p><strong>Beliebtheit anzeigen.</strong></p>
                     * Confkey: core.sys.customizing.portal.personalized.show_popularity<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Bestimmt ob die Beliebtheit eines Portlets jedem Nutzer angezeigt wird.
                     */
                    CUSTOMIZING_PORTAL_PERSONALIZED_SHOW_POPULARITY("core.sys.customizing.portal.personalized.show_popularity"),
                    /**
                     * <p><strong>Soll der Browser-Titel auch als &Uuml;berschrift auf der Startseite angezeigt werden?.</strong></p>
                     * Confkey: core.sys.customizing.portal.personalized.title_as_header_on_home_page<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Zeigt den Titel als H1-&Uuml;berschrift auch auf der Startseite an.
                     */
                    CUSTOMIZING_PORTAL_PERSONALIZED_TITLE_AS_HEADER_ON_HOME_PAGE("core.sys.customizing.portal.personalized.title_as_header_on_home_page"),
                    /**
                     * <p><strong>Personalisiertes Portal verwenden.</strong></p>
                     * Confkey: core.sys.customizing.portal.personalized_portal<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Aktivieren Sie das Layout f&uuml;r das personalisierte HISinOne-Portal.
                     */
                    CUSTOMIZING_PORTAL_PERSONALIZED_PORTAL("core.sys.customizing.portal.personalized_portal"),
                    /**
                     * <p><strong>Portalnamen anzeigen.</strong></p>
                     * Confkey: core.sys.customizing.portal.showheadlines<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Zeigt den Portalnamen und ggf. zweiten Portalnamen im Header an
                     */
                    CUSTOMIZING_PORTAL_SHOWHEADLINES("core.sys.customizing.portal.showheadlines"),
                    /**
                     * <p><strong>Nur ausgew&auml;hlte Registerkarte anzeigen.</strong></p>
                     * Confkey: core.sys.customizing.portal.showonlyselectedtab<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Wenn Themenportale verwendet werden kann es sinnvoll sein nur die &uuml;ber den URL-Prameter page selektierte Registerkarte anzuzeigen.
                     */
                    CUSTOMIZING_PORTAL_SHOWONLYSELECTEDTAB("core.sys.customizing.portal.showonlyselectedtab"),
                    /**
                     * <p><strong>Styleswitcher anzeigen.</strong></p>
                     * Confkey: core.sys.customizing.portal.styleswitcher<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Es stehen verschiedene M&ouml;glichkeiten zur Verf&uuml;gung, welche Funktionen der Styleswitcher haben soll. Der Styleswitcher befindet sich im Footer jeder Seite.
                     */
                    CUSTOMIZING_PORTAL_STYLESWITCHER("core.sys.customizing.portal.styleswitcher"),
                    /**
                     * <p><strong>Pfad zum Virenscanner.</strong></p>
                     * Confkey: core.sys.documentation.antivirus<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Pfad zum ausf&uuml;hrbaren Virenscanner zum Scannen von Datei-Downloads.
                     */
                    DOCUMENTATION_ANTIVIRUS("core.sys.documentation.antivirus"),
                    /**
                     * <p><strong>Endpunkt.</strong></p>
                     * Confkey: core.sys.documentation.dms.endpoint<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Endpunkt f&uuml;r den DMS-Connector Webservice
                     */
                    DOCUMENTATION_DMS_ENDPOINT("core.sys.documentation.dms.endpoint"),
                    /**
                     * <p><strong>Passwort.</strong></p>
                     * Confkey: core.sys.documentation.dms.password<br/>
                     * ParameterType: PASSWORD_PLAINTEXT<br/>
                     * <br/>
                     * Info: Passwort f&uuml;r den Webservice
                     */
                    DOCUMENTATION_DMS_PASSWORD("core.sys.documentation.dms.password"),
                    /**
                     * <p><strong>Lesepfad f&uuml;r Dokumente.</strong></p>
                     * Confkey: core.sys.documentation.dms.retreivepath<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Lesepfad des Webservice f&uuml;r Dokumente
                     */
                    DOCUMENTATION_DMS_RETREIVEPATH("core.sys.documentation.dms.retreivepath"),
                    /**
                     * <p><strong>Speicherpfad f&uuml;r Dokumente.</strong></p>
                     * Confkey: core.sys.documentation.dms.storepath<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Speicherpfad f&uuml;r Dokumente f&uuml;r den Webservice
                     */
                    DOCUMENTATION_DMS_STOREPATH("core.sys.documentation.dms.storepath"),
                    /**
                     * <p><strong>Timeout-Zeit (s).</strong></p>
                     * Confkey: core.sys.documentation.dms.timeout<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Timeout-Zeit f&uuml;r den Webservice in Sekunden
                     */
                    DOCUMENTATION_DMS_TIMEOUT("core.sys.documentation.dms.timeout"),
                    /**
                     * <p><strong>Benutzername.</strong></p>
                     * Confkey: core.sys.documentation.dms.username<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Benutzername f&uuml;r den Webservice
                     */
                    DOCUMENTATION_DMS_USERNAME("core.sys.documentation.dms.username"),
                    /**
                     * <p><strong>Ablagesystem f&uuml;r Dokumente.</strong></p>
                     * Confkey: core.sys.documentation.documentsfilingsystem<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Gibt an, in welchem Ablagesystem Dokumente gespeichert werden
                     */
                    DOCUMENTATION_DOCUMENTSFILINGSYSTEM("core.sys.documentation.documentsfilingsystem"),
                    /**
                     * <p><strong>Maximale Dateigr&ouml;&szlig;e f&uuml;r beliebigen Dateityp.</strong></p>
                     * Confkey: core.sys.documentation.file_size_limit<br/>
                     * ParameterType: LONG<br/>
                     * <br/>
                     * Info: Dateigr&ouml;&szlig;e in Byte
                     */
                    DOCUMENTATION_FILE_SIZE_LIMIT("core.sys.documentation.file_size_limit"),
                    /**
                     * <p><strong>Sollen die Bilder neben Dateisystem auch in Datenbank gespeichert werden.</strong></p>
                     * Confkey: core.sys.documentation.image.blob_save<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: ja/nein
                     */
                    DOCUMENTATION_IMAGE_BLOB_SAVE("core.sys.documentation.image.blob_save"),
                    /**
                     * <p><strong>Maximale Dateigr&ouml;&szlig;e f&uuml;r Image in Datenbank.</strong></p>
                     * Confkey: core.sys.documentation.image.blob_size_limit<br/>
                     * ParameterType: LONG<br/>
                     * <br/>
                     * Info: Dateigr&ouml;&szlig;e in Byte
                     */
                    DOCUMENTATION_IMAGE_BLOB_SIZE_LIMIT("core.sys.documentation.image.blob_size_limit"),
                    /**
                     * <p><strong>Maximale Dateigr&ouml;&szlig;e f&uuml;r Image.</strong></p>
                     * Confkey: core.sys.documentation.image.file_size_limit<br/>
                     * ParameterType: LONG<br/>
                     * <br/>
                     * Info: Dateigr&ouml;&szlig;e  in Byte
                     */
                    DOCUMENTATION_IMAGE_FILE_SIZE_LIMIT("core.sys.documentation.image.file_size_limit"),
                    /**
                     * <p><strong>Langzeitspeicherdauer.</strong></p>
                     * Confkey: core.sys.documentation.longvalidityperiod<br/>
                     * ParameterType: LONG<br/>
                     * <br/>
                     * Info: Bestimmt, in Minuten, wie weit in der Zukunft das Verfallsdatum von Langzeitdokumenten liegt. -1 f&uuml;r die l&auml;ngste Speicherdauer.
                     */
                    DOCUMENTATION_LONGVALIDITYPERIOD("core.sys.documentation.longvalidityperiod"),
                    /**
                     * <p><strong>Pfad, wo die Dokumente liegen.</strong></p>
                     * Confkey: core.sys.documentation.path<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Pfad f&uuml;r die Dokumente
                     */
                    DOCUMENTATION_PATH("core.sys.documentation.path"),
                    /**
                     * <p><strong>Tempor&auml;re Speicherdauer.</strong></p>
                     * Confkey: core.sys.documentation.tempvalidityperiod<br/>
                     * ParameterType: LONG<br/>
                     * <br/>
                     * Info: Bestimmt, in Minuten, wie weit in der Zukunft das Verfallsdatum von tempor&auml;r gespeicherten Dokumenten liegt. -1 f&uuml;r die l&auml;ngste Speicherdauer.
                     */
                    DOCUMENTATION_TEMPVALIDITYPERIOD("core.sys.documentation.tempvalidityperiod"),
                    /**
                     * <p><strong>Tempor&auml;res Verzeichnis f&uuml;r die Dokumente.</strong></p>
                     * Confkey: core.sys.documentation.tmp_path<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Tempor&auml;res Verzeichnis
                     */
                    DOCUMENTATION_TMP_PATH("core.sys.documentation.tmp_path"),
                    /**
                     * <p><strong>Wildcard Domain aktivieren.</strong></p>
                     * Confkey: core.sys.domain.is_wildcard_domain<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Handelt es sich bei der Untrusted-Domain um eine Wildcard-Domain, die beliebige Subdomains (http://x.) erlaubt? Dies Art von Untrusted-Domain wird aus Sicherheitsgr&uuml;nden empfohlen. Es wird erm&ouml;glicht, dass externe Inhalte von aneinander getrennt auf zuf&auml;lligen Subdomains angezeigt werden (vgl. Same-Origin-Policy). Diese Einstellung wird nur in Verbindung mit der Angabe der Untrusted-Domain ausgewertet und findet bspw. bei Google Gadget, DMS und Feeds Anwendung.
                     */
                    DOMAIN_IS_WILDCARD_DOMAIN("core.sys.domain.is_wildcard_domain"),
                    /**
                     * <p><strong>Unsichere Domain.</strong></p>
                     * Confkey: core.sys.domain.untrusted_domain<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: &Uuml;ber diese Domain darf sich kein Nutzer anmelden. Wird bspw. f&uuml;r Google Gadgets, DMS und Feeds ben&ouml;tigt.
                     */
                    DOMAIN_UNTRUSTED_DOMAIN("core.sys.domain.untrusted_domain"),
                    /**
                     * <p><strong>Addressen.</strong></p>
                     * Confkey: core.sys.externalapps.bookmarks.addresses<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Eine Liste regul&auml;rer Ausdr&uuml;cke mit Adressen externer Systeme f&uuml;r die Lesezeichen gesetzt werden d&uuml;rfen. Die id des Iframe-Systems das angesprochen werden soll muss nach einem &quot;;&quot; angegeben werden (vgl. WEB-INF\\conf\\cs\\sys\\portalConfig\\portalLinks\\portalLinks.xml). Beispiel: http://head.his.de/.*;moodle
                     */
                    EXTERNALAPPS_BOOKMARKS_ADDRESSES("core.sys.externalapps.bookmarks.addresses"),
                    /**
                     * <p><strong>Lesezeichen einschalten.</strong></p>
                     * Confkey: core.sys.externalapps.bookmarks.is_active<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll es den angemeldeten Nutzern m&ouml;glich sein Lesezeichen in HISinOne anzulegen?
                     */
                    EXTERNALAPPS_BOOKMARKS_IS_ACTIVE("core.sys.externalapps.bookmarks.is_active"),
                    /**
                     * <p><strong>CLI-Passwort.</strong></p>
                     * Confkey: core.sys.externalapps.email.communigate.clipassword<br/>
                     * ParameterType: PASSWORD_PLAINTEXT<br/>
                     * <br/>
                     * Info: Passwort des Benutzer aus dem Parameter CLI-Username
                     */
                    EXTERNALAPPS_EMAIL_COMMUNIGATE_CLIPASSWORD("core.sys.externalapps.email.communigate.clipassword"),
                    /**
                     * <p><strong>CLI-Port.</strong></p>
                     * Confkey: core.sys.externalapps.email.communigate.cliport<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: TCP-Portnummer des CLI-Servers
                     */
                    EXTERNALAPPS_EMAIL_COMMUNIGATE_CLIPORT("core.sys.externalapps.email.communigate.cliport"),
                    /**
                     * <p><strong>CLI-Server.</strong></p>
                     * Confkey: core.sys.externalapps.email.communigate.cliserver<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Name des Command Line Interface Servers (ohne Protokoll)
                     */
                    EXTERNALAPPS_EMAIL_COMMUNIGATE_CLISERVER("core.sys.externalapps.email.communigate.cliserver"),
                    /**
                     * <p><strong>CLI-SSL.</strong></p>
                     * Confkey: core.sys.externalapps.email.communigate.clissl<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll die Verbindung zum CLI verschl&uuml;sselt werden?
                     */
                    EXTERNALAPPS_EMAIL_COMMUNIGATE_CLISSL("core.sys.externalapps.email.communigate.clissl"),
                    /**
                     * <p><strong>CLI-Username.</strong></p>
                     * Confkey: core.sys.externalapps.email.communigate.cliusername<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Name eine Benutzers mit Zugang zum CommuniGate Command Line Interface und Berechtigung f&uuml;r den Aufruf von CREATE WEB USER SESSION.
                     */
                    EXTERNALAPPS_EMAIL_COMMUNIGATE_CLIUSERNAME("core.sys.externalapps.email.communigate.cliusername"),
                    /**
                     * <p><strong>Server-Name.</strong></p>
                     * Confkey: core.sys.externalapps.email.communigate.server<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Name des CommuniGate-Servers
                     */
                    EXTERNALAPPS_EMAIL_COMMUNIGATE_SERVER("core.sys.externalapps.email.communigate.server"),
                    /**
                     * <p><strong>Benutzername.</strong></p>
                     * Confkey: core.sys.externalapps.email.communigate.username<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Name des Benutzers im CommuniGate-System
                     */
                    EXTERNALAPPS_EMAIL_COMMUNIGATE_USERNAME("core.sys.externalapps.email.communigate.username"),
                    /**
                     * <p><strong>OWA URL.</strong></p>
                     * Confkey: core.sys.externalapps.email.exchange.owaurl<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Adresse des Outlook Web Access Interfaces (zum Beispiel: https://owa.his.de)
                     */
                    EXTERNALAPPS_EMAIL_EXCHANGE_OWAURL("core.sys.externalapps.email.exchange.owaurl"),
                    /**
                     * <p><strong>Server-Name.</strong></p>
                     * Confkey: core.sys.externalapps.email.exchange.servername<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Name des Exchange/OWA-Servers
                     */
                    EXTERNALAPPS_EMAIL_EXCHANGE_SERVERNAME("core.sys.externalapps.email.exchange.servername"),
                    /**
                     * <p><strong>Format des Benutzernamens f&uuml;r EWS-Aufrufe.</strong></p>
                     * Confkey: core.sys.externalapps.email.exchange.userformat<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Das E-Mail-Portlet verwendet die Exchange Web Services, um die aktuellen Mails mit ihren OWA-IDs abzurufen. Dazu ist eine Anmeldung erforderlich, die je nach Konfiguration des Exchange-Server aus username, domain\\username oder username@domain bestehen muss. Insbesondere kann das Benutzernamenformat f&uuml;r EWS von dem Format f&uuml;r OWA abweichen.
                     */
                    EXTERNALAPPS_EMAIL_EXCHANGE_USERFORMAT("core.sys.externalapps.email.exchange.userformat"),
                    /**
                     * <p><strong>Version des OWA Servers.</strong></p>
                     * Confkey: core.sys.externalapps.email.exchange.version<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Die Version des Exchange-Server f&uuml;r das E-Mail-Portlet
                     */
                    EXTERNALAPPS_EMAIL_EXCHANGE_VERSION("core.sys.externalapps.email.exchange.version"),
                    /**
                     * <p><strong>Cache-Zeit f&uuml;r Anzahl ungelesener E-Mails.</strong></p>
                     * Confkey: core.sys.externalapps.email.notification.cachetime<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Anzahl der Sekunden, die die Anzahl der ungelesen Mails zwischengespeichert werden soll, um den Mailserver zu entlasten.
                     */
                    EXTERNALAPPS_EMAIL_NOTIFICATION_CACHETIME("core.sys.externalapps.email.notification.cachetime"),
                    /**
                     * <p><strong>Zeichensatz f&uuml;r die Verbindung zum Mailserver.</strong></p>
                     * Confkey: core.sys.externalapps.email.notification.connectioncharset<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Der Zeichensatz, der f&uuml;r die TCP-Verbindung zum Mailserver und die &Uuml;bertragung von Benutzernamen und Passwort verwendet werden soll. In der Regel wird hier UTF-8 oder Latin1 verwendet.
                     */
                    EXTERNALAPPS_EMAIL_NOTIFICATION_CONNECTIONCHARSET("core.sys.externalapps.email.notification.connectioncharset"),
                    /**
                     * <p><strong>IMAP-URL.</strong></p>
                     * Confkey: core.sys.externalapps.email.notification.connectionurl<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Die URL die zum Verbindungsaufbau zum Mailserver verwendet werden soll. Session-Variablen wie [session_owausername] k&ouml;nnen verwendet werden. Beispielsweise: imap://[username]:[password]@mailbox.his.de
                     */
                    EXTERNALAPPS_EMAIL_NOTIFICATION_CONNECTIONURL("core.sys.externalapps.email.notification.connectionurl"),
                    /**
                     * <p><strong>Maximales Alter einer E-Mails.</strong></p>
                     * Confkey: core.sys.externalapps.email.portlet.ageofemails<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Es kann optional im E-Mail-Portlet ausgew&auml;hlt werden, dass nur die &quot;neusten&quot; E-Mails angezeigt werden sollen. Wie alt eine E-Mail maximal sein darf um noch als aktuell zu gelten wird hier bestimmt. Angabe in Tagen.
                     */
                    EXTERNALAPPS_EMAIL_PORTLET_AGEOFEMAILS("core.sys.externalapps.email.portlet.ageofemails"),
                    /**
                     * <p><strong>Cache Timeout.</strong></p>
                     * Confkey: core.sys.externalapps.email.portlet.cache_timeout<br/>
                     * ParameterType: LONG<br/>
                     * <br/>
                     * Info: Emails werden in einem Cache zwischengespeichert. Nach welcher Zeit sollen die Emails des Nutzers vom Mail-Server wieder neu geladen werden? Angabe in Millisekunden.
                     */
                    EXTERNALAPPS_EMAIL_PORTLET_CACHE_TIMEOUT("core.sys.externalapps.email.portlet.cache_timeout"),
                    /**
                     * <p><strong>Clix aktiveren.</strong></p>
                     * Confkey: core.sys.externalapps.learningtools.clix.active<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Schaltet die E-Learning-Plattform Clix ein. Anschlie&szlig;end kann bpsw. das E-Learning-Portlet verwendet werden.
                     */
                    EXTERNALAPPS_LEARNINGTOOLS_CLIX_ACTIVE("core.sys.externalapps.learningtools.clix.active"),
                    /**
                     * <p><strong>URL zu gebuchten Kursen.</strong></p>
                     * Confkey: core.sys.externalapps.learningtools.clix.goto_url<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Diese URL f&uuml;hrt direkt zu einem Kurs in Clix. Achten unbedingt darauf, dass der Parameter 'id=' nicht aufgef&uuml;hrt wird, bspw.:<br />http://clix.kunde.de/clix/goto_clix.jsp?clixEvent=externalentry&amp;nextEvent=my_booked_courses&amp;without_navi=true&amp;external_mode=true&amp;language=26<br /><br />Siehe Clix-Dokumentation f&uuml;r alle notwendigen Attribute.
                     */
                    EXTERNALAPPS_LEARNINGTOOLS_CLIX_GOTO_URL("core.sys.externalapps.learningtools.clix.goto_url"),
                    /**
                     * <p><strong>URL zum Web-Service.</strong></p>
                     * Confkey: core.sys.externalapps.learningtools.clix.webservice_url<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Achten Sie darauf, dass Sie Clix f&uuml;r den Zugriff auf dessen Web-Services speziell konfigurieren m&uuml;ssen. Beachten Sie die Clix-Dokumentation. Bspw.: https://clix.kunde.de/clix/webservices/ClixService
                     */
                    EXTERNALAPPS_LEARNINGTOOLS_CLIX_WEBSERVICE_URL("core.sys.externalapps.learningtools.clix.webservice_url"),
                    /**
                     * <p><strong>Aktiviert.</strong></p>
                     * Confkey: core.sys.externalapps.learningtools.moodle.active<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Ist Moodle aktiv?
                     */
                    EXTERNALAPPS_LEARNINGTOOLS_MOODLE_ACTIVE("core.sys.externalapps.learningtools.moodle.active"),
                    /**
                     * <p><strong>Anzeigename.</strong></p>
                     * Confkey: core.sys.externalapps.learningtools.moodle.displayname<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Anzeigename f&uuml;r die Externe Applikation
                     */
                    EXTERNALAPPS_LEARNINGTOOLS_MOODLE_DISPLAYNAME("core.sys.externalapps.learningtools.moodle.displayname"),
                    /**
                     * <p><strong>Endpunkt.</strong></p>
                     * Confkey: core.sys.externalapps.learningtools.moodle.endpoint<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Endpunkt f&uuml;r den Webservice
                     */
                    EXTERNALAPPS_LEARNINGTOOLS_MOODLE_ENDPOINT("core.sys.externalapps.learningtools.moodle.endpoint"),
                    /**
                     * <p><strong>Login.</strong></p>
                     * Confkey: core.sys.externalapps.learningtools.moodle.login<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Login f&uuml;r den Webservice
                     */
                    EXTERNALAPPS_LEARNINGTOOLS_MOODLE_LOGIN("core.sys.externalapps.learningtools.moodle.login"),
                    /**
                     * <p><strong>Passwort.</strong></p>
                     * Confkey: core.sys.externalapps.learningtools.moodle.password<br/>
                     * ParameterType: PASSWORD_PLAINTEXT<br/>
                     * <br/>
                     * Info: Passwort f&uuml;r den Webservice
                     */
                    EXTERNALAPPS_LEARNINGTOOLS_MOODLE_PASSWORD("core.sys.externalapps.learningtools.moodle.password"),
                    /**
                     * <p><strong>Kurs URL-Muster.</strong></p>
                     * Confkey: core.sys.externalapps.learningtools.moodle.urlcoursepattern<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: URL zu Kursen. Verwenden Sie {ID} als Platzhalter f&uuml;r die ID des Kurses.
                     */
                    EXTERNALAPPS_LEARNINGTOOLS_MOODLE_URLCOURSEPATTERN("core.sys.externalapps.learningtools.moodle.urlcoursepattern"),
                    /**
                     * <p><strong>Aktiviert.</strong></p>
                     * Confkey: core.sys.externalapps.learningtools.moodle2.active<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Gibt an, ob die Moodle-Kopplung aktiviert ist. Alle ab dem Aktivierungszeitpunkt neu angelegten Veranstaltungen werden nach Moodle &uuml;bertragen.
                     */
                    EXTERNALAPPS_LEARNINGTOOLS_MOODLE2_ACTIVE("core.sys.externalapps.learningtools.moodle2.active"),
                    /**
                     * <p><strong>Anzeigename.</strong></p>
                     * Confkey: core.sys.externalapps.learningtools.moodle2.displayname<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Im System verwendeter Name f&uuml;r Moodle
                     */
                    EXTERNALAPPS_LEARNINGTOOLS_MOODLE2_DISPLAYNAME("core.sys.externalapps.learningtools.moodle2.displayname"),
                    /**
                     * <p><strong>Endpunkt.</strong></p>
                     * Confkey: core.sys.externalapps.learningtools.moodle2.endpoint<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Endpunkt f&uuml;r den Webservice von Moodle
                     */
                    EXTERNALAPPS_LEARNINGTOOLS_MOODLE2_ENDPOINT("core.sys.externalapps.learningtools.moodle2.endpoint"),
                    /**
                     * <p><strong>Login.</strong></p>
                     * Confkey: core.sys.externalapps.learningtools.moodle2.login<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Login-Name f&uuml;r einen im Moodle-System bestehenden Webservice-Nutzer
                     */
                    EXTERNALAPPS_LEARNINGTOOLS_MOODLE2_LOGIN("core.sys.externalapps.learningtools.moodle2.login"),
                    /**
                     * <p><strong>Passwort.</strong></p>
                     * Confkey: core.sys.externalapps.learningtools.moodle2.password<br/>
                     * ParameterType: PASSWORD_PLAINTEXT<br/>
                     * <br/>
                     * Info: Passwort f&uuml;r den Moodle Webservice-Nutzer
                     */
                    EXTERNALAPPS_LEARNINGTOOLS_MOODLE2_PASSWORD("core.sys.externalapps.learningtools.moodle2.password"),
                    /**
                     * <p><strong>Kurs-Kategorie-ID.</strong></p>
                     * Confkey: core.sys.externalapps.learningtools.moodle2.sync.categoryid<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: ID der Kategorie f&uuml;r die Neuanlage von Kursen
                     */
                    EXTERNALAPPS_LEARNINGTOOLS_MOODLE2_SYNC_CATEGORYID("core.sys.externalapps.learningtools.moodle2.sync.categoryid"),
                    /**
                     * <p><strong>Kursmodell.</strong></p>
                     * Confkey: core.sys.externalapps.learningtools.moodle2.sync.coursepattern<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Prinzip, nach welchem die Kurs-Daten in Moodle aufgebaut werden. Die Art der in Moodle angelegten Daten k&ouml;nnen sich abh&auml;ngig vom Kursmodell grunds&auml;tzlich unterscheiden. Es wird nicht empfohlen, diesen Wert w&auml;hrend einer Kursplanungs- oder Belegungsphase zu &auml;ndern.
                     */
                    EXTERNALAPPS_LEARNINGTOOLS_MOODLE2_SYNC_COURSEPATTERN("core.sys.externalapps.learningtools.moodle2.sync.coursepattern"),
                    /**
                     * <p><strong>Gruppenzugeh&ouml;rigkeiten l&ouml;schen.</strong></p>
                     * Confkey: core.sys.externalapps.learningtools.moodle2.sync.delgroupassignments<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: HISinOne darf in Moodle manuell angelegte Gruppenzugeh&ouml;rigkeiten l&ouml;schen
                     */
                    EXTERNALAPPS_LEARNINGTOOLS_MOODLE2_SYNC_DELGROUPASSIGNMENTS("core.sys.externalapps.learningtools.moodle2.sync.delgroupassignments"),
                    /**
                     * <p><strong>Kurszugeh&ouml;rigkeiten l&ouml;schen.</strong></p>
                     * Confkey: core.sys.externalapps.learningtools.moodle2.sync.delroleassignments<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: HISinOne darf in Moodle manuell angelegte Kurszugeh&ouml;rigkeiten l&ouml;schen
                     */
                    EXTERNALAPPS_LEARNINGTOOLS_MOODLE2_SYNC_DELROLEASSIGNMENTS("core.sys.externalapps.learningtools.moodle2.sync.delroleassignments"),
                    /**
                     * <p><strong>E-Mail-Adressen &uuml;bernehmen.</strong></p>
                     * Confkey: core.sys.externalapps.learningtools.moodle2.sync.emailaddresses<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Benutzer werden bei &quot;Nein&quot; initial mit der festgelegten Standard E-Mail-Adresse angelegt werden. Anderfalls werden E-Mail-Adressen aus HISinOne &uuml;bernommen.<br />Beachten Sie hier den Datenschutz!
                     */
                    EXTERNALAPPS_LEARNINGTOOLS_MOODLE2_SYNC_EMAILADDRESSES("core.sys.externalapps.learningtools.moodle2.sync.emailaddresses"),
                    /**
                     * <p><strong>Gruppenmodus manuell verwalten.</strong></p>
                     * Confkey: core.sys.externalapps.learningtools.moodle2.sync.manualgroupmode<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Der Gruppenmodus f&uuml;r einen Kurs wird bei &quot;Ja&quot; in Moodle definiert und verwaltet. Andernfalls wird der Wert von HISinOne gesetzt und &Auml;nderungen gegebenenfalls &uuml;berschrieben.
                     */
                    EXTERNALAPPS_LEARNINGTOOLS_MOODLE2_SYNC_MANUALGROUPMODE("core.sys.externalapps.learningtools.moodle2.sync.manualgroupmode"),
                    /**
                     * <p><strong>Wochen-/Themen-Anzahl manuell verwalten.</strong></p>
                     * Confkey: core.sys.externalapps.learningtools.moodle2.sync.manualnumsections<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Die Anzahl der Wochen/Themen f&uuml;r einen Kurs wird bei &quot;Ja&quot; in Moodle definiert. Anderfalls legt HISinOne diesen Wert einmalig fest. Manuelle &Auml;nderungen werden generell nicht &uuml;berschrieben.
                     */
                    EXTERNALAPPS_LEARNINGTOOLS_MOODLE2_SYNC_MANUALNUMSECTIONS("core.sys.externalapps.learningtools.moodle2.sync.manualnumsections"),
                    /**
                     * <p><strong>Benutzerdaten manuell verwalten.</strong></p>
                     * Confkey: core.sys.externalapps.learningtools.moodle2.sync.manualuserdata<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Benutzerdaten werden bei &quot;Ja&quot; in Moodle verwaltet. Anderfalls &uuml;berschreibt HISinOne manuelle &Auml;nderungen gegebenenfalls.
                     */
                    EXTERNALAPPS_LEARNINGTOOLS_MOODLE2_SYNC_MANUALUSERDATA("core.sys.externalapps.learningtools.moodle2.sync.manualuserdata"),
                    /**
                     * <p><strong>Kurssichtbarkeit manuell verwalten.</strong></p>
                     * Confkey: core.sys.externalapps.learningtools.moodle2.sync.manualvisibility<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Die Kurssichtbarkeit wird bei &quot;Ja&quot; in Moodle definiert und verwaltet. Anderfalls legt HISinOne diesen Wert fest und &uuml;berschreibt manuelle &Auml;nderungen gegebenenfalls.
                     */
                    EXTERNALAPPS_LEARNINGTOOLS_MOODLE2_SYNC_MANUALVISIBILITY("core.sys.externalapps.learningtools.moodle2.sync.manualvisibility"),
                    /**
                     * <p><strong>Reichweite.</strong></p>
                     * Confkey: core.sys.externalapps.learningtools.moodle2.sync.range<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Welche Veranstaltungen sollen &uuml;bertragen werden
                     */
                    EXTERNALAPPS_LEARNINGTOOLS_MOODLE2_SYNC_RANGE("core.sys.externalapps.learningtools.moodle2.sync.range"),
                    /**
                     * <p><strong>Rollen-ID &quot;Student&quot;.</strong></p>
                     * Confkey: core.sys.externalapps.learningtools.moodle2.sync.roleidstudent<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: ID der Rolle eines Studierenden in Moodle
                     */
                    EXTERNALAPPS_LEARNINGTOOLS_MOODLE2_SYNC_ROLEIDSTUDENT("core.sys.externalapps.learningtools.moodle2.sync.roleidstudent"),
                    /**
                     * <p><strong>Rollen-ID &quot;Teacher&quot;.</strong></p>
                     * Confkey: core.sys.externalapps.learningtools.moodle2.sync.roleidteacher<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: ID der Rolle eines Lehrenden in Moodle
                     */
                    EXTERNALAPPS_LEARNINGTOOLS_MOODLE2_SYNC_ROLEIDTEACHER("core.sys.externalapps.learningtools.moodle2.sync.roleidteacher"),
                    /**
                     * <p><strong>Standard E-Mail-Adresse.</strong></p>
                     * Confkey: core.sys.externalapps.learningtools.moodle2.sync.standardemail<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: F&uuml;r die Anlage von Benutzern ohne festgelegte E-Mail-Adresse oder f&uuml;r den Fall, dass E-Mail-Adressen aus HISinOne nicht in Moodle &uuml;bernommen werden sollen.
                     */
                    EXTERNALAPPS_LEARNINGTOOLS_MOODLE2_SYNC_STANDARDEMAIL("core.sys.externalapps.learningtools.moodle2.sync.standardemail"),
                    /**
                     * <p><strong>Standard Authentifizierungsmethode.</strong></p>
                     * Confkey: core.sys.externalapps.learningtools.moodle2.sync.userauth<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Authentifizierungsmethode f&uuml;r neu angelegte Benutzer.
                     */
                    EXTERNALAPPS_LEARNINGTOOLS_MOODLE2_SYNC_USERAUTH("core.sys.externalapps.learningtools.moodle2.sync.userauth"),
                    /**
                     * <p><strong>Kurs URL-Muster.</strong></p>
                     * Confkey: core.sys.externalapps.learningtools.moodle2.urlcoursepattern<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: URL zu Kursen. Verwenden Sie {ID} als Platzhalter f&uuml;r die ID des Kurses.
                     */
                    EXTERNALAPPS_LEARNINGTOOLS_MOODLE2_URLCOURSEPATTERN("core.sys.externalapps.learningtools.moodle2.urlcoursepattern"),
                    /**
                     * <p><strong>Lebensdauer des Caches des E-Leanring Portlets.</strong></p>
                     * Confkey: core.sys.externalapps.learningtools.portlet.cache_timeout<br/>
                     * ParameterType: LONG<br/>
                     * <br/>
                     * Info: In Millisekunden.
                     */
                    EXTERNALAPPS_LEARNINGTOOLS_PORTLET_CACHE_TIMEOUT("core.sys.externalapps.learningtools.portlet.cache_timeout"),
                    /**
                     * <p><strong>Suchengine.</strong></p>
                     * Confkey: core.sys.externalapps.search.engine<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Welche Suchengine soll verwendet werden?
                     */
                    EXTERNALAPPS_SEARCH_ENGINE("core.sys.externalapps.search.engine"),
                    /**
                     * <p><strong>Port.</strong></p>
                     * Confkey: core.sys.externalapps.search.port<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: TCP-Port des Suchengine-Servers
                     */
                    EXTERNALAPPS_SEARCH_PORT("core.sys.externalapps.search.port"),
                    /**
                     * <p><strong>Server.</strong></p>
                     * Confkey: core.sys.externalapps.search.server<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Name oder IP-Adresse des Suchengine-Servers
                     */
                    EXTERNALAPPS_SEARCH_SERVER("core.sys.externalapps.search.server"),
                    /**
                     * <p><strong>App ID.</strong></p>
                     * Confkey: core.sys.externalapps.social.facebook.app_id<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Die App-ID der Facebok-Anwendung.
                     */
                    EXTERNALAPPS_SOCIAL_FACEBOOK_APP_ID("core.sys.externalapps.social.facebook.app_id"),
                    /**
                     * <p><strong>App Secret.</strong></p>
                     * Confkey: core.sys.externalapps.social.facebook.app_secret<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Das Geheimnis der Facebook-Anwendung
                     */
                    EXTERNALAPPS_SOCIAL_FACEBOOK_APP_SECRET("core.sys.externalapps.social.facebook.app_secret"),
                    /**
                     * <p><strong>Aktiviert/Deaktiviert das Workflow-Management mit AristaFlow..</strong></p>
                     * Confkey: core.sys.externalapps.workflow.aristaflowactive<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    EXTERNALAPPS_WORKFLOW_ARISTAFLOWACTIVE("core.sys.externalapps.workflow.aristaflowactive"),
                    /**
                     * <p><strong>Serverknoten.</strong></p>
                     * Confkey: core.sys.externalapps.workflow.servernode<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Auf dem angegebenen Knoten wird der AristaFlow-Server gestartet.
                     */
                    EXTERNALAPPS_WORKFLOW_SERVERNODE("core.sys.externalapps.workflow.servernode"),
                    /**
                     * <p><strong>Updates der Globalen Konfiguration.</strong></p>
                     * Confkey: core.sys.install.globalconfupdates<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: In diesem Schl&uuml;ssel werden alle bereits durchgef&uuml;hrten Updates dieser HISinOne-Installation gespeichert.
                     */
                    INSTALL_GLOBALCONFUPDATES("core.sys.install.globalconfupdates"),
                    /**
                     * <p><strong>Altes xml Export Format.</strong></p>
                     * Confkey: core.sys.metadata.old_xml_export_format<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll das alte (bis einschl. in HISinOne V3.0 verwendete) xml Export Format verwendet werden?
                     */
                    METADATA_OLD_XML_EXPORT_FORMAT("core.sys.metadata.old_xml_export_format"),
                    /**
                     * <p><strong>Regul&auml;rer Pr&uuml;fausdruck.</strong></p>
                     * Confkey: core.sys.metadata.types.www.regexp<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Beinhaltet den regul&auml;ren Ausdruck gegen den URLs f&uuml;r Internetseiten gepr&uuml;ft werden.
                     */
                    METADATA_TYPES_WWW_REGEXP("core.sys.metadata.types.www.regexp"),
                    /**
                     * <p><strong>iText aktivieren.</strong></p>
                     * Confkey: core.sys.reporting.jasperreports.itext_active<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll die iText-Bibliothek verwendet werden
                     */
                    REPORTING_JASPERREPORTS_ITEXT_ACTIVE("core.sys.reporting.jasperreports.itext_active"),
                    /**
                     * <p><strong>Server Adresse des Office Servers.</strong></p>
                     * Confkey: core.sys.reporting.oo.endpoint<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Hier kann die (IP) Adresse des Servers angegeben werden der OpenOffice Reporting Anfragen verarbeiten soll.
                     */
                    REPORTING_OO_ENDPOINT("core.sys.reporting.oo.endpoint"),
                    /**
                     * <p><strong>Verbindungsversuche bis zum Timeout.</strong></p>
                     * Confkey: core.sys.reporting.oo.endpoint_connect_retry<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Anzahl der Verbindungsversuche, bei fehlgeschlagenen Verbindungsversuch. Die Pause zwischen den Versuchen betr&auml;gt 500ms.
                     */
                    REPORTING_OO_ENDPOINT_CONNECT_RETRY("core.sys.reporting.oo.endpoint_connect_retry"),
                    /**
                     * <p><strong>Port des Office Servers.</strong></p>
                     * Confkey: core.sys.reporting.oo.endpoint_port<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Der lauschende Port des Office Servers
                     */
                    REPORTING_OO_ENDPOINT_PORT("core.sys.reporting.oo.endpoint_port"),
                    /**
                     * <p><strong>Templateverzeichnis f&uuml;r OOo Reporting.</strong></p>
                     * Confkey: core.sys.reporting.oo.templatedir<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Pfad f&uuml;r OpenOffice Dateien, die als Templates f&uuml;r das OOo basierte Reporting dienen
                     */
                    REPORTING_OO_TEMPLATEDIR("core.sys.reporting.oo.templatedir"),
                    /**
                     * <p><strong>Druckername.</strong></p>
                     * Confkey: core.sys.reporting.printer_name<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Name des Druckers der verwendet werden soll. Nur n&ouml;tig wenn HISinOne auf einem Windows System l&auml;uft.
                     */
                    REPORTING_PRINTER_NAME("core.sys.reporting.printer_name"),
                    /**
                     * <p><strong>Druckerserver IP.</strong></p>
                     * Confkey: core.sys.reporting.printserver_ip<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: IP Adresse oder Hostname des Computers der mit dem Drucker verbunden ist. Mu&szlig; nur unter Windows angegeben werden, wenn der Druckerserver nicht der HISinOne Server ist.
                     */
                    REPORTING_PRINTSERVER_IP("core.sys.reporting.printserver_ip"),
                    /**
                     * <p><strong>Sollen Stylesheets auch in einem anderen Operation-Mode als Production zusammengefasst und komprimiert weden?.</strong></p>
                     * Confkey: core.sys.ui.merge_and_compress_stylesheets_in_none_production<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    UI_MERGE_AND_COMPRESS_STYLESHEETS_IN_NONE_PRODUCTION("core.sys.ui.merge_and_compress_stylesheets_in_none_production"),
                    /**
                     * <p><strong>Men&uuml;suchfeld.</strong></p>
                     * Confkey: core.sys.ui.show_menu_search<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Wenn true wird ein kleines Suchfeld f&uuml;r die Men&uuml;struktur angeboten
                     */
                    UI_SHOW_MENU_SEARCH("core.sys.ui.show_menu_search"),
                    /**
                     * <p><strong>Mindestanzahl von Men&uuml;elementen.</strong></p>
                     * Confkey: core.sys.ui.show_menu_search_min_elements<br/>
                     * ParameterType: LONG<br/>
                     * <br/>
                     * Info: Mindestanzahl von Men&uuml;elementen, bevor das Suchfeld f&uuml;r das Men&uuml; angezeigt wird
                     */
                    UI_SHOW_MENU_SEARCH_MIN_ELEMENTS("core.sys.ui.show_menu_search_min_elements"),
                    /**
                     * <p><strong>Bl&auml;tter-Funktion auf jeder Seite auch oben anzeigen.</strong></p>
                     * Confkey: core.sys.ui.table.shownavibefore<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Damit sich diese Einstellung auf alle Tabellen bei jedem Anwender auswirkt, muss der Tomcat-server neugestartet werden.
                     */
                    UI_TABLE_SHOWNAVIBEFORE("core.sys.ui.table.shownavibefore")
                    ;
            
            
                    /** The key. */
                    private final String key;
            
                    /**
                     * Constructor taking the global configuration parameter key.
                     */
                    private SYS(String key) {
                        this.key = key;
                    }
            
                    @Override
                    public String getKey() {
                         return this.key;
                    }
                }
            
            }
        
            /**
             * Segment: PM.
             *
             * <br />
             * Company: HIS
             */
            public static class PM {
                /**
                 * Produktbereich: HRM.
                 */
                public static enum HRM implements KeyEnum<String>, Key {
                    /**
                     * <p><strong>Soll die Frage nach Arbeitslosigkeit angezeigt werden?.</strong></p>
                     * Confkey: pm.hrm.application.show_question_of_unemployment<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll die Frage nach Arbeitslosigkeit angezeigt werden?
                     */
                    APPLICATION_SHOW_QUESTION_OF_UNEMPLOYMENT("pm.hrm.application.show_question_of_unemployment"),
                    /**
                     * <p><strong>Soll Button &quot;Initiativbewerbung&quot; angezeigt werden?.</strong></p>
                     * Confkey: pm.hrm.application.show_speculative_application<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll Button &quot;Initiativbewerbung&quot; angezeigt werden?
                     */
                    APPLICATION_SHOW_SPECULATIVE_APPLICATION("pm.hrm.application.show_speculative_application"),
                    /**
                     * <p><strong>Art des verwendeten Importverfahrens f&uuml;r Zahlungen.</strong></p>
                     * Confkey: pm.hrm.payment.payment_import_type<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: Gibt an, welches Verfahren zum Import von Zahlungen verwendet wird.
                     */
                    PAYMENT_PAYMENT_IMPORT_TYPE("pm.hrm.payment.payment_import_type"),
                    /**
                     * <p><strong>Sollen die Betr&auml;ge zur Verpflichtung pro Budgetkonto zusammengefasst werden?.</strong></p>
                     * Confkey: pm.hrm.personnelcost.accounting.aggregate_additional_with_budgetaccount<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Bei der Verpflichtung von Personalkosten werden die Betr&auml;ge pro Finanzierung und Jahr zusammengefasst. Ist dieser Schalter 'TRUE', dann werden sie zus&auml;tzlich auch &uuml;ber das Budgetkonto zusammengefasst.
                     */
                    PERSONNELCOST_ACCOUNTING_AGGREGATE_ADDITIONAL_WITH_BUDGETACCOUNT("pm.hrm.personnelcost.accounting.aggregate_additional_with_budgetaccount"),
                    /**
                     * <p><strong>Der Bean-Name des Services der zum Buchen benutzt werden soll.</strong></p>
                     * Confkey: pm.hrm.personnelcost.accounting.external_accounting_service_bean_name<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Zum Verpflichten der Personalkosten k&ouml;nnen unterschiedliche Services angesprochen werden, hier wird der aktuell zu benutzende angegeben
                     */
                    PERSONNELCOST_ACCOUNTING_EXTERNAL_ACCOUNTING_SERVICE_BEAN_NAME("pm.hrm.personnelcost.accounting.external_accounting_service_bean_name"),
                    /**
                     * <p><strong>Erlaubnis Stellen &uuml;berzubesetzen.</strong></p>
                     * Confkey: pm.hrm.position.allow_overstaffing<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Mit dieser Einstellung erlauben Sie, dass Stellen &uuml;berbesetzt werden.
                     */
                    POSITION_ALLOW_OVERSTAFFING("pm.hrm.position.allow_overstaffing"),
                    /**
                     * <p><strong>Anzeige der Arbeitszeiten erfolgt sekundengenau.</strong></p>
                     * Confkey: pm.hrm.time.show_seconds<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    TIME_SHOW_SECONDS("pm.hrm.time.show_seconds"),
                    /**
                     * <p><strong>Cache-Zeit f&uuml;r Zeitkonten und Buchungsstatus.</strong></p>
                     * Confkey: pm.hrm.time.taaclocking.portlets.cache_time<br/>
                     * ParameterType: LONG<br/>
                     * <br/>
                     * Info: Wie viel Zeit, in Millisekunden, darf vergehen bis die Daten des Zeitkontos und der Status ob man bereits eingebucht ist wieder aktualisiert werden. Je mehr Zeit, desto performanter ist die Anwendung.
                     */
                    TIME_TAACLOCKING_PORTLETS_CACHE_TIME("pm.hrm.time.taaclocking.portlets.cache_time"),
                    /**
                     * <p><strong>Zeiterfassung wird verwendet.</strong></p>
                     * Confkey: pm.hrm.time.taaenabled<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: 
                     */
                    TIME_TAAENABLED("pm.hrm.time.taaenabled"),
                    /**
                     * <p><strong>L&auml;nge der Chipkartennummer.</strong></p>
                     * Confkey: pm.hrm.time.terminal.chipcard.cardnumber_length<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: L&auml;nge der Chipkartennummer
                     */
                    TIME_TERMINAL_CHIPCARD_CARDNUMBER_LENGTH("pm.hrm.time.terminal.chipcard.cardnumber_length"),
                    /**
                     * <p><strong>h&ouml;chste Chipkartennummer.</strong></p>
                     * Confkey: pm.hrm.time.terminal.chipcard.highest_id<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: h&ouml;chste Chipkartennummer
                     */
                    TIME_TERMINAL_CHIPCARD_HIGHEST_ID("pm.hrm.time.terminal.chipcard.highest_id"),
                    /**
                     * <p><strong>niedrigste Chipkartennummer.</strong></p>
                     * Confkey: pm.hrm.time.terminal.chipcard.lowest_id<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: niedrigste Chipkartennummer
                     */
                    TIME_TERMINAL_CHIPCARD_LOWEST_ID("pm.hrm.time.terminal.chipcard.lowest_id"),
                    /**
                     * <p><strong>automatisches n&auml;chtliches Ausstempeln.</strong></p>
                     * Confkey: pm.hrm.time.terminal.nightly_clock_out<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: alle Personen die vergessen auszustempeln, werden Nachts automatisch (ohne Zeitbuchunh) in den Terminals auf abwesend gesetzt. Somit muss morgens nicht erst aus- und dann wieder eingestempelt werden.
                     */
                    TIME_TERMINAL_NIGHTLY_CLOCK_OUT("pm.hrm.time.terminal.nightly_clock_out"),
                    /**
                     * <p><strong>&Uuml;bertragung des Gleitzeitguthabens.</strong></p>
                     * Confkey: pm.hrm.time.terminal.send_flexitime<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Gleitzeitguthaben wird an zur Anzeige an die Zeiterfassungsterminals &uuml;bertragen
                     */
                    TIME_TERMINAL_SEND_FLEXITIME("pm.hrm.time.terminal.send_flexitime"),
                    /**
                     * <p><strong>&Uuml;bertragung des Erholungsurlaubs.</strong></p>
                     * Confkey: pm.hrm.time.terminal.send_vacation_days<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Erholungsurlaub wird an zur Anzeige an die Zeiterfassungsterminals &uuml;bertragen
                     */
                    TIME_TERMINAL_SEND_VACATION_DAYS("pm.hrm.time.terminal.send_vacation_days"),
                    /**
                     * <p><strong>Server f&uuml;r Kommunikation mit Zeiterfassungsterminals mit HISinOne starten.</strong></p>
                     * Confkey: pm.hrm.time.terminal.server.autostart<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll der Server f&uuml;r die Kommunikation mit den Zeiterfassungsterminals automatisch beim Hochfahren von HISinOne mitgestartet werden?
                     */
                    TIME_TERMINAL_SERVER_AUTOSTART("pm.hrm.time.terminal.server.autostart"),
                    /**
                     * <p><strong>Names des Clusterknotens, auf dem der Server gestartet werden soll.</strong></p>
                     * Confkey: pm.hrm.time.terminal.server.cluster_node_name<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: 
                     */
                    TIME_TERMINAL_SERVER_CLUSTER_NODE_NAME("pm.hrm.time.terminal.server.cluster_node_name"),
                    /**
                     * <p><strong>Port des Servers.</strong></p>
                     * Confkey: pm.hrm.time.terminal.server.port<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: 
                     */
                    TIME_TERMINAL_SERVER_PORT("pm.hrm.time.terminal.server.port"),
                    /**
                     * <p><strong>Zeiterfassungsterminals liefern Sekunden.</strong></p>
                     * Confkey: pm.hrm.time.terminal.use_seconds<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Die Zeiterfassungsterminals sind so parametriert, dass sie auch Sekunden liefern.
                     */
                    TIME_TERMINAL_USE_SECONDS("pm.hrm.time.terminal.use_seconds"),
                    /**
                     * <p><strong>Zeiterfassungsterminals liefern Bedienersprache.</strong></p>
                     * Confkey: pm.hrm.time.terminal.user_language<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Die Zeiterfassungsterminals sind so parametriert, dass sie Bedienersprache liefern
                     */
                    TIME_TERMINAL_USER_LANGUAGE("pm.hrm.time.terminal.user_language")
                    ;
            
            
                    /** The key. */
                    private final String key;
            
                    /**
                     * Constructor taking the global configuration parameter key.
                     */
                    private HRM(String key) {
                        this.key = key;
                    }
            
                    @Override
                    public String getKey() {
                         return this.key;
                    }
                }
            
            }
        
            /**
             * Segment: RT.
             *
             * <br />
             * Company: HIS
             */
            public static class RT {
                /**
                 * Produktbereich: RES.
                 */
                public static enum RES implements KeyEnum<String>, Key {
                    /**
                     * <p><strong>Ist-/Soll-Anteil und Kostenstelle bei Personen/Positionen anzeigen.</strong></p>
                     * Confkey: rt.res.project.person.anteilkostenstelleposition<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Soll bei Personen/Positionen die Felder Ist-/Soll-Anteil und Kostenstelle angezeigt werden?
                     */
                    PROJECT_PERSON_ANTEILKOSTENSTELLEPOSITION("rt.res.project.person.anteilkostenstelleposition"),
                    /**
                     * <p><strong>Workflowunterst&uuml;tzung f&uuml;r die Mitarbeiterzuordnung.</strong></p>
                     * Confkey: rt.res.project.person.workflow_to_confirm_member<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Aktiviert den Workflow-Prozess bei der Zuordnung eines neuen Mitarbeiters zu einem Forschungsprojekt. Dieser Prozess erfordert einen Personenkreis mit der Funktion &quot;Personalsachbearbeiter&quot;. Wenn aktiv, wird nach der Zuordnung eines Mitarbeiters zun&auml;chst die Zustimmung des Personalsachbearbeiters eingeholt.
                     */
                    PROJECT_PERSON_WORKFLOW_TO_CONFIRM_MEMBER("rt.res.project.person.workflow_to_confirm_member")
                    ;
            
            
                    /** The key. */
                    private final String key;
            
                    /**
                     * Constructor taking the global configuration parameter key.
                     */
                    private RES(String key) {
                        this.key = key;
                    }
            
                    @Override
                    public String getKey() {
                         return this.key;
                    }
                }
            
                /**
                 * Produktbereich: RTP.
                 */
                public static enum RTP implements KeyEnum<String>, Key {
                    /**
                     * <p><strong>Workflow f&uuml;r Projektbeschreibungen.</strong></p>
                     * Confkey: rt.rtp.project.workflow.projectdata<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Aktiviert das Workflowmanagement f&uuml;r Projektbeschreibungen
                     */
                    PROJECT_WORKFLOW_PROJECTDATA("rt.rtp.project.workflow.projectdata"),
                    /**
                     * <p><strong>Workflow f&uuml;r Zuweisung zu Schwerpunkten nach Projektanlage.</strong></p>
                     * Confkey: rt.rtp.researchfocus.workflow.assign_project<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Aktiviert das Workflowmanagement f&uuml;r die Zuweisung von Projekten zu Schwerpunkten nach Neuanlage.
                     */
                    RESEARCHFOCUS_WORKFLOW_ASSIGN_PROJECT("rt.rtp.researchfocus.workflow.assign_project")
                    ;
            
            
                    /** The key. */
                    private final String key;
            
                    /**
                     * Constructor taking the global configuration parameter key.
                     */
                    private RTP(String key) {
                        this.key = key;
                    }
            
                    @Override
                    public String getKey() {
                         return this.key;
                    }
                }
            
            }
        
            /**
             * Segment: TEST.
             *
             * <br />
             * Company: HIS
             */
            public static class TEST {
                /**
                 * Produktbereich: SIMPLE.
                 */
                public static enum SIMPLE implements KeyEnum<String>, Key {
                    /**
                     * <p><strong>BigDecimal.</strong></p>
                     * Confkey: test.simple.bigdecimal<br/>
                     * ParameterType: BIGDECIMAL<br/>
                     * <br/>
                     * Info: 
                     */
                    BIGDECIMAL("test.simple.bigdecimal"),
                    /**
                     * <p><strong>Boolean.</strong></p>
                     * Confkey: test.simple.boolean<br/>
                     * ParameterType: BOOLEAN<br/>
                     * <br/>
                     * Info: Einfacher Test f&uuml;r Booleans
                     */
                    BOOLEAN("test.simple.boolean"),
                    /**
                     * <p><strong>Color.</strong></p>
                     * Confkey: test.simple.color<br/>
                     * ParameterType: COLOR<br/>
                     * <br/>
                     * Info: Einfacher Test f&uuml;r Farbwerte
                     */
                    COLOR("test.simple.color"),
                    /**
                     * <p><strong>Datum.</strong></p>
                     * Confkey: test.simple.date<br/>
                     * ParameterType: DATE<br/>
                     * <br/>
                     * Info: 
                     */
                    DATE("test.simple.date"),
                    /**
                     * <p><strong>Integer.</strong></p>
                     * Confkey: test.simple.integer<br/>
                     * ParameterType: INTEGER<br/>
                     * <br/>
                     * Info: Einfacher Test f&uuml;r Zahlen
                     */
                    INTEGER("test.simple.integer"),
                    /**
                     * <p><strong>Long.</strong></p>
                     * Confkey: test.simple.long<br/>
                     * ParameterType: LONG<br/>
                     * <br/>
                     * Info: Einfacher Test f&uuml;r Long
                     */
                    LONG("test.simple.long"),
                    /**
                     * <p><strong>Manyselect.</strong></p>
                     * Confkey: test.simple.manyselect<br/>
                     * ParameterType: MANYSELECT<br/>
                     * <br/>
                     * Info: 
                     */
                    MANYSELECT("test.simple.manyselect"),
                    /**
                     * <p><strong>Manyselect Src.</strong></p>
                     * Confkey: test.simple.manyselect_src<br/>
                     * ParameterType: MANYSELECT_SRC<br/>
                     * <br/>
                     * Info: 
                     */
                    MANYSELECT_SRC("test.simple.manyselect_src"),
                    /**
                     * <p><strong>Einfache Auswahlliste.</strong></p>
                     * Confkey: test.simple.oneselect<br/>
                     * ParameterType: ONESELECT<br/>
                     * <br/>
                     * Info: Test f&uuml;r eine einfache Auswahlliste
                     */
                    ONESELECT("test.simple.oneselect"),
                    /**
                     * <p><strong>Oneselect Src.</strong></p>
                     * Confkey: test.simple.oneselect_src<br/>
                     * ParameterType: ONESELECT_SRC<br/>
                     * <br/>
                     * Info: 
                     */
                    ONESELECT_SRC("test.simple.oneselect_src"),
                    /**
                     * <p><strong>Orgunit.</strong></p>
                     * Confkey: test.simple.orgunit<br/>
                     * ParameterType: ORGUNIT<br/>
                     * <br/>
                     * Info: 
                     */
                    ORGUNIT("test.simple.orgunit"),
                    /**
                     * <p><strong>Password.</strong></p>
                     * Confkey: test.simple.password<br/>
                     * ParameterType: PASSWORD_HASH<br/>
                     * <br/>
                     * Info: 
                     */
                    PASSWORD("test.simple.password"),
                    /**
                     * <p><strong>Password Plaintext.</strong></p>
                     * Confkey: test.simple.password_plaintext<br/>
                     * ParameterType: PASSWORD_PLAINTEXT<br/>
                     * <br/>
                     * Info: 
                     */
                    PASSWORD_PLAINTEXT("test.simple.password_plaintext"),
                    /**
                     * <p><strong>String.</strong></p>
                     * Confkey: test.simple.string<br/>
                     * ParameterType: STRING<br/>
                     * <br/>
                     * Info: Einfacher Test f&uuml;r Zeichenketten
                     */
                    STRING("test.simple.string"),
                    /**
                     * <p><strong>Term.</strong></p>
                     * Confkey: test.simple.term<br/>
                     * ParameterType: TERM<br/>
                     * <br/>
                     * Info: Einfacher Test f&uuml;r einen Term
                     */
                    TERM("test.simple.term"),
                    /**
                     * <p><strong>Time.</strong></p>
                     * Confkey: test.simple.time<br/>
                     * ParameterType: TIME<br/>
                     * <br/>
                     * Info: Test f&uuml;r eine Uhrzeit
                     */
                    TIME("test.simple.time")
                    ;
            
            
                    /** The key. */
                    private final String key;
            
                    /**
                     * Constructor taking the global configuration parameter key.
                     */
                    private SIMPLE(String key) {
                        this.key = key;
                    }
            
                    @Override
                    public String getKey() {
                         return this.key;
                    }
                }
            
            }
        
        // UPDATED: 2013/11/07 11:56:24
        /* AUTOCONF_END */

}

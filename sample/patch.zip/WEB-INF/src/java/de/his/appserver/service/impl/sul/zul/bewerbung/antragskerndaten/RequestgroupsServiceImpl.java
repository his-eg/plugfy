/*
 * Copyright (c) 2007 HIS GmbH All Rights Reserved.
 *
 * $Log: RequestgroupsServiceImpl.java,v $
 * Revision 1.314.4.6  2013-12-03 10:33:40  schirmeister#his.de
 * Fehlende Unterlage zum Fach wird nicht gespeichert #102055
 *
 * Revision 1.314.4.5  2013-11-21 09:29:51  lustig#his.de
 * Anfrage #92874 – APP: Einstellungen zu den angebotenen FS sollte funktionsspezifisch erfolgen können
 *
 * Revision 1.314.4.4  2013-11-14 10:06:29  koczewski#his.de
 * Merge von HEAD
 * Anfrage #96321 – APP: Haupt- Hilfsanträge werden in der Sachbearbeitung nicht korrekt dargestellt
 *
 * Revision 1.314.4.3  2013-11-13 10:21:27  eden#his.de
 * #100527: Pflicht-BBs und BB-Pflichtfelder dürfen nicht gelöscht werden bei Antrag >= eingegangen
 *
 * Revision 1.314.4.2  2013-10-24 13:46:46  strube#his.de
 * Anpassungen in der Online-Immatrikulation vorgenommen. Fokus: BAföG und Heimatkreis (fixes #98858)
 *
 * Revision 1.314.4.1  2013-10-09 09:27:37  strube#his.de
 * Anzeige des Antragsstatus der Bewerbung korrigiert (fixes #96119)
 *
 * Revision 1.314  2013-08-07 09:01:01  eden#his.de
 * Bewerbungsbestandteile in alter Sachbearbeitung anzeigen  und bearbeiten( #87881)
 *
 * Revision 1.313  2013-08-07 06:50:11  eden#his.de
 * Bewerbungsbestandteile in alter Sachbearbeitung anzeigen ( #87881)
 *
 * Revision 1.312  2013-07-02 16:27:22  brummermann#his.de
 * fixed compilers errors in the newest eclipse ide on java 7
 *
 * Revision 1.311  2013-06-27 10:34:59  eden#his.de
 * Verfahrenskorrektur nicht vor Ranglistenfreigabe (fixes #80324)
 *
 * Revision 1.310  2013-06-27 08:04:54  koczewski#his.de
 * Refactoring RequestStatusSwitch
 *
 * Revision 1.309  2013-06-12 09:24:56  eden#his.de
 * Validierung des geplanten Immadatums (fixes #64116)
 *
 * Revision 1.308  2013-05-22 08:24:59  schwaff#his.de
 * #90582 added error-messages when objects could not be found
 *
 * Revision 1.307  2013-05-08 10:00:51  schirmeister#his.de
 * #90264  #90284
 *
 * Revision 1.306  2013-05-02 15:31:44  burchard#his.de
 * APP: Bearbeitungsstatus für Sachbearbeiter nicht mehr auswählbar - fixes #90284
 * Bugfix: Antragsstatus beim "Immatrikulationsantrag bearbeiten" nicht mehr sicht- und editierbar - fixes #90362
 *
 * Revision 1.305  2013-04-25 09:05:06  strube#his.de
 * Test korrigiert (fixes #00000)
 *
 * Revision 1.304  2013-04-24 09:44:52  strube#his.de
 * Refactoring (#00000)
 *
 * Revision 1.303  2013-04-22 11:25:25  schwaff#his.de
 * marked method findApplicationByIdPrefetched as deprecated
 *
 * Revision 1.302  2013-04-17 14:49:31  strube#his.de
 * Online-Imma, Exma, Loeschen des Student und Stornierung Exma: RequestSubjectStatus-Uebernahme korrigiert (fixes #89010,#89423)
 *
 * Revision 1.301  2013-04-17 09:40:31  burchard#his.de
 * Bewerber übernehmen : Übernahme von Teilzulassungen - fixes #88916
 *
 * Revision 1.300  2013-04-16 08:08:30  schwaff#his.de
 * #89267 – Bugfix: In der neuen Sachbearbeitung wird die Messzahl nicht gespeichert
 *
 * Revision 1.299  2013-04-15 10:53:34  eden#his.de
 *  Umstellung id->obj_guid in glob Konf (cm.app.application.apprenticeship.unit_id , cm.app.application.measurementseconddegree.unitid) (fixes #88979)
 *
 * Revision 1.298  2013-03-18 14:39:33  schirmeister#his.de
 * Loadpath korrigiert
 *
 * Revision 1.297  2013-03-18 14:25:59  schwaff#his.de
 * enhanced loadPath on demand
 *
 * Revision 1.296  2013-03-11 12:25:55  strube#his.de
 * Debugs hinzugefuegt, Requests aus neu aus DB laden. (fixes #82374)
 *
 * Revision 1.295  2013-03-11 07:06:58  schwaff#his.de
 * #86905 – Bugfix: Fehlende fachbezogene Unterlagen auf "vorhanden" setzen, Requestsubject-Examplan Zuordnung wird gelöscht
 *
 * Revision 1.294  2013-02-26 14:21:43  koczewski#his.de
 * Refactoring: RequestStatus as service
 *
 * Revision 1.293  2013-02-08 11:35:38  schwaff#his.de
 * validate requestsubjects when set to status valid
 *
 * Revision 1.292  2013-01-28 08:26:34  strube#his.de
 * Fehlermeldung anzeigen und Imma-Button ausblenden, wenn der Bewerbungszeitraum nicht administriert ist (fixes #78126)
 *
 * Revision 1.291  2013-01-23 09:37:17  strube#his.de
 * Ausblenden des Links "Bewerbung uebernehmen" (fixes #82374)
 *
 * Revision 1.290  2013-01-18 11:09:30  strube#his.de
 * Matching-Algorithmus von Request und DegreeProgram optimiert (fixes #81004)
 *
 * Revision 1.289  2013-01-17 16:12:09  schwaff#his.de
 * added method validateRequestSubject
 *
 * Revision 1.288  2013-01-16 13:24:46  paul#his.de
 * Umstellung von List auf Set im Bereich des APP-Datenmodells.
 *
 * Revision 1.287  2013-01-16 11:38:53  paul#his.de
 * Konsequente Umstellung von List auf Set im Bereich App-Modell. Ansprechpartner Paul oder Schirmeister.
 *
 * Revision 1.286  2012-12-19 12:39:46  strube#his.de
 * Immatrikulierte Bewerbungen werden nicht mehr bei der Bewerbungsuebernahme angezeigt; Der RequestSubjectStatus wird statt des Zulassungsstatus angezeigt; Beim Speichern des STU-Kunden kriegen alle Antraege einer Bewerbung nicht mehr den gleichen Status (fixes #82374)
 *
 * Revision 1.285  2012-12-18 10:47:03  schwaff#his.de
 * removed Macker-warnings
 *
 * Revision 1.284  2012-12-17 10:47:46  schwaff#his.de
 * moved some business-code from AntragskerndatenController to RequestgroupService
 *
 * Revision 1.283  2012-12-14 10:43:13  schwaff#his.de
 * deleted method loadDtoAttribute
 *
 * Revision 1.282  2012-12-14 10:38:32  schwaff#his.de
 * mark method loadDtoAttribute as deprecated
 *
 * Revision 1.281  2012-12-14 08:14:13  strube#his.de
 * Nachladen von DTOs konkretisiert (fixes #00000)
 *
 * Revision 1.280  2012-12-13 10:46:46  strube#his.de
 * BAfoeG kann nur noch dem Antrag zugeordnet werden, aus dem heraus die Online-Imma gestartet wurde; (fixes #78511) Nach Abschluss der Online-Imma, wird der BAfoeg-Antrag vom Bew-Antrag auf den Studiengang geswitcht;
 *
 * Revision 1.279  2012-12-06 15:40:35  schwaff#his.de
 * removed loadpath
 *
 * Revision 1.278  2012-12-05 16:56:17  schwaff#his.de
 * added method findRequestSubjectByCourseOfStudyAndPerson
 *
 * Revision 1.277  2012-12-03 13:38:43  koczewski#his.de
 * Anfrage #62767 – PA: Administrator Zulassung/Bewerber-Manager prüft auf Bewerber ohne Quotenzuordnung
 *
 * Revision 1.276  2012-11-30 15:01:17  schwaff#his.de
 * corrected loadPath
 *
 * Revision 1.275  2012-11-30 14:44:21  schwaff#his.de
 * corrected loadPath
 *
 * Revision 1.274  2012-11-30 14:38:31  schwaff#his.de
 * corrected loadPath
 *
 * Revision 1.273  2012-11-30 08:03:57  schwaff#his.de
 * changed access from Lists to Sets (#77900, #80686)
 *
 * Revision 1.272  2012-11-29 11:12:36  schwaff#his.de
 * fetch application-data with loadDtoAttribute if it's not set
 *
 * Revision 1.271  2012-11-20 15:28:06  schwaff#his.de
 * performance-tuning for Semesterbereinigung (#77900)
 *
 * Revision 1.270  2012-10-22 08:33:27  strube#his.de
 * Bewerber und vorl. Studenten koennen uebernommen werden, deren Antraege "I-Antrag in Bearbeitung", "Imma beantragt", oder "zugelassen" sind, Anzeige der RequestStatus ueber den RequestStatusSwitch (fixes #79590)
 *
 * Revision 1.269  2012-10-16 08:23:55  burchard#his.de
 * Bugfix: Messazahl wird mehrfach angelegt - fixes #72047
 *
 * Revision 1.268  2012-10-15 16:56:03  burchard#his.de
 * Bugfix: Bewerbungen übernehmen funktioniert nicht - fixes #79207 #78560 #78571 #78569 #78568
 *
 * Revision 1.267  2012-10-04 09:32:03  strube#his.de
 * Fehler beim Entfernen des BAfoeG-Antrages korrigiert (fixes #76512)
 *
 * Revision 1.266  2012-10-01 14:48:37  strube#his.de
 * Rollenwechsel aus AbstractRequestStatus entfernt, RequestStatuswechsel in den StudentService verschoben, Immatrikulation für Zulassungsbeantragte Bewerbungen ermoeglicht. (fixes #78065)
 *
 * Revision 1.265  2012-09-27 11:17:50  eden#his.de
 * fixes #77104
 *
 * Revision 1.264  2012-09-06 09:20:40  schirmeister#his.de
 * TestCases und korrekturen für #64330
 *
 * Revision 1.263  2012-09-04 08:09:27  strube#his.de
 * Bewerberuebernahme auf die Uebernahme einzelner Requests umgestellt, zur Vermeidung einer NPE: Imma-Datum ermittelt (fixes #75944)
 *
 * Revision 1.262  2012-08-15 15:02:11  strube#his.de
 * Bafoeg-RequestSubject in die Sachbearbeitermaske (fixes #72358)
 *
 * Revision 1.261  2012-08-02 12:16:43  schirmeister#his.de
 * fixes #64330
 *
 * Revision 1.260  2012-08-01 14:40:16  kromm#his.de
 * Teilzulassungen in der OI und div. Fehelerkorrekturen APP
 *
 * Revision 1.259  2012-07-26 14:39:42  schwaff#his.de
 * moved the assignment of entrancequalifications from the HZB-page to the request-page (fixes #64330)
 *
 * Revision 1.258  2012-07-24 11:21:52  schirmeister#his.de
 * fixes #64330
 *
 * Revision 1.257  2012-07-19 10:28:32  eden#his.de
 * fixes #73377
 *
 * Revision 1.256  2012-07-18 08:16:31  koczewski#his.de
 *  Anfrage #63047 – APP: Ausblendung der überflüssigen Anträge bei freien Studiengängen
 *
 * Revision 1.255  2012-07-16 13:55:19  schirmeister#his.de
 * fixes #64330
 *
 * Revision 1.254  2012-07-16 10:45:55  eden#his.de
 * fixes #71971
 *
 * Revision 1.253  2012-07-03 09:18:14  eden#his.de
 * fixes #71718
 *
 * Revision 1.252  2012-06-07 11:07:42  eden#his.de
 * cm.app.edit_old_admission_regulation gelöscht (fixes #70176)
 *
 * Revision 1.251  2012-06-06 09:37:50  schwaff#his.de
 * removed superfluous methods
 *
 * Revision 1.250  2012-05-09 15:06:01  schwaff#his.de
 * avoid loading the personDto again, when not needed
 *
 * Revision 1.249  2012-04-18 09:36:13  eden#his.de
 * fixes #66954
 *
 * Revision 1.248  2012-04-17 09:03:44  schirmeister#his.de
 * Bugfix für Nachweis bev Zul #67583
 *
 * Revision 1.247  2012-04-16 11:26:40  eden#his.de
 * fixes #66954
 *
 * Revision 1.246  2012-04-13 12:30:32  schwaff#his.de
 * changed findMeasurementSeconddegree from private to public
 *
 * Revision 1.245  2012-04-10 08:40:30  schwaff#his.de
 * added method getAllRequestSubjectsByApplicationId
 *
 * Revision 1.244  2012-03-31 23:39:08  kromm#his.de
 * Umbau Online-Imma - Merge in den HEAD
 *
 * Revision 1.243  2012-03-29 14:37:59  schwaff#his.de
 * asking applicants if they haven't passed an examination at a former university
 *
 * Revision 1.242  2012-03-23 15:02:01  schwaff#his.de
 * moved ApplicationUtil
 *
 * Revision 1.241  2012-03-22 09:49:17  schwaff#his.de
 * removed unnecessary methods and classes
 *
 * Revision 1.240  2012-03-19 13:03:32  schwaff#his.de
 * merged VerwaltungsdatenBewService and VerwaltungsdatenService (fixes #14219)
 *
 * Revision 1.239  2012-03-13 15:19:50  schwaff#his.de
 * prepare app for handling no application-term (fixes #65160)
 *
 * Revision 1.238  2012-02-20 16:09:01  mclaren#his.de
 * Architektur-Verletzung geloesst, Interfaces gehöre in ein iface-Package.
 *
 * Revision 1.237  2012-02-15 10:29:59  eden#his.de
 * fixes #63340
 *
 * Revision 1.236  2012-02-06 09:44:18  eden#his.de
 * Ablehungsgrund wird nur angezeit, wenn Status auf abgelehnt; Speichern nur über die amendmentstatusId(fixes #62744)
 *
 * Revision 1.235  2012-02-02 15:43:28  schirmeister#his.de
 * bugfix für getAllCoursesOfStudiyFromApplication
 *
 * Revision 1.234  2012-01-30 10:57:09  eden#his.de
 * Anlegen einer Bewerbung ohne Antrag führt zu Fehlermeldung(fixes #61683)
 *
 * Revision 1.232  2012-01-26 08:22:14  koczewski#his.de
 * Anfrage #62457 – Nach Aufruf der Online-Bewerbung erscheint ein unspezifischer Fehler
 *
 * Revision 1.233  2012-01-26 14:34:43  koczewski#his.de
 * Anfrage #62718 – Löschen abgegebener Anträge über mehrere Browser-Tabs möglich
 *
 * Revision 1.231  2012-01-20 08:57:39  schwaff#his.de
 * removed usages of FacesUtils from Services due to macker-errors
 *
 * Revision 1.230  2012-01-17 10:43:34  schirmeister#his.de
 * Bugfix für Sachbearbeiterfunktion
 *
 * Revision 1.229  2012-01-16 15:12:28  schirmeister#his.de
 * loadpath korrigiert
 *
 * Revision 1.228  2012-01-13 10:18:09  schirmeister#his.de
 * Umstellung der Studiengangstruktur 5. Teil (Compilerfehler beseitigt, AdmissionToStudyDto entfernt)
 *
 * Revision 1.227  2012-01-13 09:42:17  schwaff#his.de
 * Umstellung der Studiengangstruktur 4. Teil (AdmissionToStudy und CourseOfStudyStart mit Referenzen entfernt)
 *
 * Revision 1.226  2012-01-12 10:34:57  schirmeister#his.de
 * Umstellung der Studiengangstruktur 1. Teil (APP noch nicht vollständig lauffähig)
 *
 * Revision 1.225  2012-01-11 12:30:23  hoersch#his.de
 * Update des Springframeworks auf Version 3.1 (inlusive Webflow und Security); Anpassungen an benutzendem Code (fixes #59121)
 *
 * Revision 1.224  2011-12-21 14:30:06  weiland#his.de
 * #59300 fix redirect from online application to online imma
 *
 * Revision 1.223  2011-12-15 10:14:10  eden#his.de
 * Korrekturen beim Suchen nach Amendments (fixes #60542)
 *
 * Revision 1.222  2011-12-15 08:20:33  schwaff#his.de
 * each requestSubject should only appear once in the selectManxyCheckbox-menu (fixes #60513)
 *
 * Revision 1.221  2011-12-14 16:23:53  schwaff#his.de
 * hardshipAmendments should be at requestsubjects (fixes #60513)
 *
 * Revision 1.220  2011-12-14 11:02:38  kromm#his.de
 * #60389
 *
 * Revision 1.219  2011-12-14 09:17:48  schwaff#his.de
 * code-formatting
 *
 * Revision 1.218  2011-12-13 15:34:28  schwaff#his.de
 * refactored some methods
 *
 * Revision 1.217  2011-12-12 12:27:17  eden#his.de
 * Speichern korrigiert(#59595)
 *
 * Revision 1.216  2011-12-12 11:31:27  eden#his.de
 *  Härtefälle in der Sachbearbeitung werden fachbezogen gespeichert(#59595)
 *
 * Revision 1.215  2011-12-08 16:55:03  schwaff#his.de
 * removed obsolete methods (III.)
 *
 * Revision 1.214  2011-12-08 16:51:32  schwaff#his.de
 * removed obsolete save-method (II.)
 *
 * Revision 1.213  2011-12-08 16:48:30  schwaff#his.de
 * removed obsolete save-method
 *
 * Revision 1.212  2011-12-06 12:48:25  schwaff#his.de
 * Added fixmes to point to macker-errors and -warnings
 *
 * Revision 1.211  2011-12-05 12:44:47  eden#his.de
 * Begonnen mit Fachbezug für Härtefälle in der Sachbearbeitung (#59595)
 *
 * Revision 1.210  2011-11-30 14:37:07  bergemann#his.de
 * - Rechte in Absprache mit A.Schwaff zurückgesetzt wegen 'Access denied' Fehler in 'Studierendendaten bearbeiten'
 *
 * Revision 1.209  2011-11-29 13:09:40  schwaff#his.de
 * Added secured annotations to APP-services
 *
 * Revision 1.208  2011-11-24 09:54:07  koczewski#his.de
 * Setzen des RequestSubjectStatus in der Sachbearbeitung (#58894)
 *
 * Revision 1.207  2011-11-22 08:13:17  eden#his.de
 * Nachfrage nur wenn Status ungleich "Bearbeitung abgeschlossen" (fixes #55787)
 *
 * Revision 1.206  2011-11-17 17:02:41  hoersch#his.de
 * Service-Metadaten auf Annotationen umgestellt
 *
 * Revision 1.205  2011-11-16 12:21:59  eden#his.de
 * "Bearbeitung abgeschlossen" auf Nachfrage beim Speichern setzen (fixes #58233)
 *
 * Revision 1.204  2011-11-09 16:04:17  koczewski#his.de
 * Änderungen am RequestSubjectStatus  durch Sachbearbeiter
 *
 * Revision 1.203  2011-11-09 13:16:10  schwaff#his.de
 * Display of missing documents for requestSubjects
 *
 * Revision 1.202  2011-11-09 11:59:07  eden#his.de
 * Antrag und Fach nach Neuanlage Status "in Vorbereitung (#fixes 57694)
 *
 * Revision 1.201  2011-11-04 12:45:51  keunecke#his.de
 * rename moved updatedAt  to updatedAdmissionRelevantDataAt (fixes #56843)
 *
 * Revision 1.200  2011-11-04 11:48:09  koczewski#his.de
 * Application.updatedAt -> Request.updatedAt
 *
 * Revision 1.199  2011-11-04 10:28:08  keunecke#his.de
 * begin move updatedAt from Application to Request (fixes #56843)
 *
 * Revision 1.198  2011-11-03 11:50:16  eden#his.de
 * "Fach hinzufügen" , "Antrag löschen" disablen, wenn Antragsstatus nicht "in Vorbereitung" oder "...canceled"
 *
 * Revision 1.197  2011-11-03 10:23:27  eden#his.de
 * Löschbutton am Fach disabled wenn Status "in Vorbereitung" oder "zurückgezogen"
 *
 * Revision 1.196  2011-11-02 11:46:21  eden#his.de
 * Bei der Neuanlage eines Antrags Status von Antrag und Fach auf "eingegangen". Fach nur änderbar im Status "in Vorbereitung".
 *
 * Revision 1.195  2011-10-27 11:25:44  eden#his.de
 * "Abschluss" und "Daten zum Fach" auf readonly, wenn der Fachstatus="eingegangen"
 *
 * Revision 1.194  2011-10-27 10:25:50  eden#his.de
 * Zulassungsstatus und Annahme readonly wenn SeSt-Studiengang
 *
 * Revision 1.193  2011-10-26 14:15:50  koczewski#his.de
 * Antragstatus für Sachbearbeiter
 *
 * Revision 1.192  2011-10-26 09:16:30  eden#his.de
 * Hinweis beim Öffnen einer Bewerbung, wenn Antrag in Status "in Vorbereitung"
 *
 * Revision 1.191  2011-10-25 10:28:33  eden#his.de
 * Hinweis beim Öffnen einer Bewerbung, wenn Antrag in Status "eingegangen"
 *
 * Revision 1.190  2011-10-20 11:10:22  eden#his.de
 * Fachstatus anzeigen
 *
 * Revision 1.189  2011-10-19 13:17:27  koczewski#his.de
 * Bewerbung: Neue Spalte in Antragsbaum für Status
 *
 * Revision 1.188  2011-10-11 12:29:06  kassner#his.de
 * WorkstatusValueXtdDtoImpl wird nicht mehr benutzt. Wird mit Interface und  Referenzen gelöscht ggf. auf WorkstatusValueDto geändert.
 *
 * Revision 1.187  2011-10-07 14:23:47  schwaff#his.de
 * initializing the requestStatus when a new request is added
 *
 * Revision 1.186  2011-09-29 07:23:36  eden#his.de
 * NPE abgefangen
 *
 * Revision 1.185  2011-09-28 10:49:47  eden#his.de
 * Zulassungsstatus = abgelehnt  => Ablehnungsgrund in BB einblenden
 *
 * Revision 1.184  2011-09-21 15:05:54  burchard#his.de
 * Bewerbung übernehmen - fixes #46987
 *
 * Revision 1.183  2011-09-21 13:41:14  kromm#his.de
 * * Attribute requestStatus und isActive sind in der DTO-Schicht readonly
 * * Status unterstützen die Abfrage von implementierten Transitions
 *
 * Revision 1.182  2011-09-21 11:18:06  schwaff#his.de
 * moved RequestXtdDto from sul.zul.bewerbung to cm.app
 *
 * Revision 1.181  2011-09-21 09:38:47  schwaff#his.de
 * changed requestStatusService to RequestStatusSwitch (together with Sergej)
 *
 * Revision 1.180  2011-09-20 11:33:57  kromm#his.de
 * status for request and request subject
 *
 * Revision 1.179  2011-08-31 15:13:59  schwaff#his.de
 * implemented logic to retrieve missing documents for each requestSubject in an application
 *
 * Revision 1.178  2011-08-17 15:01:06  schwaff#his.de
 * divided AmendmentService, HeartefallService and RequestgroupService from each other
 *
 * Revision 1.177  2011-08-16 10:55:38  schwaff#his.de
 * removed unused services
 *
 * Revision 1.176  2011-08-15 12:38:29  paul#his.de
 * Aktivierung des DOSV in der globalen Konfiguration auf ONESELECT umgestellt. Hintergrund ist, dass der Typ BOOLEAN neben true und false den Wert 'nicht vorhanden' definiert, was hier fachlich verkehrt ist.
 *
 * Revision 1.175  2011-08-02 15:04:51  schwaff#his.de
 * changed deleteRequestSubject to deleteSubject
 *
 * Revision 1.174  2011-08-01 12:46:39  schwaff#his.de
 * new method getApplicationIdFromRequst
 *
 * Revision 1.173  2011-07-28 13:30:44  schwaff#his.de
 * modified method deleteRequestSubject()
 *
 * Revision 1.172  2011-07-27 17:33:07  burchard#his.de
 * Prototyp : Bewerbung übernehmen #46238
 *
 * Revision 1.171  2011-07-26 15:28:54  schwaff#his.de
 * changed deleteRequestSubject-method
 *
 * Revision 1.170  2011-07-26 08:19:31  schwaff#his.de
 * added method loadRequest
 *
 * Revision 1.169  2011-07-21 13:26:28  schwaff#his.de
 * extends method deleteRequestSubject
 *
 * Revision 1.168  2011-07-20 14:15:58  schwaff#his.de
 * added new method deleteRequestSubject
 *
 * Revision 1.167  2011-07-19 10:59:58  eden#his.de
 * Beim Löschen eines Faches mit Antr.Bev.Zul oder beim Entfernen des Antr.Bev.Zul. wird amendment mit gelöscht.
 *
 * Revision 1.166  2011-06-10 12:02:19  schwaff#his.de
 * Changed approach to create LoadPaths
 *
 * Revision 1.165  2011-06-10 11:41:02  schwaff#his.de
 * Changed approach to create LoadPaths from ordinary String-Array to DTOFactoryUtil
 *
 * Revision 1.164  2011-06-01 13:59:34  schwaff#his.de
 * Added @Override-annotations
 *
 * Revision 1.163  2011-05-31 08:11:31  eden#his.de
 * IllegalArgumentException abgefangen
 *
 * Revision 1.162  2011-05-17 08:36:18  strube#his.de
 * not-null property referenz Fehler behoben (fixes #47391)
 *
 * Revision 1.161  2011-05-16 09:49:28  eden#his.de
 * Beim Löschen des letzten Faches eines Antrages gesamten Antrag löschen . Letzte Fach einer Bew. kann nicht gelöscht werden (#fixes 41901)
 *
 * Revision 1.160  2011-05-10 10:25:50  eden#his.de
 * Validierung des beantragen FS in BB (#fixes 36375)
 *
 * Revision 1.159  2011-04-05 08:50:18  schirmeister#his.de
 * Korrekturen/Erweiterungen für QG1 aus dem Februar-Branch in den CVS-head übernommen.
 *
 * Revision 1.158  2011-03-30 09:41:56  eden#his.de
 * In Gültigkeitsprüfung für  Studiengang den Typ mit aufgenommen (fixes #44791)
 *
 * Revision 1.157  2011-03-30 06:43:40  eden#his.de
 * In Gültigkeitsprüfung für  Studiengang den Typ mit aufgenommen (fixes #44791)
 *
 * Revision 1.156  2011-02-24 15:28:40  husmann#his.de
 * Umstellung der Confparameterabfrage vom Confparameterservice auf Conf #30471
 *
 * Revision 1.155  2011-02-23 17:06:23  schirmeister#his.de
 * updatedAt wird nur aktualisiert, falls SeSt aktiv.  #43367
 *
 * Revision 1.154  2011-02-23 16:36:10  schirmeister#his.de
 * fixes #43367
 *
 * Revision 1.153  2011-02-15 10:43:19  schirmeister#his.de
 * bugfix und refactoring für die Änderungsverfolgung in der Online-Bewerbung
 *
 * Revision 1.152  2011-02-14 09:34:24  schirmeister#his.de
 * Bei Änderung des Studiengangs in der Sachbearbeiterfunktion (cm.app.bb) wird, abhängig von einem Konfigurationsschalter ein Zeitstempel in der Application aktualisiert.
 *
 * Revision 1.151  2011-02-09 17:27:00  schirmeister#his.de
 * Bei Änderung des Studiengangs in der Online-Bewerbung wird, abhängig von einem Konfigurationsschalter ein Zeitstempel in der Bewerbung aktualisiert.
 *
 * Revision 1.150  2011-01-31 10:18:28  eden#his.de
 * "Neue Bewerbung" auf BB - Suchmaske ergänzt
 *
 * Revision 1.149  2011-01-12 11:54:32  eden#his.de
 * Verschieben des Hauptantrages nur mgl., wenn kein Antrag auf Bevorzugung gestellt wurde.
 *
 * Revision 1.148  2010-12-16 08:39:36  eden#his.de
 * In Onlinebewerbung  nur noch  Studiengänge mit gültigen Bewerbungszeiträumen auswählbar, bei Kombistudiengängen mit mind. einer gültigen Komb.
 *
 * Revision 1.147  2010-12-09 15:34:17  oberle#his.de
 * Status auf "unvollständig" zurückgesetzt, falls von Immatrikulation in freiem Studiengang zurück auf NC-Studiengang gewechselt wurde.
 *
 * Revision 1.146  2010-12-06 12:54:46  oberle#his.de
 * Lässt Online-Bewerbung auch dann änderbar, wenn der Verarbeitungsstatus "Bearbeitung abgeschlossen" ist. Nun nur noch abhängig von abgelaufenen Bewerbungsfristen.
 *
 * Revision 1.145  2010-12-03 16:03:38  husmann#his.de
 * Abfrage der globalen Konfigurationsparameter geändert. Konstante kommt aus dem enum in GlobalConfigurationKey; #30471
 *
 * Revision 1.144  2010-12-01 07:16:41  oberle#his.de
 * Weiterleitung zur Online-Immatrikulation auf Studiengänge angepasst, die in mehreren Zulassungspaketen hängen (Fachsemesterunterscheidung).
 *
 * Revision 1.143  2010-11-16 15:03:14  steuernagel#his.de
 * Online-Bewerbung: Wenn ein Bewerber im ersten Antrag nur freie Fächer wählt, wird er direkt zur Online-Immatrikulation weitergeleitet.
 *
 * Revision 1.142  2010-11-03 09:24:35  hoersch#his.de
 * Aufruf der onDelete-Callbacks von postFlush in onDelete verschoben
 *
 * Revision 1.141  2010-10-08 08:22:57  steuernagel#his.de
 * Zuordnungen von HZB zu Auswahlordnung korrigiert.
 *
 * Revision 1.140  2010-09-07 11:48:52  schirmeister#his.de
 * alte Auswahlordnungs-Implementierung konfigurierbar gemacht.
 *
 * Revision 1.139  2010-08-24 10:54:17  eden#his.de
 * Abfrage erweitert: Wurde das zu löschende Fach gerade neu angelegt (d.h. noch nicht in der DB gespeichert)?
 *
 * Revision 1.138  2010-08-10 07:33:13  eden#his.de
 * NPE behoben
 *
 * Revision 1.137  2010-08-09 10:13:14  eden#his.de
 * fehlende Metadaten ergänzt
 *
 * Revision 1.136  2010-08-04 12:40:40  oberle#his.de
 * Funktionalität für Annahmeerklärung online ergänzt.
 *
 * Revision 1.129.2.6  2010-08-02 16:14:35  strube#his.de
 * Examimport wird vor dem Studentexternal gespeichert (fixes 32358)
 *
 * Revision 1.134  2010-08-02 09:39:12  strube#his.de
 * Max. Anzahl von Abschluessen und Faecher pro Abschluss werden beruecksichtigt (fixes #32097)
 *
 * Revision 1.133  2010-07-30 13:34:25  oberle#his.de
 * Manuelle Zulassung korrigiert (fix #32257)
 *
 * Revision 1.132  2010-07-23 07:28:45  schirmeister#his.de
 * NPE verhindert
 *
 * Revision 1.131  2010-07-20 09:35:29  strube#his.de
 * Refactoring und Index-Exception abgefangen
 *
 * Revision 1.130  2010-07-19 14:34:21  d.scholz#his.de
 * Logging verbessert
 *
 * Revision 1.129  2010-07-15 15:30:17  d.scholz#his.de
 * Logging verbessert + Unnötiges entfernt
 *
 * Revision 1.128  2010-07-12 13:13:43  steuernagel#his.de
 * Manuelle Ablehnung ermöglicht; Unterstüzung mehrerer Nachrückverfahren
 *
 * Revision 1.127  2010-06-23 13:49:47  t.neumann#his.de
 * Refactoring Package-Strukturen Team Exa
 *
 * Revision 1.126  2010-05-25 16:46:28  schirmeister#his.de
 * Fachbezogene Bewerbungsfristenauswertung (Semester wird  ausgewertet) (fixes #29324)
 *
 * Revision 1.125  2010-05-25 15:37:58  schirmeister#his.de
 * Fachbezogene Bewerbungsfristenauswertung angefangen (fixes #29324)
 *
 * Revision 1.124  2010-05-24 17:31:29  oberle#his.de
 * Umstellung AdmissionShare zu AdmissionToStudy auf 1:n statt 1:1 (fix #25335).
 *
 * Revision 1.123  2010-05-18 17:12:20  oberle#his.de
 * Setter für DAOs und Services gruppiert, neue Service-Methode hinzugefügt als Vorbereitung für Annahmeerklärung online.
 *
 * Revision 1.122  2010-05-18 11:21:46  steuernagel#his.de
 * Berechnung der Auswahlnote beim Abschluß der Bewerbung
 *
 * Revision 1.121  2010-05-12 15:05:26  steuernagel#his.de
 * 'beruflich Qualifizierte' werden als HZB erfasst und es wird ein Zusatzantrag angelegt.
 *
 * Revision 1.120  2010-05-04 09:36:05  steuernagel#his.de
 * Verbuchen von fachweisen Boni auf die HZB
 *
 * Revision 1.119  2010-04-26 11:50:34  steuernagel#his.de
 * Aktualisieren der Auswahlnote beim Speichern
 *
 * Revision 1.118  2010-04-12 13:08:57  oberle#his.de
 * Umstellung von HzbService auf EntranceQualificationService
 *
 * Revision 1.117  2010-04-12 07:52:36  oberle#his.de
 * Umstellung von HeAdmission auf EntranceQualification.
 *
 * Revision 1.116  2010-03-26 07:16:30  steuernagel#his.de
 * Änderungen des Status für abgeschlossene Bewerbungen in RequestgroupsService verschoben.
 *
 * Revision 1.115  2010-03-23 16:23:44  strube#his.de
 * Fehler bei freier Suche (Imma-Antrag) behoben
 *
 * Revision 1.114  2010-03-22 14:45:59  steuernagel#his.de
 * Löschen von Fächern mit Härtefallantrag korrigiert
 *
 * Revision 1.113  2010-03-19 15:14:50  steuernagel#his.de
 * Tests für getAllCoursesOfStudiyFromApplication und createExamplanDtoForZulMissingData hinzugefügt.
 *
 * Revision 1.112  2010-03-17 15:57:40  steuernagel#his.de
 * Für ungeprüfte Bewerbungen wird der Status entsprechend gesetzt (VO bzw. VOF), je nachdem ob fehlende Unterlagen vorliegen oder nicht.
 *
 * Revision 1.111  2010-03-12 12:44:29  strube#his.de
 * Immatrikulationsdaten im studentDto und DB-Antrag Studienverlauf vom 16.02.10 umgesetzt
 *
 * Revision 1.110  2010-03-11 12:13:52  t.neumann#his.de
 * Weitere loadpaths, labelKeys und ähnliches angepasst wg. Umstellung des Mappings der Selbstrelationen
 *
 * Revision 1.109  2010-03-11 10:19:00  steuernagel#his.de
 * Loadpath angepasst: examplan.self -> defaultExamrelation
 *
 * Revision 1.108  2010-03-08 15:39:57  poeschel#his.de
 * Refactoring in examplan+unit wegen geänderter Tabellenstruktur bzgl. Standardwerte-Selbstrelation
 *
 * Revision 1.107  2010-02-26 12:30:11  strube#his.de
 * Redundanz im Loadpath entfernt
 *
 * Revision 1.106  2010-02-24 11:03:39  schirmeister#his.de
 * bugfixes für Sachbearbeiterfunkiton cm.app (für HMD-Pilotierung)
 *
 * Revision 1.105  2010-02-23 07:53:32  strube#his.de
 * Aenderungen zu fehlende Unterlagen (IM-SB)
 *
 * Revision 1.104  2010-02-19 15:35:38  schirmeister#his.de
 * Fachbereich zur Sachbearbeiterfunktion cm.app hinzugefügt. Konfiguration für HMD angepasst.
 *
 * Revision 1.103  2010-02-19 13:49:24  strube#his.de
 * Fehlende Unterlagen in IM-SB anzeigen
 *
 * Revision 1.102  2010-02-12 09:57:18  oberle#his.de
 * Umbenennung StateOfDocuments -> ApplicationStatus
 *
 * Revision 1.101  2010-02-11 16:12:26  bolte#his.de
 * ExamplanDao, ExamrelationDao, ExampathDao und ExamplanExceptionDao nach cm.exa.enrollment verschoben
 *
 * Revision 1.100  2010-02-10 08:43:34  steuernagel#his.de
 * Statusänderung der Bewerbung korrigiert
 *
 * Revision 1.99  2010-02-01 14:33:28  poeschel#his.de
 * Refactoring sul/... nach cm.exa./... für Leistungen und Regeln
 *
 * Revision 1.98  2010-01-25 12:29:56  steuernagel#his.de
 * NullPointerException beim Speichern einer (nicht vorhandenen) Auswahlnote verhindert.
 *
 * Revision 1.97  2010-01-25 12:09:20  steuernagel#his.de
 * Erfassen von fachbezogenen Boni in 'Bewerbung Bearbeiten'
 *
 * Revision 1.96  2010-01-25 10:40:02  oberle#his.de
 * Manuelle Zulassung als vereinfachten Prozess ermöglicht (spezielles Zulassungspaket gefordert). Eigener Bescheid für manuelle Zulassung/Ablehnung fehlt noch.
 *
 * Revision 1.95  2010-01-21 10:11:27  steuernagel#his.de
 * Loadpath verringert
 *
 * Revision 1.94  2010-01-19 16:35:53  strube#his.de
 * Frueheres Studium umstrukturiert (fixes #21839)
 *
 * Revision 1.93  2010-01-14 10:31:30  schirmeister#his.de
 * noch nicht vollständig implementierter Code zur Verbuchung von Boni wird (vorläufig) nicht mehr aufgerufen, da sonst Fehler auftreten.
 *
 * Revision 1.92  2010-01-12 15:14:37  steuernagel#his.de
 * Speichern fachweiser Boni für die HZB teilweise implementiert.
 *
 * Revision 1.91  2010-01-11 10:32:34  steuernagel#his.de
 * Daten für fachweisen Bonus aus dem Loadpath entfernt.
 *
 * Revision 1.90  2010-01-05 09:55:36  steuernagel#his.de
 * Eingabe fachbezogener Boni teilweise implementiert.
 *
 * Revision 1.89  2009-12-21 12:16:41  steuernagel#his.de
 * Unvollständige Implementierung auskommentiert
 *
 * Revision 1.88  2009-12-21 10:48:23  steuernagel#his.de
 * Ungültige Loadpaths entfernt.
 *
 * Revision 1.87  2009-12-17 15:25:48  steuernagel#his.de
 * Bugfix aus Branch übernommen
 *
 * Revision 1.86  2009-12-17 08:43:55  steuernagel#his.de
 * Methoden für Auswahlordnung auskommentiert
 *
 * Revision 1.85  2009-12-16 15:33:23  steuernagel#his.de
 * Anpassungen aus Branch 2009_11_17 übernommen
 *
 * Revision 1.84  2009-12-09 16:05:51  steuernagel#his.de
 * Anpassungen aus dem Branch 2009_11_17 übernommen (Pilotierung UDE)
 *
 * Revision 1.83  2009-12-09 08:39:07  burchard#his.de
 * registerCallback() ins interne EventService Interface verschoben
 *
 * Revision 1.82  2009-12-08 11:20:03  oberle#his.de
 * fixme für HIS-Key ist erfüllt, Hinweis entfernt.
 *
 * Revision 1.81  2009-12-04 16:34:59  burchard#his.de
 * Neuimplementierung einer Änderungsverfolgung für die Online-Bewerbung.
 *
 * Revision 1.80  2009-12-03 15:58:59  schirmeister#his.de
 * Keine Änderung von applicationStatus auf GE falls Status VO.
 *
 * Revision 1.79  2009-12-01 15:08:12  schirmeister#his.de
 * Angefangen: ApplicationStatus wird auf GE gesetzt, falls Fächer oder Zusatzangaben durch Bewerber nachbearbeitet werden.
 *
 * Revision 1.78  2009-11-30 10:20:55  schirmeister#his.de
 * ApplicationStatus einer Bewerbung wird auf GE geändert falls HZB-Daten durch den Bewerber nachbearbeitet werden.
 *
 * Revision 1.77  2009-11-10 14:15:12  jauer#his.de
 * NPE abgefangen
 *
 * Revision 1.76  2009-11-03 12:13:21  schirmeister#his.de
 * Fehler beim Ändern von Fächern in Bewerbung bearbeiten behoben.
 *
 * Revision 1.75  2009-11-02 12:53:41  steuernagel#his.de
 * Fix für ConcurrentModificationException.
 *
 * Revision 1.74  2009-10-23 16:11:57  oberle#his.de
 * Bugfix zu fehlender Funktionalität für Pilotierung HfM (Fehlende Unterlagen in Einstiegsseite). Nur Soll-Leistungen anzeigen!
 *
 * Revision 1.73  2009-10-23 14:45:16  steuernagel#his.de
 * Laden und Speichern der Messzahl Zweitstudienbewerber von VerwaltungsdatenBewService in RequestgroupsService verschoben.
 *
 * Revision 1.72  2009-10-23 14:14:01  oberle#his.de
 * Fehlende Funktionalität für Pilotierung HfM nachgereicht: Fehlende Unterlagen in Einstiegsseite angezeigt (Absprache mit Entwicklungsleitung erfolgt).
 *
 * Revision 1.71  2009-10-19 08:36:04  schirmeister#his.de
 * Bugfixes aus Version 1 übernommen
 *
 * Revision 1.70  2009-10-14 06:46:26  oberle#his.de
 * HIS-Key mit Aufzählungstyp statt mit Long verwendet.
 *
 * Revision 1.69  2009-10-13 20:19:01  lustig#his.de
 * Aufrufe von getApplication() reduziert. Prefetching der Application-Daten ermöglicht
 *
 * Revision 1.68  2009-10-05 07:43:10  oberle#his.de
 * Fachkennzeichen in Bewerbungsübersicht ausgegeben. (Fix #20483)
 *
 * Revision 1.67  2009-09-25 12:17:03  strube#his.de
 * * entfernt und Folgen beseitigt
 *
 * Revision 1.66  2009-09-25 07:55:32  steuernagel#his.de
 * "*" aus loadPath entfernt
 *
 * Revision 1.65  2009-09-14 08:09:23  strube#his.de
 * Fehlende Unterlagen implementiert
 *
 * Revision 1.64  2009-09-10 08:39:16  strube#his.de
 * Online-Immatrikulation: Studienbeginn implementiert
 *
 * Revision 1.63  2009-09-09 12:27:55  d.scholz#his.de
 * Änderung an den DTO-Factories: Das autom. Beachten von bidirektionalen Beziehungen kann nun optional deaktiviert werden, in diesem Fall werden Beziehungen zwischen den Objekten immer nur in eine Richtung initialisiert / gesetzt. So erhält man einen gerichteten Baum ohne rückwärts gerichtete Kanten. Außerdem wird jetzt ein Error-Log Eintrag erstellt, wenn setId() manuell aufgerufen wird.
 *
 * Revision 1.62  2009-09-09 09:15:15  oberle#his.de
 * Neuer Wert für Reaktionsstatus: "Immatrikulation", Aufzählungswerte in Großschreibung.
 *
 * Revision 1.61  2009-08-31 12:52:25  steuernagel#his.de
 * Online-Bewerbung: neue Status für Vollständigkeit eingeführt. Übersichtsseite wird nur angezeigt, wenn Bewerbung vollständig erfasst wurde, sonst Weiterleitung zum Wizard.
 *
 * Revision 1.60  2009-08-28 09:09:44  schirmeister#his.de
 * bugfix: admissionStatus und reactionStatus in den loadpath aufgenommen.
 *
 * Revision 1.59  2009-08-14 13:17:08  schirmeister#his.de
 * findByApplicationNumberAndTerm in findByApplicantIdAndTerm umbenannt.
 *
 * Revision 1.58  2009-08-06 14:22:06  strube#his.de
 * CourseOfStudyStartXtdDto benutzt
 *
 * Revision 1.57  2009-07-31 09:54:23  steuernagel#his.de
 * Link zur Online-Bewerbung wird ausgeblended, wenn die Bearbeitung durch den Sachbearbeiter abgeschossen ist.
 *
 * Revision 1.56  2009-07-31 09:33:40  steuernagel#his.de
 * Prüfung des Bearbeitungsstatus einer Bewerbung in den RequestgroupsService verschoben.
 *
 * Revision 1.55  2009-07-29 15:31:16  schirmeister#his.de
 * Manuelle Zulassung überarbeitet. Zulassung jetzt in alle Quoten des aktuellen ProcessStep möglich.
 *
 * Revision 1.54  2009-07-28 11:13:23  steuernagel#his.de
 * Kardinalität zwischen AdmissionToStudy und AdmissionShare geändert. (fixes #17436)
 *
 * Revision 1.53  2009-07-28 07:43:09  steuernagel#his.de
 * Kleinere Korrekturen. Kommentare ergänzt, Kompilerwarnungen behoben.
 *
 * Revision 1.52  2009-07-27 11:26:28  schirmeister#his.de
 * Manuelle Zulassung erweitert, Meßzahl Zweitstudienbewerber angefangen.
 *
 * Revision 1.51  2009-07-20 09:21:55  schirmeister#his.de
 * manuelle Zulassung 1. Ausbaustufe
 *
 * Revision 1.50  2009-07-06 11:16:10  strube#his.de
 * Fehler im StudentAlsBewerber Flow behoben
 *
 * Revision 1.49  2009-06-18 11:35:38  steuernagel#his.de
 * Imports, Kommentare, usw. aufgeräumt.
 *
 * Revision 1.48  2009-06-17 13:59:58  strube#his.de
 * Online-Bewerbung-Uebersichtsseite fuer die Online-IM erweitert
 *
 * Revision 1.47  2009-06-17 13:13:41  schirmeister#his.de
 * Übersicht-Seite cm.app.bb überarbeitet. Metadaten angepasst.
 *
 * Revision 1.46  2009-06-15 14:19:29  steuernagel#his.de
 * Methode getApplicationId in den RequestgroupService verschoben und BewerbungsService entfernt.
 *
 * Revision 1.45  2009-06-10 10:11:23  schirmeister#his.de
 * AdditionalAdmissionDataPage überarbeitet und  Validierungen hinzugefügt
 *
 * Revision 1.44  2009-05-28 11:22:06  steuernagel#his.de
 * Wenn eine Bewerbung den Status 'Bearbeitung abgeschlossen' hat, werden alle bis auf die letzte Wizardseite und der Link zum Drucken des Antrags deaktiviert.
 *
 * Revision 1.43  2009-05-27 13:14:11  strube#his.de
 * NPE abgefangen
 *
 * Revision 1.42  2009-05-22 07:53:43  schirmeister#his.de
 * bugfix für das Speichern von Amendments / Anlegen von Anträgen
 *
 * Revision 1.41  2009-05-18 12:01:07  schirmeister#his.de
 * Factory-Aufrufe in den Service verschoben
 *
 * Revision 1.40  2009-05-18 08:34:31  strube#his.de
 * termType in termTypeValue (Variable, Getter und Setter) umbenannt
 *
 * Revision 1.39  2009-05-15 13:32:22  schirmeister#his.de
 * AdmissionToStudyTest angepasst
 *
 * Revision 1.38  2009-05-05 11:58:19  schirmeister#his.de
 * Bugfix für Antrag auf bevorzugte Zulassung
 * (fixes #15533)
 *
 * Revision 1.37  2009-04-30 12:44:56  schirmeister#his.de
 * Validierung von Fächern verfeinert
 *
 * Revision 1.36  2009-04-29 12:17:19  schirmeister#his.de
 * Kommentare geändert
 *
 * Revision 1.35  2009-04-28 14:40:30  schirmeister#his.de
 * Antrag auf bevorzugte Zulassung wird wieder gespeichert
 *
 * Revision 1.34  2009-04-28 11:32:49  schirmeister#his.de
 * RequestSubjectXtdDto auch für getRequests
 *
 * Revision 1.33  2009-04-27 12:36:22  schirmeister#his.de
 * Teile der ZUL-Antragsdatenbearbeitung auf DTO-Factories umgestellt. (fixes #14725)
 *
 * (Metadaten und Sortierung der Anträge/Fächer sind noch nicht wieder angepasst)
 *
 * Revision 1.31  2009-03-25 08:48:30  schirmeister#his.de
 * log korrigiert
 *
 * Revision 1.30  2009-03-10 15:59:44  schirmeister#his.de
 * Umstellung des Vergabeverfahren auf DTOFactories angefangen
 *
 * Revision 1.29  2009-02-25 13:48:49  schirmeister
 * Servicenamen geändert
 *
 * Revision 1.28  2009-02-25 09:43:48  schirmeister
 * Service-Metadaten hinzugefügt
 *
 * Revision 1.27  2009-02-20 13:02:43  eden#his.de
 * Speichern der VerwaltungsdatenFach geändert (Korrektur beim Speichern von fehlenden Unterlagen für einen neues Requestsubject)
 *
 * Revision 1.26  2009-02-17 15:24:53  eden#his.de
 * Defaultbelegung für "Zulassung" und "Annahme"
 *
 * Revision 1.25  2009-02-13 14:27:01  eden#his.de
 * admissionstatus und reactionstatus in "Bewerbung bearbeiten" eingebaut
 *
 * Revision 1.24  2009-02-13 09:10:10  schirmeister
 * Property termManager für Spring-Beans die diesen benötigen
 *
 * Revision 1.23  2009-02-11 15:52:41  schirmeister
 * Refactoring von Term angefangen.
 *
 * Revision 1.22  2009-02-03 11:05:06  schirmeister
 * Änderungen im Datenbankschema für den Bereich Bewerbung und Zulassung eingepflegt.
 *
 * Revision 1.21  2008-12-18 10:06:39  eden
 * Methode "getRequests" aus "getRequestgroups" extrahiert
 *
 * Revision 1.20  2008-12-15 14:01:22  kromm
 * Studienwunschseite
 *
 * Revision 1.19  2008-11-25 16:25:45  eden
 * hiskey des Amendmentstatus statt der Id verwendet
 *
 * Revision 1.18  2008-11-14 13:08:14  eden
 * Antrag auf bevorzugte Zulassung wird in der Onlinebewerbung erfasst
 *
 * Revision 1.17  2008-10-31 12:43:24  neumann
 * - stgTreeEditor auf aktuelles DB-Schema umgestellt und in studyHierarchyEditor umbenannt
 * - StgObjekt und verwandte, nicht mehr benötigte Klassen entfernt
 *
 * Revision 1.16  2008-10-30 10:07:53  eden
 * Zuordnung eines Faches zur HZB erfolgt über den künstlichen Schlüssel "Reqeustnumber,Subjectnumber", der Zuordnungsbaum in HZB-Reiter reagiert auf Aktionen (Verschieben, Löschen) im Antragsbaum der Übersichtsseite
 *
 * Revision 1.15  2008-10-14 10:17:27  strube
 * Leere Liste statt null zurueck geben
 *
 * Revision 1.14  2008-10-14 08:05:15  eden
 * NPE bei nicht vorhandener Bewerbung zur übergebenen Id korrigiert
 *
 * Revision 1.13  2008-10-07 12:03:21  eden
 * Fehler beim Speichern eines Zusatzantrage bei neu angelegtem Antragsfach korrigiert
 *
 * Revision 1.12  2008-10-06 15:04:31  eden
 * Das zulassungsfähige Angebot wird im Dto aktualisiert, wenn Fach, Abschluss.... geändert wurden
 *
 * Revision 1.11  2008-10-02 14:42:48  eden
 * ZulkonsequenzDao  und ZulconsequenceValue in ZulConsequenceData.. umbenannt
 *
 * Revision 1.10  2008-10-02 13:30:45  eden
 * ZulunterlageDao  und ZulmissingdataValue in ZulMissingData.. umbenannt
 *
 * Revision 1.9  2008-10-01 09:19:07  brummermann#his.de
 * Massenaenderung: Imports organisiert
 *
 * Revision 1.8  2008-09-29 13:45:19  eden
 * Amendmenttype wird bei der Neuananlage eines Antrages auf Bevorzugung gesetzt.
 *
 * Revision 1.7  2008-09-23 12:06:07  schirmeister
 * Compilerwarnungen entfernt.
 *
 * Revision 1.6  2008-09-15 13:38:35  schirmeister
 * Umbenennung AbschlussDao nach DegreeDao, Fehler beim Speichern behoben.
 *
 * Revision 1.5  2008-09-10 13:09:16  schirmeister
 * einige ZUL-Klassen umbenannt
 *
 * Revision 1.4  2008-09-09 12:36:12  schirmeister
 * AntragsstatusDao in RequestStatusDao umbenannt
 *
 * Revision 1.3  2008-09-03 11:55:49  schirmeister
 * Test auf Zulassungsfähigkeit ausgelagert
 *
 * Revision 1.2  2008-09-03 09:16:58  schirmeister
 * bugfix: RequestgroupService in RequestgroupsService umbennt. Einige i18n keys umbenannt.
 *
 * Revision 1.1  2008-09-01 12:16:09  schirmeister
 * AntragskerndatenService in RequestgroupsService umbenannt, einige lokale Variablen umbenannt.
 *
 * Revision 1.19  2008-08-29 16:38:55  schirmeister
 * Antragsfach in Requestsubject umbenannt. Fehler beim Speichern von Antragsdaten korrigiert.
 *
 * Revision 1.18  2008-08-26 15:09:24  kromm
 * ZulassungsangebotDao zu AdmissionToStudyDao umbenannt
 *
 * Revision 1.17  2008-08-26 08:22:35  schirmeister
 * Antragsfachgruppe in Requestsubjectgroup umbenannt
 *
 * Revision 1.16  2008-08-25 13:32:16  schirmeister
 * Migration Antrag zu Request
 *
 * Revision 1.15  2008-08-25 12:17:40  schirmeister
 * Migration Antrag zu Request (1. Teil)
 *
 * Revision 1.14  2008-08-25 08:26:56  eden
 * JUnitTest für Unit-Mapping angelegt; Fehler beim Löschen eines Antrags mit Härtefallantrag korrigiert
 *
 * Revision 1.13  2008-08-22 08:50:32  eden
 * Zusatzantraege und Unit auf neue DB-Schema umgestellt
 *
 * Revision 1.12  2008-08-20 12:49:43  schirmeister
 * Antragsgruppe in Requestgroup umbenannt (2. Teil)
 *
 * Revision 1.11  2008-08-20 10:15:00  schirmeister
 * Antragsgruppe in Requestgroup umbenannt (1. Teil)
 *
 * Revision 1.10  2008-08-20 08:40:12  schirmeister
 * 2. Teil der Umbenennung von Bewerbung zu Application
 *
 * Revision 1.9  2008-08-15 13:55:37  schirmeister
 * 1. Teil der Umbenennung von Bewerbung zu Application
 *
 * Revision 1.8  2008-08-15 08:35:41  eden
 * Refaktoring Antragszusatz in Amendment
 *
 * Revision 1.7  2008-08-13 08:36:00  kromm
 * Zwischenstand Refactoring im Bereich ZUL
 *
 * Revision 1.6  2008-08-06 13:19:31  scheid
 * Refaktoring: Anpassung der Klassen auf neues DB-Modell.
 *
 * Revision 1.5  2008-08-06 09:10:18  schirmeister
 * Refaktoring Bewerber zu Applicant angefangen (noch nicht lauffähig)
 *
 * Revision 1.4  2008-08-01 08:36:45  eden
 * NPE korrigiert
 *
 * Revision 1.3  2008-07-17 08:31:31  schirmeister
 * Änderung am ZUL-Objektmodel (Fachmerkmalskombination, Zulassungsangebot, Studienangebot). Metadaten angepasst.
 *
 * Revision 1.2  2008-07-09 10:43:40  eden
 * Löschen der Anträge auf bevorzugte Zulassung korrigiert
 *
 * Revision 1.1  2008-07-08 09:29:31  eden
 * AntragsKerndatenService von sul.zul  in sul.zul.bewerbung.antragskerndaten verschoben
 *
 * Revision 1.101  2008-07-08 09:16:47  eden
 * Fehler beim Speichern der Anträge auf Bevorzugung (mit Not Null Constraints) behoben
 *
 * Revision 1.100  2008-07-07 16:22:04  schirmeister
 * fehler durch not-null-constraints behoben
 *
 * Revision 1.99  2008-06-30 09:39:38  schirmeister
 * Unittest vorbereite
 *
 * Revision 1.98  2008-06-30 08:44:59  scholz
 * ServiceException auf Errortype VALIDATION gesetzt
 *
 * Revision 1.97  2008-06-26 09:36:39  schirmeister
 * Antragsgruppen und Antragsfachgruppen hinzugefügt.
 * Antragsfach enthält referenz auf auf ein Studienangebot.
 *
 * Revision 1.96  2008-06-12 09:24:41  eden
 * NPE behoben
 *
 * Revision 1.95  2008-06-11 15:15:29  scholz
 * Exception sollte vom Typ Validation sein
 *
 * Revision 1.94  2008-06-11 14:55:44  eden
 * Löschen der abhängigen Daten beim Ändern des Stgobjekts zum Antragsfach korrigiert
 *
 * Revision 1.93  2008-06-10 13:06:36  eden
 * Aktualisieren der Anträge auf bevorzugte  Zulassung
 *
 * Revision 1.92  2008-06-10 09:32:30  eden
 * isMarkedToDelete zum Löschen von Dtos eingebaut
 *
 * Revision 1.91  2008-06-10 08:47:54  eden
 * Fachkennzeichen in FachkennzeichenId umbenannt, Änderungsmodus entfernt, durch ValueChangeEvents ersetzt
 *
 * Revision 1.90  2008-06-05 14:34:15  eden
 * Pflichtfeldfüllung im Service überprüft
 *
 * Revision 1.89  2008-05-30 08:15:06  eden
 * Fehler bei der Neuanlage und beim Löschen von Anträgen und Antragsstudiengängen behoben; Anpassungen an die Maskenentwürfe
 *
 * Revision 1.88  2008-05-29 09:20:11  scholz
 * Fehlerbehebung beim Löschen von Fächern
 *
 * Revision 1.87  2008-05-28 15:54:52  eden
 * Gruppen werden im Antragsbaum nicht mehr mit angezeigt, Button zur Neuanlage eines Antrags über den Baum verschoben. Vorbelegung des Fachkennzeichens bei der Neuanlage.
 *
 * Revision 1.86  2008-05-28 14:16:54  eden
 * NPE behoben (fixes #10284)
 *
 * Revision 1.85  2008-05-26 15:08:30  eden
 * Löschen von Anträgen über den Antragsbaum repariert inkl. Löschen der Anträge auf bevorzugte Zulassung, Fachnummer  wird gespeichert, Methoden umbenannt
 *
 * Revision 1.84  2008-05-21 08:00:14  eden
 * NPE bei fehlender Bewerbung abgefangen
 *
 * Revision 1.83  2008-05-20 14:36:33  eden
 * Neuanlage eines Antrages mit Antragsstudiengang
 *
 * Revision 1.82  2008-05-15 13:22:12  eden
 * Refaktoring Antragsdaten: VerwaltungsdatenFachController und VerwaltungdatenFachService gelöscht,Fkt. wird von AntragskerndatenController und AntragskerndatenService übernommen
 *
 * Revision 1.81  2008-05-14 16:30:22  eden
 * Refaktoring Antragsdaten
 *
 * Revision 1.80  2008-05-09 11:39:31  eden
 * Refaktorierung der Bewerbungsbearbeitung, AntragskerndatenDto gelöscht, abstgv in antragsstudiengang umbenannt
 *
 * Revision 1.79  2008-05-09 08:25:26  schirmeister
 * Refaktorisierung der Funktion Bewerbung bearbeiten,
 * Es wird bewerbungId und bewerberId genutzt
 *
 * Revision 1.78  2008-05-05 13:36:55  schirmeister
 * Kommentare geändert
 *
 * Revision 1.77  2008-04-29 14:34:57  eden
 * Änderung des Stgobjekts wird im Dto gespeichert
 *
 * Revision 1.76  2008-04-29 13:37:58  schirmeister
 * Bewerbungsfach entfernen vorbereitet
 *
 * Revision 1.75  2008-04-29 11:01:17  schirmeister
 * Angefangen das Bewerbungsfach zu entfernen
 *
 * Revision 1.74  2008-04-28 08:10:43  steuernagel
 * Bewerbungsfach entfernt.
 *
 * Revision 1.73  2008-04-25 15:59:17  schirmeister
 * Performance vom Leistungsservice verbessert
 *
 * Revision 1.72  2008-04-21 08:06:06  brandt
 * Validierung: DtoBaseImpl um Spring Error-Interface erweitert. ServiceException angepasst, FacesMessages für Validierung eingefügt.
 *
 * Revision 1.71  2008-04-15 08:58:41  schirmeister
 * Sicherung: Eignung bearbeiten
 *
 * Revision 1.70  2008-04-14 12:31:55  schirmeister
 * abstgvDto.fachnummer jetzt Integer
 *
 * Revision 1.69  2008-04-14 08:30:09  burchard
 * HzbService: Signatur geändert - statt int Integer
 * Antragskerndatenservice: intensiv umstrukturiert - BITTE TESTEN!!!
 *
 * Revision 1.68  2008-04-09 12:32:19  burchard
 * neue find methoden bewerber/zeitabschnitt nutzen, setter ans ende
 *
 * Revision 1.67  2008-03-28 12:41:15  schirmeister
 * Anträge werden jetzt in einer List statt in einer Map geführt um
 * die neuanlage von Anträgen zu vereinfachen.
 *
 * Revision 1.66  2008-03-27 15:04:25  schirmeister
 * Sicherung: Eignung bearbeiten
 *
 * Revision 1.65  2008/03/18 11:00:47  schirmeister
 * löschen von Anträgen erweitert
 *
 * Revision 1.64  2008/03/18 08:46:28  schirmeister
 * löschen von Anträgen
 *
 * Revision 1.63  2008/03/14 14:29:51  schirmeister
 * Löschen von Anträgen per Antragsbaum angefangen
 *
 * Revision 1.62  2008/03/12 14:58:58  eden
 * Bewerbungsfachbezogene Daten sind nur noch editierbar, wenn die Antragsdaten nicht editierbar sind. Wenn das Bewerbungsfach gelöscht wird, werden ebenfalls die Leistungen, die die zugehörigen fehlenden Nachweise speichern, gelöscht.
 *
 * Revision 1.61  2008/03/10 17:13:11  schirmeister
 * Bewerbungsfächer aktualisieren (1. Ausbaustufe)
 *
 * Revision 1.60  2008/03/10 09:41:53  schirmeister
 * save-Methode refaktorisiert
 *
 * Revision 1.59  2008/03/06 15:23:19  eden
 * Zugriff auf die fachbezogenen Verwaltungsdaten von AntragsID und AntragsstudiengangId auf BewerbungsfachId umgestellt; Aktualisieren der Konsequenz erfolgt nur noch für die geänderten Daten
 *
 * Revision 1.58  2008/03/06 13:36:44  schirmeister
 * ZulassungsfaehigesAngebot in Bewerbungsfach umbenannt
 *
 * Revision 1.57  2008/03/05 12:26:26  schirmeister
 * debugausgaben deaktiviert
 *
 * Revision 1.56  2008/03/04 10:52:09  schirmeister
 * kleinere Anpassungen bei der Antragsbearbeitung,
 * initialcommit Eignungsfeststellung
 *
 * Revision 1.55  2008/02/27 12:56:14  schirmeister
 * bugfix: Fach wurde nache Antragsstudiengangwechsel nicht korrekt angezeigt. Refaktoring: AntragsstudiengangId wird für MD-Kombobox genutzt
 *
 * Revision 1.54  2008/02/26 15:17:37  schirmeister
 * Es werden nur nach die Zeitabschnitte zur Umschaltung angezeigt in denen für den jeweiligen Bewerber eine Bewerbung vorliegt
 *
 * Revision 1.53  2008/02/21 12:01:59  steuernagel
 * boolean statt Boolean
 *
 * Revision 1.52  2008/02/21 12:00:07  steuernagel
 * Unboxing
 *
 * Revision 1.51  2008/02/21 10:51:35  schirmeister
 * Objektmodell geändert
 *
 * Revision 1.50  2008/02/21 08:54:56  scholz
 * setDtoMeta() entfernt
 *
 * Revision 1.49  2008/02/19 12:36:42  jauer
 * Autoboxing
 *
 * Revision 1.48  2008/02/19 12:29:26  schirmeister
 * Plausiprüfung auf zulassungsfähigkeit vorläufig auskommentiert.
 *
 * Revision 1.47  2008/02/19 10:37:09  schirmeister
 * code format
 *
 * Revision 1.46  2008/02/19 10:33:38  schirmeister
 * sicherung: Prüfung auf zulassungsfähiges Angebot
 *
 * Revision 1.45  2008/02/08 13:28:41  schirmeister
 * Semesterumschaltung angefangen, Mapping aktualisiert
 *
 * Revision 1.44  2008/01/30 13:05:14  schirmeister
 * Quote wird ausgelesen. refaktorisiert
 *
 * Revision 1.43  2008/01/23 16:41:29  burchard
 * HisInOne: Nachteilsausgleich aktueller Stand und Korrekturen Daos
 *
 * Revision 1.42  2008/01/23 08:44:34  eden
 * Schlüssel für den Zugriff aus die Anträge auf bevorzugte Zulassung von Fachnummer auf AntragsstudiengangId umgestellt
 *
 * Revision 1.41  2008/01/21 17:44:36  schirmeister
 * Maske Kerndaten eines Antrages bearbeiten erweitert.
 *
 * Revision 1.40  2008/01/18 09:48:33  schirmeister
 * NPE abgefangen
 *
 * Revision 1.39  2008/01/18 09:32:10  schirmeister
 * erweiterung zur Kapazität
 *
 * Revision 1.38  2008/01/15 09:57:06  schirmeister
 * Änderungen vom hisinone-default-schema in stable übernommen und Beispieldaten für Antragskerndaten hinzugefügt. Angefangen Objektmodell anzupassen.
 *
 * Revision 1.37  2008/01/11 13:25:15  liro
 * Prüfung von Priorität und Antragsgruppe auf null eingefügt.
 *
 * Revision 1.36  2008/01/08 15:22:44  schirmeister
 * Auf dem Reiter Anträge werden die Fächer nun nach Abschlüssen eingeschränkt. Nicht mehr umgekehrt.
 *
 * Revision 1.35  2007/12/18 13:20:55  steuernagel
 * Anpassung des stable DB-Schemas
 *
 * Revision 1.34  2007/12/14 12:23:53  schirmeister
 * Ein Bewerber hält nun seine Bewerbungen mit entsprechenden Anträgen
 *
 * Revision 1.33  2007/12/12 16:16:23  schirmeister
 * kleinere Fehlerkorrekturen
 *
 * Revision 1.32  2007/12/11 16:55:43  schirmeister
 * kleinere Optimierungen und Fehlerkorrekturen,
 * Hinweistext falls kein gültiges Studienangebot gewählt wurde
 *
 * Revision 1.31  2007/12/10 17:13:51  schirmeister
 * es wird jetzt die Antrags-Id als Schlüssel genutzt
 *
 * Revision 1.30  2007/12/10 10:52:46  schirmeister
 * sicherung Zwischenstand
 *
 * Revision 1.29  2007/12/07 13:05:27  schirmeister
 * validierung für Antragskerndaten angefangen
 *
 * Revision 1.28  2007/12/05 13:49:44  schirmeister
 * 2. Bewerber hinzugfügt, feste bewerbernummer entfernt. Attribut NC readonly
 *
 * Revision 1.27  2007/12/04 09:18:39  schirmeister
 * Attribut NC hinzugefügt, bugfix für Fächerauswahl
 *
 * Revision 1.26  2007/11/30 14:23:26  schirmeister
 * Studiumsform hinzugefügt
 *
 * Revision 1.25  2007/11/29 10:44:48  scholz
 * getKey() entfernt. Ist generisch in ServiceBaseImpl programmiert
 *
 * Revision 1.24  2007/11/23 09:05:36  schirmeister
 * Sicherung Zwischenstand
 *
 * Revision 1.23  2007/11/19 15:02:05  schirmeister
 * Auswertung mehrerer Anträge
 *
 * Revision 1.22  2007/11/14 13:50:37  schirmeister
 * bugfix: studienort wurde nicht gespeichert
 *
 * Revision 1.21  2007/11/12 16:59:48  schirmeister
 * Objektmodell und stable-schema von hisinone angepasst und unl-Dateien entsprechend korrigiert.
 *
 * Revision 1.20  2007/11/07 09:12:24  schirmeister
 * Studienort und Fachkennzeichen werden gespeichert. Ausgabe des Antragsstatus vorbereitet.
 *
 * Revision 1.19  2007/11/06 14:07:28  schirmeister
 * Objektmodell-Anpassung für Antragsdaten. Daten entsprechend angepasst.
 *
 * Revision 1.18  2007/11/05 17:03:33  liro
 * Konsolenausgabe in copyToDto() auskommentiert.
 *
 * Revision 1.17  2007/11/05 10:06:07  schirmeister
 * fehler beim speichern behoben
 *
 * Revision 1.16  2007/11/02 15:31:22  schirmeister
 * Zugriff auf Antragsstudiengang erfolgt jetzt über die fachnummer
 *
 * Revision 1.15  2007/11/02 13:39:08  schirmeister
 * initialcommit Speichern der Antragskerndaten
 *
 * Revision 1.14  2007/10/26 09:45:53  schirmeister
 * weiter Felder und Layoutanpassungen für den Reiter Kerndaten eines Antrages
 *
 * Revision 1.13  2007/10/23 14:52:10  schirmeister
 * einige Fehler abgefangen, die auftreten falls zu einem Bewerber nicht alle Daten vorhanden sind.
 *
 * Revision 1.12  2007/10/18 08:11:02  steuernagel
 * Checkboxen auf Comboboxen umgestellt.
 *
 * Revision 1.11  2007/10/16 15:12:55  steuernagel
 * Antragsstatus hinzugefügt
 *
 * Revision 1.10  2007/10/16 13:51:09  steuernagel
 * Erweiterungen für 'Antragskerndaten bearbeiten'.
 *
 * Revision 1.9  2007/10/08 08:55:34  scholz
 * getKey() implementiert + Setzen der Metadaten geändert
 *
 */
package de.his.appserver.service.impl.sul.zul.bewerbung.antragskerndaten;

import static de.his.appserver.model.sul.zul.bewerbung.ApplicationStatusValue.ApplicationStatusEnum.UNVOLLSTAENDIG_UV;
import static de.his.appserver.model.sul.zul.bewerbung.ApplicationStatusValue.ApplicationStatusEnum.VOLLSTAENDIG_BA;
import static de.his.appserver.model.value.AdmissionStatusValue.AdmissionStatusEnum.ADMITTED;
import static de.his.appserver.service.dto.gen.ApplicationDtoImpl.startApplicationPath;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.TreeSet;

import org.apache.log4j.LoggerExt;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.security.access.annotation.Secured;

import de.his.appserver.model.cm.app.admission.QuotaRankingStatusValue.QuotaRankingStatusEnum;
import de.his.appserver.model.cm.exa.examplan.Examplan;
import de.his.appserver.model.common.Term;
import de.his.appserver.model.common.TermManager;
import de.his.appserver.model.psv.Person;
import de.his.appserver.model.sul.common.Unit;
import de.his.appserver.model.sul.zul.bewerbung.AdmissiontypeValue.AdmissiontypeEnum;
import de.his.appserver.model.sul.zul.bewerbung.AmendmentstatusValue.AmendmentstatusEnum;
import de.his.appserver.model.sul.zul.bewerbung.AmendmenttypeValue;
import de.his.appserver.model.sul.zul.bewerbung.AmendmenttypeValue.AmendmenttypeEnum;
import de.his.appserver.model.sul.zul.bewerbung.Applicant;
import de.his.appserver.model.sul.zul.bewerbung.Application;
import de.his.appserver.model.sul.zul.bewerbung.ApplicationStatusValue;
import de.his.appserver.model.sul.zul.bewerbung.ApplicationStatusValue.ApplicationStatusEnum;
import de.his.appserver.model.sul.zul.bewerbung.CourseOfStudy;
import de.his.appserver.model.sul.zul.bewerbung.EntranceExamStatusValue;
import de.his.appserver.model.sul.zul.bewerbung.EntranceExamStatusValue.EntranceExamStatusEnum;
import de.his.appserver.model.sul.zul.bewerbung.Request;
import de.his.appserver.model.sul.zul.bewerbung.RequestSubject;
import de.his.appserver.model.sul.zul.bewerbung.Requestgroup;
import de.his.appserver.model.value.AdmissionStatusValue.AdmissionStatusEnum;
import de.his.appserver.model.value.ReactionStatusValue.ReactionStatusEnum;
import de.his.appserver.model.value.RequestStatusValue.RequestStatusEnum;
import de.his.appserver.model.value.RequestSubjectStatusValue.RequestSubjectStatusEnum;
import de.his.appserver.model.value.UnitrelationtypeValue;
import de.his.appserver.model.value.UnitrelationtypeValue.UnitrelationtypeEnum;
import de.his.appserver.model.value.WorkstatusValue;
import de.his.appserver.model.value.WorkstatusValue.WorkstatusEnum;
import de.his.appserver.model.value.ZulMissingDataValue;
import de.his.appserver.persistence.dao.iface.cm.exa.examplan.ExamplanDao;
import de.his.appserver.persistence.dao.iface.sul.CourseOfStudyDao;
import de.his.appserver.persistence.dao.iface.sul.common.UnitDao;
import de.his.appserver.persistence.dao.iface.sul.zul.bewerbung.AmendmenttypeDao;
import de.his.appserver.persistence.dao.iface.sul.zul.bewerbung.ApplicantDao;
import de.his.appserver.persistence.dao.iface.sul.zul.bewerbung.ApplicationDao;
import de.his.appserver.persistence.dao.iface.sul.zul.bewerbung.RequestDao;
import de.his.appserver.persistence.dao.iface.sul.zul.bewerbung.RequestSubjectDao;
import de.his.appserver.persistence.dao.iface.sul.zul.bewerbung.RequestgroupDao;
import de.his.appserver.persistence.dao.iface.value.ApplicationStatusValueDao;
import de.his.appserver.persistence.dao.iface.value.EntranceExamStatusValueDao;
import de.his.appserver.persistence.dao.iface.value.UnitrelationtypeDao;
import de.his.appserver.persistence.dao.iface.value.WorkstatusDao;
import de.his.appserver.persistence.dao.iface.value.ZulMissingDataDao;
import de.his.appserver.persistence.hibernate.i18n.I18nUtils;
import de.his.appserver.service.ServiceException;
import de.his.appserver.service.ServiceException.ExceptionType;
import de.his.appserver.service.StaticBeanRef;
import de.his.appserver.service.base.ServiceBaseImpl;
import de.his.appserver.service.dto.gen.AmendmentDtoFactory;
import de.his.appserver.service.dto.gen.AmendmenttypeValueDtoFactory;
import de.his.appserver.service.dto.gen.ApplicantDtoFactory;
import de.his.appserver.service.dto.gen.ApplicationDtoFactory;
import de.his.appserver.service.dto.gen.CourseOfStudyDtoFactory;
import de.his.appserver.service.dto.gen.DtoFactoryTemplateBase;
import de.his.appserver.service.dto.gen.DtoFactoryTemplateBase.LoadCtx;
import de.his.appserver.service.dto.gen.DtoFactoryTemplateBase.LoadParams;
import de.his.appserver.service.dto.gen.DtoFactoryTemplateBase.SaveParams;
import de.his.appserver.service.dto.gen.ExamplanDtoFactory;
import de.his.appserver.service.dto.gen.ExamrelationDtoFactory;
import de.his.appserver.service.dto.gen.ExamresultDtoFactory;
import de.his.appserver.service.dto.gen.ReactionStatusValueDtoFactory;
import de.his.appserver.service.dto.gen.RequestDtoFactory;
import de.his.appserver.service.dto.gen.RequestSubjectDtoFactory;
import de.his.appserver.service.dto.gen.RequestgroupDtoFactory;
import de.his.appserver.service.dto.gen.RequestsubjectgroupDtoFactory;
import de.his.appserver.service.dto.gen.RequestsubjectgroupRequestsubjectDtoFactory;
import de.his.appserver.service.dto.gen.TermTypeValueDtoFactory;
import de.his.appserver.service.dto.gen.ZulMissingDataValueDtoFactory;
import de.his.appserver.service.dto.gen.iface.AdmissionPackageDto;
import de.his.appserver.service.dto.gen.iface.AdmissionStatusValueDto;
import de.his.appserver.service.dto.gen.iface.AllocationSchemeDto;
import de.his.appserver.service.dto.gen.iface.AmendmentDto;
import de.his.appserver.service.dto.gen.iface.AmendmentstatusValueDto;
import de.his.appserver.service.dto.gen.iface.AmendmenttypeValueDto;
import de.his.appserver.service.dto.gen.iface.ApplicantDto;
import de.his.appserver.service.dto.gen.iface.ApplicationDto;
import de.his.appserver.service.dto.gen.iface.ApplicationDto.ApplicationPath;
import de.his.appserver.service.dto.gen.iface.CourseOfStudyDto;
import de.his.appserver.service.dto.gen.iface.CourseOfStudyDto.CourseOfStudyPath;
import de.his.appserver.service.dto.gen.iface.DegreeProgramDto;
import de.his.appserver.service.dto.gen.iface.DegreeProgramProgressDto;
import de.his.appserver.service.dto.gen.iface.ExamplanDto;
import de.his.appserver.service.dto.gen.iface.ExamrelationDto;
import de.his.appserver.service.dto.gen.iface.ExamresultDto;
import de.his.appserver.service.dto.gen.iface.PersonDto;
import de.his.appserver.service.dto.gen.iface.ProcessStepDto;
import de.his.appserver.service.dto.gen.iface.QuotaDto;
import de.his.appserver.service.dto.gen.iface.QuotaLevelDto;
import de.his.appserver.service.dto.gen.iface.QuotaRankingElementDto;
import de.his.appserver.service.dto.gen.iface.ReactionStatusValueDto;
import de.his.appserver.service.dto.gen.iface.RequestDto;
import de.his.appserver.service.dto.gen.iface.RequestDto.RequestPath;
import de.his.appserver.service.dto.gen.iface.RequestStatusValueDto;
import de.his.appserver.service.dto.gen.iface.RequestSubjectDto;
import de.his.appserver.service.dto.gen.iface.RequestSubjectDto.RequestSubjectPath;
import de.his.appserver.service.dto.gen.iface.RequestSubjectStatusValueDto;
import de.his.appserver.service.dto.gen.iface.RequestgroupDto;
import de.his.appserver.service.dto.gen.iface.RequestsubjectgroupDto;
import de.his.appserver.service.dto.gen.iface.RequestsubjectgroupRequestsubjectDto;
import de.his.appserver.service.dto.gen.iface.TermTypeValueDto;
import de.his.appserver.service.dto.gen.iface.UnitDto;
import de.his.appserver.service.dto.gen.iface.WorkstatusValueDto;
import de.his.appserver.service.dto.gen.iface.ZulMissingDataValueDto;
import de.his.appserver.service.dto.gen.iface.ZulMissingDataValueDto.ZulMissingDataValuePath;
import de.his.appserver.service.dto.iface.cm.app.RequestSubjectXtdDto;
import de.his.appserver.service.dto.iface.common.TermDto;
import de.his.appserver.service.dto.iface.sos.DegreeProgramProgressXtdDto;
import de.his.appserver.service.dto.iface.sul.zul.ApplicationXtdDto;
import de.his.appserver.service.dto.iface.sul.zul.bewerbung.VerwaltungsdatenBewDto;
import de.his.appserver.service.dto.impl.cm.app.CourseOfStudyBeanImpl;
import de.his.appserver.service.dto.impl.cm.app.RequestSubjectXtdDtoImpl;
import de.his.appserver.service.dto.impl.cm.app.RequestXtdDtoImpl;
import de.his.appserver.service.dto.impl.common.TermDtoImpl;
import de.his.appserver.service.dto.impl.sul.CourseOfStudyXtdDtoImpl;
import de.his.appserver.service.dto.impl.sul.zul.ApplicationXtdDtoImpl;
import de.his.appserver.service.iface.ValueService;
import de.his.appserver.service.iface.cm.app.ApplicationUtil;
import de.his.appserver.service.iface.cm.app.RequestStatusSwitch;
import de.his.appserver.service.iface.cm.app.RequestSubjectStatusSwitch;
import de.his.appserver.service.iface.cm.app.editApplication.SelectionCriteriaService;
import de.his.appserver.service.iface.sos.StudentService;
import de.his.appserver.service.iface.sul.common.TermService;
import de.his.appserver.service.iface.sul.zul.bewerbung.AmendmentService;
import de.his.appserver.service.iface.sul.zul.bewerbung.ApplicationService;
import de.his.appserver.service.iface.sul.zul.bewerbung.VerwaltungsdatenService;
import de.his.appserver.service.iface.sul.zul.bewerbung.antragskerndaten.RequestgroupsService;
import de.his.appserver.service.iface.sul.zul.vergabe.AdmissionService;
import de.his.core.util.DTOFactoryUtil;
import de.his.core.util.EnsureArgument;
import de.his.core.util.EnsureState;
import de.his.core.util.cs.psv.Right;
import de.his.core.util.cs.sys.configuration.Conf;
import de.his.core.util.cs.sys.configuration.Conf.CM;

/**
 * Company: HIS
 * @author Schirmeister, Eden
 * @version $Revision: 1.314.4.6 $
 */
@de.his.appserver.service.base.ServiceMetadata.ServiceImplMetadata(serviceRevision = "$Revision: 1.314.4.6 $")
public class RequestgroupsServiceImpl extends ServiceBaseImpl implements RequestgroupsService {

    private static final List<Long> REQUEST_SUBJECT_STATUS_HIS_KEYS = Arrays.asList(
        RequestSubjectStatusEnum.REQUEST_FOR_ENROLLMENT_IN_PROCESS.getHisKey(),
        RequestSubjectStatusEnum.REQUEST_FOR_ENROLLMENT_SUBMITTED.getHisKey(),
        RequestSubjectStatusEnum.ADMISSION_OFFERED.getHisKey(),
        RequestSubjectStatusEnum.ADMITTED.getHisKey());

    /** Hiskennzeichen für Zulassungsfahigkeit*/
    public static final Integer KAPAZITAETART_ZULASSUNGSFAEHIG = new Integer(2);

    /** logger */
    protected static LoggerExt logger = LoggerExt.getLoggerExt(RequestgroupsServiceImpl.class);

    /** Dao für Zulunterlagen */
    private ZulMissingDataDao zulMissingDataDao;

    /** Dao für Zulassungsangebote*/
    private CourseOfStudyDao courseOfStudyDao;

    private ApplicantDao applicantDao;

    private TermManager termManager;

    private RequestStatusSwitch requestStatusSwitch;

    private RequestSubjectStatusSwitch requestSubjectStatusSwitch;

    /** TermService */
    protected TermService termService;

    /** Dao for Units */
    private UnitDao unitDao;

    private UnitrelationtypeDao unitrelationtypeDao;

    /** Dao for Examplans */
    private ExamplanDao examplanDao;

    /** Dao for applicationStatus */
    private ApplicationStatusValueDao applicationStatusValueDao;

    private AmendmenttypeDao amendmenttypeDao;

    private EntranceExamStatusValueDao entranceExamStatusDao;

    private WorkstatusDao workstatusDao;

    private VerwaltungsdatenService verwaltungsdatenService;

    private AdmissionService admissionService;

    private AmendmentService amendmentService;

    private StudentService studentService;

    private ApplicationService applicationService;

    private RequestDao requestDao;

    private RequestgroupDao requestgroupDao;

    private RequestSubjectDao requestSubjectDao;

    /** Dao für die Bewerbung */
    private ApplicationDao applicationDao;

    private ValueService valueService;

    private SelectionCriteriaService selectionCriteriaService;





    @Override
    @Secured({ Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION, Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION_OWN, Right.Strings.CM_APP_APPLICATION_VIEW_APPLICATION })
    public ApplicationDto getApplication(Long applicationId) {
        logger.enter("getApplication", "applicationId=", applicationId);

        ApplicationPath applicationPath = new ApplicationPath();
        //This loadpath is humongous ... could it be a little smaller?
        String[] loadPath = DTOFactoryUtil.asLoadPath(applicationPath.applicationStatus(),
                        applicationPath.termTypeValue(),
                        applicationPath.examplans().unit(),
                        applicationPath.examplans().defaultExamrelation().examresult(),
                        applicationPath.examplans().defaultExamrelation().workstatus(),
                        applicationPath.applicant().person().examplans().examimport().country(),
                        applicationPath.applicant().person().examplans().examimport().examplan(),
                        applicationPath.applicant().person().examplans().entranceQualification().entranceQualificationType(),
                        applicationPath.requestgroups().requests().reactionstatus(),
                        applicationPath.requestgroups().requests().requestStatus(),
                        applicationPath.requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().courseOfStudy().admissionshares().admissionPackage().admissiontype(),
                        applicationPath.requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().courseOfStudy().subjectIndicator(),
                        applicationPath.requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().courseOfStudy().degree(),
                        applicationPath.requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().courseOfStudy().subject(),
                        applicationPath.requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().courseOfStudy().orgunit(),
                        applicationPath.requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().courseOfStudy().courseOfStudyTypeValue(), // wird für "Bewerbungen übernehmen" bei Studenten gebraucht
                        applicationPath.requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().courseOfStudy().courseOfStudyStart().courseOfStudyTypeValue(), // wird für "Bewerbungen übernehmen" bei Studenten gebraucht
                        applicationPath.requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().courseOfStudy().courseOfStudyStart().periodcontainerStudies().periodcontainer().periods(), // wird für "Bewerbungen übernehmen" bei Studenten gebraucht
                        applicationPath.requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().courseOfStudy().periodcontainerStudies().periodcontainer().periods(),
                        applicationPath.requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().entranceQualificationExamplan(),
                        applicationPath.requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().amendments(),
                        applicationPath.requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().amendments().amendmenttype(),
                        applicationPath.requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().admissionstatus(),
                        applicationPath.requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().reactionstatus(),
                        applicationPath.requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().examplans().defaultExamrelation().workstatus(),
                        applicationPath.requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().examplans().unit().zulmissingdata(),
                        applicationPath.requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().examplans().unit().elementtype(),
                        applicationPath.requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().examplans().accreditation(),
                        applicationPath.requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().admissionQuotaRankingElement().quotaRanking().ranking().processStep().allocationScheme().levels().quotas(),
                        applicationPath.requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().quotaRankingElements().admissionStatus(),
                        applicationPath.requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().quotaRankingElements().reactionStatus(),
                        applicationPath.requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().quotaRankingElements().quotaRanking().quota(),
                        applicationPath.requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().quotaRankingElements().quotaRanking().ranking().processStep().allocationScheme().levels().quotas(),
                        applicationPath.requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().admissionQuotaRankingElement(),
                        applicationPath.requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().requestSubjectStatus());

        ApplicationDto applicationDto = ApplicationDtoFactory.getDto(applicationId, new LoadParams().setReplacedDtoClasses(RequestXtdDtoImpl.class, RequestSubjectXtdDtoImpl.class, CourseOfStudyXtdDtoImpl.class, ApplicationXtdDtoImpl.class), loadPath);
        this.applicationService.updateRequestXtdDtos(applicationDto);
        this.applicationService.updateRequestSubjectXtdDtos(applicationDto);

        findMeasurementSeconddegree((ApplicationXtdDto) applicationDto);

        logger.leave("getApplication", applicationDto);
        return applicationDto;
    }

    @Override
    public ApplicationDto getApplicationForMissingDocuments(Long applicationId) {
        logger.enter("getApplicationForMissingDocuments", "applicationId=", applicationId);

        String[] loadPath = DTOFactoryUtil.asLoadPath(new ApplicationPath().requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().courseOfStudy().courseOfStudyStart());
        ApplicationDto applicationDto = ApplicationDtoFactory.getDto(applicationId, loadPath);

        logger.leave("getApplicationForMissingDocuments", applicationDto);
        return applicationDto;
    }

    /**
     * @param dto
     * @param application
     */
    @Secured({ Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION, Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION_OWN })
    private void saveMeasurementSeconddegree(ApplicationDto dto) {
        logger.enter("saveMeasurementSeconddegree", dto);

        ApplicationXtdDto applicationDto = (ApplicationXtdDto) dto;
        String unitGuid = Conf.getString(CM.APP.APPLICATION_MEASUREMENTSECONDDEGREE_UNITID.getKey());

        if (unitGuid != null) {
            Unit unit = unitDao.findByGuid(unitGuid);
            EnsureArgument.notNull(unit, "The Unit for the measurement of the second degree is not defined correctly. Please check the entry " + CM.APP.APPLICATION_MEASUREMENTSECONDDEGREE_UNITID.getKey() + " in the global configuration");
            List<ExamplanDto> examplans = applicationDto.getExamplans();
            ExamplanDto messzahl = null;

            for (ExamplanDto examplan : examplans) {
                if (examplan.getUnitId().equals(unit.getId())) {
                    messzahl = examplan;
                }
            }
            if (messzahl != null) {
                messzahl.getDefaultExamrelation().getExamresult().setGrade(applicationDto.getMeasurementSeconddegree());
            } else {
                messzahl = ExamplanDtoFactory.getNewDto();
                messzahl.setTermTypeValue(applicationDto.getTermTypeValue());
                messzahl.setYear(applicationDto.getYear());
                PersonDto personDto = null;
                if(applicationDto.isApplicantSet() && applicationDto.getApplicant().isPersonSet()) {
                    personDto = applicationDto.getApplicant().getPerson();
                } else {
                    String[] loadPath = DTOFactoryUtil.asLoadPath(new ApplicantDto.ApplicantPath().person());
                    personDto = ApplicantDtoFactory.getDto(applicationDto.getApplicantId(), loadPath).getPerson();
                }
                messzahl.setPerson(personDto);
                messzahl.setUnitId(unit.getId());
                ExamresultDto examresult = ExamresultDtoFactory.getNewDto();
                examresult.setGrade(applicationDto.getMeasurementSeconddegree());
                ExamrelationDto self = ExamrelationDtoFactory.getNewDto();
                examresult.setExamrelation(self);
                self.setExamresult(examresult);
                UnitrelationtypeValue unitrelationType = unitrelationtypeDao.findByHiskeyId(UnitrelationtypeEnum.Standard.getKey());
                self.setUnitrelationtypeId(unitrelationType.getId());
                messzahl.setDefaultExamrelation(self);
                ExamrelationDtoFactory.saveDto(self);
                ExamplanDtoFactory.saveDto(messzahl);
                applicationDto.addToExamplans(messzahl);
            }
        }

        logger.leave("saveMeasurementSeconddegree");
    }


    @Override
    @Secured({ Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION, Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION_OWN, Right.Strings.CM_APP_APPLICATION_VIEW_APPLICATION })
    public List<Long> findClosedAdmissionToStudyByApplication(Long applicationId) {
        logger.enter("findClosedAdmissionToStudyByApplication", "applicationId=", applicationId);

        if (applicationId == null) {
            logger.leave("findClosedAdmissionToStudyByApplication", null);
            return null;
        }
        List<Long> result = courseOfStudyDao.findClosedAdmissionToStudyByApplication(applicationId);

        logger.leave("findClosedAdmissionToStudyByApplication", result);
        return result;
    }

    /**
     * @param applicationDto
     */
    @Override
    public void findMeasurementSeconddegree(ApplicationXtdDto applicationDto) {
        logger.enter("findMeasurementSeconddegree", applicationDto);

        String unitGuid = Conf.getString(CM.APP.APPLICATION_MEASUREMENTSECONDDEGREE_UNITID.getKey());
        if (unitGuid != null) {
            Unit measurementUnit = unitDao.findByGuid(unitGuid);
            if(measurementUnit != null) {
                if(!applicationDto.isExamplansSet()) {
                    super.loadDtoAttribute(applicationDto, ApplicationDto.examplans, asLoadPath(new ExamplanDto.ExamplanPath().defaultExamrelation().examresult(), new ExamplanDto.ExamplanPath().unit()));
                }

                List<ExamplanDto> examplans = applicationDto.getExamplans();

                for (ExamplanDto examplan : examplans) {
                    Long id = null;

                    if (examplan.getUnit() != null) {
                        id = examplan.getUnit().getId();
                    } else if (examplan.getUnitId() != null) {
                        id = examplan.getUnitId();
                    }
                    if (id != null) {
                        if (measurementUnit.getId().equals(id) && examplan.getDefaultExamrelation().getExamresult() != null) {
                            applicationDto.setMeasurementSeconddegree(examplan.getDefaultExamrelation().getExamresult().getGrade());
                        }
                    } else {
                        logger.error("Unit von Examplan " + examplan.toString() + " ist null.");
                    }
                }
            } else {
                logger.error("The unit for the measurement of seconddegree (" + CM.APP.APPLICATION_MEASUREMENTSECONDDEGREE_UNITID.getKey() + ") could not be found");
            }
        } else {
            logger.error("The key for the entry in global configuration for the measurement of seconddegree (" + CM.APP.APPLICATION_MEASUREMENTSECONDDEGREE_UNITID.getKey() + ") has not been set");
        }

        logger.leave("findMeasurementSeconddegree");
    }

    @Override
    @Secured({ Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION, Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION_OWN, Right.Strings.CM_APP_APPLICATION_VIEW_APPLICATION })
    @Deprecated
    public ApplicationDto findApplicationByIdPrefetched(Long applicationId) {
        logger.enter("findApplicationByIdPrefetched", "applicationId=", applicationId);

        EnsureArgument.notNull(applicationId);
        ApplicationDto dto = getApplication(applicationId);

        logger.leave("findApplicationByIdPrefetched", dto);
        return dto;
    }


    /* (non-Javadoc)
     * @see de.his.appserver.service.iface.sul.zul.bewerbung.antragskerndaten.RequestgroupsService#addMissingDataToRequestSubject(java.lang.Long, java.lang.Long)
     */
    @Override
    public void addMissingDataToRequestSubject(Long requestSubjectId, Long zulMissingDataValueHiskey) {
        EnsureArgument.notNull(requestSubjectId);
        EnsureArgument.notNull(zulMissingDataValueHiskey);
        WorkstatusValue soll = workstatusDao.findByHiskeyId(WorkstatusEnum.Soll.getHisKey());
        if (soll == null) {
            throw new ServiceException("Die Tabelle k_workstatus enthält keinen Datensatz mit hiskey_id 3 ");
        }
        Examplan rsmd = examplanDao.findMissingDataByRequestSubjectAndZulMissingDataValueHiskey(requestSubjectId, zulMissingDataValueHiskey);

        if (rsmd == null) {
            Examplan examplan = new Examplan();
            ZulMissingDataValue zulMissingDataValue = zulMissingDataDao.findByHiskeyId(zulMissingDataValueHiskey);
            if (zulMissingDataValue == null) {
                throw new ServiceException("Kein Datensatz mit hiskey_id " + zulMissingDataValueHiskey + "in der Tabelle k_zulmissingdata gefunden");
            }
            UnitrelationtypeValue standardzuordnung = unitrelationtypeDao.findByHiskeyId(UnitrelationtypeEnum.Standard.getHisKey());
            examplan.getDefaultExamrelation().setUnitrelationtype(standardzuordnung);
            Unit unit = zulMissingDataValue.getFirstUnit();
            if(unit==null) {
                throw new ServiceException("Der Datensatz aus der Tabelle k_zulmissingdata mit hiskey_id " + zulMissingDataValueHiskey + " ist nicht mit einer Unit verknüpft. Datensatz in Tabelle missingdata fehlt oder ist nicht korrekt.");
            }
            examplan.setUnit(unit);
            examplan.getDefaultExamrelation().setWorkstatus(soll);
            // Term der fehlende Unterlage wird auf den Term der Bewerbung gesetzt
            RequestSubject rs = requestSubjectDao.findById(requestSubjectId);
            Application application = rs.getApplication();
            Person person = application.getApplicant().getPerson();
            examplan.setTerm(application.getTerm());
            examplan.setPerson(person);
            examplan.addToRequestSubjects(rs);
        } else {
                rsmd.getDefaultExamrelation().setWorkstatus(soll);
        }
    }

    /* (non-Javadoc)
     * @see de.his.appserver.service.iface.sul.zul.bewerbung.antragskerndaten.RequestgroupsService#removeMissingDataFromRequestSubject(java.lang.Long, java.lang.Long)
     */
    @Override
    public void removeMissingDataFromRequestSubject(Long requestSubjectId, Long zulMissingDataValueHiskey) {
        EnsureArgument.notNull(requestSubjectId);
        EnsureArgument.notNull(zulMissingDataValueHiskey);
        Examplan rsmd = examplanDao.findMissingDataByRequestSubjectAndZulMissingDataValueHiskey(requestSubjectId, zulMissingDataValueHiskey);
        if (rsmd != null) {
            WorkstatusValue vorhanden = workstatusDao.findByHiskeyId(WorkstatusEnum.Vorhanden.getHisKey());
            rsmd.getDefaultExamrelation().setWorkstatus(vorhanden);
        }
    }


    @Override
    @Secured({ Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION, Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION_OWN, Right.Strings.CM_APP_APPLICATION_VIEW_APPLICATION })
    public Long getApplicationId(Long applicantId, TermDto termDto) {
        logger.enter("getApplicationId", "applicantId=", applicantId, termDto);
        Long retVal = null;

        if(termDto != null) {
            Term term = termManager.getTerm(termDto.getYear(), termDto.getTermTypeCategory(), termDto.getTermTypeNumber());
            retVal = applicationDao.findApplicationIdByApplicantIdAndTerm(applicantId, term);
        }

        logger.leave("getApplicationId", retVal);
        return retVal;
    }

    /**
     *
     * - removes Dtos with isMarkedToDelete == true
     * - executes refreshRequestSubject on RequestSubjects not deleted
     * @param applicationDto applicationDto
     * @return requestDto
     */
    private ApplicationDto executeBeforeSave(ApplicationDto applicationDto) {
        logger.enter("executeBeforeSave", "applicationDto=", applicationDto);
        Date today = new Date();
        Iterator<RequestgroupDto> requestgroupIterator = applicationDto.getRequestgroups().iterator();
        while (requestgroupIterator.hasNext()) {
            RequestgroupDto requestgroupDto = requestgroupIterator.next();
            if (requestgroupDto.isMarkedToDelete()) {
                requestgroupIterator.remove();
                //continue;
            }
            Iterator<RequestDto> requestIterator = requestgroupDto.getRequests().iterator();
            while (requestIterator.hasNext()) {
                RequestDto requestDto = requestIterator.next();
                if (requestDto.isMarkedToDelete()) {
                    requestIterator.remove();
                    requestDto.setUpdatedAdmissionRelevantDataAt(today);
                    //continue;
                }
                Iterator<RequestsubjectgroupDto> requestsubjectgroupIterator = requestDto.getRequestsubjectgroups().iterator();
                while (requestsubjectgroupIterator.hasNext()) {
                    RequestsubjectgroupDto requestsubjectgroupDto = requestsubjectgroupIterator.next();
                    if (requestsubjectgroupDto.isMarkedToDelete()) {
                        requestsubjectgroupIterator.remove();
                        requestDto.setUpdatedAdmissionRelevantDataAt(today);
                        //continue;
                    }

                    Iterator<RequestsubjectgroupRequestsubjectDto> rgrsIterator = requestsubjectgroupDto.getRequestsubjectgroupRequestsubjects().iterator();
                    while (rgrsIterator.hasNext()) {
                        RequestsubjectgroupRequestsubjectDto rgrs = rgrsIterator.next();
                        RequestSubjectDto requestSubjectDto = rgrs.getRequestSubject();
                        if (requestSubjectDto.getId() != null && requestSubjectDto.isMarkedToDelete()) {
                            requestDto.setUpdatedAdmissionRelevantDataAt(today);
                            Iterator<ExamplanDto> iterator = requestSubjectDto.getExamplans().iterator();
                            while (iterator.hasNext()) {
                                ExamplanDto examplanDto = iterator.next();
                                iterator.remove();
                                examplanDto.getRequestSubjects().remove(requestSubjectDto);
                            }
                            Iterator<AmendmentDto> iterator2 = requestSubjectDto.getAmendments().iterator();
                            while (iterator2.hasNext()) {
                                AmendmentDto amendmentDto = iterator2.next();
                                iterator2.remove();
                                removeAmendmentsFromRequestSubjects(requestSubjectDto, amendmentDto);
                            }
                            rgrsIterator.remove();
                        }

                        Long termTypeValueId = applicationDto.getTermTypeValueId();
                        Integer year = applicationDto.getYear();
                        TermDto termDto = null;
                        if (year == null || termTypeValueId == null) {
                            throw new ServiceException("cm.app.bb.validation.applicationTermNULL");
                        }
                        TermTypeValueDto termTypeValueDto = TermTypeValueDtoFactory.getDto(termTypeValueId);
                        termDto = new TermDtoImpl(year, termTypeValueDto);

                        if (!requestSubjectDto.isMarkedToDelete()) {
                            refreshRequestsubject(rgrs, requestSubjectDto, termDto);
                            RequestSubjectXtdDto requestSubjectXtdDto = (RequestSubjectXtdDto) requestSubjectDto;
                            // Der Ablehungsgrund wird gelöscht, wenn der ManualAdmissionStatus != abgelehnt
                            if (requestSubjectXtdDto.getManualAdmissionStatus() != null && !admissionService.isAdmissionRefused(requestSubjectXtdDto.getManualAdmissionStatus())) {
                                requestSubjectDto.setReasonForRefusal(null);
                            }
                            // Antrag auf Bevorzugte Zulassung nicht speichern, wenn Status="nicht gestellt", evtl. Ablehnungsgrund löschen
                            AmendmentDto applicationForPreferedAdmission = requestSubjectXtdDto.getApplicationForPreferedAdmission();
                            executeBeforeSaveAmendment(requestSubjectDto, applicationForPreferedAdmission);
                            // Härtefallantag nicht speichern, wenn Status="nicht gestellt", evtl. Ablehnungsgrund löschen
                            AmendmentDto applicationForCaseOfHardship = requestSubjectXtdDto.getApplicationForCaseOfHardship();
                            executeBeforeSaveAmendment(requestSubjectDto, applicationForCaseOfHardship);
                        }
                    }
                }
            }
        }

        logger.leave("executeBeforeSave", applicationDto);
        return applicationDto;
    }

    /**
     * calls admissionService.manualAdmission
     */
    private void processManualAdmissionOnSave(RequestSubjectXtdDto rsXtdDto) {
        // only call manualAdmission if admissionStatus changed
        if (rsXtdDto.getManualAdmissionStatus() != null && !rsXtdDto.getManualAdmissionStatus().equals(rsXtdDto.getAdmissionstatus().getId())) {
            admissionService.manualAdmission(rsXtdDto);
        }
    }

    /**
     * copies missingDataList from his:selectManyPicklist back to DTOs
     * @param requestSubjectDto rs
     */
    private void processZulMissingDataOnSave(RequestSubjectDto requestSubjectDto) {
        //ZulMissingData
        RequestSubjectXtdDto rs = (RequestSubjectXtdDto) requestSubjectDto;

        // Alle Leistungen zum Fach heraussuchen und Kopie anlegen:
        List<ExamplanDto> requestSubjectExamplans = rs.getExamplans();
        List<ExamplanDto> zulExamplans = new ArrayList<ExamplanDto>(requestSubjectExamplans);


        // Falls fehlende Unterlage bereits vorhanden: Aus Kopie entfernen
        for (Long missingDataId : rs.getZulMissingDataIds()) {
            boolean found = false;
            if (requestSubjectExamplans != null) {
                for (ExamplanDto examplan : requestSubjectExamplans) {

                    if(!examplan.isDefaultExamrelationSet()) {
                        String[] loadPath = asLoadPath(new ExamrelationDto.ExamrelationPath().workstatus());
                        super.loadDtoAttribute(examplan, ExamplanDto.defaultExamrelation, loadPath);
                    }

                    ExamrelationDto erDto = examplan.getDefaultExamrelation();
                    WorkstatusValueDto workstatusValueDto = null;

                    if (erDto.isWorkstatusOrIdSet()) {
                        workstatusValueDto = erDto.getWorkstatus();
                    } else {
                        logger.error("The examplan " + examplan + " has neihter a workstatusValueDto nor a workstatusId!");
                        continue;
                    }

                    if (workstatusValueDto != null && workstatusValueDto.getHiskeyId().equals(WorkstatusEnum.Soll.getHisKey())) {
                        if (examplan.getUnit().getZulmissingdata() != null && examplan.getUnit().getZulmissingdata().size() > 0) {
                            if (examplan.getUnit().getZulmissingdata().get(0).getCategory().equals(Integer.valueOf(2))) {
                                if (missingDataId.equals(examplan.getUnit().getZulmissingdata().get(0).getId())) {
                                    found = true; // fehlende Unterlage gefunden!
                                    zulExamplans.remove(examplan);
                                    erDto.setWorkstatus(workstatusValueDto);
                                    break;
                                }
                            }
                        }
                    }

                }
            }

            // Fehlende Unterlage ist neu: Neue Leistung "fehlende Unterlage" anlegen
            if (!found) {
                ExamplanDto examplan = createExamplanDtoForZulMissingData();

                ApplicationDto applicationDto = requestSubjectDto.getRequestsubjectgroupRequestsubjects().iterator().next().getRequestsubjectgroup().getRequest().getRequestgroup().getApplication();
                Long personId = applicationDto.getApplicant().getPersonId();

                examplan.setPersonId(personId);
                // Typ der fehlenden Unterlage ermitteln und passende Unit heraussuchen:
                ZulMissingDataValueDto zmdValueDto = findZulMissingDataValueDtoById(missingDataId);
                List<UnitDto> units = zmdValueDto.getUnits();
                if (units != null && units.size() > 0) {
                    UnitDto firstUnit = units.get(0);
                    examplan.setUnit(firstUnit);
                    firstUnit.getZulmissingdata().add(zmdValueDto);
                }
                examplan.setTermTypeValueId(applicationDto.getTermTypeValueId());
                examplan.setYear(applicationDto.getYear());
//                rs.getExamplans().add(examplan);
                rs.addToExamplans(examplan);
            }

        }

        WorkstatusValueDto workstatusVorhanden = getWorkstatus(WorkstatusEnum.Vorhanden);

        if(workstatusVorhanden == null) {
            logger.error("Sorry but we are unable to find the k_workstatus 'Vorhanden' (HISKeyId: " + WorkstatusEnum.Vorhanden.getHisKey() + ")");
        }
        else {
            //nur Workstatus von fehlenden Unterlagen ändern
            for (ExamplanDto examplan : zulExamplans) {
                if(!examplan.isUnitSet()) {
                    String[] loadPath = asLoadPath(new UnitDto.UnitPath().zulmissingdata());
                    super.loadDtoAttribute(examplan, ExamplanDto.unit, loadPath);
                }
                if (examplan.getUnit() != null && examplan.getUnit().getZulmissingdata() != null && examplan.getUnit().getZulmissingdata().size() > 0) {
                    if (examplan.getDefaultExamrelation() != null){
                        examplan.getDefaultExamrelation().setWorkstatus(workstatusVorhanden);
                        examplan.setDateOfWork(new Date());
                    }
                }
            }
        }

        //consequence
        if (rs.getZulMissingDataIds() != null && rs.getZulMissingDataIds().size() > 0) {
            rs.setZulMissingDataConsequenceId(getZulMissingDataConsequence(rs.getZulMissingDataIds()));
        }
    }

    /**
     * @param allWorkstatus
     * @return
     */
    private WorkstatusValueDto getWorkstatus(WorkstatusEnum workstatusEnum) {
        Map<Long, WorkstatusValueDto> allWorkstatus = this.valueService.getAllWorkstatus(I18nUtils.getLang());

        for (WorkstatusValueDto workstatus : allWorkstatus.values()) {
            if(workstatus.getHiskeyId().equals(workstatusEnum.getHisKey())) {
                return workstatus;
            }
        }
        return null;
    }

    /**
     * AmendmentDto wird auf markedToDelete = true gesetzt, wenn Status="nicht gestellt"; Ablehnungsgrund wird gelöscht, wenn der Status != "abgelehnt"
     *
     * @param requestSubjectDto   Fach, zu dem der Zusatzantrag gespeichert werden soll
     * @param amendmentDto        Fachbezogener Zusatzantrag (Antrag auf bevorzugte Zulassung oder Härtefallantrag)
     */
    private void executeBeforeSaveAmendment(RequestSubjectDto requestSubjectDto, AmendmentDto amendmentDto) {
        if (amendmentDto != null) {
            if (amendmentDto.getAmendmentstatusId() == null) {
                requestSubjectDto.removeFromAmendments(amendmentDto);
                amendmentDto.setMarkedToDelete(true);
            } else if (!amendmentDto.getAmendmentstatus().getHiskeyId().equals(AmendmentstatusEnum.ABGELEHNT.getHisKey())){
                amendmentDto.setAmendmentstatusreason(null);
            }
        }
    }


    /**
     * @param requestSubjectDto
     * @param amendmentDto
     */
    @Override
    public void removeAmendmentsFromRequestSubjects(RequestSubjectDto requestSubjectDto, AmendmentDto amendmentDto) {
        amendmentDto.removeFromRequestSubjects(requestSubjectDto);
        if (amendmentDto.getAmendmenttypeId().equals(AmendmenttypeEnum.ANTRAG_BEVORZUGTE_ZULASSUNG.getKey())) {
            amendmentDto.setMarkedToDelete(true);
        }
    }


    @Override
    public RequestDto getRequests(Long requestId) {
        logger.enter("getRequests", "requestId=", requestId);

        RequestPath requestPath = new RequestPath();
        String[] loadPath = DTOFactoryUtil.asLoadPath(requestPath.requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().courseOfStudy().admissionshares(), requestPath.requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().amendments(), requestPath.requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().admissionstatus(), requestPath
                        .requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().reactionstatus(), requestPath.requestgroup().application().applicant().person(), requestPath.requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().examplans().defaultExamrelation(), requestPath.requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().examplans()
                        .unit());

        RequestDto requestDto = RequestDtoFactory.getDto(requestId, new LoadParams().setReplacedDtoClasses(RequestSubjectXtdDtoImpl.class), loadPath);

        logger.leave("getRequests", requestDto);
        return requestDto;
    }

    @Override
    public RequestDto searchRequest(Long requestId) {
        logger.enter("searchRequest", "requestId=", requestId);

        RequestPath requestPath = new RequestPath();
        String[] loadPath = DTOFactoryUtil.asLoadPath(
                        requestPath.requestStatus(),
                        requestPath.requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().requestSubjectStatus(),
                        requestPath.requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().courseOfStudy(),
                        requestPath.requestgroup().application().applicant().person().student()
                        );

        RequestDto requestDto = RequestDtoFactory.getDto(requestId, new LoadParams().setReplacedDtoClasses(RequestSubjectXtdDtoImpl.class),loadPath);

        logger.leave("searchRequest", requestDto);
        return requestDto;
    }

    @Override
    @Secured({ Right.Strings.CM_APP_AMENDMENT_EDIT_AMENDMENT, Right.Strings.CM_APP_AMENDMENT_EDIT_AMENDMENT_OWN })
    public void saveReceiptDatesOfAmendments(RequestDto requestDto) {
        ApplicationDto applicationDto =  requestDto.getRequestgroup().getApplication();
        Set<AmendmentDto> amendmentsToApplication = applicationDto.getAmendments();
        if (amendmentsToApplication != null && amendmentsToApplication.size()>0){
            for(AmendmentDto amendmentDto : amendmentsToApplication){
                amendmentDto.setReceiptdate(new Date());
            }
            ApplicationDtoFactory.saveDto(applicationDto);
        }

        for (RequestsubjectgroupDto requestsubjectgroupDto : requestDto.getRequestsubjectgroups()) {
            for (RequestsubjectgroupRequestsubjectDto rgrsDto : requestsubjectgroupDto.getRequestsubjectgroupRequestsubjects()){
                RequestSubjectDto requestSubjectDto = rgrsDto.getRequestSubject();
                for(AmendmentDto amendmentDto : requestSubjectDto.getAmendments()){
                    amendmentDto.setReceiptdate(new Date());
                }
                RequestSubjectDtoFactory.saveDto(requestSubjectDto);
            }
        }
    }

    @Override
    @Secured({ Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION, Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION_OWN })
    public void saveRequestSubjects(List<RequestSubjectDto> requestSubjectDtos) {
        EnsureArgument.notNull(requestSubjectDtos, "requestSubjectDtos must not be null");
        logger.enter("saveRequestSubjects", "requestSubjectDtos=", requestSubjectDtos);
        for (RequestSubjectDto requestSubjectDto : requestSubjectDtos) {
            if(requestSubjectDto.getNotPassedDegree() != null && requestSubjectDto.getNotPassedDegree().booleanValue() == false) {
                requestSubjectDto.setNotPassedDegreeUniversityId(null);
                requestSubjectDto.setUniversityBackgroundComment(null);
            }
        }
        RequestSubjectDtoFactory.saveDto(requestSubjectDtos);
        logger.leave("saveRequestSubjects");
    }

    @Override
    @Secured({ Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION, Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION_OWN })
    public ApplicationDto save(ApplicationDto applicationDto) {
    	return save(applicationDto, true);
    }

    @Override
    @Secured({ Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION, Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION_OWN })
    public ApplicationDto save(ApplicationDto applicationDto, boolean saveMeasurementSeconddegree) {
        logger.enter("save", "applicationDto=", applicationDto);
        validate(applicationDto);
        executeBeforeSave(applicationDto);
        if (saveMeasurementSeconddegree) saveMeasurementSeconddegree(applicationDto);
        String[] savePath = DTOFactoryUtil.asLoadPath(
                startApplicationPath().examplans().defaultExamrelation().examresult(),
                startApplicationPath().termTypeValue(),
                startApplicationPath().applicant().person().roles().role(),
                startApplicationPath().applicant().person().student().degreePrograms().progress().studentstatus(),
                startApplicationPath().applicant().person().student().degreePrograms().progress().studyStatus(),
                startApplicationPath().applicant().person().student().degreePrograms().progress().courseOfStudy(),
                startApplicationPath().requestgroups().requests().requestStatus(),
                startApplicationPath().requestgroups().requests().amendments().amendmenttype(),
                startApplicationPath().requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().selectedToEnrollCourseOfStudy().courseOfStudyStart(),
                startApplicationPath().requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().requestSubjectStatus(),
                startApplicationPath().requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().admissionstatus(),
                startApplicationPath().requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().reactionstatus(),
                startApplicationPath().requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().courseOfStudy(),
                startApplicationPath().requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().courseOfStudy().courseOfStudyStart(),
                startApplicationPath().requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().amendments(),
                startApplicationPath().requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().examplans().defaultExamrelation().workstatus(),
                startApplicationPath().requestgroups().requests().requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().examplans().unit().zulmissingdata()
        );
        Application application = ApplicationDtoFactory.saveDto(applicationDto, new SaveParams().setSavePaths(savePath));
        Set<Request> requests = application.getRequests();
        if (requests != null) {
            for (Request request : requests) {
                if (request.getRequestStatus() == null) {
                    requestStatusSwitch.init(request);
                } else {
                    for (RequestSubject requestSubject : request.getRequestSubjects()) {
                        if (requestSubject.getRequestSubjectStatus() == null) {
                            requestSubjectStatusSwitch.init(requestSubject);
                        }
                    }
                }
            }
        }
        logger.leave("applicationDto");
        return applicationDto;
    }

    private void validate(ApplicationDto applicationDto) {
        // Validierung: Keine Bewerbung ohne Fächer
        validateRequestSubjectExists(applicationDto);
        // Validierung: das geplannte Immadatum muss in der Zukunft liegen
        validateScheduledDateOfEnrollment(applicationDto);
    }

    private void validateScheduledDateOfEnrollment(ApplicationDto applicationDto) {
        // Aktuelles Datum ermitteln
        Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("ECT"));
        calendar.set(Calendar.HOUR,0);
        calendar.set(Calendar.MINUTE,0);
        calendar.set(Calendar.SECOND,0);
        calendar.set(Calendar.MILLISECOND,0);
        Date today = calendar.getTime();

        for (RequestSubjectDto requestsubjectDto : applicationDto.getRequestSubjects()){
            Date scheduledDateOfEnrollment = requestsubjectDto.getScheduledDateOfEnrollment();
            if (scheduledDateOfEnrollment != null) {
                int compareDate = requestsubjectDto.getScheduledDateOfEnrollment().compareTo(today);
                if (compareDate < 0){
                    throw new ServiceException("cm.app.validation.ScheduledDateOfEnrollment.notInFuture", ExceptionType.VALIDATION);
                }
            }
        }
    }

    private void validateRequestSubjectExists(ApplicationDto applicationDto) {
        int count = 0;
        if (applicationDto == null){
            throw new ServiceException("cm.app.bb.noApplication.error");
        }
        Iterator<RequestgroupDto> requestgroupIterator = applicationDto.getRequestgroups().iterator();
        while (requestgroupIterator.hasNext()) {
            RequestgroupDto requestgroupDto = requestgroupIterator.next();
            if (!requestgroupDto.isMarkedToDelete()) {
                Iterator<RequestDto> requestIterator = requestgroupDto.getRequests().iterator();
                while (requestIterator.hasNext()) {
                    RequestDto requestDto = requestIterator.next();
                    if (!requestDto.isMarkedToDelete()) {
                        Iterator<RequestsubjectgroupDto> requestsubjectgroupIterator = requestDto.getRequestsubjectgroups().iterator();
                        while (requestsubjectgroupIterator.hasNext()) {
                            RequestsubjectgroupDto requestsubjectgroupDto = requestsubjectgroupIterator.next();
                            if (!requestsubjectgroupDto.isMarkedToDelete()) {
                                Iterator<RequestsubjectgroupRequestsubjectDto> rgrsIterator = requestsubjectgroupDto.getRequestsubjectgroupRequestsubjects().iterator();
                                while (rgrsIterator.hasNext()) {
                                    RequestSubjectDto requestSubjectDto = rgrsIterator.next().getRequestSubject();
                                    if (!requestSubjectDto.isMarkedToDelete()){
                                        count++;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (count == 0){
            throw new ServiceException("cm.app.bb.noRequests.error");
        }
    }

    @Override
    @Secured({ Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION, Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION_OWN })
    public Long save(ApplicationDto applicationDto, Long applicantId, Long personId) {
        // Bei der Neuanlage einer Bewerbung
        if (applicationDto.getApplicant() == null && applicantId != null) {
            applicationDto.setApplicantId(applicantId);
        }
        processOnSave(applicationDto);
        save(applicationDto);

        return applicationDto.getId();
    }

    // Calls processZulMissingDataOnSave(copies missingDataList from his:selectManyPicklist back to DTOs) and
    //       processManualAdmissionOnSave(only call manualAdmission if admissionStatus changed)
    @Override
    @Secured({ Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION, Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION_OWN })
    public void processOnSave(ApplicationDto applicationDto) {
        for (RequestDto requestDto : applicationDto.getRequests()) {
            for (RequestsubjectgroupDto requestsubjectgroupDto : requestDto.getRequestsubjectgroups()) {
                for (RequestsubjectgroupRequestsubjectDto requestsubjectgroupRequestsubjectDto : requestsubjectgroupDto.getRequestsubjectgroupRequestsubjects()) {
                    RequestSubjectDto requestSubjectDto = requestsubjectgroupRequestsubjectDto.getRequestSubject();
                    RequestSubjectXtdDto rsXtdDto = (RequestSubjectXtdDto) requestSubjectDto;
                    //ZulMissingData
                    processZulMissingDataOnSave(requestSubjectDto);
                    processManualAdmissionOnSave(rsXtdDto);
                }
            }
        }
    }

    @Override
    public Long getZulMissingDataConsequence(List<Long> zulMissingData) {
        Long consequence = null;
        if (zulMissingData != null && zulMissingData.size() != 0) {
            // Wenn Unterlagen fehlen, wird die härteste Konsequenz angezeigt

            List<ZulMissingDataValue> zulmissingdata = zulMissingDataDao.findZulMissingDataConsequence(zulMissingData);
            // Liste wird so sortiert, dass das 0. Element immer die höchste Prio hat
            Collections.sort(zulmissingdata);
            consequence = zulmissingdata.get(0).getZulconsequence().getId();
        }
        return consequence;
    }

    @Override
    public Long getHisKeyRequestStatusEnumReceived() {
        return RequestStatusEnum.RECEIVED.getHisKey();
    }

    @Override
    public Long getHisKeyRequestStatusEnumInPreperation() {
        return RequestStatusEnum.IN_PREPARATION.getHisKey();
    }

    /* (non-Javadoc)
     * @see de.his.appserver.service.iface.sul.zul.bewerbung.antragskerndaten.RequestgroupsService#isApplicationForPreferedAdmission(de.his.appserver.service.dto.gen.iface.RequestDto)
     */
    @Override
    public boolean isApplicationForPreferedAdmission(RequestDto request) {
        boolean applicationForPreferedAdmission = false;

        Long bevorzugteZulassung = this.amendmentService.getAmendmenttypeId(AmendmenttypeEnum.ANTRAG_BEVORZUGTE_ZULASSUNG);

        Collection<RequestSubjectDto> requestSubjects = request.getRequestSubjects();
        for (RequestSubjectDto requestsubject : requestSubjects) {
            if (!requestsubject.isMarkedToDelete()) {
                List<AmendmentDto> amendments = requestsubject.getAmendments();
                if (amendments != null && amendments.size() > 0) {
                    for (AmendmentDto amendment : amendments) {
                        if (amendment.getAmendmenttypeId().equals(bevorzugteZulassung)) {
                            if (amendment.getAmendmentstatusId() != null) { // d.h. Status != gestellt, genehmigt, abgelehnt
                                applicationForPreferedAdmission = true;
                                // We obviously can skip to iterate here over and over, because the variable applicationForPreferedAdmission will never set back to false again
                                return true;
                            }
                        }
                    }
                }
            }
        }
        return applicationForPreferedAdmission;
    }

    @Override
    public boolean hasRequestSubjectReferenceToDegreeProgramProgress(RequestSubjectDto requestSubjectDto, DegreeProgramProgressDto degreeProgramProgressDto) {
        return hasRequestSubjectReferenceToCourseOfStudy(requestSubjectDto, degreeProgramProgressDto.getCourseOfStudy());
    }

    @Override
    public boolean hasRequestSubjectReferenceToCourseOfStudy(RequestSubjectDto requestSubjectDto, CourseOfStudyDto courseOfStudyDto) {
        Iterator<CourseOfStudyDto> it = requestSubjectDto.getCourseOfStudy().getCourseOfStudyStart().iterator();
        while (it.hasNext()) {
            if (courseOfStudyDto.equals(it.next())) {
                return true;
            }
        }
        return false;
    }


    @Override
    public RequestgroupDto createRequestgroupDto() {
        RequestgroupDto requestgroupDto = RequestgroupDtoFactory.getNewDto();
        return requestgroupDto;
    }



    /* (non-Javadoc)
     * @see de.his.appserver.service.iface.sul.zul.bewerbung.antragskerndaten.RequestgroupsService#createRequestsubjectDto()
     */
    @Override
    public RequestSubjectDto createRequestsubjectDto(RequestsubjectgroupDto requestsubjectgroupDto) {
        RequestSubjectDto requestSubjectDto = RequestSubjectDtoFactory.getNewDto(RequestSubjectXtdDtoImpl.class);
        requestSubjectDto.setCourseOfStudy(CourseOfStudyDtoFactory.getNewDto());
        //TODO MaySucceed: Prüfen ob fachlich korrekt
        requestSubjectDto.setMaySucceed(Boolean.FALSE);
        EntranceExamStatusValue defaultEES = entranceExamStatusDao.findByHiskeyId(EntranceExamStatusEnum.TEILNAHME_MOEGLICH.getHisKey());
        if (defaultEES != null) {
            requestSubjectDto.setEntranceExamStatusId(defaultEES.getId());
        }

        //Admissionstatus
        Map<Long, AdmissionStatusValueDto> allAdmissionStatus = valueService.getAllAdmissionStatus(Locale.ENGLISH.getLanguage());
        for (AdmissionStatusValueDto admissionStatusValueDto : allAdmissionStatus.values()) {
            if(admissionStatusValueDto.getHiskeyId().equals(AdmissionStatusEnum.UNDECIDED.getKey())) {
                requestSubjectDto.setAdmissionstatus(admissionStatusValueDto);
                break;
            }
        }

        //Reactionstatus
        Map<Long, ReactionStatusValueDto> allReactionStatus = valueService.getAllReactionStatus(Locale.ENGLISH.getLanguage());
        for (ReactionStatusValueDto reactionStatusValueDto : allReactionStatus.values()) {
            if(reactionStatusValueDto.getHiskeyId().equals(ReactionStatusEnum.UNDECIDED.getKey())) {
                requestSubjectDto.setReactionstatus(reactionStatusValueDto);
                break;
            }
        }

        //RequestSubjectStatus
        Map<Long, RequestSubjectStatusValueDto> allRequestSubjectStatus = valueService.getAllRequestSubjectStatus(Locale.ENGLISH.getLanguage());
        for (RequestSubjectStatusValueDto requestSubjectStatusValueDto : allRequestSubjectStatus.values()) {
            if(requestSubjectStatusValueDto.getHiskeyId().equals(RequestSubjectStatusEnum.IN_PREPARATION.getKey())) {
                requestSubjectDto.setRequestSubjectStatus(requestSubjectStatusValueDto);
                break;
            }
        }
        RequestsubjectgroupRequestsubjectDto rgrsDto = RequestsubjectgroupRequestsubjectDtoFactory.getNewDto();
        rgrsDto.setRequestSubject(requestSubjectDto);
        rgrsDto.setSubjectPriority(Integer.valueOf(1));
        rgrsDto.setRequestsubjectgroup(requestsubjectgroupDto);
        return requestSubjectDto;
    }


    @Override
    public RequestDto createRequestDto() {
        RequestDto newRequestDto = RequestDtoFactory.getNewDto(RequestXtdDtoImpl.class);
        newRequestDto.setReactionstatus(ReactionStatusValueDtoFactory.getDto(ReactionStatusEnum.UNDECIDED.getKey()));
        return newRequestDto;
    }



    @Override
    public RequestsubjectgroupDto createRequestsubjectgroupDto() {
        RequestsubjectgroupDto requestsubjectgroupDto = RequestsubjectgroupDtoFactory.getNewDto();
        //TODO ggf. subjectIndicatorId = 1 setzen
        return requestsubjectgroupDto;
    }

    @Override
    public RequestSubjectDto refreshRequestsubject(RequestsubjectgroupRequestsubjectDto rgrsDto, RequestSubjectDto requestSubjectDto, TermDto termDto) {
        RequestSubjectXtdDto currentRequestSubject = null;
        TermDto admissionTermDto;
        Term term;
        List<CourseOfStudy> admissionToStudylist;
        List<CourseOfStudy> atsTestStudysemesterRequested = new ArrayList<CourseOfStudy>();
        Integer studySemester;

        if (requestSubjectDto instanceof RequestSubjectXtdDto) {
            currentRequestSubject = (RequestSubjectXtdDto) requestSubjectDto;
        } else {
            return requestSubjectDto;
        }
        if (currentRequestSubject.getCourseOfStudy() == null) {
            return requestSubjectDto;
        }
        if (currentRequestSubject.getCourseOfStudyBean() == null) return requestSubjectDto;
        if (termDto != null) {
            admissionTermDto = termDto;
        } else {
            admissionTermDto = termService.getCurrentAdmissionTerm();
        }
        term = termManager.getTerm(admissionTermDto.getYear(), admissionTermDto.getTermType().getTermCategory(), admissionTermDto.getTermType().getTermNumber());
        studySemester = requestSubjectDto.getStudysemesterAdmitted();
        if (studySemester == null) {
            studySemester = requestSubjectDto.getStudysemesterRequested();
        }
        AdmissionToStudyTest admissionToStudyTest = new AdmissionToStudyTest(courseOfStudyDao);
        admissionToStudylist = admissionToStudyTest.test(
                        currentRequestSubject.getCourseOfStudyBean().getDegreeId(),
                        currentRequestSubject.getCourseOfStudyBean().getSubjectId(),
                        currentRequestSubject.getCourseOfStudyBean().getMajorFieldOfStudyId(),
                        currentRequestSubject.getCourseOfStudyBean().getCourseOfStudyTypeValueId(),
                        currentRequestSubject.getCourseOfStudyBean().getCourseSpecializationId(),
                        currentRequestSubject.getCourseOfStudyBean().getSubjectIndicatorId(),
                        currentRequestSubject.getCourseOfStudyBean().getExaminationversionId(),
                        currentRequestSubject.getCourseOfStudyBean().getPlaceOfStudiesId(),
                        currentRequestSubject.getCourseOfStudyBean().getEnrollmentId(),
                        currentRequestSubject.getCourseOfStudyBean().getTypeOfStudyId(),
                        currentRequestSubject.getCourseOfStudyBean().getFormOfStudiesId());
        // Used for test of the requested studysemester
        atsTestStudysemesterRequested.addAll(admissionToStudylist);

        // Remove Candidates from admissionToStudyCandidates if a Application to the given Term and studysemesterAdmitted is not possible
        Boolean activateValidationOfStudysemesterrestrictions = Conf.getBoolean(Conf.CM.APP.EDIT_VALIDATE_STUDYSEMESTERRESTRICTIONS, Boolean.TRUE);
        if (activateValidationOfStudysemesterrestrictions.booleanValue()) {
            Iterator<CourseOfStudy> admissionToStudyCandidatesIterator = admissionToStudylist.iterator();
            while (admissionToStudyCandidatesIterator.hasNext()) {
                CourseOfStudy atsCandidate = admissionToStudyCandidatesIterator.next();
                List<Integer> possibleStudySemesterForThisCandidate = atsCandidate.getStudySemester(term);
                if (possibleStudySemesterForThisCandidate == null || (studySemester != null && !possibleStudySemesterForThisCandidate.contains(studySemester))) {
                    admissionToStudyCandidatesIterator.remove();
                }
                // Tests the studysemesterRequested
                if (possibleStudySemesterForThisCandidate == null || (requestSubjectDto.getStudysemesterRequested() != null && !possibleStudySemesterForThisCandidate.contains(requestSubjectDto.getStudysemesterRequested()))) {
                    atsTestStudysemesterRequested.remove(atsCandidate);
                }
            }
        }
        
        if (admissionToStudylist.size() < 1) {
            throw new ServiceException("cm.app.validation.studysemesterrestriction.admitted", ExceptionType.VALIDATION);
        }
        if (atsTestStudysemesterRequested.size() < 1) {
            throw new ServiceException("cm.app.validation.studysemesterrestriction.requested", ExceptionType.VALIDATION);
        }
        if (admissionToStudylist.size() == 1) {

            CourseOfStudyPath admissionToStudyPath = new CourseOfStudyDto.CourseOfStudyPath();
            String[] loadPath = DTOFactoryUtil.asLoadPath(admissionToStudyPath.orgunit(), admissionToStudyPath.admissionshares().admissionPackage().admissiontype());

            CourseOfStudyDto courseOfStudyDto = CourseOfStudyDtoFactory.getDto(admissionToStudylist.get(0), loadPath);
            currentRequestSubject.getCourseOfStudyBean().setDegreeId(courseOfStudyDto.getDegreeId());
            currentRequestSubject.getCourseOfStudyBean().setSubjectId(courseOfStudyDto.getSubjectId());
            currentRequestSubject.getCourseOfStudyBean().setMajorFieldOfStudyId(courseOfStudyDto.getMajorFieldOfStudyId());
            currentRequestSubject.getCourseOfStudyBean().setCourseOfStudyTypeValueId(courseOfStudyDto.getCourseOfStudyTypeValueId());
            currentRequestSubject.getCourseOfStudyBean().setCourseSpecializationId(courseOfStudyDto.getCourseSpecializationId());
            currentRequestSubject.getCourseOfStudyBean().setSubjectIndicatorId(courseOfStudyDto.getSubjectIndicatorId());
            currentRequestSubject.getCourseOfStudyBean().setExaminationversionId(courseOfStudyDto.getExaminationversionId());
            currentRequestSubject.getCourseOfStudyBean().setPlaceOfStudiesId(courseOfStudyDto.getPlaceOfStudiesId());
            currentRequestSubject.getCourseOfStudyBean().setEnrollmentId(courseOfStudyDto.getEnrollmentId());
            currentRequestSubject.getCourseOfStudyBean().setTypeOfStudyId(courseOfStudyDto.getTypeOfStudyId());
            currentRequestSubject.getCourseOfStudyBean().setFormOfStudiesId(courseOfStudyDto.getFormOfStudiesId());

            if (courseOfStudyDto.getOrgunit() != null) {
                currentRequestSubject.getCourseOfStudyBean().setOrgunitDefaultText(courseOfStudyDto.getOrgunit().getDefaulttext());
            }

            ApplicationDto applicationDto = currentRequestSubject.getApplication();
            if (currentRequestSubject.getCourseOfStudy() != null && currentRequestSubject.getCourseOfStudy().getId() != null && !currentRequestSubject.getCourseOfStudy().getId().equals(courseOfStudyDto.getId())) {
               if  (applicationDto.getRequestSubjectsByCourseOfStudyAndStudysemesterAdmitted(currentRequestSubject.getCourseOfStudy().getId(), currentRequestSubject.getStudysemesterAdmitted()).size() > 1) {
                   currentRequestSubject = (RequestSubjectXtdDto) createRequestsubjectDto(rgrsDto.getRequestsubjectgroup());
                   //rgrsDto.setRequestSubject(currentRequestSubject);
               }
            }
            currentRequestSubject.setCourseOfStudy(courseOfStudyDto);
            // requestsubject wiederverwenden falls in der vorliegenden Bewerbung
            // bereits eine Bewerbung auf die gewählte CourseOfStudy/studysemesteradmitted-Kombination vorliegt
            for (RequestDto requestDto : applicationDto.getRequests()) {
                List<RequestsubjectgroupDto> requestsubjectgroups = requestDto.getRequestsubjectgroups();
                for (RequestsubjectgroupDto requestsubjectgroupDto : requestsubjectgroups) {
                    List<RequestsubjectgroupRequestsubjectDto> requestsubjectgroupRequestsubjects = requestsubjectgroupDto.getRequestsubjectgroupRequestsubjects();
                    for (RequestsubjectgroupRequestsubjectDto requestsubjectgroupRequestsubjectDto : requestsubjectgroupRequestsubjects) {
                        RequestSubjectDto candidate = requestsubjectgroupRequestsubjectDto.getRequestSubject();
                        if (!currentRequestSubject.getObjGuid().equals(candidate.getObjGuid())) {
                            if (courseOfStudyDto.getObjGuid().equals(candidate.getCourseOfStudy().getObjGuid())) {
                                if (currentRequestSubject.getStudysemesterAdmitted() != null && candidate.getStudysemesterAdmitted().equals(currentRequestSubject.getStudysemesterAdmitted())) {
                                    rgrsDto.setRequestSubject(candidate);
                                    currentRequestSubject.setMarkedToDelete(true);

                                }
                            }
                        }
                    }
                }
            }

            // TODO: Klären, ob bessere Lösung möglich
            if (currentRequestSubject.getAdmissionPackage() != null) {
                currentRequestSubject.getAdmissionPackage().getAdmissiontype().initMeta();
            }

            List<Integer> studySemester2 = admissionToStudylist.get(0).getStudySemester(term);
            if (studySemester == null) {
                if (studySemester2.size() == 1) {
                    requestSubjectDto.setStudysemesterAdmitted(studySemester2.get(0));
                } else if (activateValidationOfStudysemesterrestrictions.booleanValue()) {
                    throw new ServiceException("cm.app.validation.studysemesterrestriction.admitted", ExceptionType.VALIDATION);
                }
            }
        }
        if (admissionToStudylist.size() > 1) {
            throw new ServiceException("cm.app.validation.admissionToStudy.ToManyMatches", ExceptionType.VALIDATION);
        }
        return requestSubjectDto;
    }


    @Override
    @Secured({ Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION, Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION_OWN, Right.Strings.CM_APP_APPLICATION_VIEW_APPLICATION })
    public PersonDto getPersonDtoByApplicationId(Long applicationId) {
        PersonDto personDto = null;
        String[] asLoadPath = DTOFactoryUtil.asLoadPath(new ApplicationPath().applicant().person());
        ApplicationDto applicationDto = ApplicationDtoFactory.getDto(applicationId, asLoadPath);
        personDto = applicationDto.getApplicant().getPerson();
        return personDto;
    }

    /**
     * @param applicantId
     * @param termDto
     * @return Liste mit Requestgroups
     */
    @Override
    public ApplicationDto getRequestgroups(Long applicantId, TermDto termDto) {
        if (applicantId == null) {
            return null;
        }
        Applicant applicant = applicantDao.findById(applicantId);
        Term term = termManager.getTerm(termDto.getYear(), termDto.getTermTypeCategory(), termDto.getTermTypeNumber());
        List<Application> applications = null;
        if (applicant != null) {
            applications = applicant.getApplications(term);
        }
        if (applications != null && applications.size() > 0) {
            //only one Application in a term allowed TODO ServiceException?
            return getApplication(applications.get(0).getId());
        }
        return null;

    }


    /**
     * @param termManager
     */
    public void setTermManager(TermManager termManager) {
        this.termManager = termManager;
    }

    @Override
    @Secured({ Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION, Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION_OWN })
    public ApplicationDto createApplicationDto() {
        return createApplicationDto(null);
    }

    @Override
    @Secured({ Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION, Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION_OWN })
    public ApplicationDto createApplicationDto(TermDto termDto) {
        ApplicationXtdDto applicationDto = (ApplicationXtdDto) ApplicationDtoFactory.getNewDto(ApplicationXtdDtoImpl.class);
        if(termDto == null) {
            termDto = termService.getCurrentAdmissionTerm();
        }
        applicationDto.setTermTypeValueId(termDto.getTermTypeId());
        applicationDto.setYear(termDto.getYear());
        return applicationDto;
    }

    @Override
    @Deprecated
    public AmendmentDto createAmendmentDto() {
        logger.warn("de.his.appserver.service.iface.sul.zul.bewerbung.antragskerndaten.RequestgroupsService.createAmendmentDto() was called but is marked as deprecated; please use de.his.appserver.service.iface.sul.zul.bewerbung.AmendmentService.createAmendmentDto()");
        return this.amendmentService.createAmendmentDto();
    }

    @Override
    @Deprecated
    public AmendmentDto createApplicationForPreferedAdmissionDtoByAmendmenttypeId() {
        return this.amendmentService.createPreferedAdmissionAmendment();

    }

    @Override
    public AmendmentDto createApplicationForPreferedAdmissionDto() {
        AmendmentDto amendmentDto = AmendmentDtoFactory.getNewDto();
        AmendmenttypeValue amendmenttypeValue = amendmenttypeDao.findByHiskeyId(AmendmenttypeEnum.ANTRAG_BEVORZUGTE_ZULASSUNG.getHisKey());
        AmendmenttypeValueDto dto = AmendmenttypeValueDtoFactory.getDto(amendmenttypeValue);
        amendmentDto.setAmendmenttype(dto);
        return amendmentDto;
    }

    @Override
    public boolean isApplicationForPreferedAdmissionDtoFilled(RequestSubjectXtdDto requestSubjectDto) {
        AmendmentDto amendmentDto = requestSubjectDto.getApplicationForPreferedAdmission();
        return amendmentService.isAmendmentstatusFilled(amendmentDto);
    }

    @Override
    public boolean isApplicationForCaseOfHardshipFilled(RequestSubjectXtdDto requestSubjectDto) {
        AmendmentDto amendmentDto = requestSubjectDto.getApplicationForCaseOfHardship();
        return amendmentService.isAmendmentstatusFilled(amendmentDto);
    }

    @Override
    public AmendmentDto createApplicationForCaseOfHardship() {
        AmendmentDto amendmentDto = AmendmentDtoFactory.getNewDto();
        AmendmenttypeValue amendmenttypeValue = amendmenttypeDao.findByHiskeyId(AmendmenttypeEnum.HAERTEFALL_ANTRAG.getHisKey());
        AmendmenttypeValueDto dto = AmendmenttypeValueDtoFactory.getDto(amendmenttypeValue);
        amendmentDto.setAmendmenttype(dto);
        return amendmentDto;
    }

    @Override
    public ExamplanDto createExamplanDtoForZulMissingData() {
        ExamplanDto examplan = ExamplanDtoFactory.getNewDto();
        ExamrelationDto examrelationDto = ExamrelationDtoFactory.getNewDto();
        examrelationDto.setWorkstatus(getWorkstatus(WorkstatusEnum.Soll));
        examplan.setDefaultExamrelation(examrelationDto);
        return examplan;
    }

    @Override
    public ZulMissingDataValueDto findZulMissingDataValueDtoById(Long zulMissingDataId) {
        String[] loadPath = DTOFactoryUtil.asLoadPath(new ZulMissingDataValuePath().units().zulmissingdata());
        return ZulMissingDataValueDtoFactory.getDto(zulMissingDataId, loadPath);
    }

    /* (non-Javadoc)
     * @see de.his.appserver.service.iface.sul.zul.bewerbung.antragskerndaten.RequestgroupsService#updateApplicationStatus(java.lang.Long, java.lang.String)
     */
    @Override
    @Secured({ Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION, Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION_OWN })
    public void updateApplicationStatus(Long applicationId, String applicationStatusUniquename) {
        logger.debug(">>>>>>>>>>>>>>>>>>>>> updateApplicationStatus for application with id " + applicationId);
        if (applicationId != null) {
            Application application = applicationDao.findById(applicationId);
            if (application != null) {
                ApplicationStatusValue oldApplicationStatus = application.getApplicationStatus();
                logger.debug(">>>>>>>>>>>>>>>>>>>>> oldApplicationStatusValue " + oldApplicationStatus);
                if (oldApplicationStatus == null
                                || (!oldApplicationStatus.getHiskeyId().equals(ApplicationStatusEnum.UNVOLLSTAENDIG_UV.getHisKey()) && !oldApplicationStatus.getHiskeyId().equals(ApplicationStatusEnum.GEAENDERT_GE.getHisKey())
                                                && !oldApplicationStatus.getHiskeyId().equals(ApplicationStatusEnum.UNGEPRUEFT_VO.getHisKey()) && !oldApplicationStatus.getHiskeyId().equals(ApplicationStatusEnum.VOLLSTAENDIG_FEHLERHAFT_VOF.getHisKey()) && !oldApplicationStatus.getHiskeyId().equals(
                                                ApplicationStatusEnum.UNGUELTIG_UN.getHisKey()))) {
                    ApplicationStatusValue newApplicationStatus = applicationStatusValueDao.findByShortcut(applicationStatusUniquename);
                    application.setApplicationStatus(newApplicationStatus);
                    logger.debug(">>>>>>>>>>>>>>>>>>>>> newApplicationStatusValue " + newApplicationStatus);
                }
            } else {
                logger.debug("no Application for id " + applicationId + " found, no update of applicationStatus possible.");
            }
            logger.debug("<<<<<<<<<<<<<<<<<<<<< updateApplicationStatus for application with id " + applicationId);

        }
    }


    /* (non-Javadoc)
     * @see de.his.appserver.service.iface.sul.zul.bewerbung.antragskerndaten.RequestgroupsService#resetApplicationStatus(java.lang.Long)
     */
    @Override
    @Secured({ Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION })
    public void resetApplicationStatus(Long applicationId) {
        EnsureArgument.notNull(applicationId);
        Application application = applicationDao.findById(applicationId);
        if (application != null) {
            ApplicationStatusValue status = applicationStatusValueDao.findByHiskeyId(UNVOLLSTAENDIG_UV.getHisKey());
            application.setApplicationStatus(status);
        } else {
            logger.debug("no application for id " + applicationId + " found, reset of application status not possible.");
        }
    }

    @Override
    @Secured({ Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION, Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION_OWN, Right.Strings.CM_APP_APPLICATION_VIEW_APPLICATION })
    public Long findApplicationIdByPersonIdAndTerm(Long personId, TermDto termDto) {
        EnsureArgument.notNull(personId);
        EnsureArgument.notNull(termDto);
        Term term = termManager.getTerm(termDto.getYear(), termDto.getTermTypeCategory(), termDto.getTermTypeNumber());
        return applicationDao.findApplicationIdByPersonIdAndTerm(personId, term);
    }

    @Override
    public boolean isApplicationComplete(Long applicationId) {
        logger.enter("isApplicationComplete", "applicationId=", applicationId);

        EnsureArgument.notNull(applicationId);
        Application application = applicationDao.findById(applicationId);
        EnsureState.notNull(application, "Found no Application with Id " + applicationId);
        boolean res = application.isComplete();

        logger.leave("isApplicationComplete", res);
        return res;
    }


    @Override
    public boolean isApplicationProcessCompleted(Long applicationId) {
        logger.enter("isApplicationComplete", "applicationId=", applicationId);

        EnsureArgument.notNull(applicationId);
        Application application = applicationDao.findById(applicationId);
        EnsureState.notNull(application, "Found no Application with Id " + applicationId);
        boolean res = application.isProcessed();

        logger.leave("isApplicationComplete", res);
        return res;
    }

    @Override
    public boolean allRequestsChecked(ApplicationDto applicationDto) {
        EnsureArgument.notNull(applicationDto);
        for (RequestDto requestDto : applicationDto.getRequests()) {
            if ((!requestDto.isMarkedToDelete())
                            && (requestDto.getRequestStatus() == null || requestDto.getRequestStatus().getHiskeyId().equals(RequestStatusEnum.IN_PREPARATION.getHisKey()) || requestDto.getRequestStatus().getHiskeyId().equals(RequestStatusEnum.RECEIVED.getHisKey()) || requestDto
                                            .getRequestStatus().getHiskeyId().equals(RequestStatusEnum.IN_PROCESS.getHisKey()))) {
                return false;
            }
        }
        return true;
    }

    @Override
    public boolean isAdmissiontypeService(RequestSubjectXtdDto requestSubjectDto) {
        if (requestSubjectDto.getAdmissionPackage() != null && requestSubjectDto.getAdmissionPackage().getAdmissiontype().getHiskeyId().equals(AdmissiontypeEnum.SERVICE.getHisKey())) {
            return true;
        }
        return false;
    }

    @Override
    public boolean isQuotaRankingReleased(RequestSubjectXtdDto requestSubjectDto) {
        QuotaRankingElementDto quotaRankingElementDto = requestSubjectDto.getAdmissionQuotaRankingElement();
        if (quotaRankingElementDto !=null &&
            (quotaRankingElementDto.getQuotaRanking().getQuotaRankingStatus().getHiskeyId().equals(QuotaRankingStatusEnum.freigegeben.getHisKey()))){
            return true;
        }
        return false;
    }

    @Override
    public boolean isRequestSubjectStatusInPreperation(RequestSubjectDto requestSubjectDto) {
        if (requestSubjectDto.getRequestSubjectStatus() != null && requestSubjectDto.getRequestSubjectStatus().getHiskeyId().equals(RequestSubjectStatusEnum.IN_PREPARATION.getHisKey())) {
            return true;
        }
        return false;
    }

    @Override
    public boolean isRequestSubjectStatusAdmissionWithdrawn(RequestSubjectDto requestSubjectDto) {
        if (requestSubjectDto.getRequestSubjectStatus() != null && requestSubjectDto.getRequestSubjectStatus().getHiskeyId().equals(RequestSubjectStatusEnum.ADMISSION_WITHDRAWN.getHisKey())) {
            return true;
        }
        return false;
    }


    @Override
    public boolean isRequestStatusInPreperation(RequestDto requestDto) {
        if (requestDto.getRequestStatus() != null && requestDto.getRequestStatus().getHiskeyId().equals(RequestStatusEnum.IN_PREPARATION.getHisKey())) {
            return true;
        }
        return false;
    }

    @Override
    public boolean isRequestStatusAdmissionWithdrawn(RequestDto requestDto) {
        if (requestDto.getRequestStatus() != null && requestDto.getRequestStatus().getHiskeyId().equals(RequestStatusEnum.ADMISSION_WITHDRAWN.getHisKey())) {
            return true;
        }
        return false;
    }

    @Override
    public boolean isRequestStatusAdmissionWithdrawn(Long requestId) {
    	EnsureArgument.notNull(requestId);
        Request request = this.requestDao.findById(requestId);
        if (request.getRequestStatus() != null && request.getRequestStatus().getHiskeyId().equals(RequestStatusEnum.ADMISSION_WITHDRAWN.getHisKey())) {
            return true;
        }
        return false;
    }

    @Override
    public boolean isRequestStatusReceivedCanceled(RequestDto requestDto) {
        if (requestDto.getRequestStatus() != null && requestDto.getRequestStatus().getHiskeyId().equals(RequestStatusEnum.RECEIVED_CANCELED.getHisKey())) {
            return true;
        }
        return false;
    }

    @Override
    public boolean isRequestStatusInProcessCanceled(RequestDto requestDto) {
        if (requestDto.getRequestStatus() != null && requestDto.getRequestStatus().getHiskeyId().equals(RequestStatusEnum.IN_PROCESS_CANCELED.getHisKey())) {
            return true;
        }
        return false;
    }

    @Override
    public boolean isRequestStatusValidCanceled(RequestDto requestDto) {
        if (requestDto.getRequestStatus() != null && requestDto.getRequestStatus().getHiskeyId().equals(RequestStatusEnum.VALID_CANCELED.getHisKey())) {
            return true;
        }
        return false;
    }

    @Override
    public boolean isRequestStatusAdmissionCurrentlyImpossibleCanceled(RequestDto requestDto) {
        if (requestDto.getRequestStatus() != null && requestDto.getRequestStatus().getHiskeyId().equals(RequestStatusEnum.ADMISSION_CURRENTLY_IMPOSSIBLE_CANCELED.getHisKey())) {
            return true;
        }
        return false;
    }

    @Override
    public Map<Long, List<ZulMissingDataValueDto>> getMissingDataForEachRequestSubject(ApplicationDto applicationDto) {
        Map<Long, List<ZulMissingDataValueDto>> map = new HashMap<Long, List<ZulMissingDataValueDto>>();
        List<RequestSubjectDto> requestSubjectDtos = ApplicationUtil.getRequestSubjectDto(applicationDto);
        for (RequestSubjectDto requestSubjectDto : requestSubjectDtos) {
            List<ZulMissingDataValueDto> findZulMissingDataForRequestSubject = this.findZulMissingDataForRequestSubject(requestSubjectDto.getId());
            if (findZulMissingDataForRequestSubject != null && findZulMissingDataForRequestSubject.size() > 0) {
                map.put(requestSubjectDto.getId(), findZulMissingDataForRequestSubject);
            }
        }
        return map;
    }

    @Override
    public List<ZulMissingDataValueDto> findZulMissingDataForApplication(Long applicationId) {
        logger.enter("findZulMissingDataForApplication", "applicationId=", applicationId);

        List<Examplan> missingData = examplanDao.getMissingData(applicationId);
        List<ZulMissingDataValueDto> result = new ArrayList<ZulMissingDataValueDto>();
        LoadCtx loadCtx = DtoFactoryTemplateBase.loadBegin();
        for (Examplan md : missingData) {
            //get(0) ist hier ok da es sich um eine OneToOne beziehung handelt die aber nur alse toMany abgebildet werden konnte.
            ZulMissingDataValue zmdv = md.getUnit().getZulmissingdata().get(0);
            ZulMissingDataValueDto dto = ZulMissingDataValueDtoFactory.getDto(zmdv, loadCtx);
            result.add(dto);
        }
        DtoFactoryTemplateBase.loadEnd(loadCtx);
        logger.leave("findZulMissingDataForApplication", result);
        return result;
    }

    @Override
    public List<ZulMissingDataValueDto> findZulMissingDataForRequestSubject(Long requestSubjectId) {
        EnsureArgument.notNull(requestSubjectId, "requestSubjectId must not be null");
        logger.enter("findZulMissingDataForRequestSubject", "requestSubjectId=", requestSubjectId);
        List<Examplan> missingData = examplanDao.getMissingDataForRequestSubject(requestSubjectId);
        List<ZulMissingDataValueDto> result = new ArrayList<ZulMissingDataValueDto>();
        LoadCtx loadCtx = DtoFactoryTemplateBase.loadBegin();
        for (Examplan md : missingData) {
            //get(0) ist hier ok da es sich um eine OneToOne beziehung handelt die aber nur alse toMany abgebildet werden konnte.
            ZulMissingDataValue zmdv = md.getUnit().getZulmissingdata().get(0);
            ZulMissingDataValueDto dto = ZulMissingDataValueDtoFactory.getDto(zmdv, loadCtx);
            result.add(dto);
        }
        DtoFactoryTemplateBase.loadEnd(loadCtx);
        logger.leave("findZulMissingDataForRequestSubject", result);
        return result;
    }


    /* (non-Javadoc)
     * @see de.his.appserver.service.iface.sul.zul.bewerbung.antragskerndaten.RequestgroupsService#updateApplicationUpdateTimestamp(java.lang.Long)
     */
    @Override
    public boolean updateRequestsUpdateTimestamp(Long applicationId) {
        boolean updated = false;
        Application application = applicationDao.findById(applicationId);
        if (application != null) {
            if (application.getApplicationStatus() != null && (!ApplicationStatusEnum.UNVOLLSTAENDIG_UV.getHisKey().equals(application.getApplicationStatus().getHiskeyId()))) {
                logger.debug(">>>>>>>>>>>>>>>>>>>>> application " + applicationId + " changed");
                Date currentDate = new Date();
                updated = true;
                for (Request request : application.getRequests()) {
                    request.setUpdatedAdmissionRelevantDataAt(currentDate);
                }
            }
        }
        return updated;
    }



    @Override
    public List<CourseOfStudyDto> getAllCoursesOfStudiyFromApplication(ApplicationDto applicationDto) {
        List<CourseOfStudyDto> courseOfStudyListByApplication = new ArrayList<CourseOfStudyDto>();
        if (applicationDto != null) {
            for (RequestDto requestDto : applicationDto.getRequests()) {
                List<RequestsubjectgroupDto> requestsubjectgroups = requestDto.getRequestsubjectgroups();
                for (RequestsubjectgroupDto requestsubjectgroupDto : requestsubjectgroups) {
                    for (RequestsubjectgroupRequestsubjectDto rgrs : requestsubjectgroupDto.getRequestsubjectgroupRequestsubjects()) {
                        CourseOfStudyDto courseOfStudyDto = rgrs.getRequestSubject().getCourseOfStudy();
                        if (courseOfStudyDto.getIsCourseOfStudyStart().booleanValue()) {
                            courseOfStudyListByApplication.add(courseOfStudyDto);
                        }
                        Set<CourseOfStudyDto> courseOfStudyStartSet = courseOfStudyDto.getCourseOfStudyStart();

                        Iterator<CourseOfStudyDto> it = courseOfStudyStartSet.iterator();
                        while (it.hasNext()) {
                            courseOfStudyListByApplication.add(it.next());
                        }
                    }
                }
            }
        }
        return courseOfStudyListByApplication;
    }


    @Override
    public List<CourseOfStudy> findAdmissionToStudyByDegree(Long degreeId) {
        return courseOfStudyDao.findByDegree(degreeId);
    }


    @Override
    public void completeApplication(Long applicationId, Long personId) {
        if (!isApplicationComplete(applicationId)) {
            VerwaltungsdatenBewDto verwaltungsdatenBewDto = verwaltungsdatenService.search(personId, applicationId);
            List<Long> fehlendeZulunterlagen = verwaltungsdatenBewDto.getFehlendeZulunterlagen();
            Application application = applicationDao.findById(applicationId);

            if (fehlendeZulunterlagen.size() > 0) {
                // Speziellen Status für fehlende Unterlagen
                // Uni Duisburg-Essen holen, falls vorhanden:
                ApplicationStatusValue appStatus = applicationStatusValueDao.findByHiskeyId(ApplicationStatusEnum.VOLLSTAENDIG_FEHLERHAFT_VOF.getHisKey());
                if (appStatus == null) {
                    // Falls nicht vorhanden, dann Status
                    // für "Bewerbung vollständig" setzen
                    appStatus = applicationStatusValueDao.findByHiskeyId(ApplicationStatusEnum.UNGEPRUEFT_VO.getHisKey());
                }
                application.setApplicationStatus(appStatus);
            } else {
                ApplicationStatusValue vo = applicationStatusValueDao.findByHiskeyId(ApplicationStatusEnum.UNGEPRUEFT_VO.getHisKey());
                application.setApplicationStatus(vo);
            }
        }
    }


    /* (non-Javadoc)
     * @see de.his.appserver.service.iface.sul.zul.bewerbung.antragskerndaten.RequestgroupsService#prepareEnrollmentForFreeCourses(java.lang.Long)
     */
    @Override
    public void prepareEnrollmentForFreeCourses(Long applicationId) {
        Application application = applicationDao.findById(applicationId);
        if (application != null) {
            ApplicationStatusValue editingCompleted = applicationStatusValueDao.findByHiskeyId(VOLLSTAENDIG_BA.getHisKey());
//            AdmissionStatusValue admitted = admissionstatusDao.findByHiskeyId(ADMITTED.getHisKey());
//            ReactionStatusValue accepted = reactionstatusDao.findByHiskeyId(PLACE_ACCEPTED.getHisKey());

            application.setApplicationStatus(editingCompleted);
        }
    }


    @Override
    public void correctApplicationStatus(final Long applicationId, final Long personId) {
        if (applicationId == null) throw new IllegalArgumentException("applicationId == null");
        Application application = applicationDao.findById(applicationId);

        if (application.getApplicationStatus().getHiskeyId().equals(ApplicationStatusEnum.UNGEPRUEFT_VO.getHisKey()) || (application.getApplicationStatus().getHiskeyId().equals(ApplicationStatusEnum.VOLLSTAENDIG_FEHLERHAFT_VOF.getHisKey()))) {
            VerwaltungsdatenBewDto verwaltungsdatenBewDto = verwaltungsdatenService.search(personId, applicationId);
            List<Long> fehlendeZulunterlagen = verwaltungsdatenBewDto.getFehlendeZulunterlagen();
            if (fehlendeZulunterlagen.size() > 0) {
                // Speziellen Status für fehlende Unterlagen
                // Uni Duisburg-Essen holen, falls vorhanden:
                ApplicationStatusValue vof = applicationStatusValueDao.findByHiskeyId(ApplicationStatusEnum.VOLLSTAENDIG_FEHLERHAFT_VOF.getHisKey());
                if (vof != null) {
                    application.setApplicationStatus(vof);
                }
            } else {
                ApplicationStatusValue vo = applicationStatusValueDao.findByHiskeyId(ApplicationStatusEnum.UNGEPRUEFT_VO.getHisKey());
                application.setApplicationStatus(vo);
            }
        }
    }

    @Override
    public void deleteRequest(Long applicantId, TermDto selectedTerm, Long requestId) {
        EnsureArgument.notNull(applicantId, "applicantId must not be null");
        EnsureArgument.notNull(selectedTerm, "selectedTerm must not be null");
        EnsureArgument.notNull(requestId, "requestId must not be null");

        Request requestToDelete = this.requestDao.findById(requestId);
        boolean deletable = StaticBeanRef.getRequestStatusSwitch().isDeletable(requestToDelete);

        logger.debug("delete Request for Request with id " + requestId +" and status " + requestToDelete.getRequestStatus().getDefaulttext());
        if (!deletable) throw new IllegalStateException("delete() not allowed for request #"+requestToDelete.getId());


        List<Long> courseOfStudyLidsNoLongerUsed = new ArrayList<Long>();
        for (RequestSubject rs : requestToDelete.getRequestSubjects()) {
            if (rs.getRequestsubjectgroupRequestsubjects().size() == 1) {
                //keine wiederverwendung des Antragsfach
                rs.clearAmendments();
            }
            courseOfStudyLidsNoLongerUsed.add(rs.getCourseOfStudy().getLid());
        }

        List<Long> usedCourseOfStudyLidsThisApplication = new ArrayList<Long>();
        Requestgroup requestgroup = requestToDelete.getRequestgroup();
        Collection<Request> requests = requestgroup.getRequests();
        for (Request request2 : requests) {
            if (!request2.equals(requestToDelete)) {
                Set<RequestSubject> requestSubjectsWithEntranceExamRelevance = request2.getRequestSubjectsWithEntranceExamRelevance();
                for (RequestSubject requestSubject : requestSubjectsWithEntranceExamRelevance) {
                    usedCourseOfStudyLidsThisApplication.add(requestSubject.getCourseOfStudy().getLid());
                }
            }
        }
        selectionCriteriaService.deleteSelectionCriteriaExamplansFromApplication(requestToDelete.getRequestgroup().getApplication().getId(), usedCourseOfStudyLidsThisApplication, courseOfStudyLidsNoLongerUsed);

        if (requestgroup.getRequests().size() == 1) {
            requestToDelete.clearRequestsubjectgroups();
            requestgroup.removeFromRequests(requestToDelete);
            Application application = requestgroup.getApplication();
            application.removeFromRequestgroups(requestgroup);
            this.requestgroupDao.makeTransient(requestgroup);
        } else {
            requestToDelete.clearRequestsubjectgroups();
            requestgroup.removeFromRequests(requestToDelete);
            this.requestDao.makeTransient(requestToDelete);
        }
    }

    @Override
    public RequestDto loadRequest(Long requestId) {
        EnsureArgument.notNull(requestId, "requestId must not be null");
        LoadParams loadParams = new LoadParams().setReplacedDtoClasses(RequestSubjectXtdDto.class);
        RequestPath requestPath = new RequestPath();
        String[] loadPaths = DTOFactoryUtil.asLoadPath(requestPath.requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().courseOfStudy(), requestPath.requestsubjectgroups().requestsubjectgroupRequestsubjects().requestSubject().examplans().entranceQualification());
        RequestDto requestDto = RequestDtoFactory.getDto(requestId, loadParams, loadPaths);
        return requestDto;
    }

    @Override
    public Long getApplicationIdFromRequst(Long requestId) {
        EnsureArgument.notNull(requestId, "requestId must not be null");
        Request request = this.requestDao.findById(requestId);
        Long applicationId = request.getRequestgroup().getApplication().getId();
        return applicationId;
    }

    @Override
    public List<RequestSubjectDto> getAllRequestSubjects(Long requestId) {
        List<RequestSubjectDto> requestSubjectDtos = new ArrayList<RequestSubjectDto>();
        List<Long> requestSubjectIds = new ArrayList<Long>();
        Request request = this.requestDao.findById(requestId);
        Collection<RequestSubject> requestSubjects = request.getRequestSubjects();
        RequestSubjectPath path = new RequestSubjectDto.RequestSubjectPath();
        String[] loadPath = DTOFactoryUtil.asLoadPath(
                        path.courseOfStudy(),
                        path.amendments().amendmentstatus(),
                        path.amendments().amendmenttype());
        LoadCtx loadCtx = DtoFactoryTemplateBase.loadBegin();
        for (RequestSubject requestSubject : requestSubjects) {
            if(!requestSubjectIds.contains(requestSubject.getId())) {
                RequestSubjectDto requestSubjectDto = RequestSubjectDtoFactory.getDto(requestSubject, loadCtx, loadPath);
                requestSubjectDtos.add(requestSubjectDto);
                requestSubjectIds.add(requestSubject.getId());
            }
        }
        DtoFactoryTemplateBase.loadEnd(loadCtx);
        return requestSubjectDtos;
    }

    @Override
    public List<RequestSubjectDto> getNonFreeRequestSubjects(Long requestId) {
        List<RequestSubjectDto> subjects = getAllRequestSubjects(requestId);
        Iterator<RequestSubjectDto> iterator = subjects.iterator();
        while (iterator.hasNext()) {
            RequestSubjectDto subject = iterator.next();
            if (subject.isCourseOfStudyFree()) iterator.remove();
        }
        return subjects;
    }

    @Override
    public List<RequestSubjectDto> getAllRequestSubjectsByApplicationId(Long applicationId) {
        List<RequestSubjectDto> requestSubjectDtos = new ArrayList<RequestSubjectDto>();
        List<Long> requestSubjectIds = new ArrayList<Long>();
        Application application = this.applicationDao.findById(applicationId);
        Collection<RequestSubject> requestSubjects = application.getRequestSubjects();
        RequestSubjectPath path = new RequestSubjectDto.RequestSubjectPath();
        String[] loadPath = DTOFactoryUtil.asLoadPath(
                        path.courseOfStudy(),
                        path.amendments().amendmentstatus(),
                        path.amendments().amendmenttype());
        LoadCtx loadCtx = DtoFactoryTemplateBase.loadBegin();
        for (RequestSubject requestSubject : requestSubjects) {
            if(!requestSubjectIds.contains(requestSubject.getId())) {
                RequestSubjectDto requestSubjectDto = RequestSubjectDtoFactory.getDto(requestSubject, loadCtx, loadPath);
                requestSubjectDtos.add(requestSubjectDto);
                requestSubjectIds.add(requestSubject.getId());
            }
        }
        DtoFactoryTemplateBase.loadEnd(loadCtx);
        return requestSubjectDtos;
    }

    @Override
    public RequestDto getRequest(DegreeProgramDto degreeProgram, boolean isForEnrollment) {
        if (degreeProgram != null && degreeProgram.getStudent() != null) {
            //Die letzten Dpps des Studenten werden selektiert
            List<DegreeProgramProgressDto> degreeProgramProgresses = studentService.getRecentDegreeProgramProgressDtos(degreeProgram);
            for (DegreeProgramProgressDto degreeProgramProgress : degreeProgramProgresses) {
                //Bewerbungen der Person der Dpps
                ApplicantDto applicant = degreeProgram.getStudent().getPerson().getApplicant();
                TermDto term = termService.getTerm(degreeProgramProgress.getPeriod().getYear(), degreeProgramProgress.getPeriod().getTermTypeValueId());
                if (applicant != null) {
                    List<ApplicationDto> applications = applicant.getApplications();
                    for (ApplicationDto application : applications) {
                        Set<RequestDto> requests = new HashSet<RequestDto>();
                        if(application.getTermTypeValueId().equals(term.getTermTypeId())
                            && application.getYear().equals(term.getYear())){
                            if (isForEnrollment) {
                                requests = applicationService.getRequestsForEnrollmentOnlyAdmittedOrAdmissionOffered(application.getRequests());
                            } else {
                                requests = application.getRequests();
                            }
                        }
                        for (RequestDto tmpRequest : requests) {
                            if(isMatching(tmpRequest,degreeProgram,term)){
                                //Da das Entity über den RequestStatusSwitch gespeichert wird, muss das Dto neu geladen werden
                                RequestDto request = null;
                                if(tmpRequest != null){
                                    if(tmpRequest.getId() != null){
                                        request = searchRequest(tmpRequest.getId());
                                    } else { //noch nicht persistiert
                                        request = tmpRequest;
                                    }
                                }
                                return request;
                            }
                        }
                    }
                }
            }
        }
        return null;
    }
    private boolean isMatching(RequestDto request, DegreeProgramDto degreeProgram, TermDto term) {
        Set<RequestSubjectDto> requestSubjectList = request.getRequestSubjects();
        List<DegreeProgramProgressDto> degreeProgramProgressList = degreeProgram.getProgress(term.getYear(),term.getTermTypeId());
        if(requestSubjectList.size() == degreeProgramProgressList.size()){
            Set<Long> rsCourseOfStudyIds = new TreeSet<Long>();
            Set<Integer> rsStudySemester = new TreeSet<Integer>();
            for (RequestSubjectDto _requestSubject : requestSubjectList) {
                if (_requestSubject.getSelectedToEnrollCourseOfStudyId() != null) {
                    rsCourseOfStudyIds.add(_requestSubject.getSelectedToEnrollCourseOfStudyId());
                } else if (_requestSubject.getCourseOfStudyId() != null){
                    rsCourseOfStudyIds.add(_requestSubject.getCourseOfStudyId());
                }
                rsStudySemester.add(_requestSubject.getStudysemesterAdmitted());
            }
            Set<Long> dppCourseOfStudyIds = new TreeSet<Long>();
            Set<Integer> dppStudySemester = new TreeSet<Integer>();
            for (DegreeProgramProgressDto _degreeProgramProgress : degreeProgramProgressList) {
                if (_degreeProgramProgress.getCourseOfStudyId() != null) {
                    dppCourseOfStudyIds.add(_degreeProgramProgress.getCourseOfStudyId());
                }

                if (_degreeProgramProgress.getStudysemester() != null) {
                    dppStudySemester.add(new Integer(_degreeProgramProgress.getStudysemester().intValue()));
                } else {
                    dppStudySemester.add(new Integer(-1)); // dann passt es halt nie!!!
                }
            }
            if(rsCourseOfStudyIds.equals(dppCourseOfStudyIds) && rsStudySemester.equals(dppStudySemester)){
                return true;
            }
        }
        return false;
    }

    @Override
    public List<RequestDto> filterRequestForEnrollment(List<RequestDto> requests) {
        return applicationService.getRequestsForEnrollment(requests);
    }

    @Override
    public List<RequestsubjectgroupRequestsubjectDto> filterRequestsubjectgroupRequestsubjectsByRequestStatus(List<RequestsubjectgroupRequestsubjectDto> rsgrsList) {
        List<RequestsubjectgroupRequestsubjectDto> filteredRsgrsList = new ArrayList<RequestsubjectgroupRequestsubjectDto>();
        for(RequestsubjectgroupRequestsubjectDto rsgrs : rsgrsList){
            RequestStatusValueDto requestStatus = rsgrs.getRequestsubjectgroup().getRequest().getRequestStatus();
            if(isSelectableByStuStaff(requestStatus)){
                filteredRsgrsList.add(rsgrs);
            }
        }
        return filteredRsgrsList;
    }

    @Override
    public List<RequestDto> filterRequestsForDPPMerging(List<RequestDto> requests) {
        List<RequestDto> filteredRequest = new ArrayList<RequestDto>();
        for (RequestDto request : requests) {
            RequestStatusValueDto requestStatus = request.getRequestStatus();
            if(isValidForDegreeProgramProgressMerging(requestStatus)){
                filteredRequest.add(request);
            }
        }

        return filteredRequest;
    }

    /**
     * @param requestStatus
     * @return true, if requestStatus is REQUEST_FOR_ENROLLMENT_IN_PROCESS, REQUEST_FOR_ENROLLMENT_SUBMITTED, REQUEST_FOR_ENROLLMENT_DECLINED, REQUEST_FOR_ENROLLMENT_ACCEPTED, ADMISSION_OFFERED or ADMITTED
     */
    public boolean isSelectableByStuStaff(RequestStatusValueDto requestStatus) {
        if(requestStatus == null){
            return false;
        }
        return requestStatus.getHiskeyId().equals(RequestStatusEnum.REQUEST_FOR_ENROLLMENT_IN_PROCESS.getHisKey())
            || requestStatus.getHiskeyId().equals(RequestStatusEnum.REQUEST_FOR_ENROLLMENT_SUBMITTED.getHisKey())
            || requestStatus.getHiskeyId().equals(RequestStatusEnum.REQUEST_FOR_ENROLLMENT_DECLINED.getHisKey())
            || requestStatus.getHiskeyId().equals(RequestStatusEnum.REQUEST_FOR_ENROLLMENT_ACCEPTED.getHisKey())
            || requestStatus.getHiskeyId().equals(RequestStatusEnum.ADMISSION_OFFERED.getHisKey())
            || requestStatus.getHiskeyId().equals(RequestStatusEnum.ADMITTED.getHisKey());
    }

    /**
     * @param requestStatus
     * @return true, if requestStatus is REQUEST_FOR_ENROLLMENT_IN_PROCESS, REQUEST_FOR_ENROLLMENT_SUBMITTED, ADMISSION_OFFERED or ADMITTED
     */
    public boolean isValidForDegreeProgramProgressMerging(RequestStatusValueDto requestStatus) {
        if(requestStatus == null){
            return false;
        }
        return requestStatus.getHiskeyId().equals(RequestStatusEnum.REQUEST_FOR_ENROLLMENT_IN_PROCESS.getHisKey())
            || requestStatus.getHiskeyId().equals(RequestStatusEnum.REQUEST_FOR_ENROLLMENT_SUBMITTED.getHisKey())
            || requestStatus.getHiskeyId().equals(RequestStatusEnum.ADMISSION_OFFERED.getHisKey())
            || requestStatus.getHiskeyId().equals(RequestStatusEnum.ADMITTED.getHisKey());
    }

    @Override
    public List<RequestDto> filterRequestsByRequestStatus(List<RequestDto> requests) {
        List<RequestDto> filteredRequest = new ArrayList<RequestDto>();
        for (RequestDto request : requests) {
            RequestStatusValueDto requestStatus = request.getRequestStatus();
            if(isSelectableByStuStaff(requestStatus)){
                filteredRequest.add(request);
            }
        }

        return filteredRequest;
    }

    @Override
    public List<RequestSubjectDto> filterRequestsubjectsByRequestStatus(List<RequestDto> requests) {
        List<RequestSubjectDto> filteredRequestSubjects = new ArrayList<RequestSubjectDto>();
        for (RequestDto request : requests) {
            List<RequestsubjectgroupDto> requestsubjectgroups = request.getRequestsubjectgroups();
            for (RequestsubjectgroupDto requestsubjectgroup : requestsubjectgroups) {
                if(requestsubjectgroup.getSubjectnumber().compareTo(Integer.valueOf(1)) == 0){
                    List<RequestsubjectgroupRequestsubjectDto> filterRsgrsListByRequestStatus = filterRequestsubjectgroupRequestsubjectsByRequestStatus(requestsubjectgroup.getRequestsubjectgroupRequestsubjects());
                    for(RequestsubjectgroupRequestsubjectDto rsgrs: filterRsgrsListByRequestStatus){
                        filteredRequestSubjects.add(rsgrs.getRequestSubject());
                    }
                }
            }
        }
        return filteredRequestSubjects;
    }

    @Override
    public RequestSubjectDto findRequestSubjectByCourseOfStudyAndPerson(Long courseOfStudyId, Long personId) {
        RequestSubject requestSubject = this.requestSubjectDao.findRequestSubjectByCourseOfStudyAndPerson(courseOfStudyId, personId);
        if(requestSubject == null) {
            return null;
        }
//        String[] loadPath = DTOFactoryUtil.asLoadPath(new RequestSubjectDto.RequestSubjectPath().requestsubjectgroupRequestsubjects().requestsubjectgroup().request());
        RequestSubjectDto requestSubjectDto = RequestSubjectDtoFactory.getDto(requestSubject);
        return requestSubjectDto;
    }

    @Override
    public void loadRequestgroupFor(RequestDto request){
        super.loadDtoAttribute(request, RequestDto.requestgroup);
    }


    /**
     * Laden der fachbezogenen fehlende Unterlagen, des Zulassungsstatus und setzen der CourseOfStudyBean
     */
    @Override
    public void processOnLoad(ApplicationDto applicationDto) {
        for (RequestDto requestDto : applicationDto.getRequests()) {
            List<RequestsubjectgroupDto> requestsubjectgroups = requestDto.getRequestsubjectgroups();
            if (requestsubjectgroups != null && requestsubjectgroups.size() != 0){
                for (RequestsubjectgroupDto requestsubjectgroupDto : requestsubjectgroups){
                    List<RequestsubjectgroupRequestsubjectDto> rgrsDtos =  requestsubjectgroupDto.getRequestsubjectgroupRequestsubjects();
                    if (rgrsDtos != null && rgrsDtos.size() != 0){
                        for (RequestsubjectgroupRequestsubjectDto rgrsDto : rgrsDtos){
                            processZulMissingDataOnLoad(rgrsDto.getRequestSubject());
                            processManualAdmissionOnLoad(rgrsDto.getRequestSubject());
                            //Sicher stellen, dass für jedes requestSubject eine CourseOfStudyBean erzeugt wird
                            copyAts(rgrsDto.getRequestSubject());
                        }
                    }
                }
            }
        }
    }

    /**
     *
     * Prepare missingData for his:selectManyPicklist when a RequestSubject is Selected in the View
     * @param requestSubjectDto The modified RequestSubject
     * @return
     */
    @Override
    public RequestSubjectDto processZulMissingDataOnLoad(RequestSubjectDto requestSubjectDto) {
//        List<Long> missingDataList = new ArrayList<Long>();
//        Collection<Examplan> missingData = this.requestgroupDao.findRequestSubjectMissingData(requestSubjectDto.getId(), WorkstatusEnum.Soll.getHisKey());
//        String[] loadPaths = asLoadPath(
//                        new ExamplanDto.ExamplanPath().defaultExamrelation().workstatus(),
//                        new ExamplanDto.ExamplanPath().unit().zulmissingdata());
//        List<ExamplanDto> examplanDtos = ExamplanDtoFactory.getDtos(missingData, loadPaths);
//        requestSubjectDto.addToExamplans(examplanDtos);
//        for (ExamplanDto examplanDto : examplanDtos) {
//            missingDataList.add(examplanDto.getUnit().getZulmissingdata().get(0).getId());
//        }


        List<Long> missingDataList = requestSubjectDto.getFehlendeZulunterlagen();
        List<ExamplanDto> examplans = requestSubjectDto.getExamplans();
        if (examplans != null) {
            for (ExamplanDto examplan : examplans) {

                if(!examplan.isDefaultExamrelationSet()) {
                    String[] loadPath = asLoadPath(new ExamrelationDto.ExamrelationPath());
                    super.loadDtoAttribute(examplan, ExamplanDto.defaultExamrelation, loadPath);
                }

                ExamrelationDto erDto = examplan.getDefaultExamrelation();
                Long workstatusId = erDto.getWorkstatusId();
                Map<Long, WorkstatusValueDto> allWorkstatus = this.valueService.getAllWorkstatus(I18nUtils.getLang());
                WorkstatusValueDto workstatusValueDto = allWorkstatus.get(workstatusId);
                // ist dies eine Soll-Leistung?
                if (workstatusValueDto != null && workstatusValueDto.getHiskeyId().equals(WorkstatusEnum.Soll.getHisKey())) {
                    if (examplan.getUnit().getZulmissingdata() != null && examplan.getUnit().getZulmissingdata().size() > 0) {
                        /*  //handelt es sich um eine fachbezogene Unterlage? : Offensichtlich keine Schlüsseltabelle hierfür vorhanden
                         *  1: bewerbungsbezogene fehlende Unterlage
                         *  2: fachbezogene fehlende Unterlage
                         */
                        if (examplan.getUnit().getZulmissingdata().get(0).getCategory().equals(Integer.valueOf(2))) {
                            missingDataList.add(examplan.getUnit().getZulmissingdata().get(0).getId());
                        }
                    }
                }
            }
        }
        RequestSubjectXtdDto rs = (RequestSubjectXtdDto) requestSubjectDto;
        rs.setZulMissingDataIds(missingDataList);
        //härteste Konsequenz wird anhand der fehlenden Unterlagen gesetzt
        if (missingDataList.size() > 0) {
            rs.setZulMissingDataConsequenceId(this.getZulMissingDataConsequence(rs.getZulMissingDataIds()));
        }

        return requestSubjectDto;
    }

    /**
     * This Method sets the following transient attributes
     *
     * <ul>
     * <li> requestSubjectXtdDto.quotaId </li>
     * <li> requestSubjectXtdDto.manualadmissionStatus </li>
     * <li> requestSubjectXtdDto.reactionStatusId </li>
     * </ul>
     *
     * RequestSubjectXTDDto.quotaId contains the possible quotas for manual admission
     * and if admissionStatus is admitted the relevant quotaId as initialisation value.
     *
     * sets manualAdmissionStatus and quota if admitted
     *
     * @param requestSubjectDto
     */
    @Override
    public void processManualAdmissionOnLoad(RequestSubjectDto requestSubjectDto) {
        RequestSubjectXtdDto rs = (RequestSubjectXtdDto) requestSubjectDto;
        rs.setManualAdmissionStatus(requestSubjectDto.getAdmissionstatus().getId());
        rs.setReactionStatusId(requestSubjectDto.getReactionstatus().getId());

        // If there is an admission from an automatic process:
        // Set the quota for which the admission was granted.
        //
        if (rs.getAdmissionstatus().getHiskeyId().equals(ADMITTED.getKey())) {
            if(!rs.isAdmissionQuotaRankingElementSet()) {
                String[] loadPath = asLoadPath(new QuotaRankingElementDto.QuotaRankingElementPath().quotaRanking().ranking().processStep());
                loadDtoAttribute(rs, RequestSubjectDto.admissionQuotaRankingElement, loadPath);
            }
            QuotaRankingElementDto qre = rs.getAdmissionQuotaRankingElement();
            if (qre != null) {
                rs.setProcessStep(qre.getQuotaRanking().getRanking().getProcessStep());
                rs.setQuotaId(rs.getAdmissionQuotaRankingElement().getQuotaRanking().getQuotaId());
            } else {
                rs.setProcessStep(admissionService.createEmptyProcessStepDto());
            }
        } else {
            // If there is no admission: walk through former quota rankings
            // and look for an element with status "admitted, but deleted".
            // Set the quota for that element.
            ProcessStepDto currentProcessStep = findCurrentProcessStep(rs);
            if (currentProcessStep != null) { // is null if request subject changed without ranking list corrections
                rs.setProcessStep(currentProcessStep);
                for (QuotaRankingElementDto qre : rs.getQuotaRankingElements()) {
                    if (qre.getIsDeleted() != null && qre.getIsDeleted().equals(Integer.valueOf(0))) {
                        // Achtung vergleich mittels equals auf die ProcessStepDtos ist hier
                        // absichtlich nicht implementiert da die processStep unterschiedliche
                        // DtoIds haben können!! Bitte nicht ändern
                        if (qre.getAdmissionStatus().getHiskeyId().equals(ADMITTED.getKey()) &&
                                        qre.getQuotaRanking().getRanking().getProcessStep().getId().equals(currentProcessStep.getId())) {
                            rs.setQuotaId(qre.getQuotaRanking().getQuota().getId());
                            break;
                        }
                    }
                }
            } else {
                rs.setProcessStep(admissionService.createEmptyProcessStepDto());
            }
        }
    }

    @Override
    public void copyAts(RequestSubjectDto requestSubjectDto) {
        if(requestSubjectDto.getCourseOfStudy() != null) {
            RequestSubjectXtdDto rsxtd = (RequestSubjectXtdDto) requestSubjectDto;
            if (rsxtd.getCourseOfStudyBean() == null) {
                de.his.appserver.service.dto.iface.cm.app.CourseOfStudyBean courseOfStudyBean = new CourseOfStudyBeanImpl();
                rsxtd.setCourseOfStudyBean(courseOfStudyBean);
            }
            if (rsxtd.getCourseOfStudyBean().getDegreeId() == null) {
                rsxtd.getCourseOfStudyBean().setDegreeId(rsxtd.getCourseOfStudy().getDegreeId());
            }
            rsxtd.getCourseOfStudyBean().setSubjectId(rsxtd.getCourseOfStudy().getSubjectId());
            rsxtd.getCourseOfStudyBean().setMajorFieldOfStudyId(rsxtd.getCourseOfStudy().getMajorFieldOfStudyId());
            rsxtd.getCourseOfStudyBean().setCourseSpecializationId(rsxtd.getCourseOfStudy().getCourseSpecializationId());
            rsxtd.getCourseOfStudyBean().setSubjectIndicatorId(rsxtd.getCourseOfStudy().getSubjectIndicatorId());
            rsxtd.getCourseOfStudyBean().setPlaceOfStudiesId(rsxtd.getCourseOfStudy().getPlaceOfStudiesId());
            rsxtd.getCourseOfStudyBean().setEnrollmentId(rsxtd.getCourseOfStudy().getEnrollmentId());
            rsxtd.getCourseOfStudyBean().setTypeOfStudyId(rsxtd.getCourseOfStudy().getTypeOfStudyId());
            rsxtd.getCourseOfStudyBean().setFormOfStudiesId(rsxtd.getCourseOfStudy().getFormOfStudiesId());
            rsxtd.getCourseOfStudyBean().setExaminationversionId(rsxtd.getCourseOfStudy().getExaminationversionId());
            rsxtd.getCourseOfStudyBean().setCourseOfStudyTypeValueId(rsxtd.getCourseOfStudy().getCourseOfStudyTypeValueId());
            // orgunit (Fachbereich) TODO Internationalisierung testen
            if (rsxtd.getCourseOfStudy().getOrgunit() != null) {
                rsxtd.getCourseOfStudyBean().setOrgunitDefaultText(rsxtd.getCourseOfStudy().getOrgunit().getDefaulttext());
            }
        }
    }

    /**
     * @param rs
     * @return the highest MAIN_PROCESS or POST_PROCESS for the given requestSubject
     */
    private ProcessStepDto findCurrentProcessStep(RequestSubjectDto requestSubjectDto) {

        RequestSubjectXtdDto rsxDto = (RequestSubjectXtdDto) requestSubjectDto;
        AdmissionPackageDto admissionPackageDto = rsxDto.getAdmissionPackage();

        ProcessStepDto currentProcessStepDto = null;
        if (admissionPackageDto != null) {
            currentProcessStepDto = admissionService.findCurrentProcessStep(admissionPackageDto);
        }
        return currentProcessStepDto;
    }

    /**
     * @return List of Quotas possible for this RequestSubject for manual admission
     */
    @Override
    public List<QuotaDto> getQuotaByRequestSubject(RequestSubjectDto rs) {
        List<QuotaDto> quotaList = new ArrayList<QuotaDto>();
        ProcessStepDto currentProcessStep;

        if (rs.getAdmissionQuotaRankingElement() != null) {
            currentProcessStep = rs.getAdmissionQuotaRankingElement().getQuotaRanking().getRanking().getProcessStep();
        } else {
            currentProcessStep = findCurrentProcessStep(rs);
        }
        if (currentProcessStep == null) {
            return quotaList;
        }
        // use all Quotas of the highest processStep
        if(!currentProcessStep.isAllocationSchemeSet()) {
            loadDtoAttribute(currentProcessStep, ProcessStepDto.allocationScheme , asLoadPath(new AllocationSchemeDto.AllocationSchemePath().levels().quotas()));
        }
        for (QuotaLevelDto quotaLevelDto : currentProcessStep.getAllocationScheme().getLevels()) {
            for (QuotaDto quotaDto : quotaLevelDto.getQuotas()) {
                quotaList.add(quotaDto);
            }
        }
        return quotaList;
    }

    @Override
    public List<ExamplanDto> getZulExamplans(RequestSubjectDto requestSubjectDto) {
        if(!requestSubjectDto.isExamplansSet()) {
            String[] loadPath = asLoadPath(new ExamplanDto.ExamplanPath().unit().zulmissingdata());
            loadDtoAttribute(requestSubjectDto, RequestSubjectDto.examplans, loadPath);
        }
        Collection<ExamplanDto> examplanDtos = requestSubjectDto.getExamplans(); // Alle Leistungen zum Antragsstudiengang
        List<ExamplanDto> examplanDtoZulList = new ArrayList<ExamplanDto>();
        if (examplanDtos != null) {
            for (ExamplanDto examplanDto : examplanDtos) {
                if ((examplanDto.getUnit() != null) && examplanDto.getUnit().isZulunterlageAntragsstudiengang()) {
                    examplanDtoZulList.add(examplanDto);
                }
            }
        }
        return examplanDtoZulList;
    }

    @Override
    public boolean isPossibleToEnroll(RequestDto request) {
        if(request != null){
            RequestDto _request = null;
            if(request.getId() == null){
                _request = request;
            } else { // neu aus DB
                _request = searchRequest(request.getId());
            }
            logger.debug("RequestId: "+_request.getId());
            logger.debug("RequestStatus: "+_request.getRequestStatus().getDefaulttext());
            Collection<RequestSubjectDto> requestSubjects = _request.getRequestSubjects();
            for (RequestSubjectDto requestSubject : requestSubjects) {
                if(isPossibleToEnroll(requestSubject)){
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public boolean isPossibleToEnroll(RequestSubjectDto requestSubject) {
        logger.debug("RequestSubjectId: "+requestSubject.getId());
        logger.debug("RequestSubjectCourseOfStudy: "+requestSubject.getCourseOfStudy().getDefaulttext());
        logger.debug("RequestSubjectStatus: "+requestSubject.getRequestSubjectStatus().getDefaulttext());
        logger.debug("RequestSubject.isFree: "+((RequestSubjectXtdDto) requestSubject).isFree());
        if((REQUEST_SUBJECT_STATUS_HIS_KEYS.indexOf(requestSubject.getRequestSubjectStatus().getHiskeyId()) != -1)
            || ((RequestSubjectXtdDto) requestSubject).isFree()
                && !(RequestSubjectStatusEnum.REQUEST_FOR_ENROLLMENT_ACCEPTED.getHisKey().equals(requestSubject.getRequestSubjectStatus().getHiskeyId()))){
            logger.debug(requestSubject.getCourseOfStudy().getDefaulttext()+" isPossibleToEnroll !");
            return true;
        }
        logger.debug(requestSubject.getCourseOfStudy().getDefaulttext()+" isNotPossibleToEnroll !");
        return false;
    }

    @Override
    public List<String> validateRequestSubject(RequestSubjectDto requestSubjectDto) {
        EnsureArgument.notNull(requestSubjectDto, "requestSubjectDto must not be null");
        List<String> returnMessges = new ArrayList<String>();

        ApplicationDto applicationDto = requestSubjectDto.getRequestsubjectgroupRequestsubjects().iterator().next().getRequestsubjectgroup().getRequest().getRequestgroup().getApplication();

        // Nachsehen, ob der Bewerber bereits das Limit an zulässingen Anträgen erreicht hat
        boolean maxRequestsReached = this.applicationService.checkMaxRequestsReached(applicationDto.getId());
        if(maxRequestsReached) {
            returnMessges.add("cm.app.application.noRemainingRequests");
        }

        // Bei nicht-freien Studiengängen muss eine HZB zugeordnet sein
        if(!requestSubjectDto.isCourseOfStudyFree()) {
            Long entranceQualificationExamplanId = requestSubjectDto.getEntranceQualificationExamplanId();
            if(entranceQualificationExamplanId == null) {
                returnMessges.add("cm.app.application.noEntranceQualification");
            }
        }

        // Wurde ein Nachtilsausgleich  gestellt und nocht nicht bearbeitet
        List<AmendmentDto> amendments = requestSubjectDto.getAmendments();
        if(amendments != null) {

            Long amendmentStatusGestellt = null;
            Map<Long, AmendmentstatusValueDto> allAmendmentstatus = this.valueService.getAllAmendmentstatus(I18nUtils.getLang());
            for (AmendmentstatusValueDto amendmentstatusValueDto : allAmendmentstatus.values()) {
                if(amendmentstatusValueDto.getHiskeyId().equals(AmendmentstatusEnum.GESTELLT.getHisKey())) {
                    amendmentStatusGestellt = amendmentstatusValueDto.getId();
                    break;
                }
            }

            for (AmendmentDto amendmentDto : amendments) {
                if(amendmentDto.getAmendmentstatusId() == null ||
                                amendmentDto.getAmendmentstatusId().equals(amendmentStatusGestellt)) {
                    returnMessges.add("cm.app.application.amendment.filed");
                }
            }
        }

        return returnMessges;
    }

    @Override
    public List<RequestSubjectDto> findRequestSubjectsByCosIdsAndApplicantId(List<Long> cosIds, Long applicantId) {
        List<RequestSubjectDto> retVal = new ArrayList<RequestSubjectDto>();
        LoadCtx loadCtx = DtoFactoryTemplateBase.loadBegin();
        RequestSubjectPath rsPath = new RequestSubjectPath();

        String[] loadPath = DTOFactoryUtil.asLoadPath(
                        rsPath.courseOfStudy().admissionshares().admissionPackage().admissiontype(),
                        rsPath.courseOfStudy().subjectIndicator(),
                        rsPath.courseOfStudy().degree(),
                        rsPath.courseOfStudy().subject(),
                        rsPath.courseOfStudy().orgunit(),
                        rsPath.courseOfStudy().courseOfStudyTypeValue(), // wird für "Bewerbungen übernehmen" bei Studenten gebraucht
                        rsPath.courseOfStudy().courseOfStudyStart().courseOfStudyTypeValue(), // wird für "Bewerbungen übernehmen" bei Studenten gebraucht
                        rsPath.courseOfStudy().courseOfStudyStart().periodcontainerStudies().periodcontainer().periods(), // wird für "Bewerbungen übernehmen" bei Studenten gebraucht
                        rsPath.courseOfStudy().periodcontainerStudies().periodcontainer().periods(),
                        rsPath.selectedToEnrollCourseOfStudy().degree(), // wird für Bewerber/Bewerbungen übernehmen benötigt
                        rsPath.selectedToEnrollCourseOfStudy().subject(),
                        rsPath.entranceQualificationExamplan(),
                        rsPath.amendments(),
                        rsPath.amendments().amendmenttype(),
                        rsPath.admissionstatus(),
                        rsPath.reactionstatus(),
                        rsPath.examplans().defaultExamrelation().workstatus(),
                        rsPath.examplans().unit().zulmissingdata(),
                        rsPath.examplans().unit().elementtype(),
                        rsPath.examplans().accreditation(),
                        rsPath.admissionQuotaRankingElement().quotaRanking().ranking().processStep().allocationScheme().levels().quotas(),
                        rsPath.quotaRankingElements().admissionStatus(),
                        rsPath.quotaRankingElements().reactionStatus(),
                        rsPath.quotaRankingElements().quotaRanking().quota(),
                        rsPath.quotaRankingElements().quotaRanking().ranking().processStep().allocationScheme().levels().quotas(),
                        rsPath.admissionQuotaRankingElement(),
                        rsPath.requestSubjectStatus());

        List<RequestSubject> result = requestSubjectDao.findByCosIdsAndApplicantId(cosIds, applicantId);

        for (RequestSubject rs : result) {
            RequestSubjectDto requestSubjectDto = RequestSubjectDtoFactory.getDto(rs, loadCtx, loadPath);
            retVal.add(requestSubjectDto);
        }

        return retVal;
    }

    @Override
    public void updateRequestSubjectSelectedToEnrollCos(RequestSubjectDto requestSubject) {
        RequestSubject subject = requestSubjectDao.findById(requestSubject.getId());
        CourseOfStudy cos = null;

        if (requestSubject.getSelectedToEnrollCourseOfStudyId() != null) {
            cos = courseOfStudyDao.findById(requestSubject.getSelectedToEnrollCourseOfStudyId());
        }

        subject.setSelectedToEnrollCourseOfStudy(cos);
    }

    @Override
    public void undoImportedRequestSubject(Boolean undo, Set<DegreeProgramProgressDto> degreeProgramProgress) {
        for (DegreeProgramProgressDto dpp : degreeProgramProgress) {
            RequestSubjectDto requestSubject = ((DegreeProgramProgressXtdDto) dpp).getRequestSubject().getRequestSubject();

            if (undo != null && undo.booleanValue()) {
                if (requestSubject.getRequestSubjectStatus().getHiskeyId().equals(RequestSubjectStatusEnum.REQUEST_FOR_ENROLLMENT_ACCEPTED.getHisKey())
                                || requestSubject.getRequestSubjectStatus().getHiskeyId().equals(RequestSubjectStatusEnum.REQUEST_FOR_ENROLLMENT_IN_PROCESS.getHisKey())
                                || requestSubject.getRequestSubjectStatus().getHiskeyId().equals(RequestSubjectStatusEnum.REQUEST_FOR_ENROLLMENT_SUBMITTED.getHisKey())) {
                    requestSubjectStatusSwitch.undoRequestForEnrollment(requestSubject.getId(), false);
                    requestSubject.setRequestSubjectStatus(RequestSubjectStatusEnum.ADMISSION_OFFERED.getDto()); // den neuen Status merken - darf nicht gespeichert werden!

                    if (logger.ISDEBUG) {
                        logger.debug("undoImportedRequestSubjects() - Request for enrollment released: " + requestSubject.getCourseOfStudy().getDefaulttext());
                    }
                } else {
                    logger.warn("undoImportedRequestSubjects() - RequestSubject is not in state 'Request for enrollment accepted/in process/submitted'.");
                }
            } else {
                requestSubject.setSelectedToEnrollCourseOfStudy(dpp.getCourseOfStudy());
            }

            updateRequestSubjectSelectedToEnrollCos(requestSubject);
        }
    }

    @Override
    public RequestSubject findRequestSubject(Long requestSubjectId) {
        return requestSubjectDao.findById(requestSubjectId);
    }
    
    @Override
    public Set<Long> getAdmissionPackageIds(Set<RequestSubjectDto> requestSubjectDtos){
        Set<Long> admissionPackageIds = new HashSet<>();
        for (RequestSubjectDto requestSubjectDto : requestSubjectDtos){
            RequestSubject requestSubject = requestSubjectDao.findById(requestSubjectDto.getId());
            admissionPackageIds.add(requestSubject.getAdmissionPackage().getId());
        }
        return admissionPackageIds;
    }
    
    // Setters for DAOs and Services:

    /**
     * @param applicantDao
     */
    @Required
    public void setApplicantDao(ApplicantDao applicantDao) {
        this.applicantDao = applicantDao;
    }

    /**
     * @param courseOfStudyDao
     */
    @Required
    public void setCourseOfStudyDao(CourseOfStudyDao courseOfStudyDao) {
        this.courseOfStudyDao = courseOfStudyDao;
    }

    /**
     * @param applicationStatusValueDao
     */
    @Required
    public void setApplicationStatusValueDao(ApplicationStatusValueDao applicationStatusValueDao) {
        this.applicationStatusValueDao = applicationStatusValueDao;
    }

    /**
     * @param amendmenttypeDao
     */
    public void setAmendmenttypeDao(AmendmenttypeDao amendmenttypeDao) {
        this.amendmenttypeDao = amendmenttypeDao;
    }

    /**
     * @param unitDao Dao for Units
     */
    @Required
    public void setUnitDao(UnitDao unitDao) {
        this.unitDao = unitDao;
    }

    /**
     * @param unitrelationtypeDao the unitrelationtypeDao to set
     */
    @Required
    public void setUnitrelationtypeDao(UnitrelationtypeDao unitrelationtypeDao) {
        this.unitrelationtypeDao = unitrelationtypeDao;
    }

    /**
     * @param examplanDao
     */
    @Required
    public void setExamplanDao(ExamplanDao examplanDao) {
        this.examplanDao = examplanDao;
    }

    /**
     * @param workstatusDao the workstatusDao to set
     */
    @Required
    public void setWorkstatusDao(WorkstatusDao workstatusDao) {
        this.workstatusDao = workstatusDao;
    }

    /**
     * @param zulMissingDataDao the zulMissingDataDao to set
     */
    @Required
    public void setZulMissingDataDao(ZulMissingDataDao zulMissingDataDao) {
        this.zulMissingDataDao = zulMissingDataDao;
    }

    /**
     * @param termService the termService to set
     */
    @Required
    public void setTermService(TermService termService) {
        this.termService = termService;
    }

    /**
     * @param verwaltungsdatenService the verwaltungsdatenService to set
     */
    @Required
    public void setVerwaltungsdatenService(VerwaltungsdatenService verwaltungsdatenService) {
        this.verwaltungsdatenService = verwaltungsdatenService;
    }

    /**
     * @param admissionService
     */
    @Required
    public void setAdmissionService(AdmissionService admissionService) {
        this.admissionService = admissionService;
    }

    /**
     * @param entranceExamStatusDao
     */
    @Required
    public void setEntranceExamStatusDao(EntranceExamStatusValueDao entranceExamStatusDao) {
        this.entranceExamStatusDao = entranceExamStatusDao;
    }

    /**
     * @param amendmentService
     */
    @Required
    public void setAmendmentService(AmendmentService amendmentService) {
        this.amendmentService = amendmentService;
    }

    /**
     * @param requestDao the requestDao to set
     */
    @Required
    public void setRequestDao(RequestDao requestDao) {
        this.requestDao = requestDao;
    }

    /**
     * @param requestgroupDao the requestgroupDao to set
     */
    @Required
    public void setRequestgroupDao(RequestgroupDao requestgroupDao) {
        this.requestgroupDao = requestgroupDao;
    }

    /**
     * @param applicationDao the applicationDao to set
     */
    @Required
    public void setApplicationDao(ApplicationDao applicationDao) {
        this.applicationDao = applicationDao;
    }

    /**
     * @param requestStatusSwitch the requestStatusSwitch to set
     */
    @Required
    public void setRequestStatusSwitch(RequestStatusSwitch requestStatusSwitch) {
        this.requestStatusSwitch = requestStatusSwitch;
    }

    /**
     * @param requestSubjectStatusSwitch the requestSubjectStatusSwitch to set
     */
    @Required
    public void setRequestSubjectStatusSwitch(RequestSubjectStatusSwitch requestSubjectStatusSwitch) {
        this.requestSubjectStatusSwitch = requestSubjectStatusSwitch;
    }

    /**
     * @param valueService the valueService to set
     */
    @Required
    public void setValueService(ValueService valueService) {
        this.valueService = valueService;
    }

    /**
     * @param studentService the studentService to set
     */
    public void setStudentService(StudentService studentService) {
        this.studentService = studentService;
    }

    /**
     * @param applicationService the applicationService to set
     */
    public void setAppApplicationService(ApplicationService applicationService) {
        this.applicationService = applicationService;
    }

    /**
     * @param requestSubjectDao
     */
    public void setRequestSubjectDao(RequestSubjectDao requestSubjectDao) {
        this.requestSubjectDao = requestSubjectDao;
    }

    /**
     * @param selectionCriteriaService
     */
    public void setSelectionCriteriaService(SelectionCriteriaService selectionCriteriaService) {
        this.selectionCriteriaService = selectionCriteriaService;
    }

}

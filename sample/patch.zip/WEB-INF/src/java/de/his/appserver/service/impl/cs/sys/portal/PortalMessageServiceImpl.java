/*
 * Copyright (c) 2013 HIS GmbH All Rights Reserved.
 *
 * $Id: PortalMessageServiceImpl.java,v 1.54.8.1 2013-12-04 11:39:17 wassmann#his.de Exp $
 * $Log: PortalMessageServiceImpl.java,v $
 * Revision 1.54.8.1  2013-12-04 11:39:17  wassmann#his.de
 * Portalmeldungen nur senden, wenn Person auch einen Account hat (#99881)
 *
 * Revision 1.54  2013-02-25 13:56:41  schirmeister#his.de
 * #83952
 *
 * Revision 1.53  2013-02-19 12:36:18  koczewski#his.de
 * Versand der PortalMessage-Email erst nach erfolgreichem Commit.
 * Anfrage #83952 – Task: Benachrichtigungs-Email für Portalnachrichten wird auch dann Versand, wenn das Speichern der Portalnachricht fehl schlägt
 *
 * Revision 1.52  2013-02-12 14:28:21  paul#his.de
 * Zeile wieder einkommentiert, war ein Versehentlicher Commit.
 *
 * Revision 1.51  2013-02-12 13:51:37  wassmann#his.de
 * NPE verhindern wenn eine Kategorie nicht in der DB vorhanden ist
 *
 * Revision 1.50  2013-02-12 12:22:56  paul#his.de
 * Warnungen beseitigt.
 *
 * Revision 1.49  2013-01-24 17:10:13  mshenavai#werkstoffbit.de
 * verification of preliminary pictures
 *
 * Revision 1.48  2012-12-04 10:28:41  wassmann#his.de
 * Fuer alle Kategorien von Portalmeldungen Test-Meldungen erzeugt
 *
 * Revision 1.47  2012-11-29 11:21:50  wassmann#his.de
 * Weitere Attribute einer Person an das E-Mail Template ueber geben (#81382)
 *
 * Revision 1.46  2012-10-15 15:31:30  wassmann#his.de
 * category_uniquename mit an das Mail-Template uebergeben (#67778)
 *
 * Revision 1.45  2012-10-10 18:23:36  wassmann#his.de
 * Junit-Tests wieder zum laufen gebracht
 *
 * Revision 1.44  2012-09-14 13:31:33  wassmann#his.de
 * Fuer Portalmeldungen, die auch als E-Mail versendet werden einen eigenen Inhaltstext ermoeglichen (#77430)
 *
 * Revision 1.43  2012-09-10 13:46:15  wassmann#his.de
 * Bei Properties das Encoding der Werte ausschaulten koennen (#76691)
 *
 * Revision 1.42  2012-07-17 12:42:56  wassmann#his.de
 * todo
 *
 * Revision 1.41  2012-07-13 10:27:40  wassmann#his.de
 * E-Mail-Spam-Schutz fuer PortalMessageKategorie deaktiviieren koennen (#73138)
 *
 * Revision 1.40  2012-05-29 10:55:14  wagenmann#his.de
 * Klonen von Nachrichten korrigiert, so dass nun auch die Properties geklont werden. (fixes #70398)
 *
 * Revision 1.39  2012-05-07 17:05:07  koczewski#his.de
 * Debug-Ausgabe, wenn keine SPAM-Prevention zuschlägt
 *
 * Revision 1.38  2012-05-02 08:45:50  koczewski#his.de
 * Anfrage #68832 – PortalMessages werden an Telefonnummer gemailt
 *
 * Revision 1.37  2012-05-02 08:38:58  koczewski#his.de
 * Anfrage #68832 – PortalMessages werden an Telefonnummer gemailt
 *
 * Revision 1.36  2012-04-18 17:01:13  wassmann#his.de
 * Spamschutz deaktiveren koennen (#66261)
 *
 * Revision 1.35  2012-02-21 13:49:09  koczewski#his.de
 * Anfrage #59348 - Benachrichtigung des Bewerbers per Email bei falscher BID/BAN
 *
 * Revision 1.34  2012-02-07 14:46:56  wassmann#his.de
 * Refactoring einiger Methoden im PortalMessageService (#62996)
 *
 * Revision 1.33  2012-01-26 13:33:29  sass#his.de
 * #62264
 *
 * Revision 1.32  2011-11-17 17:04:00  hoersch#his.de
 * Service-Metadaten auf Annotationen umgestellt
 *
 * Revision 1.31  2011-11-17 16:34:07  wassmann#his.de
 * variable wird nicht mehr gebraucht
 *
 * Revision 1.30  2011-11-16 14:49:17  wassmann#his.de
 * Stellenauschreibungen als Feed
 *
 * Revision 1.29  2011-10-26 14:09:29  hoersch#his.de
 * Interface des UserprofileService in Interface-Paket verschoben
 *
 * Revision 1.28  2011-10-06 13:18:42  wassmann#his.de
 * Portalmeldungen auch mit Person-Object versenden, ohne viele Parameter
 *
 * Revision 1.27  2011-10-06 09:07:56  wassmann#his.de
 * NPE verhindern wenn Kategorie nicht in DB vorhanden
 *
 * Revision 1.26  2011-10-06 08:18:53  wassmann#his.de
 * Portalmeldung für Statusaenderungen (#49095)
 *
 * Revision 1.25  2011-09-26 12:54:39  wassmann#his.de
 * Verschiedene Fehlerkorrekturen: #54615, #54606, #54605, #54598, #54597
 *
 * Revision 1.24  2011-09-21 07:56:10  wassmann#his.de
 * Antispam beim Mail-Versand vervollstaendigt
 *
 * Revision 1.23  2011-09-20 07:43:02  wassmann#his.de
 * Portalmeldungen als E-Mail versenden verbesert, Antispam, Portal auch ohne Default-Config, Styleswitcher Default im UserProfile geaendert
 *
 * Revision 1.22  2011-09-19 11:35:30  wassmann#his.de
 * Nur Portalmeldung als E-Mail versenden, wenn es auch eine Adresse gibt
 *
 * Revision 1.21  2011-09-19 07:59:45  wassmann#his.de
 * #49265, #53575, #54014, #53196, #53687, #49095
 * - Portalswitcher: Wert im UserProfile speichern
 * - selectedId  nicht auswerten bei nicht persistenten Portlets
 * - Bei leerem Portal Reset anbieten
 * - Portlet aus Gruppe verschieben
 * - Navigationsmenue unter Studentisches Leben
 * - Portalmeldungen auch als E-Mail
 *
 * Revision 1.20  2011-08-16 15:24:11  wassmann#his.de
 * korrektes prufen auf aktiv (#51844)
 *
 * Revision 1.19  2011-08-16 15:10:07  wassmann#his.de
 * Aktivieren /Deaktivieren von einzelnen Portalmeldungen unterstuetzen
 *
 * Revision 1.18  2011-08-15 16:38:07  wassmann#his.de
 * Portalmeldungen aktiven eingebaut
 *
 * Revision 1.17  2011-08-15 16:11:02  wassmann#his.de
 * Jede Kategorie nur einmal anzeigen (#51693)
 *
 * Revision 1.16  2011-08-03 13:19:54  wassmann#his.de
 * Verfahren zum ermitteln ob es etwas Neues in der Infobox gibt, integration time auf Minuten geaendert, Testdaten angepasst
 *
 * Revision 1.15  2011-08-02 09:47:46  wassmann#his.de
 * Parameterersetzung in URLs von Portalmeldungen
 *
 * Revision 1.14  2011-07-04 16:42:54  wassmann#his.de
 * setzen der Kategorie bei neuen Meldungen
 *
 * Revision 1.13  2011-07-04 11:23:10  wassmann#his.de
 * Portalmeldungen auch als E-Mail versenden und hochschuleigene Kategorien von Portalmeldungen ermoeglicht
 *
 * Revision 1.12  2011-07-01 14:31:38  wassmann#his.de
 * Portalmeldungen Admin GUI und Erweiterung der Infobox
 *
 * Revision 1.11  2011-06-30 08:06:12  hoersch#his.de
 * PortalMessageCategory-spezifischen Code ins Enum ausgelagert um switch/cases zu vermeiden
 *
 * Revision 1.10  2011-06-29 14:31:16  reifschneider#his.de
 * send job completion portal messages
 *
 * Revision 1.9  2011-03-25 13:14:21  wassmann#his.de
 * Verschiedene Fehler im Portal und PortalMessages behoben; Neue Portalmeldungen; Senden von Meldungen; Kommentare im JavaDoc; weitere Konfigurationsmoeglichkeiten
 *
 * Revision 1.8  2011-03-23 13:15:48  wassmann#his.de
 * Beispiel fuer Portalmeldungen und Weiterentwicklung
 *
 * Revision 1.7  2011-03-02 16:21:27  hoersch#his.de
 * EntityEnhancer/DTOGenerator
 *
 * Revision 1.6  2011-03-01 12:56:41  wassmann#his.de
 * Portalmeldungen auch als Feed bereitstellen
 *
 * Revision 1.5  2011-02-28 12:41:27  wassmann#his.de
 * weitere send-Methoden
 *
 * Revision 1.4  2011-02-28 12:36:20  wassmann#his.de
 * header-text
 *
 * Revision 1.3  2011-02-28 11:59:08  wassmann#his.de
 * internationalisierte Testmeldung
 *
 * Revision 1.2  2011-02-28 09:05:18  wassmann#his.de
 * Portalmeldungen an DB angeschlossen
 *
 * Revision 1.1  2011-02-10 16:15:32  wassmann#his.de
 * Prototyp (Mockup) fuer Portalmeldungen (#40849)
 *
 */
package de.his.appserver.service.impl.cs.sys.portal;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.criterion.Order;

import com.google.common.base.Strings;
import com.sun.syndication.feed.synd.SyndContent;
import com.sun.syndication.feed.synd.SyndContentImpl;
import com.sun.syndication.feed.synd.SyndEntry;
import com.sun.syndication.feed.synd.SyndEntryImpl;
import com.sun.syndication.feed.synd.SyndFeed;

import de.his.appserver.model.cs.psv.userprofile.UserProfile;
import de.his.appserver.model.cs.sys.portal.messages.PortalMessage;
import de.his.appserver.model.cs.sys.portal.messages.PortalMessageCategory;
import de.his.appserver.model.cs.sys.portal.messages.PortalMessageProperty;
import de.his.appserver.model.cs.sys.portal.messages.PortalMessageText;
import de.his.appserver.model.psv.EMail;
import de.his.appserver.model.psv.Person;
import de.his.appserver.persistence.dao.iface.DaoConfig;
import de.his.appserver.persistence.dao.iface.cs.psv.userprofile.UserProfileDao;
import de.his.appserver.persistence.dao.iface.cs.sys.portal.message.PortalMessageCategoryDao;
import de.his.appserver.persistence.dao.iface.cs.sys.portal.message.PortalMessageDao;
import de.his.appserver.persistence.dao.iface.psv.his.PersonDao;
import de.his.appserver.service.ServiceTokenSendingSendMailException;
import de.his.appserver.service.base.ServiceBaseImpl;
import de.his.appserver.service.base.ServiceMetadata.ServiceImplMetadata;
import de.his.appserver.service.dto.gen.PortalMessageCategoryDtoFactory;
import de.his.appserver.service.dto.gen.iface.EAddressDto;
import de.his.appserver.service.dto.iface.cs.sys.portal.PortalMessageDto;
import de.his.appserver.service.dto.impl.cs.sys.portal.PortalMessageDtoImpl;
import de.his.appserver.service.iface.common.event.CallbackAdapter;
import de.his.appserver.service.iface.common.event.InternalEventService;
import de.his.appserver.service.iface.cs.psv.person.AddressService;
import de.his.appserver.service.iface.cs.psv.userprofile.UserProfileService;
import de.his.appserver.service.iface.cs.sys.portal.PortalMessageService;
import de.his.appserver.service.iface.cs.sys.portal.RSSFeedService;
import de.his.core.net.mail.SendEnvelope;
import de.his.core.net.mail.TemplatingMailer;
import de.his.core.util.cs.sys.configuration.Conf;
import de.his.core.webapp.qis.ConfigUtil;
import de.his.core.webapp.spring.SpringApplicationContext;
import de.his.tools.QISStringUtil;

/**
 * Service für Portal Meldungen des personaliserbaren HISinOne-Portals. Wird für das Portalmeldungen-Portlet benötigt.
 *
 * TODO: sendMessage in einen eigenen Thread auslagern?
 *
 * @author Wassmann
 * @version $Id: PortalMessageServiceImpl.java,v 1.54.8.1 2013-12-04 11:39:17 wassmann#his.de Exp $
 */
@ServiceImplMetadata(serviceRevision = "$Revision: 1.54.8.1 $")
public class PortalMessageServiceImpl extends ServiceBaseImpl implements PortalMessageService {

    private static final Logger logger = Logger.getLogger(PortalMessageServiceImpl.class);

    private PersonDao personDao;
    private PortalMessageDao portalMessageDao;
    private PortalMessageCategoryDao portalMessageCategoryDao;
    private UserProfileService userProfileService;
    private UserProfileDao userProfileDao;
    private TemplatingMailer templatingMailer;
    private AddressService addressService;
    private RSSFeedService rssFeedService;
    InternalEventService eventService;
    private boolean isTestMode = false;

    //Sind Portalmeldungen aktiv?
    private static final String CONFKEY_MESSAGESACTIVE = "core.sys.customizing.portal.messages.active";

    /**
     * Constructor
     */
    PortalMessageServiceImpl() {
        //
    }

    /**
     * Service im Test-Modus betreiben
     * @param isTestMode
     */
    @Override
    public void setTestMode(boolean isTestMode) {
        this.isTestMode = isTestMode;
    }

    /**
     * Portalmeldung als E-Mail versenden
     *
     * @param surname
     * @param firstname
     * @param recipientMail
     * @param gender
     * @param qisUrl
     * @param account
     * @param language
     * @param portalMessage
     */
    private void sendMail(Person person, String recipientMail, String gender, PortalMessageDto portalMessage) {
        String subject = portalMessage.getMessage().get("de").get("header");
        //Ermögliche einen anderen Text für den Mailinhalt: Achtung wird noch mit dem Mail-Tempalte gemischt!
        String content = portalMessage.getMessage().get("de").get("mail_content");
        if (Strings.isNullOrEmpty(content)) {
            content = subject;
        }
        Map<String, Object> model = new HashMap<String, Object>();
        model.put("name", person.getSurname());
        model.put("vorname", person.getFirstname());

        model.put("artistname", person.getArtistname());
        model.put("allfirstnames", person.getAllfirstnames());
        model.put("birthcity", person.getBirthcity());
        model.put("birthdate", person.getBirthdate());
        model.put("birthname", person.getBirthname());
        model.put("country", person.getCountry());

        model.put("title", person.getTitle());
        model.put("nameprefix", person.getNameprefix());
        model.put("namesuffix", person.getNamesuffix());

        model.put("email", recipientMail);
        model.put("personGender_type", gender);
        model.put("hochschulname", ConfigUtil.getHochschulName());
        model.put("subject", content);
        model.put("category_uniquename", portalMessage.getUniqueName());
        model.put("topic", portalMessage.getCategoryName());

        try {
            //TODO i18n, Sprache in userProfile merken und auslesen
            SendEnvelope envelope = SendEnvelope
                                        .forRecipient(recipientMail)
                                        .fromSender(getReplyMailAddress())
                                        .withSubject(subject)
                                        .withPreferredLocale(new Locale("de"));
            //kann die Portalmeldung als E-Mail versendet werden?
            if (!portalMessage.getPublishedDate().after(new Date())) {
                registerSendMailAfterCommited(model, envelope);
            } else {
                registerSendMailAfterCommited(model, envelope);
            }

        } catch (Exception e) {
            logger.warn("Error while sending portalmessage as e-mail", e);
            //TODO
            throw new ServiceTokenSendingSendMailException("error.sys.Portalmessage.emailDeliveryFailed");
        }        
    }

    private void registerSendMailAfterCommited(final Map<String, Object> model, final SendEnvelope envelope) {
        final TemplatingMailer myMailer = templatingMailer;
        eventService.registerCallback(new CallbackAdapter() {
            @Override
            public void onAfterTransactionCompletion(boolean wasCommitted) {
                eventService.removeCallback(this);
                if (wasCommitted) {
                    myMailer.sendMail(envelope, model);
                }
                
            }
            
            
        });
    }

    private String getReplyMailAddress() {
        //TODO: Absende Email
        String replyMailAddress = Conf.getString(Conf.CS.SYS.CUSTOMIZING_PORTAL_MESSAGES_MAIL_NOREPLYEMAILADDRESS.getKey());
        if (replyMailAddress != null && !replyMailAddress.isEmpty()) {
            return replyMailAddress;
        }

        return "Bitte Absenderaddresse konfigurieren: core.sys.customizing.portal.messages.mail.noreplyemailaddress)";
    }

    @Override
    public void sendPortalMessageByPersonIds(List<Long> personIdList, PortalMessageCategoryType category, Date publishedDate, Date expiredDate, String... params) {
        List<Person> personList = personDao.findAllById(personIdList);
        if (personList == null || personList.isEmpty()) {
            logger.error("Konnte keine Portalmeldungen erzeugen, weil es keine Personen gab ...");
            return;
        }
        sendPortalMessageToPersons(personList, category, publishedDate, expiredDate, params);
    }

    @Override
    public void sendPortalMessageToPersons(List<Person> personList, PortalMessageCategoryType category, Date publishedDate, Date expiredDate, String... params) {
        if (!Conf.getBoolean(CONFKEY_MESSAGESACTIVE, Boolean.FALSE).booleanValue()) {
            logger.warn("Konnte keine Portmeldung erzeugen, weil Portalmeldungen in der Globalen Konfiguration nicht aktiviert wurden.");
            return;
        }

        PortalMessageCategory cat = loadPortalMessageCategory(category);
        if (!Boolean.TRUE.equals(cat.getActive())) {
            logger.info("Portalmeldung wurde nicht verschickt, weil die Kategorie '"+category+ "' nicht aktiv ist.");
            return;
        }

        //Dummy holen
        PortalMessage portalMessage = createNewPortalMessage(null, category, publishedDate, expiredDate, params);
        if (portalMessage == null) {
            return;
        }
        //Clone vom Dummy für jede Person speichern
        for (Person person : personList) {
            PortalMessage pm = new PortalMessage(portalMessage);
            pm.setPerson(person);
            portalMessageDao.makePersistent(pm);
            //TODO sendMail
            if (Boolean.TRUE.equals(pm.getPortalMessageCategory().getSendAsEmail())) {
                try {
                    PortalMessageDto dto = preparePortalMessageDto(portalMessage);
                    sendMail(person, dto, cat.getMailSpamProtected());
                } catch (Exception e) {
                    logger.error("Konnte zu der Portalmessage " +portalMessage.getPortalMessageCategory().getUniquename()+ "E-Mail an PersonId "+person.getId()+" versenden.",e);
                }
            }
        }

    }

    private PortalMessageCategory loadPortalMessageCategory(PortalMessageCategoryType category) {
        PortalMessageCategory cat = portalMessageCategoryDao.findByUniqueName(category.name());
        if (cat == null) {
            logger.error("Konnte keine Portalmeldungkategorie mit dem Namen in der DB '"+category.name()+"' finden.");
            return null;
        }
        if (isTestMode) {
            //Im Testbetrieb keine Mails versenden
            cat.setSendAsEmail(Boolean.FALSE);
            //Im Testbetrieb alle Kategorien aktivieren
            cat.setActive(Boolean.TRUE);
        }
        return cat;
    }

    @Override
    public void savePortalMessageCategory(de.his.appserver.service.dto.gen.iface.PortalMessageCategoryDto dto) {
        PortalMessageCategoryDtoFactory.saveDto(dto);
    }


    /**
     * Sende eine Portalmeldung per E-Mail an diese Person
     * @param person
     * @param pm
     * @param spamProtected
     */
    private void sendMail(Person person, PortalMessageDto pm, Boolean spamProtected) {

        //TODO welche Email?
        String emailAdress = "";
        //FIXME Hack für APP, hier sollte ein allgmein gültiges Konzept her, bspw. durch die Kategorie konfiguriert
        if (pm.getUniqueName().startsWith("APP_")) {
            List<EAddressDto> listOfEAdresses = addressService.searchEAddress(person.getId(), "person", Long.valueOf(1));
            for (EAddressDto eAddress : listOfEAdresses) {
                if (eAddress.isEmail()) {
                    emailAdress = eAddress.getEaddress();
                    break;
                }
            }
        }
        //FIXME: Standardfall, nimm einfach die erste ...
        if (emailAdress.isEmpty()) {
            if (person.getEmailList() != null && !person.getEmailList().isEmpty()) {
                EMail mail = person.getEmailList().get(0);
                emailAdress = mail.getEaddress();
            }
        }

        //Gibt es eine E-Mail-Adresse?
        if (!emailAdress.isEmpty()) {
            String uniqueName = pm.getUniqueName();
            //Antispam

//            String antispam = ConfigUtil.getProperty("PORTAL_MESSAGE_ANTISPAM", "Y");
            String sendMailToCategories = userProfileService.getValue(person.getId(), "cs.sys.portal.message.sendMailToCategories");
            List<String> sendedMailToCategoriesList = new ArrayList<String>();
            if (sendMailToCategories != null && !sendMailToCategories.isEmpty()) {
                sendedMailToCategoriesList = QISStringUtil.stringToListWithEmptyEntries(sendMailToCategories, ',');
                //Es wurde bereits eine Liste mit dieser Kategorie versendet.
                //Erst nach dem nächsten Login wird wieder eine E-Mail mit dieser Kategorie versendet
                if (Boolean.TRUE.equals(spamProtected)) {
                    if (sendedMailToCategoriesList.contains(uniqueName)) {
                        //Spam verhindern
                        logger.debug("Portalmeldung wird nicht als E-Mail versendet, um SPAM zu verhindern");
                        return;
                    }
                }
            }

            sendMail(person, emailAdress, person.getGender().getUniquename(), pm);
            sendedMailToCategoriesList.add(uniqueName);
            userProfileService.save(person.getId(), "cs.sys.portal.message.sendMailToCategories", QISStringUtil.listToString(sendedMailToCategoriesList, ","), "");
        } else {
            logger.info("Konnte keine Portalmeldung als E-Mail versenden: Die Person mit der Id " + person.getId() + " hat keine E-Mail Adresse");
        }
    }

    @Override
    public void sendPortalMessageToPerson(Person person, PortalMessageCategoryType category, Date publishedDate, Date expiredDate, String... params) {
        if (!Conf.getBoolean(CONFKEY_MESSAGESACTIVE, Boolean.FALSE).booleanValue()) {
            logger.warn("Konnte keine Portmeldung erzeugen, weil Portalmeldungen in der Globalen Konfiguration nicht aktiviert wurden.");
            return;
        }

        PortalMessageCategory cat = loadPortalMessageCategory(category);
        if (cat == null) {
            logger.debug("Eine Category mit dem Name '" +category+ "' konnte in der DB nicht gefunden werden. Eine Portalmeldung kann daher nicht versendet werden.");
            return;
        }
        if (!Boolean.TRUE.equals(cat.getActive())) {
            logger.info("Portalmeldung wurde nicht verschickt, weil die Kategorie '"+category+ "' nicht aktiv ist.");
            return;
        }
        
        //Die Person muss einen Account haben, damit Sie sich später auch im
        //System anmelden kann.
        if (Conf.getBoolean(Conf.CS.SYS.CUSTOMIZING_PORTAL_MESSAGES_ONLYMESSAGESTOPERSONSWITHACCOUNTS.getKey(), true)) {
            if (person == null || person.getAccounts() == null || person.getAccounts().size() < 1) {
                return;
            }
        }
        
        try {
            //Neue PortalMessage erzeugen
            PortalMessage portalMessage = createNewPortalMessage(person, category, publishedDate, expiredDate, params);
            if (portalMessage != null) {
                //Speichern
                portalMessageDao.makePersistent(portalMessage);
                //TODO sendmail
                if (Boolean.TRUE.equals(portalMessage.getPortalMessageCategory().getSendAsEmail())) {
                    try {
                        PortalMessageDto dto = preparePortalMessageDto(portalMessage);
                        sendMail(person, dto, cat.getMailSpamProtected());
                    } catch (Exception e) {
                       logger.error("Konnte zu der Portalmessage '" +portalMessage.getPortalMessageCategory().getUniquename()+ "' keine E-Mail an PersonId "+person.getId()+" versenden.",e);
                    }
                }
            }
        } catch (Exception e) {
            logger.error("Konnte keine Meldung erzeugen: " + e.getMessage(),e);
        }
    }

    /**
     * Erzeugt eine neue PortalMessage
     *
     * @param person
     * @param category
     * @param publishedDate
     * @param expiredDate
     * @param params
     * @return PortalMessage
     */
    private PortalMessage createNewPortalMessage(Person person, PortalMessageCategoryType category, Date publishedDate, Date expiredDate, String... params) {

        //Wenn es sich um diese PortalMessageCategories handelt muss eine Ausnahme geprüft werden
        if (category.equals(PortalMessageCategoryType.NEW_PORTLET)) {
            if (params == null || params[1] == null || params[1].isEmpty()) {
                logger.error("Für die PortalMessageCategory 'NEW_PORTLET' wurden nicht alle erforderlichen Parameter übergeben!");
                return null;
            }
            if (!portalMessageDao.findByPropertyValue(params[1]).isEmpty()) {
                //Bereits eine entsprechende Meldung versendet
                return null;
            }
        }

        PortalMessage portalMessage = new PortalMessage();
        if (expiredDate != null) { //Defaultverhalten, läuft nie ab, wird aber irgendwann nicht mehr von der GUI angezeigt
            portalMessage.setExpiredDate(expiredDate);
        }
        portalMessage.setIsDeleted(Boolean.FALSE);
        portalMessage.setIsNew(Boolean.TRUE); //Neue Nachricht
        portalMessage.setPerson(person);
        if (publishedDate == null) {
            //Defaultverhalten
            portalMessage.setPublishedDate(new Date());
        } else {
            portalMessage.setPublishedDate(publishedDate);
        }
        setPortalMessageCategory(portalMessage, category);
        setPortalMessageProperties(portalMessage, category, params);
        return portalMessage;
    }

    /**
     * Setzt die Kategorie einer Meldung
     *
     * @param portalMessage
     * @param categoryUniqueName
     */
    private void setPortalMessageCategory(PortalMessage portalMessage, PortalMessageCategoryType category) {
        PortalMessageCategory portalMessageCategory = portalMessageCategoryDao.findByUniqueName(category.toString());
        if (isTestMode) {
            //Im Testbetrieb keine Mails versenden
            portalMessageCategory.setSendAsEmail(Boolean.FALSE);
            //Im Testbetrieb alle Kategorien aktivieren
            portalMessageCategory.setActive(Boolean.TRUE);
        }
        portalMessage.setPortalMessageCategory(portalMessageCategory);
    }

    /**
     * Setzt abhängig von der Kategorie die Properties
     *
     * @param portalMessage
     * @param params
     * @param categoryUniqueName
     */
    private void setPortalMessageProperties(PortalMessage portalMessage, PortalMessageCategoryType category, String[] params) {
        try {
            PortalMessageCategoryType cat = category;
            if (cat == null) {
                cat = PortalMessageCategoryType.DEFAULT;
            }
            cat.addPortalMessageProperties(portalMessage, params);
        } catch (Exception e) {
            logger.error("Fehler beim erzeugen der Properties: " + e.getMessage(), e);
        }
    }

    @Override
    public void sendPortalMessageByPersonId(Long personId, PortalMessageCategoryType category, Date publishedDate, Date expiredDate, String... params) {
        personDao = (PersonDao) SpringApplicationContext.getBean("personDao"); //TODO: warum klappt das anders nicht?
        //Lade Person
        Person person = personDao.findById(personId);
        if (person == null) {
            logger.error("Konnte keine Meldung erzeugen für Person mit der ID " + personId + ", weil keine Person in der DB gefunden werden konnte.");
            return;
        }
        sendPortalMessageToPerson(person, category, publishedDate, expiredDate, params);
    }

    @Override
    public List<PortalMessageDto> getPortalMessagesForPerson(Long personId) {
        List<PortalMessageDto> portalMessageDtos = new ArrayList<PortalMessageDto>();
        //"Alle" Meldungen einer Person finden die gültig sind
        List<PortalMessage> list = portalMessageDao.findByPersonId(personId);
        if (list == null) {
            return null;
        }
        for (PortalMessage portalMessage : list) {
            //Entity zu DTO
            PortalMessageDto dto = preparePortalMessageDto(portalMessage);

            //Nur eine Meldung anzeigen, wenn es mehrere der selben Kategorie gibt und die im gültigen Zeitraum liegen
            if (!integrateDto(dto,portalMessageDtos,portalMessage.getPortalMessageCategory().getIntegratePeriod())) {
                portalMessageDtos.add(dto);
            }

            //Wenn einmal angezeigt, dann ist die Meldung nicht mehr neu ...
            if (dto.isNewMessage()) {
                portalMessageDao.setNewToFalse(portalMessage.getId());
            }

        }
        return portalMessageDtos;
    }

    /**
     * Kopiert die Daten eines Entities in ein DTO
     *
     * @param portalMessage
     * @return PortalMessageDto
     */
    private PortalMessageDto preparePortalMessageDto(PortalMessage portalMessage) {
        PortalMessageDto dto = new PortalMessageDtoImpl();
        dto.setId(portalMessage.getId());
        dto.setNewMessage(portalMessage.getIsNew().booleanValue());
        dto.setPublishedDate(portalMessage.getPublishedDate());
        setMessageText(portalMessage, dto);
        dto.setLinkTarget(portalMessage.getPortalMessageCategory().getLinkTarget());
        dto.setLinkUrl(repleaceUrlParameter(portalMessage.getPortalMessageCategory().getLinkUrl(), portalMessage.getPortalMessageProperties()));
        dto.setUniqueName(portalMessage.getPortalMessageCategory().getUniquename());
        dto.setCategoryName(portalMessage.getPortalMessageCategory().getCategoryName());
        dto.setIcon(portalMessage.getPortalMessageCategory().getIcon());
        dto.setChildren(new ArrayList<PortalMessageDto>()); // NPE immer verhindern
        return dto;
    }

    /**
     * Ersetzt alle Platzhalter in einer URL durch seine Properties
     *
     * @param linkUrl
     * @param list
     * @return String
     */
    private String repleaceUrlParameter(String linkUrl, List<PortalMessageProperty> list) {
        if (linkUrl == null) {
            return null;
        }
        if (!(linkUrl.contains("[") && linkUrl.contains("]"))) {
            return linkUrl;
        }

        Map<String, String> propMap = createPropertyMap(list);
        String url = QISStringUtil.argsubst(linkUrl, propMap);
        return url;
    }

    /**
     * Erzeugt aus einer Liste mit PortalMessageProperty's eine Map
     *
     * @param list
     * @return Map<String, String>
     */
    private Map<String, String> createPropertyMap(List<PortalMessageProperty> list) {
        if (list == null || list.isEmpty()) {
            return null;
        }
        Map<String, String> propMap = new HashMap<String, String>();
        for (PortalMessageProperty portalMessageProperty : list) {
            propMap.put(portalMessageProperty.getPropertyKey(), portalMessageProperty.getPropertyValueEncoding() ? QISStringUtil.encodeURL(portalMessageProperty.getPropertyValue()) : portalMessageProperty.getPropertyValue() );
        }
        return propMap;
    }

    /**
     * Konnte die Meldung zusammengefasst werden?
     *
     * @param dto
     * @param portalMessageDtos
     * @return boolean
     */
    private boolean integrateDto(PortalMessageDto dto, List<PortalMessageDto> portalMessageDtos, Long integratePeriod) {
        for (PortalMessageDto portalMessageDto : portalMessageDtos) {
            if (portalMessageDto.getUniqueName().equals(dto.getUniqueName()) && checkIntegratePeriod(integratePeriod, portalMessageDto.getPublishedDate(), dto.getPublishedDate())) {
                portalMessageDto.getChildren().add(dto);
                return true;
            }
        }
        return false;
    }

    /**
     * Dürfen die Meldungen zusammengefasst werden, weil der Zeitraum ok ist?
     *
     * @param integratePeriod
     * @param publishedDate
     * @param publishedDate2
     * @return boolean
     */
    private boolean checkIntegratePeriod(Long integratePeriod, Date publishedDate, Date publishedDate2) {
        long time = publishedDate.getTime() - publishedDate2.getTime();
        long i = integratePeriod.longValue();
        i = i * 60 * 1000; // Von einer Minute ausgehen
        return time < i;
    }

    private Map<String, String> portalMessageTextListToMap(List<PortalMessageText> list) {
        Map<String, String> map = new HashMap<String, String>();
        for (PortalMessageText portalMessageText : list) {
            map.put(portalMessageText.getMessageKey(), portalMessageText.getMessageText());
        }
        return map;
    }

    /**
     * Setzt den Text zusammen. Ist abhängig von der Kategorie der Meldung
     * @param portalMessage
     * @param dto
     */
    private void setMessageText(PortalMessage portalMessage, PortalMessageDto dto) {
        //Sprache, <MessageKey, Übersetzer und mit Properties ergänzter Text>
        Map<String, Map<String, String>> text = new HashMap<String, Map<String,String>>();

        try {
            PortalMessageCategoryType category = PortalMessageCategoryType.valueOf(portalMessage.getPortalMessageCategory().getUniquename());
            if (category == null) {
                category = PortalMessageCategoryType.DEFAULT;
            }

            PortalMessageCategory portalMessageCategory = portalMessage.getPortalMessageCategory();
            Map<String, String> textMap = portalMessageTextListToMap(portalMessageCategory.getPortalMessageTexts());
            text = category.getTexts(portalMessage, textMap);
        } catch (Exception e) {
            logger.error(e,e);
        }

        //Text hinzufügen
        dto.setMessage(text);
    }

    /**
     * @param personDao
     */
    public void setPersonDao(PersonDao personDao) {
        this.personDao = personDao;
    }

    @Override
    public void deleteMessage(Long messageId) {
        if (messageId == null) {
            return;
        }
        portalMessageDao.deleteMessage(messageId);
    }

    @Override
    public void resetIndividualSettings(Long personId) {
        portalMessageDao.resetIndividualSettings(personId);
    }

    /**
     * @param portalMessageDao
     */
    public void setPortalMessageDao(PortalMessageDao portalMessageDao) {
        this.portalMessageDao = portalMessageDao;
    }

    /**
     * @param portalMessageCategoryDao
     */
    public void setPortalMessageCategoryDao(PortalMessageCategoryDao portalMessageCategoryDao) {
        this.portalMessageCategoryDao = portalMessageCategoryDao;
    }

    /**
     * @param addressService
     */
    public void setAddressService(AddressService addressService) {
        this.addressService = addressService;
    }

    @Override
    public void sendPortalMessageByPersonIds(List<Long> personIdList, PortalMessageCategoryType category, String... params) {
        sendPortalMessageByPersonIds(personIdList, category, new Date(), null, params);
    }

    @Override
    public void sendPortalMessageByPersonId(Long personId, PortalMessageCategoryType category, String... params) {
       sendPortalMessageByPersonId(personId, category, new Date(), null, params);
    }

    @Override
    public void sendPortalMessageToPersons(List<Person> personList, PortalMessageCategoryType category, String... params) {
        sendPortalMessageToPersons(personList, category,  new Date(), null, params);
    }

    @Override
    public SyndFeed getPortalMessageFeed(String identifier, String serverUrl, String contextPath) {
        UserProfile userProfile = userProfileDao.findByIdentifierToken(identifier);
        if (userProfile == null) {
            return null;
        }
        List<PortalMessage> messages = this.portalMessageDao.findByPersonId(userProfile.getPerson().getId());
        return createFeed(messages, serverUrl, contextPath);
    }


    /**
     * Erzeugt einen Feed aus Portalmeldungen
     * TODO: Feed internationaliserien
     *
     * @param messages
     * @param contextPath
     * @return SyndFeed
     */
    private SyndFeed createFeed(List<PortalMessage> messages, String serverUrl, String contextPath) {
        SyndFeed feed = rssFeedService.createFeed(serverUrl, "Persönliche Meldungen", "Meine Persönlichen Meldungen als Feed.", "de");

        //Feed-Einträge
        List<SyndEntry> syndEntryList = new ArrayList<SyndEntry>();
        for (PortalMessage portalMessage : messages) {
            SyndEntry entry = new SyndEntryImpl();
            String link = serverUrl; //TODO Default soll die URL zu diesem System sein
            try {
                //In DTO umwandeln, damit bereits die Meldungen und andere Attribute richtig zusammen gesetzt sind.
                PortalMessageDto dto = preparePortalMessageDto(portalMessage);
                //Titel des Eintrags
                entry.setTitle(dto.getMessage().get("de").get("header"));
                //Link
                if (dto.getLinkUrl() != null && !dto.getLinkUrl().isEmpty()) {
                    link += contextPath + dto.getLinkUrl();
                }
                entry.setLink(link);
                //Gibt es weitere Infos?
                if (dto.getMessage().get("de").containsKey("detail")) {
                    SyndContent content = new SyndContentImpl();
                    content.setValue(dto.getMessage().get("de").get("detail"));
                    entry.setDescription(content);
                }

                //Datum
                entry.setPublishedDate(dto.getPublishedDate());
                syndEntryList.add(entry);
            } catch (Exception e) {
                logger.debug("Eine Meldung konnte nicht in ein Feed-SyndEntry umgewandelt werden.", e);
                continue;
            }
        }
        feed.setEntries(syndEntryList);
        return feed;
    }

    /**
     * @param userProfileService
     */
    public void setUserProfileService(UserProfileService userProfileService) {
        this.userProfileService = userProfileService;
    }

    /**
     * @param userProfileDao
     */
    public void setUserProfileDao(UserProfileDao userProfileDao) {
        this.userProfileDao = userProfileDao;
    }

    @Override
    public List<de.his.appserver.service.dto.gen.iface.PortalMessageCategoryDto> getAllPortalMessageCategories() {
        List<PortalMessageCategory> portalMessageCategoryList = portalMessageCategoryDao.findAll(new DaoConfig().addOrder(Order.asc("uniquename")));
        List<de.his.appserver.service.dto.gen.iface.PortalMessageCategoryDto> dtos = new ArrayList<de.his.appserver.service.dto.gen.iface.PortalMessageCategoryDto>();
        List<String> uniquenames = new ArrayList<String>();
        for (PortalMessageCategory portalMessageCategory : portalMessageCategoryList) {
            if (uniquenames.contains(portalMessageCategory.getUniquename())) {
                continue;
            }
            uniquenames.add(portalMessageCategory.getUniquename());
            dtos.add(PortalMessageCategoryDtoFactory.getDto(portalMessageCategory, "portalMessageTexts"));
        }
        return dtos;
    }

    @Override
    public Long countMessagesByCategory(String uniquename) {
        return portalMessageDao.countMessages(uniquename);
    }


    /**
     * @param templatingMailer
     */
    public void setTemplatingMailer(TemplatingMailer templatingMailer) {
        this.templatingMailer = templatingMailer;
    }

    @Override
    public void sendPortalMessageToPerson(Person person, PortalMessageCategoryType category, String... params) {
        sendPortalMessageToPerson(person, category, new Date(), null, params);
    }

    /**
     * @param rssFeedService
     */
    public void setRssFeedService(RSSFeedService rssFeedService) {
        this.rssFeedService = rssFeedService;
    }
    
    @SuppressWarnings("javadoc")
    public void setEventService(InternalEventService eventService) {
        this.eventService = eventService;
    }
    
}

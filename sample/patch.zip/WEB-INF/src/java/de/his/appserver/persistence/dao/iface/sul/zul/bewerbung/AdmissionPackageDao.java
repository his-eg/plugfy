package de.his.appserver.persistence.dao.iface.sul.zul.bewerbung;

import java.util.Collection;
import java.util.List;

import de.his.appserver.model.common.Term;
import de.his.appserver.model.sul.zul.bewerbung.AdmissionPackage;
import de.his.appserver.model.sul.zul.bewerbung.AdmissiontypeValue.AdmissiontypeEnum;
import de.his.appserver.persistence.dao.iface.GenericDao;

/**
 * Company: HIS
 * @author Schirmeister, Oberle
 * @version $Revision: 1.7.4.1 $
 */
public interface AdmissionPackageDao extends GenericDao<AdmissionPackage> {
    /**
     * @param admissionTypeHisKey admissionType by hiskey
     * @param termTypeId 
     * @param year 
     * @return List of admissionPackages
     */
    public List<AdmissionPackage> findByAdmissionType(final Long admissionTypeHisKey, Integer year, Long termTypeId);

    /**
     * @param s
     * @return AdmissionPackage
     */
    public AdmissionPackage findByShorttext(String s);
    
    /**
     * Retrieves all terms with AdmissionPackages
     * @return List of Terms
     */
    public List<Term> getAvailableTermsOfAdmissionPackages();
    
    /**
     * Retrieves a list of admission-packages of the given term (consists of {@year} and {@code termTypeValueId} 
     * @param year
     * @param termTypeValueId
     * @return list of admission-packages
     */
    public List<AdmissionPackage> getAdmissionPackagesByTerm(final Integer year, final Long termTypeValueId);

    /**
     * Finds all AdmissionPackages by the given term.
     * @param term
     * @return all AdmissionPackages by the given term.
     */
    public Collection<AdmissionPackage> findByTerm(Term term);

    /**
     * Finds all AdmissionPackages by the given type and term.
     * @param admissionType
     * @param term
     * @return a list of AdmissionPackages for the given type and term.
     */
    public List<AdmissionPackage> findByAdmissionTypeAndTerm(AdmissiontypeEnum admissionType, Term term);

    /**
     * Determines the next sortorder of the ApplicationContentAdmissionPackage of the AdmissionPackage with the given {@code admissionPackageId}<br />
     * This method identifies the highest existing ApplicationContentAdmissionPackage-sortorder and adds 1 to this integer
     * @param admissionPackageId
     * @return the next ApplicationContentAdmissionPackage-sortorder
     */
    public Integer getNextApplicationContentAdmissionPackageSortorder(Long admissionPackageId);
}

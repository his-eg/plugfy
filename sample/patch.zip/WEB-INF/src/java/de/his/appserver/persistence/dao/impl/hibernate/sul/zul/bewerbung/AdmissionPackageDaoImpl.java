package de.his.appserver.persistence.dao.impl.hibernate.sul.zul.bewerbung;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;

import de.his.appserver.model.common.Term;
import de.his.appserver.model.common.TermTypeValue;
import de.his.appserver.model.sul.zul.bewerbung.AdmissionPackage;
import de.his.appserver.model.sul.zul.bewerbung.AdmissiontypeValue.AdmissiontypeEnum;
import de.his.appserver.persistence.dao.iface.sul.zul.bewerbung.AdmissionPackageDao;
import de.his.appserver.persistence.dao.impl.hibernate.GenericHibernateDao;
import de.his.appserver.persistence.hibernate.hist.HistorizationUtil;
import de.his.core.util.EnsureArgument;

/**
 * Company: HIS
 * @author Schirmeister, Oberle
 * @version $Revision: 1.12.4.1 $
 */
public class AdmissionPackageDaoImpl extends GenericHibernateDao<AdmissionPackage> implements AdmissionPackageDao {

    /**
     * @param admissionTypeHisKey
     * @return List of AdmissionPackages
     */
    @Override
    @SuppressWarnings("unchecked")
    public List<AdmissionPackage> findByAdmissionType(final Long admissionTypeHisKey, final Integer year, final Long termTypeValueId) {
        EnsureArgument.notNull(admissionTypeHisKey);
        EnsureArgument.notNull(year);
        EnsureArgument.notNull(termTypeValueId);
        return (List<AdmissionPackage>) getHibernateTemplate().execute(new HibernateCallback<Object>() {
            @Override
            public Object doInHibernate(Session session) throws HibernateException, SQLException {
                HistorizationUtil.setTime(new Date(), session);
                Query query = session.createQuery("FROM AdmissionPackage p " +
                		"WHERE p.admissiontype.hiskeyId = :hiskeyid " +
                		"AND p.term.year = :year " +
                		"AND p.term.termTypeValue.id = :termTypeValueId " +
                		"ORDER BY p.defaulttext");
                query.setLong("hiskeyid", admissionTypeHisKey.longValue());
                query.setInteger("year", year.intValue());
                query.setLong("termTypeValueId", termTypeValueId.longValue());
                List<AdmissionPackage> admissionPackages = query.list();
                return admissionPackages;
            }
        });
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public List<Term> getAvailableTermsOfAdmissionPackages() {
        return (List<Term>) getHibernateTemplate().execute(new HibernateCallback<Object>() {
            @Override
            public List<Term> doInHibernate(final Session session) throws HibernateException, SQLException {
                HistorizationUtil.setTime(new Date(), session);
                final Query query = session.createQuery("select distinct p.term as t from AdmissionPackage p order BY 1");
                List<Term> terms = query.list();
                return terms;
            }
        });
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public List<AdmissionPackage> getAdmissionPackagesByTerm(final Integer year, final Long termTypeValueId) {
        EnsureArgument.notNull(year);
        EnsureArgument.notNull(termTypeValueId);
        return (List<AdmissionPackage>) getHibernateTemplate().execute(new HibernateCallback<Object>() {
            @Override
            public List<AdmissionPackage> doInHibernate(Session session) throws HibernateException, SQLException {
                HistorizationUtil.setTime(new Date(), session);
                Query query = session.createQuery("FROM AdmissionPackage p WHERE p.term.year = :year and p.term.termTypeValue.id = :termTypeValueId ORDER BY p.defaulttext");
                query.setInteger("year", year.intValue());
                query.setLong("termTypeValueId", termTypeValueId.longValue());
                return query.list();
            }
        });
    }

    @Override
    public AdmissionPackage findByShorttext(String s) {
        return (AdmissionPackage) queryUnique("from " + AdmissionPackage.class.getSimpleName()+ " where shorttext = ?" , s);
    }

    @SuppressWarnings("unchecked")
    @Override
    public Collection<AdmissionPackage> findByTerm(final Term term) {
        EnsureArgument.notNull(term);
        Object[] parameterList = new Object[3];
        if (term != null) {
            parameterList[0] = term.getYear();
            parameterList[1] = term.getTermTypeValue().getTermCategory();
            parameterList[2] = term.getTermTypeValue().getTermNumber();
            return getHibernateTemplate().findByNamedQuery(AdmissionPackage.QUERY_FIND_ADMISSIONPACKAGE_BY_TERM, parameterList);
        }
        return new ArrayList<AdmissionPackage>(0);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public List<AdmissionPackage> findByAdmissionTypeAndTerm(final AdmissiontypeEnum admissionType, final Term term) {
        EnsureArgument.notNull(admissionType);
        EnsureArgument.notNull(term);
        return (List<AdmissionPackage>) getHibernateTemplate().execute(new HibernateCallback<Object>() {
            @Override
            public Object doInHibernate(Session session) throws HibernateException, SQLException {
                HistorizationUtil.setTime(new Date(), session);
                Query query = session.createQuery("FROM AdmissionPackage p " +
                        "WHERE p.admissiontype.hiskeyId = :hiskeyid " +
                        "AND p.term.year = :termYear " +
                        "AND p.term.termTypeValue.termCategory = :termCategory " +
                        "AND p.term.termTypeValue.termNumber = :termNumber " +
                        "ORDER BY p.defaulttext");
                query.setLong("hiskeyid", admissionType.getHisKey().longValue());
                Integer termYear = term.getYear();
                TermTypeValue termTypeValue = term.getTermTypeValue();
                Integer termCategory = termTypeValue.getTermCategory();
                Integer termNumber = termTypeValue.getTermNumber();
                query.setParameter("termYear", termYear);
                query.setParameter("termCategory", termCategory);
                query.setParameter("termNumber", termNumber);
                List<AdmissionPackage> admissionPackages = query.list();
                return admissionPackages;
            }
        });
    }

    @Override
    public Integer getNextApplicationContentAdmissionPackageSortorder(final Long admissionPackageId) {
        EnsureArgument.notNull(admissionPackageId);
        return getHibernateTemplate().execute(new HibernateCallback<Integer>() {
            @Override
            public Integer doInHibernate(Session session) throws HibernateException, SQLException {
                HistorizationUtil.setTime(new Date(), session);
                Query query = session.createQuery("SELECT max(acap.sortorder) as sortorder " +
                		"FROM AdmissionPackage ap " +
                		"JOIN ap.applicationContentAdmissionPackages acap " +
                        "WHERE ap.id = :admissionPackageId");
                query.setInteger("admissionPackageId", admissionPackageId.intValue());
                Integer sortorder = (Integer) query.uniqueResult();
                if(sortorder == null) {
                    return Integer.valueOf(0);
                }
                return Integer.valueOf(sortorder.intValue() + 1);
            }
        });
    }
}

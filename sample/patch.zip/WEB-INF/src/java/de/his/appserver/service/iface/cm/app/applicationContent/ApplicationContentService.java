/*
 * Copyright (c) 2013 HIS GmbH All Rights Reserved.
 *
 * $Id: ApplicationContentService.java,v 1.42.4.9 2013-12-03 07:28:45 schwaff#his.de Exp $
 *
 */
package de.his.appserver.service.iface.cm.app.applicationContent;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.faces.model.SelectItem;
import javax.faces.model.SelectItemGroup;

import org.springframework.security.access.annotation.Secured;

import de.his.appclient.jsf.genericSearch.SelectedValuesHashMap;
import de.his.appserver.model.cm.app.applicationContent.ApplicationContentInput;
import de.his.appserver.model.cm.app.applicationContent.ApplicationContentInputStatus;
import de.his.appserver.model.cm.app.applicationContent.FieldInput.FieldInputDiscriminatorType;
import de.his.appserver.model.common.ExpressionLogger;
import de.his.appserver.service.base.ServiceBase;
import de.his.appserver.service.dto.base.GeneratedDtoBase;
import de.his.appserver.service.dto.gen.iface.ApplicationContentAdmissionPackageDto;
import de.his.appserver.service.dto.gen.iface.ApplicationContentConditionDto;
import de.his.appserver.service.dto.gen.iface.ApplicationContentDto;
import de.his.appserver.service.dto.gen.iface.ApplicationContentInputDto;
import de.his.appserver.service.dto.gen.iface.FieldDto;
import de.his.appserver.service.dto.gen.iface.InputKeySelectionItemDto;
import de.his.appserver.service.dto.gen.iface.InputSelectionItemDto;
import de.his.appserver.service.dto.gen.iface.KeyTableSelectionFieldDto;
import de.his.appserver.service.dto.gen.iface.SelectionFieldDto;
import de.his.appserver.service.dto.gen.iface.SelectionItemDto;
import de.his.appserver.service.dto.gen.iface.SelectionItemGroupDto;
import de.his.core.util.cs.psv.Right;

/**
 * Service for creating, loading and update dynamic application contents
 * 
 * Company: HIS
 * @author schwaff
 * @version $Revision: 1.42.4.9 $
 */
@de.his.appserver.service.base.ServiceMetadata.ServiceInterfaceMetadata(
                serviceName = "ApplicationContentService",
                interfaceVersion = "1.0",
                interfaceRevision = "$Revision: 1.42.4.9 $",
                serviceId = "2f541401-4ef3-4953-8a3c-6b31775c0297",
                serviceDescription = "Service for creating, loading and update dynamic application contents")
public interface ApplicationContentService extends ServiceBase {

    /**
     * Save-Path of the ApplicationContentAdmissionPackageDto
     */
    public static final String[] applicationContentAdmissionPackageSavePath = new String[] { ApplicationContentAdmissionPackageDto.admissionPackage, ApplicationContentAdmissionPackageDto.applicationContent };

    /**
     * Save-Path of the ApplicationContentInputDto
     */
    public static final String[] applicationContentInputSavePath = new String[] { ApplicationContentInputDto.fieldInputs };

    /**
     * Creates a new ApplicationContentDto
     * @return ApplicationContentDto
     */
    @Secured({ Right.Strings.CM_APP_APPLICATIONCONTENT_EDIT_APPLICATION_CONTENT })
    public ApplicationContentDto createApplicationContent();
    
    /**
     * Retrieves the ApplicationContentDto by the given {@code applicationContentId}
     * @param applicationContentId
     * @return ApplicationContentDto
     */
    @Secured({ Right.Strings.CM_APP_APPLICATIONCONTENT_EDIT_APPLICATION_CONTENT })
    public ApplicationContentDto loadApplicationContent(Long applicationContentId);

    /**
     * Retrieves a list of ApplicationContentDtos by the given {@code applicationContentIds}
     * @param applicationContentIds
     * @return List of ApplicationContentDtos
     */
    @Secured({ Right.Strings.CM_APP_APPLICATIONCONTENT_EDIT_APPLICATION_CONTENT })
    public List<ApplicationContentDto> loadApplicationContents(List<Long> applicationContentIds);
    
    /**
     * Attempts to delete the ApplicationContent with the given {@code applicationContentId}
     * @param applicationContentId
     * @return {@code true} if the ApplicationContent has been deleted; {@code false} otherwise
     */
    @Secured({ Right.Strings.CM_APP_APPLICATIONCONTENT_EDIT_APPLICATION_CONTENT })
    public boolean deleteApplicationContent(Long applicationContentId);
    
    /**
     * Persists the given {@code applicationContentDto}
     * @param applicationContentDto
     */
    @Secured({ Right.Strings.CM_APP_APPLICATIONCONTENT_EDIT_APPLICATION_CONTENT })
    public void saveApplicationContent(ApplicationContentDto applicationContentDto);
    
    /**
     * Retrieves the ApplicationContentAdmissionPackageDto of the Request with the given {@code requestId}
     * 
     * @param requestId
     * @return List of ApplicationContentAdmissionPackageDtos
     * 
     * @deprecated please load the ApplicationContentAdmissionPackageDtos by requestSubjects using the method: de.his.appserver.service.iface.cm.app.applicationContent.ApplicationContentService.getApplicationContentAdmissionPackagesByRequestSubjectId(Long)
     */
    @Deprecated
    public List<ApplicationContentAdmissionPackageDto> getApplicationContentAdmissionPackagesByRequestId(Long requestId);
    
    /**
     * Retrieves the ApplicationContentAdmissionPackageDto of the RequestSubject with the given {@code requestSubjectId}
     * 
     * @param requestSubjectId
     * @return List of ApplicationContentAdmissionPackageDtos
     */
    public List<ApplicationContentAdmissionPackageDto> getApplicationContentAdmissionPackagesByRequestSubjectId(Long requestSubjectId);

    /**
     * Retrieves the ApplicationContentAdmissionPackageIds of the Request with the given {@code requestId}
     * 
     * @param requestId
     * @return List of ApplicationContentAdmissionPackage-Ids
     */
    public List<Long> getApplicationContentAdmissionPackagesIdsByRequestId(Long requestId);
    
    /**
     * Creates a new association between the applicationContent with the given {@code applicationContentId} and the 
     * admissionPackage with the given {@code admissionPackageId} 
     * @param applicationContentId
     * @param admissionPackageId
     * @return ApplicationContentAdmissionPackageDto
     */
    @Secured({ Right.Strings.CM_APP_APPLICATIONCONTENT_EDIT_APPLICATION_CONTENT })
    public ApplicationContentAdmissionPackageDto createApplicationContentAdmissionPackage(Long applicationContentId, Long admissionPackageId);

    /**
     * Creates a new ApplicationContentAdmissionPackageDto and associates the given {@code applicationContentDto} with the new ApplicationContentAdmissionPackageDto
     * admissionPackage with the given {@code admissionPackageId} 
     * @param applicationContentDto
     * @return ApplicationContentAdmissionPackageDto
     */
    @Secured({ Right.Strings.CM_APP_APPLICATIONCONTENT_EDIT_APPLICATION_CONTENT })
    public ApplicationContentAdmissionPackageDto createApplicationContentAdmissionPackage(ApplicationContentDto applicationContentDto);
    
    /**
     * Creates a new associations between the given {@code applicationContentDto} and the admissionPackages with the given {@code admissionPackageIds} 
     * @param applicationContentDto
     * @param admissionPackageIds
     * @return List of ApplicationContentAdmissionPackageDto
     */
    @Secured({ Right.Strings.CM_APP_APPLICATIONCONTENT_EDIT_APPLICATION_CONTENT })
    public List<ApplicationContentAdmissionPackageDto> createApplicationContentAdmissionPackages(ApplicationContentDto applicationContentDto, List<Long> admissionPackageIds);
    
    /**
     * Saves the association between the applicationContent and the admissionPackage<br />
     * <strong style="color:red">ATTENTION: Stores only Objects defined in {@code de.his.appserver.service.iface.cm.app.applicationContent.ApplicationContentService.applicationContentAdmissionPackageSavePath} !!</strong>
     * @param applicationContentAdmissionPackage
     */
    @Secured({ Right.Strings.CM_APP_APPLICATIONCONTENT_EDIT_APPLICATION_CONTENT })
    public void saveApplicationContentAdmissionPackage(ApplicationContentAdmissionPackageDto applicationContentAdmissionPackage);

    /**
     * Added a new field of the FieldInputDiscriminatorType {@code type} to the given {@code applicationContentDto}
     * @param applicationContentDto
     * @param type
     * @return instance of the FieldDto 
     */
    public FieldDto createField(ApplicationContentDto applicationContentDto, String type);
    
    /**
     * Added a new field of the FieldInputDiscriminatorType {@code type} to the given {@code applicationContentDto}
     * @param applicationContentDto
     * @param type
     * @return instance of the FieldDto 
     */
    @Secured({ Right.Strings.CM_APP_APPLICATIONCONTENT_EDIT_APPLICATION_CONTENT })
    public FieldDto createField(ApplicationContentDto applicationContentDto, FieldInputDiscriminatorType type);

    /**
     * Creates a new SelectionItemDto that will be added to the given {@code dtoBase}<br />
     * The {@code dtoBase} must be either a {@code SelectionFieldDto} or a {@code SelectionItemGroupDto}
     * @param dtoBase
     * @return SelectionItemDto
     */
    public SelectionItemDto addSelectionItem(GeneratedDtoBase dtoBase);
    
    /**
     * Creates a new SelectionItemGroupDto that will be added to the given {@code selectionFieldDto}
     * @param selectionFieldDto
     * @return SelectionItemGroupDto
     */
    public SelectionItemGroupDto addSelectionItemGroup(SelectionFieldDto selectionFieldDto);
    
    /**
     * Sets the {@code selectedValuesHashMap} to the given {@code fieldDto}
     * @param fieldDto
     * @param selectedValuesHashMap
     */
    public void setKeyTableSelectionItems(KeyTableSelectionFieldDto fieldDto, SelectedValuesHashMap selectedValuesHashMap);

    /**
     * Creates, saves and returns a copy of the given object. 
     * @param originalApplicationContentDto
     * @return the saved copy.
     */
    @Secured({ Right.Strings.CM_APP_APPLICATIONCONTENT_EDIT_APPLICATION_CONTENT })
    public ApplicationContentDto saveApplicationContentAsCopy(ApplicationContentDto originalApplicationContentDto);

    /**
     * Retrieves a list of ApplicationContentInputDtos that belongs to the requestSubject with the {@code requestSubjectId} and 
     * the applicationContent with the {@code applicationContentId}<br />
     * <b>This method is to be used in online-application</b>
     * 
     * @param requestSubjectId
     * @param applicationContentId 
     * @return List of ApplicationContentInputDtos
     */
    @Secured({ Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION_OWN, Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION })
    public List<ApplicationContentInputDto> getApplicationContentInputDtos(Long requestSubjectId, Long applicationContentId);

   /**
    * Retrieves a list of ApplicationContentInputDtos that belongs to the request with the {@code requestId} and 
     * the applicationContent with the {@code applicationContentId}<br />
     * <b>This method is to be used in online-application</b>
     * 
    * @param requestId
    * @param applicationContentId
    * @return List of ApplicationContentInputDtos
    */
    @Secured({ Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION_OWN, Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION })
    public List<ApplicationContentInputDto> getApplicationContentInputDtosByRequestId(Long requestId, Long applicationContentId);
    
    /**
     * Retrieves a map with the request-id as key and a list of ApplicationContentInputDtos that belongs to each request<br /> 
     * <b>This method is to be used in the controlpage of the online-application</b>
     * 
     * @param requestIds

     * @return List of ApplicationContentInputDtos
     */
    @Secured({ Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION_OWN, Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION })
    public Map<Long, List<ApplicationContentInputDto>> getAllApplicationContentInputDtos(List<Long> requestIds);
    
    /**
     * Retrieves a list of ApplicationContentInputDtos that belongs to the request with the {@code requestId} 
     * <b>This method is to be used in the controlpage of the online-application</b>
     * 
     * @param requestId

     * @return List of ApplicationContentInputDtos
     */
    @Secured({ Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION_OWN, Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION })
    public List<ApplicationContentInputDto> getAllApplicationContentInputDtos(Long requestId);
    
    /**
     * Retrieves a list of ApplicationContentInputDtos that belongs to the application with the {@code applicationId} 
     * <b>This method is to be used in application-processing</b>
     * 
     * @param applicationId
     * @return Map with requestSubjectId as key and a set of ApplicationContentInputDtos
     */
    @Secured({ Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION, Right.Strings.CM_APP_APPLICATION_VIEW_APPLICATION })
    public Map<Long, Collection<ApplicationContentInputDto>> getApplicationContentInputDtosProcessing(Long applicationId);
    
    /**
     * Retrieves a list of ApplicationContentDtos that belongs to the application with the {@code applicationId} 
     * <b>This method is to be used in application-processing</b>
     * 
     * @param applicationId
     * @return Map with requestSubjectId as key and a list of ApplicationContentDtos
     */
    @Secured({ Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION, Right.Strings.CM_APP_APPLICATION_VIEW_APPLICATION })
    public  Map<Long, List<ApplicationContentDto>> getApplicationContentProcessing(Long applicationId); 

    /**
     * Attempts to saves the given {@code applicationContentInputDto}
     * @param applicationContentInputDto
     */
    @Secured({ Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION_OWN, Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION })
    public void saveApplicationContentInput(ApplicationContentInputDto applicationContentInputDto);

    /**
     * Attempts to saves the given {@code applicationContentInputDtos} that are used in Online-application 
     * @param applicationContentInputDtos
     */
    @Secured({ Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION_OWN, Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION })
    public void saveApplicationContentInputs(List<ApplicationContentInputDto> applicationContentInputDtos);

    /**
     * Create a new InputKeySelectionItemDto 
     * @return InputKeySelectionItemDto
     */
    public InputKeySelectionItemDto createInputKeySelectionItem();

    /**
     * Creates a new InputSelectionItemDto
     * @return InputSelectionItemDto
     */
    public InputSelectionItemDto createInputSelectionItem();
    
    /**
     * Retrieves a list of all ApplicationContentDto
     * @return all ApplicationContentDto
     */
    public List<ApplicationContentDto> getAllApplicationContents();

    /**
     * Retrieves a list of all ApplicationContentDto
     * @return all ApplicationContentDto
     */
    public List<ApplicationContentDto> getAllApplicationContentsWithFields();

    /**
     * 
     * @param applicationContentInputDto
     */
    @Secured({ Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION_OWN, Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION })
    public void createFieldInputOnlineApplication(ApplicationContentInputDto applicationContentInputDto);

    /**
     * 
     * @param applicationContentInputDto
     */
    @Secured({ Right.Strings.CM_APP_APPLICATION_EDIT_APPLICATION })
    public void createFieldInputApplicationProcessing(ApplicationContentInputDto applicationContentInputDto);
   
    /**
     * Creates a Selection-Array that can be used on the gui to display the allowedValues of the 
     * given {@codekeyTableSelectionFieldDto}
     * <b>The label is the keyValues defaulttext<br />
     * The value is the KeySelectionItem-{@code id}</b>
     * 
     * @param keyTableSelectionFieldDto
     * @return Array of SelectItems with allowedValues
     */
    public SelectItem[] getKeyTableSelectionItems(KeyTableSelectionFieldDto keyTableSelectionFieldDto);
    
    /**
     * Deletes all FieldInputDtos of the given {@code applicationContentInputDto}
     * @param applicationContentInputDto
     */
    public void deleteOptionalApplicationContentInputFields(ApplicationContentInputDto applicationContentInputDto);
    
    /**
     * Creates a new ApplicationContentInputDto for the ApplicationContent with the given {@code applicationContentId}<br />
     * This method is used to add a new ApplicationContentInputDto when the allocation to the admissionpackage according to 
     * the RequestSubject with the given {@code requestSubjectId} is set to {@code multipleInputAllowed} = true
     * @param applicationContentId
     * @param requestSubjectId 
     * @param isOnlineApplication 
     * @return ApplicationContentInputDto
     */
    public ApplicationContentInputDto createApplicationContentInput(Long applicationContentId, Long requestSubjectId, boolean isOnlineApplication);
    
    /**
     * Creates the KeyTableSelectionFieldDto that belongs to the given {@code keyTableSelectionFieldId}
     * @param keyTableSelectionFieldId
     * @return KeyTableSelectionFieldDto
     */
    public KeyTableSelectionFieldDto createKeyTableSelectionFieldDto(Long keyTableSelectionFieldId);

    /**
     * Creates the SelectionFieldDto that belongs to the given {@code selectionFieldId}
     * @param selectionFieldId
     * @return SelectionFieldDto
     */
    public SelectionFieldDto createSelectionFieldDto(Long selectionFieldId);
    
    /**
     * Create a new ApplicationContentConditionDto
     * @return ApplicationContentConditionDto
     */
    @Secured({ Right.Strings.CM_APP_APPLICATIONCONTENT_EDIT_CONDITIONS })
    public ApplicationContentConditionDto createApplicationContentCondition();
    
    /**
     * Retrieves the ApplicationContentConditionDto with the given {@code applicationContentConditionId}
     * @param applicationContentConditionId
     * @return ApplicationContentConditionDto
     */
    public ApplicationContentConditionDto readApplicationContentCondition(Long applicationContentConditionId);
    
    /**
     * Saves the given {@code applicationContentConditionDto}
     * @param applicationContentConditionDto
     */
    @Secured({ Right.Strings.CM_APP_APPLICATIONCONTENT_EDIT_CONDITIONS })
    public void saveApplicationContentCondition(ApplicationContentConditionDto applicationContentConditionDto);
    
    /**
     * Retrieves a list of all ApplicationContentConditionDto
     * @return all ApplicationContentConditionDto
     */
    public Map<Long, ApplicationContentConditionDto> getAllApplicationContentConditions();
    
    /**
     * Attempts to delete the ApplicationContentCondition with the given {@code applicationContentConditionId}
     * @param applicationContentConditionId
     * @param checkReferences
     * @return {@code true} if the conditon has been deleted; {@code false} otherwise
     */
    @Secured({ Right.Strings.CM_APP_APPLICATIONCONTENT_EDIT_CONDITIONS })
    public boolean deleteApplicationContentCondition(Long applicationContentConditionId, boolean checkReferences);
    
    /**
     * Executes the expression given in the {@code applicationContentConditionDto} on the RequestSubject with the given {@code requestSubjectId}.
     * The execution will be logged into the {@code expressionLogger}
     * @param applicationContentConditionDto 
     * @param requestSubjectId
     * @param expressionLogger 
     * @return {@code TRUE} or {@code FALSE}
     */
    public boolean testCondition(ApplicationContentConditionDto applicationContentConditionDto, Long requestSubjectId, ExpressionLogger expressionLogger);
    
    /**
     * Returns {@code true} if this condition is already used in online-applications or {@code false} if not. 
     * @param applicationContentConditionId
     * @return {@code true} or {@code false}
     */
    public boolean isUsedInOnlineApplication(Long applicationContentConditionId);
    
    /**
     * Counts the usage of the condition with the given {@code applicationContentConditionId} in application-content-definitions like:
     * <ul>
     * <li>ApplicationContent</li>
     * <li>Field</li>
     * <li>ApplicationContentAdmissionPackage</li>
     * </ul>
     * @param applicationContentConditionId
     * @return the amount of usages in application-content-definitions
     */
    public int countUsagesInApplicationContents(Long applicationContentConditionId);

    /**
     * Retrieves a list of SelectItemGroups of the given {@code selectionFieldDto}
     * @param selectionFieldDto
     * @return list of SelectItemGroups
     */
    public List<SelectItemGroup> getSelectionItems(SelectionFieldDto selectionFieldDto);

    /**
     * Saves the given {@code fieldDto}
     * @param fieldDto
     */
    @Secured({ Right.Strings.CM_APP_APPLICATIONCONTENT_EDIT_APPLICATION_CONTENT })
    public void saveApplicationContentField(FieldDto fieldDto);
    
    /**
     * Returns {@code true} if any Request using the applicationContentInput with the given {@code applicationContentInputId} is already submitted<br />
     * <b>ApplicationContentInputs that are defined to applicant (instead of the admissionpackage) will return {@code true} if any request is submitted.</b>
     * @param applicationContentInputDtos
     * @return {@code true} or {@code false}
     */
    public boolean isAnyRequestSubmitted(List<ApplicationContentInputDto> applicationContentInputDtos);
    
    /**
     * Returns {@code true} if any Request using the applicationContentInput with the given {@code applicationContentInputId} is already submitted<br />
     * <b>ApplicationContentInputs that are defined to applicant (instead of the admissionpackage) will return {@code true} if any request is submitted.</b>
     * @param applicationContentInputDto
     * @return {@code true} or {@code false}
     */
    public boolean isAnyRequestSubmitted(ApplicationContentInputDto applicationContentInputDto);
    
    /**
     * Returns titles of all request subjects which use the given application content inputs
     * @param applicationContentInputDtos
     * @return defaulttext of course of studies
     */
    public Set<String> getTitlesOfAffectedCourses(List<ApplicationContentInputDto> applicationContentInputDtos);

    /**
     * Finds the count of inputs for the given field.
     * @param fieldId
     * @return the count of field inputs
     */
    public int findFieldInputCountByField(Long fieldId);
    
    /**
     *  Pflichtfeldvalidierung
     * @param applicationContentInputDto ApplicationContentInputDto to be validated
     * @return Fehlertext
     */
    public String validateApplicationContentInputDto(ApplicationContentInputDto applicationContentInputDto);

    /**
     * @return the ApplicationContentInputStatus Correct
     */
    public ApplicationContentInputStatus getApplicationContentInputStatuCorrect();

    /**
     * Returns a list of {@code ApplicationContentInputs} of the RequestSubject with the given {@code requestSubjectId}. <br />
     * The optional second parameter ({@code applicationContentKey} can be used to restrict the list of {@code ApplicationContentInputs}
     * to ApplicationContentInputs with ApplicationContent containing the given {@code applicationContentKey} as uniquename 
     * (de.his.appserver.model.cm.app.applicationContent.ApplicationContent.uniquename)   
     * 
     * @param requestSubjectId the Id of the RequestSubject
     * @param applicationContentKey the optional ApplicationContent.uniquename 
     * @return List of ApplicationContentInputs
     */
    public List<ApplicationContentInput> getApplicationContentInputs(Long requestSubjectId, String applicationContentKey);
    
    /**
     * @param applicationContentInputDto
     * @return true, if optional
     */
    public boolean isOptional(ApplicationContentInputDto applicationContentInputDto);
    
    /**
     * @param applicationContentInputDto
     * @return true, if multiple
     */
    public boolean isMultiple(ApplicationContentInputDto applicationContentInputDto);
    
    /**
     * Returns a list of ApplicationContents-Ids that should be inquired for the Request with the given {@code requestId}
     * @param requestId
     * @return Id-list of ApplicationContents to inquire
     */
    public Collection<Long> getApplicationContentsByRequestId(Long requestId);

}

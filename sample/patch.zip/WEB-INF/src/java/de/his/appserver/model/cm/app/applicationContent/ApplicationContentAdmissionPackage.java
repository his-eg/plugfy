/*
 * Copyright (c) 2013 HIS GmbH All Rights Reserved.
 *
 * $Id: ApplicationContentAdmissionPackage.java,v 1.1.4.2 2013-12-03 07:28:44 schwaff#his.de Exp $
 * $Log: ApplicationContentAdmissionPackage.java,v $
 * Revision 1.1.4.2  2013-12-03 07:28:44  schwaff#his.de
 * #102016 – Bugfix: BB: Massenzuordung von Zulassungspaketen ohne sortorder
 *
 * Revision 1.1.4.1  2013-09-10 13:34:10  schwaff#his.de
 * #97466 – Mehrfacherfassung von Bestandteilen bei Kombinationsstudiengängen
 *
 * Revision 1.1  2013-08-05 14:23:20  schirmeister#his.de
 * #87881
 *
 * Revision 1.11  2013-06-26 13:04:12  schwaff#his.de
 * Bewerber gibt "en bloc" Haupt-/Hilfsanträge ab, um dabei Haupt- und Hilfsanträge zu bestimmen (#89682)
 *
 * Revision 1.10  2013-06-21 08:20:19  schwaff#his.de
 * #87881: PA: Bewerbungsinhalte und Bewerbungsbestandteile
 * https://hiszilla.his.de/hiszilla/show_bug.cgi?id=87881
 *
 * Revision 1.9  2013-06-17 15:11:07  schwaff#his.de
 * #87881: PA: Bewerbungsinhalte und Bewerbungsbestandteile
 * https://hiszilla.his.de/hiszilla/show_bug.cgi?id=87881
 *
 * Revision 1.8  2013-06-10 07:11:07  schwaff#his.de
 * #87881: PA: Bewerbungsinhalte und Bewerbungsbestandteile
 * https://hiszilla.his.de/hiszilla/show_bug.cgi?id=87881
 *
 * Revision 1.7  2013-06-05 11:49:58  paul#his.de
 * DoSV Mapping von Bewerbungsinhalten. #87881
 *
 * Revision 1.6  2013-06-03 09:35:41  schwaff#his.de
 * #87881: PA: Bewerbungsinhalte und Bewerbungsbestandteile
 * https://hiszilla.his.de/hiszilla/show_bug.cgi?id=87881
 *
 * Revision 1.5  2013-05-30 07:23:51  schwaff#his.de
 * #87881: PA: Bewerbungsinhalte und Bewerbungsbestandteile
 * https://hiszilla.his.de/hiszilla/show_bug.cgi?id=87881
 *
 * Revision 1.4  2013-05-28 11:00:32  paul#his.de
 * Funktion Kopie Speichern Als in die Bewerbungsinhalte eingebaut. #87881
 *
 * Revision 1.3  2013-05-27 15:31:56  paul#his.de
 * Copy Methode in die Bewerbungsinhalt Entities eingebaut. #87881
 *
 * Revision 1.2  2013-05-27 14:06:02  paul#his.de
 * Copy Methode in die Bewerbungsinhalt Entities eingebaut. #87881
 *
 * Revision 1.1  2013-05-13 13:43:32  schwaff#his.de
 * #87881: PA: Bewerbungsinhalte und Bewerbungsbestandteile
 * https://hiszilla.his.de/hiszilla/show_bug.cgi?id=87881
 *
 */
package de.his.appserver.model.cm.app.applicationContent;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.annotations.AccessType;
import org.hibernate.annotations.Type;

import de.his.appserver.model.base.AbstractPersistentObject;
import de.his.appserver.model.base.value.SortorderValue;
import de.his.appserver.model.sul.zul.bewerbung.AdmissionPackage;
import de.his.appserver.persistence.hibernate.BooleanMapping;
import de.his.core.codegeneration.entity.annotation.AddGenerationGetMethodComment;
import de.his.core.codegeneration.entity.annotation.EnableCopyToDto;

/**
 * Zuordnung von Bewerbungsinhalt zum Zulassungspaket
 * 
 * Company: HIS
 * @author schwaff
 * @version $Revision: 1.1.4.2 $
 */
@EnableCopyToDto
@AccessType("field")
@Entity
@Table(name="application_content_admissionpackage")
@NamedQueries(value={
                @NamedQuery(name = ApplicationContentAdmissionPackage.FIND_APPLICATION_CONTENT_ADMISSSIONPACKAGE_BY_REQUESTSUBJECT_ID, 
                    query = "SELECT aca " +
                        "from RequestSubject rs " +
                        "join rs.courseOfStudy cos " +
                        "join cos.admissionshares ash " +
                        "join ash.admissionPackage ap " +
                        "join ap.applicationContentAdmissionPackages aca " +
                        "where rs.id = :requestSubjectId " +
                        "order by aca.sortorder"),
                @NamedQuery(name = ApplicationContentAdmissionPackage.FIND_APPLICATION_CONTENT_ADMISSSIONPACKAGE_BY_REQUEST_ID, 
                    query = "SELECT aca " +
                        "from Request r " +
                        "join r.requestsubjectgroups rsg " +
                        "join rsg.requestsubjectgroupRequestsubjects rsgrs " +
                        "join rsgrs.requestSubject rs " +
                        "join rs.courseOfStudy cos " +
                        "join cos.admissionshares ash " +
                        "join ash.admissionPackage ap " +
                        "join ap.applicationContentAdmissionPackages aca " +
                        "where r.id = :requestId " +
                        "order by aca.sortorder")
            })
public class ApplicationContentAdmissionPackage extends AbstractPersistentObject implements SortorderValue {

    /** findApplicationContentAdmissionPackageByRequestSubjectId */
    public static final String FIND_APPLICATION_CONTENT_ADMISSSIONPACKAGE_BY_REQUESTSUBJECT_ID = "findApplicationContentAdmissionPackageByRequestSubjectId";

    /** findApplicationContentAdmissionPackageByRequestId */
    public static final String FIND_APPLICATION_CONTENT_ADMISSSIONPACKAGE_BY_REQUEST_ID = "findApplicationContentAdmissionPackageByRequestId";

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 1L;
    
    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "admissionpackage_id")
    private AdmissionPackage admissionPackage;
    
    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "application_content_id")
    private ApplicationContent applicationContent;
    
    @Column(name="is_optional", nullable = false)
    @Type(type = BooleanMapping.USER_TYPE_NAME)
    @AddGenerationGetMethodComment("0 - Nein, 1 - Ja")
    private Boolean isOptional;
    


    @ManyToOne(optional = true)
    @JoinColumn(name = "condition_ruleentity_id")
    private ApplicationContentCondition condition;
    
    @Column(nullable=false)
    private Integer sortorder;
    
    /* COPY_TO_DTO_BEGIN */

    /**
     * @return if isOptional is not null and is true.
     */
    public boolean isOptional() {
        return Boolean.TRUE.equals(getIsOptional());
    }
    
    /* COPY_TO_DTO_END */
    
    /* GENERATED_BEGIN */

    /**
     * Autogenerated Default-Constructor
     * cut&paste out of 'GENERATED'-Block to modify
     */
    public ApplicationContentAdmissionPackage() {
        super();
    }

    /**
     * Autogenerated Constructor to use if an already generated objGuid is to be used (e.g. from an EntityDto)
     * @param objGuid
     */
    public ApplicationContentAdmissionPackage(de.his.core.util.generator.UUIDWrapper objGuid) {
        this();
        setObjGuid(objGuid.toString());
    }

    // Template: Entity-Template ManyToOne
    /**
     * @return admissionPackage
     */
    public AdmissionPackage getAdmissionPackage() {
        return admissionPackage;
    }


    /**
     * @param newValue
     */
    public void setAdmissionPackage(AdmissionPackage newValue) {
        AdmissionPackage oldValue = admissionPackage;
        if (de.his.core.util.EntityUtil.equals(newValue, oldValue)) {
            return;
        }
        admissionPackage = newValue;

        // Handle Bidirectionality
        if (oldValue != null && oldValue.getApplicationContentAdmissionPackages().contains(this)) {
            oldValue.removeFromApplicationContentAdmissionPackages(this);
        }
        if (newValue!= null && !newValue.getApplicationContentAdmissionPackages().contains(this)) {
            newValue.addToApplicationContentAdmissionPackages(this);
        }
    }

    // Template: Entity-Template ManyToOne
    /**
     * @return applicationContent
     */
    public ApplicationContent getApplicationContent() {
        return applicationContent;
    }


    /**
     * @param newValue
     */
    public void setApplicationContent(ApplicationContent newValue) {
        ApplicationContent oldValue = applicationContent;
        if (de.his.core.util.EntityUtil.equals(newValue, oldValue)) {
            return;
        }
        applicationContent = newValue;

        // Handle Bidirectionality
        if (oldValue != null && oldValue.getApplicationContentAdmissionPackages().contains(this)) {
            oldValue.removeFromApplicationContentAdmissionPackages(this);
        }
        if (newValue!= null && !newValue.getApplicationContentAdmissionPackages().contains(this)) {
            newValue.addToApplicationContentAdmissionPackages(this);
        }
    }

    /**
     * 0 - Nein, 1 - Ja
     * @return isOptional
     */
    public Boolean getIsOptional() {
        return isOptional;
    }


    /**
     * 0 - Nein, 1 - Ja
     * @param newValue
     */
    public void setIsOptional(Boolean newValue) {
        this.isOptional = newValue;
    }

    // Template: Entity-Template ManyToOneUnidirectional
    /**
     * @return condition
     */
    public ApplicationContentCondition getCondition() {
        return condition;
    }


    /**
     * @param condition
     */
    public void setCondition(ApplicationContentCondition condition) {
        this.condition = condition;
    }

    /**
     * @return sortorder
     */
    @Override
    public Integer getSortorder() {
        return sortorder;
    }


    /**
     * @param newValue
     */
    @Override
    public void setSortorder(Integer newValue) {
        this.sortorder = newValue;
    }


    private static final java.util.List<String> allAttributeNames = java.util.Arrays.asList(new String[]{"isOptional", "sortorder"});

    /**
     * {@inheritDoc}
     */
    @java.lang.Override
    public java.util.List<String> getAllAttributeNames() {
        return getAllAttributeNamesIntern();
    }

    /**
     * {@inheritDoc}
     */
    @java.lang.Override
    protected java.util.List<String> getAllAttributeNamesIntern() {
        java.util.List<String> tmp = super.getAllAttributeNamesIntern();
        tmp.addAll(allAttributeNames);
        return tmp;
    }
    /* GENERATED_END */

}

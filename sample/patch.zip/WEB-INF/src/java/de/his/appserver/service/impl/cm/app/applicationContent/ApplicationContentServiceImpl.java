package de.his.appserver.service.impl.cm.app.applicationContent;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedSet;

import javax.faces.model.SelectItem;
import javax.faces.model.SelectItemGroup;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

import org.apache.log4j.LoggerExt;
import org.springframework.beans.factory.annotation.Required;

import com.google.common.collect.Lists;

import de.his.appclient.http.cs.sys.filemanagement.DocumentMetadataObjectType;
import de.his.appclient.jsf.framework.facelets.I18nSupport;
import de.his.appclient.jsf.framework.tag.CollectionUtil;
import de.his.appclient.jsf.genericSearch.SelectedValuesHashMap;
import de.his.appserver.model.cm.app.applicationContent.AllocationObject;
import de.his.appserver.model.cm.app.applicationContent.ApplicantVisibility;
import de.his.appserver.model.cm.app.applicationContent.ApplicationContent;
import de.his.appserver.model.cm.app.applicationContent.ApplicationContentAdmissionPackage;
import de.his.appserver.model.cm.app.applicationContent.ApplicationContentCondition;
import de.his.appserver.model.cm.app.applicationContent.ApplicationContentInput;
import de.his.appserver.model.cm.app.applicationContent.ApplicationContentInputStatus;
import de.his.appserver.model.cm.app.applicationContent.Field;
import de.his.appserver.model.cm.app.applicationContent.FieldInput;
import de.his.appserver.model.cm.app.applicationContent.FieldInput.FieldInputDiscriminatorType;
import de.his.appserver.model.common.ExpressionLogger;
import de.his.appserver.model.cs.sys.scripting.EngineType;
import de.his.appserver.model.cs.sys.scripting.ScriptException;
import de.his.appserver.model.sul.zul.bewerbung.AdmissionPackage;
import de.his.appserver.model.sul.zul.bewerbung.Application;
import de.his.appserver.model.sul.zul.bewerbung.Request;
import de.his.appserver.model.sul.zul.bewerbung.RequestSubject;
import de.his.appserver.persistence.dao.iface.cm.app.applicationContent.ApplicationContentAdmissionPackageDao;
import de.his.appserver.persistence.dao.iface.cm.app.applicationContent.ApplicationContentConditionDao;
import de.his.appserver.persistence.dao.iface.cm.app.applicationContent.ApplicationContentDao;
import de.his.appserver.persistence.dao.iface.cm.app.applicationContent.ApplicationContentInputDao;
import de.his.appserver.persistence.dao.iface.cm.app.applicationContent.FieldDao;
import de.his.appserver.persistence.dao.iface.sul.zul.bewerbung.ApplicationDao;
import de.his.appserver.persistence.dao.iface.sul.zul.bewerbung.RequestDao;
import de.his.appserver.persistence.dao.iface.sul.zul.bewerbung.RequestSubjectDao;
import de.his.appserver.persistence.hibernate.i18n.I18nUtils;
import de.his.appserver.service.ServiceException;
import de.his.appserver.service.StaticBeanRef;
import de.his.appserver.service.base.ServiceBaseImpl;
import de.his.appserver.service.base.meta.FieldMetadata;
import de.his.appserver.service.dto.base.DtoBase;
import de.his.appserver.service.dto.base.GeneratedDtoBase;
import de.his.appserver.service.dto.gen.ApplicationContentAdmissionPackageDtoFactory;
import de.his.appserver.service.dto.gen.ApplicationContentConditionDtoFactory;
import de.his.appserver.service.dto.gen.ApplicationContentDtoFactory;
import de.his.appserver.service.dto.gen.ApplicationContentInputDtoFactory;
import de.his.appserver.service.dto.gen.DateFieldDtoFactory;
import de.his.appserver.service.dto.gen.DateFieldInputDtoFactory;
import de.his.appserver.service.dto.gen.DecimalFieldDtoFactory;
import de.his.appserver.service.dto.gen.DecimalFieldInputDtoFactory;
import de.his.appserver.service.dto.gen.DocumentFieldInputDtoFactory;
import de.his.appserver.service.dto.gen.DocumentUploadFieldDtoFactory;
import de.his.appserver.service.dto.gen.DtoFactoryTemplateBase.LoadParams;
import de.his.appserver.service.dto.gen.DtoFactoryTemplateBase.SaveParams;
import de.his.appserver.service.dto.gen.InputKeySelectionItemDtoFactory;
import de.his.appserver.service.dto.gen.InputSelectionItemDtoFactory;
import de.his.appserver.service.dto.gen.IntegerFieldDtoFactory;
import de.his.appserver.service.dto.gen.IntegerFieldInputDtoFactory;
import de.his.appserver.service.dto.gen.KeySelectionItemDtoFactory;
import de.his.appserver.service.dto.gen.KeyTableSelectionFieldDtoFactory;
import de.his.appserver.service.dto.gen.KeyTableSelectionFieldInputDtoFactory;
import de.his.appserver.service.dto.gen.PeriodFieldDtoFactory;
import de.his.appserver.service.dto.gen.PeriodFieldInputDtoFactory;
import de.his.appserver.service.dto.gen.RequestSubjectDtoFactory;
import de.his.appserver.service.dto.gen.SelectionFieldDtoFactory;
import de.his.appserver.service.dto.gen.SelectionFieldInputDtoFactory;
import de.his.appserver.service.dto.gen.SelectionItemDtoFactory;
import de.his.appserver.service.dto.gen.SelectionItemGroupDtoFactory;
import de.his.appserver.service.dto.gen.TextFieldDtoFactory;
import de.his.appserver.service.dto.gen.TextFieldInputDtoFactory;
import de.his.appserver.service.dto.gen.iface.AbstractSelectionItemDto;
import de.his.appserver.service.dto.gen.iface.ApplicationContentAdmissionPackageDto;
import de.his.appserver.service.dto.gen.iface.ApplicationContentConditionDto;
import de.his.appserver.service.dto.gen.iface.ApplicationContentDto;
import de.his.appserver.service.dto.gen.iface.ApplicationContentInputDto;
import de.his.appserver.service.dto.gen.iface.DateFieldDto;
import de.his.appserver.service.dto.gen.iface.DateFieldInputDto;
import de.his.appserver.service.dto.gen.iface.DecimalFieldDto;
import de.his.appserver.service.dto.gen.iface.DecimalFieldInputDto;
import de.his.appserver.service.dto.gen.iface.DocumentFieldInputDto;
import de.his.appserver.service.dto.gen.iface.DocumentUploadFieldDto;
import de.his.appserver.service.dto.gen.iface.FieldDto;
import de.his.appserver.service.dto.gen.iface.FieldInputDto;
import de.his.appserver.service.dto.gen.iface.InputKeySelectionItemDto;
import de.his.appserver.service.dto.gen.iface.InputSelectionItemDto;
import de.his.appserver.service.dto.gen.iface.IntegerFieldDto;
import de.his.appserver.service.dto.gen.iface.IntegerFieldInputDto;
import de.his.appserver.service.dto.gen.iface.KeySelectionItemDto;
import de.his.appserver.service.dto.gen.iface.KeyTableSelectionFieldDto;
import de.his.appserver.service.dto.gen.iface.KeyTableSelectionFieldInputDto;
import de.his.appserver.service.dto.gen.iface.PeriodFieldDto;
import de.his.appserver.service.dto.gen.iface.PeriodFieldInputDto;
import de.his.appserver.service.dto.gen.iface.RequestSubjectDto;
import de.his.appserver.service.dto.gen.iface.SelectionFieldDto;
import de.his.appserver.service.dto.gen.iface.SelectionFieldInputDto;
import de.his.appserver.service.dto.gen.iface.SelectionItemDto;
import de.his.appserver.service.dto.gen.iface.SelectionItemGroupDto;
import de.his.appserver.service.dto.gen.iface.TextFieldDto;
import de.his.appserver.service.dto.gen.iface.TextFieldInputDto;
import de.his.appserver.service.dto.iface.KeyValueDto;
import de.his.appserver.service.dto.iface.cm.app.applicationContent.DocumentFieldInputXtdDto;
import de.his.appserver.service.dto.iface.cm.app.applicationContent.KeyTableSelectionFieldInputXtdDto;
import de.his.appserver.service.dto.iface.cm.app.applicationContent.SelectionFieldInputXtdDto;
import de.his.appserver.service.dto.iface.cs.sys.filemanagement.DocumentMetadataXtdDto;
import de.his.appserver.service.dto.impl.cm.app.applicationContent.DocumentFieldInputXtdDtoImpl;
import de.his.appserver.service.dto.impl.cm.app.applicationContent.KeyTableSelectionFieldInputXtdDtoImpl;
import de.his.appserver.service.dto.impl.cm.app.applicationContent.SelectionFieldInputXtdDtoImpl;
import de.his.appserver.service.iface.ValueService;
import de.his.appserver.service.iface.cm.app.applicationContent.ApplicationContentService;
import de.his.appserver.service.iface.cs.sys.filemanagement.DocumentMetadataService;
import de.his.appserver.service.iface.cs.sys.validation.ValidationService;
import de.his.appserver.service.iface.sul.zul.bewerbung.antragskerndaten.RequestgroupsService;
import de.his.appserver.service.impl.value.SortorderValueDtoComparator;
import de.his.core.TransactionSupport;
import de.his.core.util.ConverterUtil;
import de.his.core.util.DTOFactoryUtil;
import de.his.core.util.EnsureArgument;
import de.his.core.webapp.qis.ConfigUtil;
import de.his.tools.QISReflectionUtil;

/**
 * Company: HIS
 * @author schwaff
 */
@de.his.appserver.service.base.ServiceMetadata.ServiceImplMetadata(serviceRevision = "$Revision: 1.85.4.25 $")
public class ApplicationContentServiceImpl extends ServiceBaseImpl implements ApplicationContentService {

    private static final LoggerExt logger = LoggerExt.getLoggerExt(ApplicationContentServiceImpl.class);
    
    private ApplicationContentDao applicationContentDao;
    
    private ApplicationContentInputDao applicationContentInputDao;
    
    private ApplicationContentAdmissionPackageDao applicationContentAdmissionPackageDao;
    
    private RequestDao requestDao;
    
    private ApplicationDao applicationDao;
    
    private ValueService valueService;
    
    private RequestSubjectDao requestSubjectDao;
    
    private FieldDao fieldDao;
    
    private ApplicationContentConditionDao applicationContentConditionDao;
    
    private DocumentMetadataService documentMetadataService;
    
    private ValidationService validationService;
    
    private RequestgroupsService requestgroupsService;
    
    //@formatter:off
    // Load-paths
    private static final String[] APPLICATION_CONTENT_LOAD_PATHS = DTOFactoryUtil.asLoadPath(
                    new ApplicationContentDto.ApplicationContentPath().applicationContentFields().allowedValue(),
                    new ApplicationContentDto.ApplicationContentPath().applicationContentFields().selectionItems().selectionItems(),
                    new ApplicationContentDto.ApplicationContentPath().applicationContentAdmissionPackages());

    private static final String[] APPLICATION_CONTENT_INPUT_LOAD_PATHS = DTOFactoryUtil.asLoadPath(
                    new ApplicationContentInputDto.ApplicationContentInputPath().applicationContentDefinition().applicationContentFields().allowedValue(),
                    new ApplicationContentInputDto.ApplicationContentInputPath().applicationContentDefinition().applicationContentFields().selectionItems().selectionItems(),
                    new ApplicationContentInputDto.ApplicationContentInputPath().applicationContentDefinition().applicationContentAdmissionPackages(),
                    new ApplicationContentInputDto.ApplicationContentInputPath().fieldInputs().selectionItemValues().selectionItem(),
                    new ApplicationContentInputDto.ApplicationContentInputPath().fieldInputs().keyTableItemValues().keySelectionItem(),
                    new ApplicationContentInputDto.ApplicationContentInputPath().fieldInputs().field().allowedValue(),
                    new ApplicationContentInputDto.ApplicationContentInputPath().fieldInputs().field().selectionItems().selectionItems(),
                    new ApplicationContentInputDto.ApplicationContentInputPath().requestSubjects());
    
    private static final String[] APPLICATION_CONTENT_WITH_FIELDS_LOAD_PATHS = DTOFactoryUtil.asLoadPath(
                    new ApplicationContentDto.ApplicationContentPath().applicationContentInputs().fieldInputs());
    
    //@formatter:on
    
    @Override
    public ApplicationContentDto createApplicationContent() {
        ApplicationContentDto applicationContentDto = ApplicationContentDtoFactory.getNewDto();
        applicationContentDto.setIsMultiple(Boolean.FALSE);
        applicationContentDto.setDefaultlanguage(I18nUtils.getLanguageId());
        applicationContentDto.setAllocationObject(AllocationObject.APPLICATION.getKey());
        return applicationContentDto;
    }
    
    @Override
    public ApplicationContentDto loadApplicationContent(Long applicationContentId) {
        EnsureArgument.notNull(applicationContentId, "applicationContentId must not be null");
        ApplicationContentDto applicationContentDto = ApplicationContentDtoFactory.getDto(applicationContentId, APPLICATION_CONTENT_LOAD_PATHS);
        EnsureArgument.notNull(applicationContentDto, "applicationContentDto with id " + applicationContentId + " cannot be found!");
        return applicationContentDto;
    }
    
    @Override
    public List<ApplicationContentDto> loadApplicationContents(List<Long> applicationContentIds) {
        EnsureArgument.notNull(applicationContentIds, "applicationContentIds must not be null");
        List<ApplicationContent> applicationContents = this.applicationContentDao.findAllById(applicationContentIds);
        if(applicationContents != null) {
            return ApplicationContentDtoFactory.getDtos(applicationContents, APPLICATION_CONTENT_WITH_FIELDS_LOAD_PATHS);
        }
        return null;
    }

    private List<ApplicationContentDto> loadApplicationContents(List<Long> applicationContentIds, Long requestSubjectId) {
        EnsureArgument.notNull(applicationContentIds, "applicationContentIds must not be null");
        EnsureArgument.notNull(requestSubjectId, "requestSubject must not be null");
        List<ApplicationContentDto> applicationContentDtos = new ArrayList<ApplicationContentDto>();
        List<ApplicationContent> applicationContents = this.applicationContentDao.findAllById(applicationContentIds);
        if(applicationContents != null) {
            for (ApplicationContent applicationContent : applicationContents) {
                
                List<ApplicationContentInput> applicationContentInputs = this.applicationContentInputDao.findByApplicationContentAndRequestSubject(applicationContent.getId(), requestSubjectId);
                if(!applicationContentInputs.isEmpty()) {
                    // Es gibt bereits Eingaben, die wir laden
                    ApplicationContentInput applicationContentInput = applicationContentInputs.iterator().next();
                    String[] loadPath = DTOFactoryUtil.asLoadPath(new ApplicationContentInputDto.ApplicationContentInputPath().applicationContentDefinition());
                    ApplicationContentInputDto applicationContentInputDto = ApplicationContentInputDtoFactory.getDto(applicationContentInput, loadPath);
                    applicationContentDtos.add(applicationContentInputDto.getApplicationContentDefinition());
                    continue;
                }
                
                // Noch keine Eingaben vorhanden, mal sehen, ob das überhaupt angezeigt werden soll
                ApplicationContentCondition condition = applicationContent.getCondition();
                boolean evaluateCondition = evaluateCondition(condition, requestSubjectId);
                if(evaluateCondition) {
                    ApplicationContentDto applicationContentDto = ApplicationContentDtoFactory.getDto(applicationContent);
                    applicationContentDtos.add(applicationContentDto);
                } else {
                    logger.debug("The applicationContent " + applicationContent.getName() + " has not been added because the condition on requestSubject " + requestSubjectId + " returned false!");
                }
            }
        }
        return applicationContentDtos;
    }
    
    @Override
    public boolean deleteApplicationContent(Long applicationContentId) {
        EnsureArgument.notNull(applicationContentId, "applicationContentId must not be null");
        ApplicationContent applicationContent = this.applicationContentDao.findById(applicationContentId);
        if(applicationContent != null) {
            if(!applicationContent.getApplicationContentInputs().isEmpty()) {
                return false;
            }
            try {
                this.applicationContentDao.makeTransient(applicationContent);
                return true;
            } catch (Exception e) {
                logger.error("An error occured while trying to delete the applicationContent with id " + applicationContentId, e);
            }
        }
        return false;
    }
    
    @Override
    public void saveApplicationContent(ApplicationContentDto applicationContentDto) {
        EnsureArgument.notNull(applicationContentDto, "applicationContentDto must not be null");
        checkUniquename(applicationContentDto);
        ApplicationContentDtoFactory.saveDto(applicationContentDto, new SaveParams().setSavePaths(APPLICATION_CONTENT_LOAD_PATHS));
    }

    @Override
    public void saveApplicationContentField(FieldDto fieldDto) {
        EnsureArgument.notNull(fieldDto, "fieldDto must not be null");
        
        checkselectionField(fieldDto);
        
        ApplicationContentDto applicationContent = fieldDto.getApplicationContent();
        checkFieldUniquename(applicationContent);
        ApplicationContentDtoFactory.saveDto(applicationContent, new SaveParams().setSavePaths(APPLICATION_CONTENT_LOAD_PATHS));
    }

    /**
     * @param applicationContentDto
     */
    private void checkUniquename(ApplicationContentDto applicationContentDto) {
        // Überprüfen, ob der eingegebene uniquename wirklich unique ist
        ApplicationContent byUniquename = this.applicationContentDao.findByUniquename(applicationContentDto.getUniquename());
        if(byUniquename != null) {
            if(applicationContentDto.getId() == null || (!applicationContentDto.getId().equals(byUniquename.getId()))) {
                throw new ServiceException("cm.app.applicationContent.noUniquename", applicationContentDto.getUniquename());
            } 
        }
    }
    
    /**
     * Überprüft die Eingaben bei der Definition der einfachen Auswahllisten. 
     * <ul>
     * <li>Mindestens zwei Auswahlmöglichkeiten müssen konfiguriert werden, bevor gespeichert werden kann. (https://hiszilla.his.de/hiszilla/show_bug.cgi?id=95547)</li>
     * <li>Einfache Auswahl: nur eine Auswahlmöglichkeit darf als Vorbelegung verwendet werden</li>
     * </ul>
     * 
     * @param fieldDto
     * @throws ServiceException
     */
    private void checkselectionField(FieldDto fieldDto) throws ServiceException {
        if(fieldDto instanceof SelectionFieldDto) { 
            SelectionFieldDto selectionFieldDto = (SelectionFieldDto) fieldDto;
            
            List<AbstractSelectionItemDto> selectionItems = selectionFieldDto.getSelectionItems();
            if(selectionItems == null || selectionItems.size() < 2) {
                throw new ServiceException("cm.app.applicationContent.selectionField.minTwoSelections");
            }
            
            // Nur bei nicht-merhfachauswahlen selectionFields prüfen
            if(selectionFieldDto.isMultipleSelectionAllowedSet() && 
                            selectionFieldDto.getMultipleSelectionAllowed()!= null && 
                            !selectionFieldDto.getMultipleSelectionAllowed().booleanValue()) {
                int defaultSelections = 0;
                
                for (AbstractSelectionItemDto abstractSelectionItemDto : selectionItems) {
                    if(abstractSelectionItemDto instanceof SelectionItemDto) {
                        SelectionItemDto selectionItemDto = (SelectionItemDto) abstractSelectionItemDto;
                        if(selectionItemDto.getIsDefault() != null && selectionItemDto.getIsDefault().booleanValue()) {
                            defaultSelections++;
                            if(defaultSelections > 1) {
                                throw new ServiceException("cm.app.applicationContent.selectionField.multipleSelectionNotAllowed");
                            }
                        }
                    } if(abstractSelectionItemDto instanceof SelectionItemGroupDto) {
                        SelectionItemGroupDto selectionItemGroupDto = (SelectionItemGroupDto) abstractSelectionItemDto;
                        List<SelectionItemDto> selectionItems2 = selectionItemGroupDto.getSelectionItems();
                        for (SelectionItemDto selectionItemDto : selectionItems2) {
                            if(selectionItemDto.getIsDefault() != null && selectionItemDto.getIsDefault().booleanValue()) {
                                defaultSelections++;
                                if(defaultSelections > 1) {
                                    throw new ServiceException("cm.app.applicationContent.selectionField.multipleSelectionNotAllowed");
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private void checkFieldUniquename(ApplicationContentDto applicationContentDto) {
        // Prüfen, ob die Uniquenames der Felder jeweils eindeutig sind
        Collection<FieldDto> fields = applicationContentDto.getApplicationContentFields();
        Collection<String> fieldUniquenames = new HashSet<String>();
        for (FieldDto field : fields) {
            String key = field.getUniquename();
            if (fieldUniquenames.contains(key)) {
                throw new ServiceException("cm.app.applicationContent.noUniquename", key);
            }
            fieldUniquenames.add(key);
        }
    }
    
    @Override
    public ApplicationContentDto saveApplicationContentAsCopy(ApplicationContentDto applicationContentDto) {
        EnsureArgument.notNull(applicationContentDto, "applicationContentDto must not be null");
        applicationContentDto.makeSaveableAsNewEntity(APPLICATION_CONTENT_LOAD_PATHS);
        applicationContentDto.setName(applicationContentDto.getName() + " (Kopie)");
        applicationContentDto.setUniquename(applicationContentDto.getUniquename() + " (Kopie)");
        checkUniquename(applicationContentDto);
        ApplicationContentDtoFactory.saveDto(applicationContentDto);
        return applicationContentDto;
    }
    
    @Override
    @Deprecated
    public List<ApplicationContentAdmissionPackageDto> getApplicationContentAdmissionPackagesByRequestId(Long requestId) {
        logger.enter("getApplicationContentAdmissionPackagesByRequestId", "requestId", requestId);
        List<ApplicationContentAdmissionPackage> applicationContentAdmissionPackagesToLoad = new ArrayList<ApplicationContentAdmissionPackage>();
        List<ApplicationContentAdmissionPackage> applicationContentAdmissionPackages = this.applicationContentAdmissionPackageDao.findByRequestId(requestId);
        logger.debug("Found " + applicationContentAdmissionPackages.size() + " applicationContentAdmissionPackages for requestId " + requestId);
        Request request = this.requestDao.findById(requestId);
        Collection<RequestSubject> requestSubjects = request.getRequestSubjects();
        for (ApplicationContentAdmissionPackage applicationContentAdmissionPackage : applicationContentAdmissionPackages) {
            // Über die condition Überprüfen, ob dieser Bewerbungsinhalt angezeigt werden soll
            if(showApplicationContent(applicationContentAdmissionPackage, requestSubjects)) {
                applicationContentAdmissionPackagesToLoad.add(applicationContentAdmissionPackage);
            }
        }
        List<ApplicationContentAdmissionPackageDto> dtos = ApplicationContentAdmissionPackageDtoFactory.getDtos(applicationContentAdmissionPackagesToLoad);
        logger.leave("getApplicationContentAdmissionPackagesByRequestId");
        return dtos;
    }
    
    @Override
    public List<ApplicationContentAdmissionPackageDto> getApplicationContentAdmissionPackagesByRequestSubjectId(Long requestSubjectId) {
        logger.enter("getApplicationContentAdmissionPackagesByRequestSubjectId", "requestSubjectId", requestSubjectId);
        List<ApplicationContentAdmissionPackage> applicationContentAdmissionPackagesToLoad = new ArrayList<ApplicationContentAdmissionPackage>();
        List<ApplicationContentAdmissionPackage> applicationContentAdmissionPackages = this.applicationContentAdmissionPackageDao.findByRequestSubjectId(requestSubjectId);
        logger.debug("Found " + applicationContentAdmissionPackages.size() + " applicationContentAdmissionPackages for requestSubjectId " + requestSubjectId);
        for (ApplicationContentAdmissionPackage applicationContentAdmissionPackage : applicationContentAdmissionPackages) {
            ApplicationContentCondition condition = applicationContentAdmissionPackage.getCondition();
            // Über die condition Überprüfen, ob dieser Bewerbungsinhalt angezeigt werden soll
            boolean evaluateCondition = evaluateCondition(condition, requestSubjectId, null);
            if(!evaluateCondition) {
                logger.debug("The condition " + condition + " evaluates to FALSE for requestSubjectId " + requestSubjectId + "; we will skip this applicationContentAdmissionPackage.");
                continue;
            }
            // wir können vorzeitig abbrechen, da die Zuordnug des AdmissionPackages eindeutig ist
            applicationContentAdmissionPackagesToLoad.add(applicationContentAdmissionPackage);
        }
        List<ApplicationContentAdmissionPackageDto> dtos = ApplicationContentAdmissionPackageDtoFactory.getDtos(applicationContentAdmissionPackagesToLoad);
        logger.leave("getApplicationContentAdmissionPackagesByRequestId");
        return dtos;
    }
    
    private boolean showApplicationContent(ApplicationContentAdmissionPackage applicationContentAdmissionPackage, Collection<RequestSubject> requestSubjects) {
        ApplicationContentCondition condition = applicationContentAdmissionPackage.getCondition();
        if (condition != null && condition.getExpression() != null && !condition.getExpression().isEmpty()) {
            AdmissionPackage admissionPackage = applicationContentAdmissionPackage.getAdmissionPackage();
            for (RequestSubject requestSubject : requestSubjects) {
                if(requestSubject.getAdmissionPackage().getObjGuid().equals(admissionPackage.getObjGuid())) {
                    boolean evaluateCondition = evaluateCondition(condition, requestSubject.getId(), null);
                    if(!evaluateCondition) {
                        logger.debug("The condition " + condition + " evaluates to FALSE for requestSubject " + requestSubject + "; we will skip this applicationContentAdmissionPackage.");
                        return false;
                    }
                    // wir können vorzeitig abbrechen, da die Zuordnug des AdmissionPackages eindeutig ist
                    return true;
                }
            }
        }
        return true;
    }
    
    @Override
    public List<Long> getApplicationContentAdmissionPackagesIdsByRequestId(Long requestId) {
        List<Long> list = new ArrayList<Long>(); 
        List<ApplicationContentAdmissionPackage> applicationContentAdmissionPackages = this.applicationContentAdmissionPackageDao.findByRequestId(requestId);
        for (ApplicationContentAdmissionPackage applicationContentAdmissionPackage : applicationContentAdmissionPackages) {
            list.add(applicationContentAdmissionPackage.getId());
        }
        return list;
    }
    
    @Override
    public ApplicationContentAdmissionPackageDto createApplicationContentAdmissionPackage(Long applicationContentId, Long admissionPackageId) {
        EnsureArgument.notNull(applicationContentId, "applicationContentId must not be null");
        EnsureArgument.notNull(admissionPackageId, "admissionPackageId must not be null");
        ApplicationContentAdmissionPackageDto ApplicationContentAdmissionPackageDto = ApplicationContentAdmissionPackageDtoFactory.getNewDto();
        ApplicationContentAdmissionPackageDto.setAdmissionPackageId(admissionPackageId);
        ApplicationContentAdmissionPackageDto.setApplicationContentId(applicationContentId);
        ApplicationContentAdmissionPackageDto.setIsOptional(Boolean.FALSE);
        ApplicationContentAdmissionPackageDto.setSortorder(Integer.valueOf(0));
        return ApplicationContentAdmissionPackageDto;
    }
    
    @Override
    public ApplicationContentAdmissionPackageDto createApplicationContentAdmissionPackage(ApplicationContentDto applicationContentDto) {
        EnsureArgument.notNull(applicationContentDto, "applicationContentDto must not be null");
        ApplicationContentAdmissionPackageDto ApplicationContentAdmissionPackageDto = ApplicationContentAdmissionPackageDtoFactory.getNewDto();
        int i = 0;
        Collection<ApplicationContentAdmissionPackageDto> applicationContentAdmissionPackages = applicationContentDto.getApplicationContentAdmissionPackages();
        for (ApplicationContentAdmissionPackageDto _ApplicationContentAdmissionPackageDto : applicationContentAdmissionPackages) {
            if(_ApplicationContentAdmissionPackageDto.getSortorder().intValue() >= i) {
                i = _ApplicationContentAdmissionPackageDto.getSortorder().intValue() + 1;
            }
        }
        ApplicationContentAdmissionPackageDto.setSortorder(Integer.valueOf(i));
        ApplicationContentAdmissionPackageDto.setIsOptional(Boolean.FALSE);
        ApplicationContentAdmissionPackageDto.setApplicationContent(applicationContentDto);
        return ApplicationContentAdmissionPackageDto;
    }
    
    @Override
    public List<ApplicationContentAdmissionPackageDto> createApplicationContentAdmissionPackages(ApplicationContentDto applicationContentDto, List<Long> admissionPackageIds) {
        EnsureArgument.notNull(applicationContentDto, "applicationContentDto must not be null");
        EnsureArgument.notNull(admissionPackageIds, "admissionPackageIds must not be null");
        List<ApplicationContentAdmissionPackageDto> admissionPackageDtos = new ArrayList<ApplicationContentAdmissionPackageDto>();
        for (Long admissionPackageId : admissionPackageIds) {
            ApplicationContentAdmissionPackageDto applicationContentAdmissionPackage = this.createApplicationContentAdmissionPackage(applicationContentDto);
            applicationContentAdmissionPackage.setAdmissionPackageId(admissionPackageId);
            admissionPackageDtos.add(applicationContentAdmissionPackage);
        }
        return admissionPackageDtos;
    }
    
    @Override
    public void saveApplicationContentAdmissionPackage(ApplicationContentAdmissionPackageDto applicationContentAdmissionPackage) {
        EnsureArgument.notNull(applicationContentAdmissionPackage, "applicationContentAdmissionPackage must not be null");
        ApplicationContentAdmissionPackageDtoFactory.saveDto(applicationContentAdmissionPackage, new SaveParams().setSavePaths(applicationContentAdmissionPackageSavePath));
    }
    
    @Override
    public FieldDto createField(ApplicationContentDto applicationContentDto, String type) {
        EnsureArgument.notNull(type, "FieldInputDiscriminatorType must not be null");
        return this.createField(applicationContentDto, FieldInputDiscriminatorType.valueOf(type));
    }
    
    @Override
    public FieldDto createField(ApplicationContentDto applicationContentDto, FieldInputDiscriminatorType type) {
        EnsureArgument.notNull(applicationContentDto, "applicationContentDto must not be null");
        EnsureArgument.notNull(type, "FieldInputDiscriminatorType must not be null");
        FieldDto fieldDto = null;
        switch (type) {
            case SIMPLE_SELECTION:
                fieldDto = SelectionFieldDtoFactory.getNewDto();
                break;
            case DATE:
                fieldDto = DateFieldDtoFactory.getNewDto();
                break;
            case DECIMAL:
                fieldDto = DecimalFieldDtoFactory.getNewDto();
                break;
            case DOCUMENT:
                fieldDto = DocumentUploadFieldDtoFactory.getNewDto();
                break;
            case INTEGER:
                fieldDto = IntegerFieldDtoFactory.getNewDto();
                break;
            case KEY_TABLE_SELECTION:
                KeyTableSelectionFieldDto keyTableSelectionFieldDto = KeyTableSelectionFieldDtoFactory.getNewDto();
                keyTableSelectionFieldDto.setSortOrderProperty("defaulttext");
                fieldDto = keyTableSelectionFieldDto;
                break;
            case PERIOD:
                fieldDto = PeriodFieldDtoFactory.getNewDto();
                break;
            case TEXT:
                fieldDto = TextFieldDtoFactory.getNewDto();
                break;
            default:
                logger.error("unexpected FieldInputDiscriminatorType: " + type);
                break;
        }
        if(fieldDto != null) {
            fieldDto.setVisibilityForApplicants(ApplicantVisibility.IS_EDITABLE.getKey());
            fieldDto.setOptional(Boolean.FALSE);
            fieldDto.setSortorder(getNextSortorder(applicationContentDto));
            fieldDto.setDefaultlanguage(applicationContentDto.getDefaultlanguage());
        }
        applicationContentDto.addToApplicationContentFields(fieldDto);
        return fieldDto;
    }
    
    @Override
    public SelectionItemDto addSelectionItem(GeneratedDtoBase dtoBase) {
        SelectionItemDto selectionItemDto = SelectionItemDtoFactory.getNewDto();
        
        if(dtoBase instanceof SelectionFieldDto) {            
            SelectionFieldDto selectionFieldDto = (SelectionFieldDto) dtoBase;
            List<AbstractSelectionItemDto> selectionItems = selectionFieldDto.getSelectionItems();
            setSortorder(selectionItemDto, selectionItems);
            selectionItemDto.setDefaultlanguage(selectionFieldDto.getDefaultlanguage());
            selectionFieldDto.addToSelectionItems(selectionItemDto);
        } else if(dtoBase instanceof SelectionItemGroupDto) {            
            SelectionItemGroupDto selectionItemGroupDto = (SelectionItemGroupDto) dtoBase;
            List<SelectionItemDto> selectionItems = selectionItemGroupDto.getSelectionItems();
            setSortorder(selectionItemDto, selectionItems);
            selectionItemDto.setDefaultlanguage(selectionItemGroupDto.getDefaultlanguage());
            selectionItemGroupDto.addToSelectionItems(selectionItemDto);
        } else {
            logger.error("The object " + dtoBase + " is undefined");
        }
        return selectionItemDto;
    }

    /**
     * @param selectionItemDto
     * @param selectionItems
     */
    private void setSortorder(SelectionItemDto selectionItemDto, List<? extends AbstractSelectionItemDto> selectionItems) {
        int i = 0;
        for (AbstractSelectionItemDto selectionItem : selectionItems) {
            int sortorder = selectionItem.getSortorder().intValue();
            if(sortorder >= i) {
                i = sortorder + 1;
            }
        }
        selectionItemDto.setSortorder(Integer.valueOf(i));
    }

    @Override
    public SelectionItemGroupDto addSelectionItemGroup(SelectionFieldDto selectionFieldDto) {
        SelectionItemGroupDto selectionItemGroupDto = SelectionItemGroupDtoFactory.getNewDto();
        
        List<AbstractSelectionItemDto> selectionItems = selectionFieldDto.getSelectionItems();
        int i = 0;
        for (AbstractSelectionItemDto selectionItem : selectionItems) {
            int sortorder = selectionItem.getSortorder().intValue();
            if(sortorder >= i) {
                i = sortorder + 1;
            }
        }
        selectionItemGroupDto.setSortorder(Integer.valueOf(i));
        
        selectionItemGroupDto.setDefaultlanguage(selectionFieldDto.getDefaultlanguage());
        selectionFieldDto.addToSelectionItems(selectionItemGroupDto);
        return selectionItemGroupDto;
    }
    
    @Override
    public void setKeyTableSelectionItems(KeyTableSelectionFieldDto fieldDto, SelectedValuesHashMap selectedValuesHashMap) {
        List<KeySelectionItemDto> keySelectionItemDtos = new ArrayList<KeySelectionItemDto>();
        List<KeySelectionItemDto> allowedValues = fieldDto.getAllowedValue();
        for (KeySelectionItemDto keySelectionItemDto : allowedValues) {
            keySelectionItemDto.setMarkedToDelete(true);
        }
        fieldDto.clearAllowedValue();
        Set<Entry<Object, Boolean>> entrySet = selectedValuesHashMap.entrySet();
        for (Entry<Object, Boolean> entry : entrySet) {
            if (entry.getValue() != null && entry.getValue().booleanValue()) {
                String entityObjGuid = ConverterUtil.asString(entry.getKey());
                KeySelectionItemDto keySelectionItemDto = KeySelectionItemDtoFactory.getNewDto();
                keySelectionItemDto.setEntityObjGuid(entityObjGuid);
                keySelectionItemDto.setApplicationContentField(fieldDto);
                keySelectionItemDto.setIsDefault(Boolean.FALSE);
                keySelectionItemDtos.add(keySelectionItemDto);
            }
        }
        fieldDto.setAllowedValue(keySelectionItemDtos);
        String[] keyTableSelectionFieldDtoSavePath = new String[] { KeyTableSelectionFieldDto.allowedValue };
        KeyTableSelectionFieldDtoFactory.saveDto(fieldDto, new SaveParams().setSavePaths(keyTableSelectionFieldDtoSavePath));
    }
    
    
    /**
     * Determines the sortorder by getting the greatest existing sortorder and increase it by one
     * @param applicationContentDto
     * @return the next sortorder
     */
    private Integer getNextSortorder(ApplicationContentDto applicationContentDto) {
        int max = 0;
        List<FieldDto> applicationContentFields = applicationContentDto.getApplicationContentFields();
        for (FieldDto fieldDto : applicationContentFields) {
            if(fieldDto.getSortorder().intValue() > max) {
                max = fieldDto.getSortorder().intValue();
            }
        }
        return Integer.valueOf(max + 1);
    }

    @Override
    public void saveApplicationContentInput(ApplicationContentInputDto applicationContentInputDto) {
        EnsureArgument.notNull(applicationContentInputDto, "applicationContentInputDto mut not be null");
        ApplicationContentInputDtoFactory.saveDto(applicationContentInputDto);
    }
    
    @Override
    public void saveApplicationContentInputs(List<ApplicationContentInputDto> applicationContentInputDtos) {
        EnsureArgument.notNull(applicationContentInputDtos, "applicationContentInputDtos mut not be null");
        try {
            ApplicationContentInputDtoFactory.saveDto(applicationContentInputDtos);
        } catch (Exception e) {
            logger.warn("An error occured while save the applicationContentInputDtos", e);
            throw new ServiceException(e.getMessage());
        }
    }

    @Override
    public Map<Long, List<ApplicationContentInputDto>> getAllApplicationContentInputDtos(List<Long> requestIds) {
        EnsureArgument.notNull(requestIds);
        Map<Long, List<ApplicationContentInputDto>> map = new HashMap<Long, List<ApplicationContentInputDto>>();
        for (Long requestId : requestIds) {
            List<ApplicationContentInputDto> allApplicationContentInputDtos = getAllApplicationContentInputDtos(requestId);
            Collections.sort(allApplicationContentInputDtos, new ApplicationContentInputComparator());
            map.put(requestId, allApplicationContentInputDtos);
        }
        return map;
    }
    
    @Override
    public List<ApplicationContentInputDto> getAllApplicationContentInputDtos(Long requestId) {
        EnsureArgument.notNull(requestId, "requestId must not be null");
        logger.enter("getAllApplicationContentInputDtos", "requestId", requestId);
        
        List<ApplicationContentInputDto> applicationContentInputDtoList = new ArrayList<ApplicationContentInputDto>();
        Request request = this.requestDao.findById(requestId);
        if(request != null) {
            Set<RequestSubject> requestSubjects = request.getRequestSubjects();
            for (RequestSubject requestSubject : requestSubjects) {
                Long requestSubjectId = requestSubject.getId();
                logger.debug("Attempt to load ApplicationContentAdmissionPackages by requestSubjectId " + requestSubjectId);
                List<ApplicationContentAdmissionPackage> applicationContentAdmissionPackages = this.applicationContentAdmissionPackageDao.findByRequestSubjectId(requestSubjectId);
                logger.debug("Found " + applicationContentAdmissionPackages.size() + " ApplicationContentAdmissionPackages by requestSubjectId " + requestSubjectId);
                for (ApplicationContentAdmissionPackage applicationContentAdmissionPackage : applicationContentAdmissionPackages) {
                    Map<Long, Collection<ApplicationContentInputDto>> applicationContentInputDtos = getApplicationContentInputDtos(true, requestSubject, applicationContentAdmissionPackage.getApplicationContent().getId());
                    for (Collection<ApplicationContentInputDto> _applicationContentInputDtos : applicationContentInputDtos.values()) {
                        for (ApplicationContentInputDto applicationContentInputDto : _applicationContentInputDtos) {
                            applicationContentInputDtoList.add(applicationContentInputDto);
                        }
                    }
                }
            }
        }
        logger.leave("getAllApplicationContentInputDtos", applicationContentInputDtoList);
        return applicationContentInputDtoList;
    }

    @Override
    public List<ApplicationContentInputDto> getApplicationContentInputDtos(Long requestSubjectId, Long applicationContentId) {
        logger.enter("getApplicationContentInputDtos", "requestSubjectId", requestSubjectId, "applicationContentId", applicationContentId);
        List<ApplicationContentInputDto> applicationContentInputDtoList = new ArrayList<ApplicationContentInputDto>();
        RequestSubject requestSubject = this.requestSubjectDao.findById(requestSubjectId);
        if(requestSubject != null) {
            Map<Long, Collection<ApplicationContentInputDto>> applicationContentInputDtos = getApplicationContentInputDtos(true, requestSubject, applicationContentId);
            for (Collection<ApplicationContentInputDto> _applicationContentInputDtos : applicationContentInputDtos.values()) {
                applicationContentInputDtoList.addAll(_applicationContentInputDtos);
            }
        } else {
            logger.error("Cannot find RequestSubject with id " + requestSubjectId);
        }
        logger.leave("getApplicationContentInputDtos");
        return applicationContentInputDtoList;
    }
    
    @Override
    public List<ApplicationContentInputDto> getApplicationContentInputDtosByRequestId(Long requestId, Long applicationContentId) {
        logger.enter("getApplicationContentInputDtos", "requestId", requestId, "applicationContentId", applicationContentId);
        
        // bereits erfrage ApplicationContents (mit der Zuordnung zur Bewerbung)
        List<String> alreadyInquiredApplicationContentInputs = new ArrayList<String>();
        
        List<ApplicationContentInputDto> applicationContentInputDtoList = new ArrayList<ApplicationContentInputDto>();
        Request request = this.requestDao.findById(requestId);
        if(request != null) {
            Set<RequestSubject> requestSubjects = request.getRequestSubjects();
            for (RequestSubject requestSubject : requestSubjects) {
                
//                ApplicationContent applicationContent = this.applicationContentDao.findById(applicationContentId);
//                if(applicationContent.getAllocationObject().equals(AllocationObject.APPLICATION.getKey())) {
//                    if(alreadyInquiredApplicationContents.contains(applicationContentId)) {
//                        // bereits erfragt ... 
//                        continue;
//                    }
//                }
                
                Map<Long, Collection<ApplicationContentInputDto>> applicationContentInputDtos = getApplicationContentInputDtos(true, requestSubject, applicationContentId);
                for (Collection<ApplicationContentInputDto> _applicationContentInputDtos : applicationContentInputDtos.values()) {
                    for (ApplicationContentInputDto applicationContentInputDto : _applicationContentInputDtos) {
                        if(alreadyInquiredApplicationContentInputs.contains(applicationContentInputDto.getObjGuid())) {
                            continue;
                        }
                        alreadyInquiredApplicationContentInputs.add(applicationContentInputDto.getObjGuid());
                        applicationContentInputDtoList.add(applicationContentInputDto);
                    }
                }
            }
        } else {
            logger.error("Cannot find Request with id " + requestId);
        }
        Collections.sort(applicationContentInputDtoList, new ApplicationContentInputComparator());
        logger.leave("getApplicationContentInputDtos");
        return applicationContentInputDtoList;
    }
    
    @Override
    public Map<Long, Collection<ApplicationContentInputDto>> getApplicationContentInputDtosProcessing(Long applicationId) {
        EnsureArgument.notNull(applicationId, "applicationId must not be null");
        Map<Long, Collection<ApplicationContentInputDto>> map = new HashMap<Long, Collection<ApplicationContentInputDto>>();
        Application application = this.applicationDao.findById(applicationId);
        Collection<RequestSubject> requestSubjects = application.getRequestSubjects();
        for (RequestSubject requestSubject : requestSubjects) {
            List<ApplicationContentAdmissionPackage> applicationContentAdmissionPackages = this.applicationContentAdmissionPackageDao.findByRequestSubjectId(requestSubject.getId());
            for (ApplicationContentAdmissionPackage applicationContentAdmissionPackage : applicationContentAdmissionPackages) {
                Map<Long, Collection<ApplicationContentInputDto>> applicationContentInputs = __getApplicationContentInput(false, applicationContentAdmissionPackage.getApplicationContent(), requestSubject);
                for (Long requestSubjectId : applicationContentInputs.keySet()) {
                    if(map.containsKey(requestSubjectId)) {
                        Collection<ApplicationContentInputDto> list = map.get(requestSubjectId);
                        list.addAll(applicationContentInputs.get(requestSubjectId));
                        map.put(requestSubjectId, list);
                    } else {
                        map.put(requestSubjectId, applicationContentInputs.get(requestSubjectId));
                    }
                }
            }
        }
        return map;
    }
    
    @Override
    public Map<Long, List<ApplicationContentDto>> getApplicationContentProcessing(Long applicationId) {
        EnsureArgument.notNull(applicationId, "applicationId must not be null");
        Map<Long, List<ApplicationContentDto>> map = new HashMap<Long, List<ApplicationContentDto>>();
        Application application = this.applicationDao.findById(applicationId);
        Set<RequestSubject> requestSubjects = (Set<RequestSubject>) application.getRequestSubjects();
        for (RequestSubject requestSubject : requestSubjects) {
            List<Long> applicationContentIds = applicationContentDao.findByRequestSubjectId(requestSubject.getId());
            if (applicationContentIds != null && applicationContentIds.size() > 0) {
                List<ApplicationContentDto> applicationContentDtos = loadApplicationContents(applicationContentIds, requestSubject.getId());
                map.put(requestSubject.getId(), applicationContentDtos);                
            }
        }
        
        return map;
    }
    
    private Map<Long, Collection<ApplicationContentInputDto>> getApplicationContentInputDtos(boolean isOnlineApplication, RequestSubject requestSubject, Long applicationContentId) {
        EnsureArgument.notNull(requestSubject, "requestSubject mut not be null");
        if(applicationContentId != null) {
            logger.debug("Attempt to load ApplicationContentInputs by requestSubject " + requestSubject);
            if(requestSubject != null) {
                logger.debug("Attempt to load ApplicationContent by applicationContentId " + applicationContentId);
                ApplicationContent applicationContent = this.applicationContentDao.findById(applicationContentId);
                return __getApplicationContentInput(isOnlineApplication, applicationContent, requestSubject);
            }
        }
        return new HashMap<Long, Collection<ApplicationContentInputDto>>();
    }

    /**
     * @param isOnlineApplication
     * @param applicationContentId
     * @param applicationContentInputDtos
     * @param request
     */
    private Map<Long, Collection<ApplicationContentInputDto>> __getApplicationContentInput(boolean isOnlineApplication, ApplicationContent applicationContent, RequestSubject requestSubject) {
        logger.enter("__getApplicationContentInput", "isOnlineApplication", Boolean.valueOf(isOnlineApplication), "applicationContent", applicationContent, "requestSubject", requestSubject);
        HashMap<Long,Collection<ApplicationContentInputDto>> hashMap = new HashMap<Long, Collection<ApplicationContentInputDto>>();
        
        LoadParams loadParams = new LoadParams();
        loadParams.setReplacedDtoClasses(KeyTableSelectionFieldInputXtdDtoImpl.class, SelectionFieldInputXtdDtoImpl.class, DocumentFieldInputXtdDtoImpl.class);
        
        // Ist der gegebene applicationContent überhaupt zu diesem Antragsfach zugeordnet?
        Set<ApplicationContentAdmissionPackage> applicationContentAdmissionPackages = applicationContent.getApplicationContentAdmissionPackages();
        for (ApplicationContentAdmissionPackage applicationContentAdmissionPackage : applicationContentAdmissionPackages) {
            if(applicationContentAdmissionPackage.getAdmissionPackage().equals(requestSubject.getAdmissionPackage())) {
                
                Collection<ApplicationContentInputDto> applicationContentInputDtos = new HashSet<ApplicationContentInputDto>();
                
                // Auswertung der condition
                Application application = requestSubject.getApplication();
                ApplicationContentCondition condition = applicationContent.getCondition();
                boolean evaluateCondition = evaluateCondition(condition, requestSubject.getId(), null);
                if(!evaluateCondition) {
                    logger.debug("The condition " + condition + " evaluates to FALSE for requestSubject " + requestSubject + "; we will skip this applicationContent.");
                    continue;
                }
                
                if(isOnlineApplication && !applicationContent.isVisibleForApplicant()) {
                    // dieser Bewerbugnsinhalt soll nicht in der Online-Bewerbung angezeigt werden
                    logger.debug("The applicationContent " + applicationContent + " is not visible in online-application; we will skip this applicationContent.");
                    continue;
                } else if(!isOnlineApplication) {
                    // TODO: Sachbearbeitung ... wir müssen sehen, ob der Sachbearbeiter das überhaupt sehen darf
                }
                
                Long applicationId = application.getId();
                if(applicationContent.getAllocationObject().equals(AllocationObject.APPLICATION.getKey())) {
                    // Bewerbungsinhalt, der der Bewerbung zugordnet ist
                    logger.debug("The applicationContent " + applicationContent + " is allocated to the application.");
                    List<ApplicationContentInput> applicationContentInputs = this.applicationContentInputDao.findByApplicationId(applicationId, applicationContent.getId());
                    addApplicationContentInputs(isOnlineApplication, applicationContent, loadParams, requestSubject, applicationContentInputDtos, applicationContentInputs);
                }
                else if(applicationContent.getAllocationObject().equals(AllocationObject.ADMISSIONPACKAGE.getKey())) {
                    // Bewerbungsinhalt, der dem Zulassungspaket zugordnet ist
                    logger.debug("The applicationContent " + applicationContent + " is allocated to the admissionpackage.");
                    List<ApplicationContentInput> applicationContentInputs = this.applicationContentInputDao.findByAdmissionPackageId(requestSubject.getAdmissionPackage().getId(), applicationId, applicationContent.getId());
                    addApplicationContentInputs(isOnlineApplication, applicationContent, loadParams, requestSubject, applicationContentInputDtos, applicationContentInputs);
                }
                logger.debug("We have found " + applicationContentInputDtos.size() + " applicationContentInputs("+applicationContent.getName() +") for requestSubject " + requestSubject);
                hashMap.put(requestSubject.getId(), applicationContentInputDtos);
                
                break;
            }
        }
        logger.leave("__getApplicationContentInput");
        return hashMap;
    }

    /**
     * @param isOnlineApplication
     * @param applicationContent
     * @param loadParams
     * @param requestSubject
     * @param applicationContentInputDtos
     * @param admissionPackageId
     * @param requestSubjectDto
     * @param applicationId
     * @param applicationContentInputs
     */
    private void addApplicationContentInputs(boolean isOnlineApplication, ApplicationContent applicationContent, LoadParams loadParams, RequestSubject requestSubject, Collection<ApplicationContentInputDto> applicationContentInputDtos, List<ApplicationContentInput> applicationContentInputs) {
        if(applicationContentInputs != null && !applicationContentInputs.isEmpty()) {
            logger.debug("Found " + applicationContentInputs.size() + " applicationContentInputs for applicationContent " + applicationContent);
            // Die Bewerbungsinhalte aus der Datenbank lesen
            for (ApplicationContentInput applicationContentInput : applicationContentInputs) {
                logger.debug("Attempt to load ApplicationContentInput " + applicationContentInput);
                ApplicationContentInputDto dto = loadApplicationContentInputDto(isOnlineApplication, loadParams, requestSubject, applicationContentInput);
                applicationContentInputDtos.add(dto);                                
            }
        } else if (isOnlineApplication) {
            if(!applicationContent.isAnyFieldEditable()) {
                logger.debug("No field of the applicationContent " + applicationContent + " is editable, so we will skip to create this.");
            } else {
                // Dieser Bewerbungsinhalt wurde noch nicht angelegt. Es muss ein neuer erstellt werden
                logger.debug("Create a new ApplicationContentInput: applicationContent: " + applicationContent + "; requestSubject: " + requestSubject + "; isOnlineApplication: " + isOnlineApplication);
                ApplicationContentInputDto applicationContentInputDto = createApplicationContentInput(applicationContent, requestSubject, isOnlineApplication, false);
                
                applicationContentInputDtos.add(applicationContentInputDto);
            }
        }
    }
    
    /**
     * @param isOnlineApplication
     * @param loadParams
     * @param requestSubject
     * @param admissionPackageId
     * @param requestSubjectDto
     * @param applicationContentInput
     * @return
     */
    private ApplicationContentInputDto loadApplicationContentInputDto(boolean isOnlineApplication, LoadParams loadParams, RequestSubject requestSubject, ApplicationContentInput applicationContentInput) {
        ApplicationContentInputDto applicationContentInputDto = ApplicationContentInputDtoFactory.getDto(applicationContentInput, loadParams, APPLICATION_CONTENT_INPUT_LOAD_PATHS);
        String[] loadPath = DTOFactoryUtil.asLoadPath(new RequestSubjectDto.RequestSubjectPath().applicationContentInputs());
        RequestSubjectDto requestSubjectDto = RequestSubjectDtoFactory.getDto(requestSubject, loadPath);
        if(!applicationContentInputDto.getRequestSubjects().contains(requestSubjectDto)) {
            // dieses RequestSubject hinzufügen
            applicationContentInputDto.addToRequestSubjects(requestSubjectDto);
        }
        applicationContentInputDto.setRequestSubjectId(requestSubject.getId());
        applicationContentInputDto.setAdmissionPackageId(requestSubject.getAdmissionPackage().getId());
        applicationContentInputDto.setApplicationId(requestSubject.getApplication().getId());
        this.setFieldInputMetaData(applicationContentInputDto, isOnlineApplication);
        return applicationContentInputDto;
    }
    
    @Override
    public InputKeySelectionItemDto createInputKeySelectionItem() {
        return InputKeySelectionItemDtoFactory.getNewDto();
    }

    @Override
    public InputSelectionItemDto createInputSelectionItem() {
        return InputSelectionItemDtoFactory.getNewDto();
    }
    
    @Override
    public ApplicationContentInputDto createApplicationContentInput(Long applicationContentId, Long requestSubjectId, boolean isOnlineApplication) {
        EnsureArgument.notNull(applicationContentId);
        EnsureArgument.notNull(requestSubjectId);
        ApplicationContent applicationContent = this.applicationContentDao.findById(applicationContentId);
        RequestSubject requestSubject = this.requestSubjectDao.findById(requestSubjectId);
        return this.createApplicationContentInput(applicationContent, requestSubject, isOnlineApplication, true);
    }
    
    /**
     * Erzeugt Eingaben für Bewerbungsbestandteile mit den entprechenden Feldern. Dabei werden die conditions berücksichtigt.
     * 
     * @param applicationContent Der Bewerbugnsbestandteil
     * @param requestSubject Das Antragsfach
     * @param isOnlineApplication {@code true} = OnlineBewerbung; {@code fasle} = Sachbearbeitung
     * @param createOptionalFieldImmediate wenn {@code true} werden optionale Felder sofort erzeugt (beim Anlegen von Mehrfachangaben)
     * @return
     */
    private ApplicationContentInputDto createApplicationContentInput(ApplicationContent applicationContent, RequestSubject requestSubject, boolean isOnlineApplication, boolean createOptionalFieldImmediate) {
        
        // Neuees ApplicationContentInputDto erzeugen
        ApplicationContentInputDto applicationContentInputDto = ApplicationContentInputDtoFactory.getNewDto();
        
        // Zuordnen des ApplicationContent
        LoadParams loadParams = new LoadParams();
        loadParams.setReplacedDtoClasses(KeyTableSelectionFieldInputXtdDtoImpl.class, SelectionFieldInputXtdDtoImpl.class, DocumentFieldInputXtdDtoImpl.class);
        ApplicationContentDto applicationContentDto = ApplicationContentDtoFactory.getDto(applicationContent, loadParams, APPLICATION_CONTENT_LOAD_PATHS);
        applicationContentInputDto.setApplicationContentDefinition(applicationContentDto);
        
        
        
        // Das Antragsfach, für den dieser Bewerbungsbestandteil ist
        String[] loadPath = DTOFactoryUtil.asLoadPath(new RequestSubjectDto.RequestSubjectPath().applicationContentInputs());
        RequestSubjectDto requestSubjectDto = RequestSubjectDtoFactory.getDto(requestSubject, loadPath);
        applicationContentInputDto.addToRequestSubjects(requestSubjectDto);
        
        // Zusätzliche Infos, die später wichtig sind
        applicationContentInputDto.setRequestSubjectId(requestSubject.getId());
        applicationContentInputDto.setAdmissionPackageId(requestSubject.getAdmissionPackage().getId());
        applicationContentInputDto.setApplicationId(requestSubject.getApplication().getId());
        


        // wenn es eine optionale Zuordnung zu dem entsprechenden Admissionpackage gibt,
        // sollen die FieldInputs nicht sofort, sondern erst auf Anfordernung angelegt werden
        AdmissionPackage admissionPackage = requestSubject.getAdmissionPackage();
        Collection<ApplicationContentAdmissionPackage> applicationContentAdmissionPackages = applicationContent.getApplicationContentAdmissionPackages();
        for (ApplicationContentAdmissionPackage applicationContentAdmissionPackage : applicationContentAdmissionPackages) {
            if(applicationContentAdmissionPackage.getAdmissionPackage().equals(admissionPackage)) {
                
                // ist die Zuordnung optional?
                boolean optional = applicationContentAdmissionPackage.getIsOptional().booleanValue();
                if(!createOptionalFieldImmediate && optional) {
                    // Die Zuordnung ist optional und soll  erst auf Anfordernung angelegt werden
                    logger.debug("The ApplicationContentAdmissionPackage " + applicationContentAdmissionPackage + " is optional and the fields will not be created now");
                    break;
                }
                else {
                    logger.debug("The ApplicationContentAdmissionPackage " + applicationContentAdmissionPackage + " is not optional; we will now create the fields");
                    createFieldInputDtos(applicationContentInputDto, isOnlineApplication);
                }
            }
        }
        
        this.setFieldInputMetaData(applicationContentInputDto, isOnlineApplication);
        return applicationContentInputDto;
    }
    
    @Override
    public void createFieldInputOnlineApplication(ApplicationContentInputDto applicationContentInputDto) {
        EnsureArgument.notNull(applicationContentInputDto, "applicationContentInputDto must not be null");        
        createFieldInputDtos(applicationContentInputDto, true);
    }

    @Override
    public void createFieldInputApplicationProcessing(ApplicationContentInputDto applicationContentInputDto) {
        EnsureArgument.notNull(applicationContentInputDto, "applicationContentInputDto must not be null");
        createFieldInputDtos(applicationContentInputDto, false);
    }
    
    private void createFieldInputDtos(ApplicationContentInputDto applicationContentInputDto, boolean isOnlineApplication) {
        logger.enter("createFieldInputDtos", "applicationContentInputDto", applicationContentInputDto, "isOnlineApplication", Boolean.valueOf(isOnlineApplication));
        EnsureArgument.notNull(applicationContentInputDto.getRequestSubjectId(), "Die RequestSubjectId für das applicationContentInputDto (" + applicationContentInputDto + ") ist nicht gesetzt!");
        ApplicationContentDto applicationContentDto = applicationContentInputDto.getApplicationContentDefinition();
        
        
        RequestSubject requestSubject = requestSubjectDao.findById(applicationContentInputDto.getRequestSubjectId());
        
        applicationContentInputDto.setFieldInputs(getFieldInputDtos(applicationContentDto, requestSubject));
        this.setFieldInputMetaData(applicationContentInputDto, isOnlineApplication);
        logger.leave("createFieldInputDtos");
    }
     

    private List<FieldInputDto> getFieldInputDtos(ApplicationContentDto applicationContentDto, RequestSubject requestSubject) {
        EnsureArgument.notNull(applicationContentDto, "applicationContentDto must not be null");
        logger.enter("getFieldInputDtos", "applicationContentDto", applicationContentDto);
        
        List<FieldInputDto> dtos = new ArrayList<FieldInputDto>();
        List<FieldDto> applicationContentFields = applicationContentDto.getApplicationContentFields();
        
        for (FieldDto fieldDto : applicationContentFields) {
            
            FieldInputDto fieldInputDto = null;
            // Schlüsseltabellenauswahl
            if(fieldDto instanceof KeyTableSelectionFieldDto) {
                KeyTableSelectionFieldDto keyTableSelectionFieldDto = (KeyTableSelectionFieldDto) fieldDto;

                LoadParams loadParams = new LoadParams();
                loadParams.setReplacedDtoClasses(KeyTableSelectionFieldInputXtdDtoImpl.class, SelectionFieldInputXtdDtoImpl.class);
                KeyTableSelectionFieldInputXtdDto keyTableSelectionFieldInputDto = (KeyTableSelectionFieldInputXtdDto) KeyTableSelectionFieldInputDtoFactory.getNewDto(loadParams);
                
                // set default-items
                keyTableSelectionFieldInputDto.setSelectItems(this.getKeyTableSelectionItems(keyTableSelectionFieldDto));
                if(keyTableSelectionFieldDto.getMultipleSelectionAllowed().booleanValue()) {
                    keyTableSelectionFieldInputDto.setSelectedKeyTableItems(keyTableSelectionFieldDto.getDefaultSelectionItems());                    
                } else {
                    keyTableSelectionFieldInputDto.setSelectedKeyTableItem(keyTableSelectionFieldDto.getDefaultSelectionItem());                    
                }
              
                fieldInputDto = keyTableSelectionFieldInputDto;
            }
            // einfache Auswahl
            else if(fieldDto instanceof SelectionFieldDto) {
                SelectionFieldDto selectionFieldDto = (SelectionFieldDto) fieldDto;
                
                // Set default-value
                List<InputSelectionItemDto> inputSelectionItems = new ArrayList<InputSelectionItemDto>(); 
                List<AbstractSelectionItemDto> selectionItems = selectionFieldDto.getSelectionItems();
                for (AbstractSelectionItemDto abstractSelectionItemDto : selectionItems) {
                    if(abstractSelectionItemDto instanceof SelectionItemDto) {
                        SelectionItemDto selectionItemDto = (SelectionItemDto) abstractSelectionItemDto;
                        if(selectionItemDto.getIsDefault().booleanValue()) {
                            
                            // Dieses selectionItem soll als default-Auswahl dienen
                            InputSelectionItemDto inputSelectionItemDto = InputSelectionItemDtoFactory.getNewDto();
                            inputSelectionItemDto.setSelectionItem(selectionItemDto);
                            inputSelectionItemDto.setSelectionItemId(selectionItemDto.getId());
                            
                            inputSelectionItems.add(inputSelectionItemDto);
                        }
                    }
                }
                LoadParams loadParams = new LoadParams();
                loadParams.setReplacedDtoClasses(SelectionFieldInputXtdDtoImpl.class);
                
                SelectionFieldInputDto selectionFieldInputDto = SelectionFieldInputDtoFactory.getNewDto(loadParams);
                
                selectionFieldInputDto.setSelectionItemValues(inputSelectionItems);
                fieldInputDto = selectionFieldInputDto;
                
            }
            // Datumsfeld
            else if(fieldDto instanceof DateFieldDto) {
                DateFieldDto dateFieldDto = (DateFieldDto) fieldDto;
                
                // Set default-value
                DateFieldInputDto dateFieldInputDto = DateFieldInputDtoFactory.getNewDto();
                dateFieldInputDto.setDateValue(dateFieldDto.getDefaultValue());
                fieldInputDto = dateFieldInputDto;
                         
            }
            // Decimal-Feld
            else if(fieldDto instanceof DecimalFieldDto) {
                DecimalFieldDto decimalFieldDto = (DecimalFieldDto) fieldDto;
                
                // Set default-value
                DecimalFieldInputDto decimalFieldInputDto = DecimalFieldInputDtoFactory.getNewDto();
                decimalFieldInputDto.setDecimalValue(decimalFieldDto.getDefaultValue());
                fieldInputDto = decimalFieldInputDto;
                
            }
            // DocumentUploadField
            else if(fieldDto instanceof DocumentUploadFieldDto) {
                LoadParams loadParams = new LoadParams();
                loadParams.setReplacedDtoClasses(DocumentFieldInputXtdDtoImpl.class);
                DocumentFieldInputDto documentFieldInputDto = DocumentFieldInputDtoFactory.getNewDto(loadParams);
                DocumentFieldInputXtdDto documentFieldInputXtdDto = (DocumentFieldInputXtdDto) documentFieldInputDto;
                
                fieldInputDto = documentFieldInputXtdDto;
            }
            // IntegerField
            else if(fieldDto instanceof IntegerFieldDto) {
                IntegerFieldDto integerFieldDto = (IntegerFieldDto) fieldDto;
                
                // Set default-value
                IntegerFieldInputDto integerFieldInputDto = IntegerFieldInputDtoFactory.getNewDto();
                integerFieldInputDto.setIntegerValue(integerFieldDto.getDefaultValue());
                fieldInputDto = integerFieldInputDto;
                
            }
            // PeriodField
            else if(fieldDto instanceof PeriodFieldDto) {
                PeriodFieldDto periodFieldDto = (PeriodFieldDto) fieldDto;
                
                // Set default-value
                PeriodFieldInputDto periodFieldInputDto = PeriodFieldInputDtoFactory.getNewDto();
                periodFieldInputDto.setStartDate(periodFieldDto.getDefaultMinValue());
                periodFieldInputDto.setEndDate(periodFieldDto.getDefaultMaxValue());
                fieldInputDto = periodFieldInputDto;
                
            }
            // TextField
            else if(fieldDto instanceof TextFieldDto) {
                TextFieldDto textFieldDto = (TextFieldDto) fieldDto;
                
                // Set default-value
                TextFieldInputDto textFieldInputDto = TextFieldInputDtoFactory.getNewDto();
                textFieldInputDto.setStringValue(textFieldDto.getDefaultValue());
                fieldInputDto = textFieldInputDto;
                
            }
            if(fieldInputDto != null) {
                
                

                // Auswertung der condition
                if(requestSubject != null) {
                    Field field = this.fieldDao.findById(fieldDto.getId());
                    ApplicationContentCondition condition = field.getCondition();
                    boolean evaluateCondition = evaluateCondition(condition, requestSubject.getId(), null);
                    if(!evaluateCondition) {
                        logger.debug("The condition " + condition + " evaluates to FALSE for requestSubject " + requestSubject + "; we will skip this applicationContent.");
                        continue;
                    }
                }
                
                
                // Soll das Feld als required markiert werden?
                fieldInputDto.getMeta(KeyTableSelectionFieldInputDto.field, true).getMandatory(!fieldDto.getOptional().booleanValue());
                
                fieldInputDto.setField(fieldDto);
                dtos.add(fieldInputDto);
            }
        }
        logger.leave("getFieldInputDtos");
        return dtos;
    }

    /**
     * Applies the meta-data into the fields
     * @param applicationContentInputDto
     * @param isOnlineApplication 
     * @param requestSubject 
     */
    private void setFieldInputMetaData(ApplicationContentInputDto applicationContentInputDto, boolean isOnlineApplication) {
        EnsureArgument.notNull(applicationContentInputDto, "applicationContentInputDto must not be null");
        logger.enter("setFieldInputMetaData", "applicationContentInputDto", applicationContentInputDto, "isOnlineApplication", Boolean.valueOf(isOnlineApplication));
        List<FieldInputDto> fieldInputs = applicationContentInputDto.getFieldInputs();
        logger.debug("Found " + fieldInputs.size() + " FieldInputs for applicationContentInput " + applicationContentInputDto);
        if(applicationContentInputDto.getRequestSubjectId() == null) {
            throw new ServiceException("The applicationContentInput " + applicationContentInputDto + " has no requestSubjectId");
        }
        
        RequestSubject requestSubject = this.requestSubjectDao.findById(applicationContentInputDto.getRequestSubjectId());
        
        for (FieldInputDto fieldInputDto : fieldInputs) {
            

            // Soll das Feld versteckt werden?
            Boolean hidden = isFieldInputHidden(fieldInputDto.getField(), isOnlineApplication);
            
            // Soll das Feld disabled werden?
            Boolean disbled = isFieldInputDisabled(fieldInputDto, isOnlineApplication);
            
            // Auswertung der condition
            if(requestSubject != null) {
                Field field = this.fieldDao.findById(fieldInputDto.getField().getId());
                ApplicationContentCondition condition = field.getCondition();
                boolean evaluateCondition = evaluateCondition(condition, requestSubject.getId(), null);
                if(!evaluateCondition) {
                    logger.debug("The condition " + condition + " evaluates to FALSE for requestSubject " + requestSubject + " and field " + field + "; we will set this field to hidden.");
                    hidden = Boolean.TRUE;
                }
            }
            
            
            // Schlüsseltabellenauswahl
            if(fieldInputDto.getField() instanceof KeyTableSelectionFieldDto) {
                
                KeyTableSelectionFieldInputXtdDto keyTableSelectionFieldInputXtdDto = (KeyTableSelectionFieldInputXtdDto) fieldInputDto;
                KeyTableSelectionFieldDto keyTableSelectionFieldDto = (KeyTableSelectionFieldDto) keyTableSelectionFieldInputXtdDto.getField();
                keyTableSelectionFieldInputXtdDto.setSelectItems(this.getKeyTableSelectionItems(keyTableSelectionFieldDto));
                
                
                FieldMetadata meta = fieldInputDto.getMeta(KeyTableSelectionFieldInputDto.keyTableItemValues, true).getStandard(true);
                setFieldMetadataHiddenAndReadonly(isOnlineApplication, fieldInputDto, hidden, disbled, meta);
            }
            // einfache Auswahl
            else if(fieldInputDto.getField() instanceof SelectionFieldDto) {

                SelectionFieldInputXtdDto selectionFieldInputXtdDto = (SelectionFieldInputXtdDto) fieldInputDto;
                SelectionFieldDto selectionFieldDto = (SelectionFieldDto) selectionFieldInputXtdDto.getField();
                selectionFieldInputXtdDto.setSelectItems(getSelectionItems(selectionFieldDto));
                
                FieldMetadata meta = fieldInputDto.getMeta(SelectionFieldInputDto.selectionItemValues, true).getStandard(true);
                setFieldMetadataHiddenAndReadonly(isOnlineApplication, fieldInputDto, hidden, disbled, meta);
            }
            // Datum-Feld
            else if(fieldInputDto.getField() instanceof DateFieldDto) {
                DateFieldDto dateFieldDto = (DateFieldDto) fieldInputDto.getField();
                
                FieldMetadata meta = fieldInputDto.getMeta(DateFieldInputDto.dateValue, true).getStandard(true);
                meta.setMaxValueDate(dateFieldDto.getMaxValue());
                meta.setMinValueDate(dateFieldDto.getMinValue());
                setFieldMetadataHiddenAndReadonly(isOnlineApplication, fieldInputDto, hidden, disbled, meta);
            }
            // Decimal-Feld
            else if(fieldInputDto.getField() instanceof DecimalFieldDto) {
                DecimalFieldDto decimalFieldDto = (DecimalFieldDto) fieldInputDto.getField();
                FieldMetadata meta = fieldInputDto.getMeta(DecimalFieldInputDto.decimalValue, true).getStandard(true);

                if(decimalFieldDto.getMinValue() != null) {
                    double minValue = decimalFieldDto.getMinValue().doubleValue();
                    meta.setMinValueDouble(Double.valueOf(minValue));                    
                }
                if(decimalFieldDto.getMaxValue() != null) {
                    double maxValue = decimalFieldDto.getMaxValue().doubleValue();
                    meta.setMaxValueDouble(Double.valueOf(maxValue));                    
                }
                
                setFieldMetadataHiddenAndReadonly(isOnlineApplication, fieldInputDto, hidden, disbled, meta);
            }
            // Dokumenten-Feld
            else if(fieldInputDto.getField() instanceof DocumentUploadFieldDto) {
                DocumentFieldInputXtdDto documentFieldInputDto = (DocumentFieldInputXtdDto) fieldInputDto;
                
                List<DocumentMetadataXtdDto> documentMetadataDtos = new ArrayList<DocumentMetadataXtdDto>();
                if(documentFieldInputDto.getId() != null) {
                    documentMetadataDtos = this.documentMetadataService.load(DocumentMetadataObjectType.documentFieldInput.getTarget(), documentFieldInputDto.getId());
                }
                documentFieldInputDto.setDocumentMetadataDtos(documentMetadataDtos);
                fieldInputDto = documentFieldInputDto;
                // für die Pflichtfeldmarkierung in der Sachbearbeitung
                if(isOnlineApplication ){
                    FieldMetadata meta = fieldInputDto.getMeta(DocumentFieldInputDto.documentValue, true).getStandard(true);
                    meta.setRequired(Boolean.valueOf(!fieldInputDto.getField().getOptional().booleanValue()));
                }
                
            }
            // Integer-Feld
            else if(fieldInputDto.getField() instanceof IntegerFieldDto) {
                IntegerFieldDto integerFieldDto = (IntegerFieldDto) fieldInputDto.getField();
                
                FieldMetadata meta = fieldInputDto.getMeta(IntegerFieldInputDto.integerValue, true).getStandard(true);
                meta.setMaxValueInteger(integerFieldDto.getMaxValue());
                meta.setMinValueInteger(integerFieldDto.getMinValue());
                meta.setHidden(hidden);
                meta.setReadonly(disbled);
                if(isOnlineApplication ){
                    meta.setRequired(Boolean.valueOf(!fieldInputDto.getField().getOptional().booleanValue()));
                }
            }
            // Period-Field
            else if(fieldInputDto.getField() instanceof PeriodFieldDto) {
                PeriodFieldDto periodFieldDto = (PeriodFieldDto) fieldInputDto.getField();
                
                FieldMetadata metaStartDate = fieldInputDto.getMeta(PeriodFieldInputDto.startDate, true).getStandard(true);
                metaStartDate.setMaxValueDate(periodFieldDto.getMaxValue());
                metaStartDate.setMinValueDate(periodFieldDto.getMinValue());
                setFieldMetadataHiddenAndReadonly(isOnlineApplication, fieldInputDto, hidden, disbled, metaStartDate);

                FieldMetadata metaEndDate = fieldInputDto.getMeta(PeriodFieldInputDto.endDate, true).getStandard(true);
                metaEndDate.setMaxValueDate(periodFieldDto.getMaxValue());
                metaEndDate.setMinValueDate(periodFieldDto.getMinValue());
                setFieldMetadataHiddenAndReadonly(isOnlineApplication, fieldInputDto, hidden, disbled, metaEndDate);
                
            }
            // Text-Field
            else if(fieldInputDto.getField() instanceof TextFieldDto) {
                TextFieldDto textFieldDto = (TextFieldDto) fieldInputDto.getField();
                
                FieldMetadata meta = fieldInputDto.getMeta(TextFieldInputDto.stringValue, true).getStandard(true);
                meta.setMaxLength(textFieldDto.getLength());
                meta.setRegexPattern(textFieldDto.getRegularExpressionFormat());
                setFieldMetadataHiddenAndReadonly(isOnlineApplication, fieldInputDto, hidden, disbled, meta);
            }

        }
        logger.leave("setFieldInputMetaData");
    }

    /**
     * @param isOnlineApplication
     * @param fieldInputDto
     * @param hidden
     * @param disbled
     * @param meta
     */
    private void setFieldMetadataHiddenAndReadonly(boolean isOnlineApplication, FieldInputDto fieldInputDto, Boolean hidden, Boolean disbled, FieldMetadata meta) {
        meta.setHidden(hidden);
        meta.setReadonly(disbled);
        if(isOnlineApplication && !hidden.booleanValue()) {
            // In der Sachbearbeitung sollen keine Pflichtfelder gesetzt werden
            // Wenn das Feld nicht sichtbar ist, darf es nicht als Pflichtfeld gelten, da 
            // Pflichtfelder nicht ausgeblendet werden können
            meta.setRequired(Boolean.valueOf(!fieldInputDto.getField().getOptional().booleanValue()));
        }
    }

    private Boolean isFieldInputHidden(FieldDto field, boolean isOnlineApplication) {
        Boolean hidden = Boolean.TRUE;
        if(isOnlineApplication) { 
            // Online-Bewerbung
            if(field.getVisibilityForApplicants().equals(ApplicantVisibility.IS_EDITABLE.getKey())) {
                // Das applicationContentField ist in der Online-Bewerbung sichtbar und bearbeitbar
                return Boolean.FALSE;
            }
            else if(field.getVisibilityForApplicants().equals(ApplicantVisibility.IS_VISIBLE.getKey())) {
                // Das applicationContentField ist in der Online-Bewerbung nur sichtbar, nicht aber bearbeitbar
                return Boolean.FALSE;
            }
            else if(field.getVisibilityForApplicants().equals(ApplicantVisibility.IS_FOR_INTERNAL_USE.getKey())) {
                // Das applicationContentField ist nur für Sachbearbeiter
                return Boolean.TRUE;
            } else {
                logger.error("Upps, was war denn das für eine Sichtbarkeit: " + field.getVisibilityForApplicants() + " von FieldDto " + field);
            }
        } else {
            // TODO: Sachbearbeitung
            hidden = Boolean.FALSE;
//            HISinOneAuthentication currentAuthentication = HisAuthenticationProviderFactory.getProvider().getCurrentAuthentication();
        }
        return hidden;
    }

    private Boolean isFieldInputDisabled(FieldInputDto fieldInputDto, boolean isOnlineApplication) {
        Boolean disabled = Boolean.TRUE;
        FieldDto field = fieldInputDto.getField();
        
        if(isOnlineApplication) { 
            // Online-Bewerbung
            if(field.getVisibilityForApplicants().equals(ApplicantVisibility.IS_EDITABLE.getKey())) {
                // Das applicationContentField ist in der Online-Bewerbung sichtbar und bearbeitbar
                disabled = Boolean.FALSE;
            } else if(field.getVisibilityForApplicants().equals(ApplicantVisibility.IS_VISIBLE.getKey())) {
                // Das applicationContentField ist in der Online-Bewerbung nur sichtbar, nicht aber bearbeitbar
                return Boolean.TRUE;
            } else if(field.getVisibilityForApplicants().equals(ApplicantVisibility.IS_FOR_INTERNAL_USE.getKey())) {
                // Das applicationContentField ist nur für Sachbearbeiter
                return Boolean.TRUE;
            } else {
                logger.error("Upps, was war denn das für eine Sichtbarkeit: " + field.getVisibilityForApplicants() + " von FieldDto " + field);
            }
        } else {
            // TODO: Sachbearbeitung
            disabled = Boolean.FALSE;
//            HISinOneAuthentication currentAuthentication = HisAuthenticationProviderFactory.getProvider().getCurrentAuthentication();
        }
        return disabled;
    }

    @Override
    public List<ApplicationContentDto> getAllApplicationContents() {
        return getAllApplicationContents(false);
    }
    
    @Override
    public List<ApplicationContentDto> getAllApplicationContentsWithFields() {
        return getAllApplicationContents(true);
    }

    private List<ApplicationContentDto> getAllApplicationContents(boolean loadFields) {
        List<ApplicationContent> applicationContents = this.applicationContentDao.findAll();
        String[] loadPath = new String[0];
        if(loadFields) {
            loadPath = DTOFactoryUtil.asLoadPath(new ApplicationContentDto.ApplicationContentPath().applicationContentFields());
        }
        return ApplicationContentDtoFactory.getDtos(applicationContents, loadPath);
    }

    @Override
    @SuppressWarnings("unchecked")
    public SelectItem[] getKeyTableSelectionItems(KeyTableSelectionFieldDto keyTableSelectionFieldDto) {
        String valueEntity = keyTableSelectionFieldDto.getValueEntity();
        Map<Long, KeyValueDto> allByName = valueService.getAllByName(valueEntity, I18nUtils.getLang());
        List<KeyValueDto> asList = (List<KeyValueDto>) CollectionUtil.asList(allByName.values());
        List<KeyValueDto> keyValueDtos = asList;
        
        String sortOrderProperty = keyTableSelectionFieldDto.getSortOrderProperty();
        Boolean sortOrderDirection = keyTableSelectionFieldDto.getSortOrderDirection();
        // sortieren nach dem sortOrderProperty und sortOrderDirection
        Collections.sort(keyValueDtos, new KeyValueComparator(sortOrderProperty, sortOrderDirection));
        
        List<SelectItem> __selectItems = new LinkedList<SelectItem>();
        List<KeySelectionItemDto> allowedValue = keyTableSelectionFieldDto.getAllowedValue();
        for (KeyValueDto keyValueDto : keyValueDtos) {
            for (KeySelectionItemDto keySelectionItemDto : allowedValue) {
                if(keyValueDto.getObjGuid().equals(keySelectionItemDto.getEntityObjGuid())) {
                    SelectItem selectItem = new SelectItem(keySelectionItemDto.getId(), keyValueDto.getDefaulttext());
                    __selectItems.add(selectItem); 
                    break;
                }
            }
        }
        
        return toArray(__selectItems);
    }

    private SelectItem[] toArray(List<SelectItem> __selectItems) {
        SelectItem[] _selectItems = new SelectItem[__selectItems.size()];
        int i = 0;
        for (SelectItem selectItem : __selectItems) {
            _selectItems[i++] = selectItem;
        }
        return _selectItems;
    }
    
    @Override
    public void deleteOptionalApplicationContentInputFields(ApplicationContentInputDto applicationContentInputDto) {
        EnsureArgument.notNull(applicationContentInputDto);
        List<FieldInputDto> fieldInputs = applicationContentInputDto.getFieldInputs();
        for (FieldInputDto fieldInputDto : fieldInputs) {
            fieldInputDto.setField(null);
            fieldInputDto.setMarkedToDelete(true);
        }
        applicationContentInputDto.clearFieldInputs();
    }
    
    @Override
    public KeyTableSelectionFieldDto createKeyTableSelectionFieldDto(Long keyTableSelectionFieldId) {
        String[] loadPath = DTOFactoryUtil.asLoadPath(new KeyTableSelectionFieldDto.KeyTableSelectionFieldPath().allowedValue());
        KeyTableSelectionFieldDto keyTableSelectionFieldDto = KeyTableSelectionFieldDtoFactory.getDto(keyTableSelectionFieldId, loadPath);
        return keyTableSelectionFieldDto;
    }
    
    @Override
    public SelectionFieldDto createSelectionFieldDto(Long selectionFieldId) {
        String[] loadPath = DTOFactoryUtil.asLoadPath(new SelectionFieldDto.SelectionFieldPath().selectionItems());
        SelectionFieldDto selectionFieldDto = SelectionFieldDtoFactory.getDto(selectionFieldId, loadPath);
        return selectionFieldDto;
    }
    

    @Override
    public ApplicationContentConditionDto createApplicationContentCondition() {
        return ApplicationContentConditionDtoFactory.getNewDto();
    }
    
    @Override
    public ApplicationContentConditionDto readApplicationContentCondition(Long id) {
        return ApplicationContentConditionDtoFactory.getDto(id);
    }
    
    @Override
    public void saveApplicationContentCondition(ApplicationContentConditionDto condition) {
        this.validate(condition);
        
        if (!ConfigUtil.HIS_DEVELOPMENT_MODUS && condition.isNative()) {
            throw new ServiceException("cm.app.applicationContentCondition.native.error");
        }
        
        if (!condition.isDefaultlanguageSet()) {
            condition.setDefaultlanguage(I18nUtils.getLanguageId());
        }
        
        ApplicationContentCondition byUniquename = this.applicationContentConditionDao.findByUniquename(condition.getUniqueName());
        if(byUniquename != null) {
            if(condition.getId() == null || (!condition.getId().equals(byUniquename.getId()))) {
                throw new ServiceException("cm.app.applicationContentCondition.noUniquename", condition.getUniqueName());
            } 
        }

        ApplicationContentConditionDtoFactory.saveDto(condition);
    }
    
    @Override
    public Map<Long, ApplicationContentConditionDto> getAllApplicationContentConditions() {
        List<ApplicationContentCondition> all = this.applicationContentConditionDao.findAll();
        Map<Long, ApplicationContentConditionDto> map = new HashMap<Long, ApplicationContentConditionDto>();
        List<ApplicationContentConditionDto> dtos = ApplicationContentConditionDtoFactory.getDtos(all);
        for (ApplicationContentConditionDto dto : dtos) {
            map.put(dto.getId(), dto);
        }
        return map;
    }
    
    @Override
    public boolean deleteApplicationContentCondition(Long applicationContentConditionId, boolean checkReferences) {
        EnsureArgument.notNull(applicationContentConditionId, "applicationContentConditionId must not be null");
        
        // check if this condition is already used
        if(checkReferences) {
            List<Object> usagesInApplicationContents = this.applicationContentConditionDao.getUsagesInApplicationContents(applicationContentConditionId);
            if(!usagesInApplicationContents.isEmpty()) {
//                String msg = "cm.app.applicationContentCondtion.alreadyInUse";
//                throw new ServiceException(msg);
                return false;
            }
        }

        try {
            ApplicationContentCondition entity = applicationContentConditionDao.findById(applicationContentConditionId);
            if (entity != null) {
                try {
                    applicationContentConditionDao.makeTransient(entity);
                    return true;
                } catch (Exception e) {
                    String msg = "Deletion of Condition failed";
                    logger.error(msg, e);
                    throw new ServiceException(msg, e);
                }
            } else {
                String msg = "Condition to delete (with id= " + applicationContentConditionId + ") doesn't exist";
                logger.error(msg);
                return false;
            }
        } catch (Exception e) {
            String msg = "Exception loading Condition to delete";
            logger.error(msg, e);
            throw new ServiceException(msg, e);
        }
    }
    
    @Override
    public boolean testCondition(ApplicationContentConditionDto applicationContentConditionDto, Long requestSubjectId, ExpressionLogger expressionLogger) {
        TransactionSupport transactionSupport = new TransactionSupport().openNewReadonlyTransaction();
        try {
            expressionLogger.clear();
            ApplicationContentCondition applicationContentCondition = this.applicationContentConditionDao.findById(applicationContentConditionDto.getId());
            applicationContentCondition.setExpression(applicationContentConditionDto.getExpression());
            boolean evaluateCondition = evaluateCondition(applicationContentCondition, requestSubjectId, expressionLogger);
            
            return evaluateCondition;
        } catch (ScriptException e) {
            String msg = "Evaluation of condition failed.";
            logger.error(msg, e);
            Throwable cause = e.getCause();
            if (cause.getCause() instanceof javax.script.ScriptException) {
                javax.script.ScriptException err = (javax.script.ScriptException) cause.getCause();
                expressionLogger.setLineNumber(err.getLineNumber());
                expressionLogger.setColumnNumber(err.getColumnNumber());
                expressionLogger.setMessage(err.getMessage());
            } 
            throw new ServiceException(msg, e);
        } catch (Exception e) {
            String msg = "Evaluation of condition failed.";
            throw new ServiceException(msg, e);
        } finally {
            transactionSupport.rollbackTransaction();
        }
    }


    /**
     * Evaluates the condition of the {@code conditionalObject}
     * @param condition
     * @param requestSubjectId
     * @return {@code TRUE} or {@code FALSE}
     */
    public static boolean evaluateCondition(ApplicationContentCondition condition, Long requestSubjectId) {
        return evaluateCondition(condition, requestSubjectId, null);
    }

    /**
     * Evaluates the condition of the {@code conditionalObject}
     * @param condition
     * @param requestSubjectId
     * @param log a logger that can be used to debug the script
     * @return {@code TRUE} or {@code FALSE}
     */
    public static boolean evaluateCondition(ApplicationContentCondition condition, Long requestSubjectId, ExpressionLogger log) {
        logger.enter("evaluateCondition", "condition", condition, "requestSubjectId", requestSubjectId);
        boolean retVal = true; 
        if(condition != null && !condition.getExpression().isEmpty()) {
            boolean junit = QISReflectionUtil.isCalledByJUnit();     
            TransactionSupport transactionSupport =  !junit ? new TransactionSupport().openNewReadonlyTransaction() : null;
            
            try {
                RequestSubjectDao requestSubjectDao = StaticBeanRef.getRequestSubjectDao();
                RequestSubject requestSubject = requestSubjectDao.findById(requestSubjectId);
                if(requestSubject == null) {
                    throw new ServiceException("The requestSubject with the id " + requestSubjectId + " cannot be found!");
                }
                
                ScriptEngine scriptEngine = new ScriptEngineManager().getEngineByName(EngineType.JAVASCRIPT.getName());
                scriptEngine.put("requestSubject", requestSubject);
                scriptEngine.put("entranceQualification", requestSubject.getEntranceQualification());
                scriptEngine.put("person", requestSubject.getApplication().getApplicant().getPerson());
                scriptEngine.put("applicant", requestSubject.getApplication().getApplicant());
                scriptEngine.put("application", requestSubject.getApplication());
                scriptEngine.put("admissionPackage", requestSubject.getAdmissionPackage());
                if (log == null) {
                    log = new ExpressionLogger();
                } 
                scriptEngine.put("logger", log);
                scriptEngine.put("LOG", log);
                
                Map<String, ApplicationContentInput> contentMap = new HashMap<String, ApplicationContentInput>();
                scriptEngine.put("contentmap", contentMap);
                Map<String, FieldInput> fieldMap = new HashMap<String, FieldInput>();
                scriptEngine.put("fieldmap", fieldMap);
                Collection<ApplicationContentInput> applicationContentInputs = requestSubject.getApplicationContentInputs();
                for (ApplicationContentInput applicationContentInput : applicationContentInputs) {
                    ApplicationContent applicationContentDefinition = applicationContentInput.getApplicationContentDefinition();
                    String contentKey = applicationContentDefinition.getUniquename();
                    contentMap.put(contentKey, applicationContentInput);
                    Collection<FieldInput> fieldInputs = applicationContentInput.getFieldInputs();
                    for (FieldInput fieldInput : fieldInputs) {
                        Field field = fieldInput.getField();
                        String fieldKey = field.getUniquename();
                        fieldMap.put(contentKey + "." + fieldKey, fieldInput);
                    }
                }
                
                logger.debug("attempt to execute the following JavaScript: " + condition.getExpression());
                
                retVal = condition.evaluate(scriptEngine);
            } catch (ScriptException e) {
                throw new ScriptException(e);
            } catch (Exception e) {
                logger.error("Ececution of the script " + condition.getExpression() + " faild!", e);
                throw new ServiceException(e.getMessage());
            } finally {
                if (transactionSupport != null) {
                    transactionSupport.rollbackTransaction();
                }
            }
            logger.leave("evaluateCondition", retVal);
        }
        return retVal;
    }
    
    @Override
    public boolean isUsedInOnlineApplication(Long applicationContentConditionId) {
        List<Object> usagesInOnlineApplication = this.applicationContentConditionDao.getUsagesInOnlineApplication(applicationContentConditionId);
        if(usagesInOnlineApplication.isEmpty()) {
            return false;
        }
        return true;
    }
    
    @Override
    public int countUsagesInApplicationContents(Long applicationContentConditionId) {
        List<Object> usagesInApplicationContents = this.applicationContentConditionDao.getUsagesInApplicationContents(applicationContentConditionId);
        return usagesInApplicationContents.size();
    }

    private void validate(DtoBase dto) {
        ServiceException exception = new ServiceException("Validation failed.");
        if (!this.validationService.validate(this.getContextKey(), dto, exception.getMessages())) {
            throw exception;
        }
    }

    /**
     * 
     * @param selectionFieldDto
     * @return
     */
    @Override
    public List<SelectItemGroup> getSelectionItems(SelectionFieldDto selectionFieldDto) {

        List<SelectItemGroup> selectItemGroups = new ArrayList<SelectItemGroup>();
        List<SelectItemGroup> _selectItemGroups = new ArrayList<SelectItemGroup>();
        
        List<AbstractSelectionItemDto> selectionItems = selectionFieldDto.getSelectionItems();
        
        List<AbstractSelectionItemDto> result = Lists.newArrayList(selectionItems);
        Collections.sort(result, new SortorderValueDtoComparator());
        
        List<SelectItem> selectItems = new ArrayList<SelectItem>();
        
        for (AbstractSelectionItemDto abstractSelectionItemDto : result) {
            if(abstractSelectionItemDto instanceof SelectionItemDto) {
                SelectionItemDto selectionItemDto = (SelectionItemDto) abstractSelectionItemDto;
                String i18nDtoAttr = I18nSupport.getI18nTranslation(selectionItemDto, SelectionItemDto.name);
                SelectItem selectItem = new SelectItem(selectionItemDto.getId(), i18nDtoAttr);
                selectItems.add(selectItem);
                
            } 
            else if(abstractSelectionItemDto instanceof SelectionItemGroupDto) {
                SelectionItemGroupDto selectionItemGroupDto = (SelectionItemGroupDto) abstractSelectionItemDto;
                List<SelectionItemDto> _selectionItems = selectionItemGroupDto.getSelectionItems();
                
                SelectItem[] _selectItems = new SelectItem[_selectionItems.size()];
                int i = 0;
                for (SelectionItemDto selectionItemDto : _selectionItems) {
                    String i18nDtoAttr = I18nSupport.getI18nTranslation(selectionItemDto, SelectionItemDto.name);
                    SelectItem selectItem = new SelectItem(selectionItemDto.getId(), i18nDtoAttr);
                    _selectItems[i++] = selectItem;
                }
                String i18nDtoAttr = I18nSupport.getI18nTranslation(selectionItemGroupDto, SelectionItemGroupDto.name);
                SelectItemGroup selectItemGroup = new SelectItemGroup(i18nDtoAttr, i18nDtoAttr, false, _selectItems);
                _selectItemGroups.add(selectItemGroup);
            }
        }
        
        
        SelectItem[] __selectItems = new SelectItem[selectItems.size()];
        for (int a = 0; selectItems.size() > a; a++) {
            __selectItems[a] = selectItems.get(a);
        }

        SelectItemGroup defaultSelectItemGroup = new SelectItemGroup("", "", false, __selectItems);
        selectItemGroups.add(defaultSelectItemGroup);
        selectItemGroups.addAll(_selectItemGroups);
        
        return selectItemGroups;
    }
    
    @Override
    public boolean isAnyRequestSubmitted(ApplicationContentInputDto applicationContentInputDto) {
        List<ApplicationContentInputDto> applicationContentInputDtoList = new ArrayList<ApplicationContentInputDto>();
        applicationContentInputDtoList.add(applicationContentInputDto);
        return isAnyRequestSubmitted(applicationContentInputDtoList);
    }
    
    @Override
    public boolean isAnyRequestSubmitted(List<ApplicationContentInputDto> applicationContentInputDtos) {
        // Bewerbungsbestandteile müssen gesperrt werden, sobald ein damit verbundener Antrag abgegeben ist.
        EnsureArgument.notNull(applicationContentInputDtos, "applicationContentInputDtos must not be null");
        for (ApplicationContentInputDto applicationContentInputDto : applicationContentInputDtos) {
            if(applicationContentInputDto.getId() != null) {
                List<Request> requests = this.applicationContentInputDao.findRequestsByApplicationContentInput(applicationContentInputDto.getId());
                for (Request request : requests) {
                    if (request.getRequestStatus().isSubmitted()) return true;
                }
            }
        }
        return false;
    }
    
    @Override
    public Set<String> getTitlesOfAffectedCourses(List<ApplicationContentInputDto> applicationContentInputDtos) {
        // Für die Anzeige von Fächern, auf welche sich die Angaben beziehen
        EnsureArgument.notNull(applicationContentInputDtos, "applicationContentInputDtos must not be null");

        Set<String> ret = new HashSet<String>();
        
        for (ApplicationContentInputDto applicationContentInputDto : applicationContentInputDtos) {
            if(applicationContentInputDto.getId() == null) {
                continue;
            }
            ApplicationContentInput applicationContentInput = this.applicationContentInputDao.findById(applicationContentInputDto.getId());
            Set<RequestSubject> requestSubjects = applicationContentInput.getRequestSubjects();
            for (RequestSubject subject : requestSubjects) {
                // Das selbe Fach muss hier nicht nochmal angezeigt werden 
                if(subject.getId().equals(applicationContentInputDto.getRequestSubjectId())) {
                    continue;
                }
                ret.add(subject.getCourseOfStudy().getDefaulttext());
            }
        }
        return ret;
    }
    
    @Override
    public int findFieldInputCountByField(Long fieldId) {
        return applicationContentDao.findFieldInputCountByField(fieldId);
    }
    
    @Override
    public String validateApplicationContentInputDto(ApplicationContentInputDto applicationContentInputDto){
        String errormessage = null;
        ApplicationContentInput applicationContentInput = applicationContentInputDao.findById(applicationContentInputDto.getId());
        SortedSet<FieldInput> fieldInputs = applicationContentInput.getFieldInputs();
        for (FieldInput fieldInput : fieldInputs) {
            Field field = fieldInput.getField();
            Boolean optional = field.getOptional();
            // Wenn im Pflichfeld keine Eingabe erfolgt ist.
            if ((optional == null || !optional.booleanValue()) && !fieldInput.hasValue()) {
                if (errormessage != null) {
                    errormessage = errormessage + "\r\n - " + fieldInput.getField().getDefaulttext(); 
                } else {
                    errormessage = "- " + fieldInput.getField().getDefaulttext();
                }
            }
        }
        return errormessage;
        
    }
    

    @Override
    public ApplicationContentInputStatus getApplicationContentInputStatuCorrect(){
       return ApplicationContentInputStatus.CORRECT;
        
    }
    
    @Override
    public List<ApplicationContentInput> getApplicationContentInputs(Long requestSubjectId, String applicationContentKey) {
        EnsureArgument.notNull(requestSubjectId, "requestSubjectId must not be null");
        logger.enter("getApplicationContentInputs", "requestSubjectId", requestSubjectId, "applicationContentKey", applicationContentKey);
        List<ApplicationContentInput> applicationContentInputList = new ArrayList<ApplicationContentInput>();
        RequestSubject requestSubject = this.requestSubjectDao.findById(requestSubjectId);
        if(requestSubject != null) {
            Set<ApplicationContentInput> applicationContentInputs = requestSubject.getApplicationContentInputs();
            
            if(applicationContentKey != null) {
                for (ApplicationContentInput applicationContentInput : applicationContentInputs) {
                    if(applicationContentInput.getApplicationContentDefinition().getUniquename().equalsIgnoreCase(applicationContentKey)) {
                        applicationContentInputList.add(applicationContentInput);
                        return applicationContentInputList;
                    }
                }
            } else {
                applicationContentInputList.addAll(applicationContentInputs);
            }
        } else {
            logger.error("Cannot find RequestSubject with id " + requestSubjectId);
        }
        logger.leave("getApplicationContentInputs");
        return applicationContentInputList;
    }
    
    
    @Override
    public boolean isOptional(ApplicationContentInputDto applicationContentInputDto){
        boolean optional = true;
        Set<Long> admissionPackageIds = requestgroupsService.getAdmissionPackageIds(applicationContentInputDto.getRequestSubjects());      
        
        ApplicationContentDto applicationContentDefinitionDto = applicationContentInputDto.getApplicationContentDefinition();
        for (Long admissionPackageId : admissionPackageIds) {
            Set<ApplicationContentAdmissionPackageDto> applicationContentAdmissionPackageDtos = applicationContentDefinitionDto.getApplicationContentAdmissionPackages();
            for (ApplicationContentAdmissionPackageDto applicationContentAdmissionPackageDto: applicationContentAdmissionPackageDtos ){
                Long id = applicationContentAdmissionPackageDto.getAdmissionPackageId();
                if (id.equals(admissionPackageId)){
                    optional = applicationContentAdmissionPackageDto.isOptional();
                    break;
                }
            }
            if (!optional){
                break;
            }
        }
        return optional;
    }
    
    @Override
    public boolean isMultiple(ApplicationContentInputDto applicationContentInputDto){
        return applicationContentInputDto.getApplicationContentDefinition().isMultiple(); 
    }
    
    
    
    @Override
    public Collection<Long> getApplicationContentsByRequestId(Long requestId) {
        EnsureArgument.notNull(requestId, "requestId must not be null");
        List<ApplicationContentAdmissionPackage> applicationContentAdmissionPackages = this.applicationContentAdmissionPackageDao.findByRequestId(requestId);
        
        // Der Rückgabewert
        List<Long> applicationContentIds = new ArrayList<Long>();
        
        // bereits erfrage ApplicationContents (mit der Zuordnung zur Bewerbung)
        List<Long> alreadyInquiredApplicationContents = new ArrayList<Long>();
    
        if(applicationContentAdmissionPackages != null) {
            for (ApplicationContentAdmissionPackage applicationContentAdmissionPackage : applicationContentAdmissionPackages) {
                Long applicationContentId = applicationContentAdmissionPackage.getApplicationContent().getId();
                // Wenn ein Bewerbungsbestandteil der Bewerbung zugeordnet ist, soll jede Frage 
                // nur einmal erscheinen
                if(alreadyInquiredApplicationContents.contains(applicationContentId)) {
                    // bereits erfragt ... 
                    continue;
                }
                
                applicationContentIds.add(applicationContentId);
                alreadyInquiredApplicationContents.add(applicationContentId);
            }
        }
        
        return applicationContentIds;
    }
    
    // SETTER
    
    /**
     * @param applicationContentDao the applicationContentDao to set
     */
    @Required
    public void setApplicationContentDao(ApplicationContentDao applicationContentDao) {
        this.applicationContentDao = applicationContentDao;
    }

    /**
     * @param applicationContentInputDao the applicationContentInputDao to set
     */
    @Required
    public void setApplicationContentInputDao(ApplicationContentInputDao applicationContentInputDao) {
        this.applicationContentInputDao = applicationContentInputDao;
    }

    /**
     * @param applicationContentAdmissionPackageDao the applicationContentAdmissionPackageDao to set
     */
    @Required
    public void setApplicationContentAdmissionPackageDao(ApplicationContentAdmissionPackageDao applicationContentAdmissionPackageDao) {
        this.applicationContentAdmissionPackageDao = applicationContentAdmissionPackageDao;
    }

    /**
     * @param requestDao the requestDao to set
     */
    @Required
    public void setRequestDao(RequestDao requestDao) {
        this.requestDao = requestDao;
    }

    /**
     * @param valueService the valueService to set
     */
    @Required
    public void setValueService(ValueService valueService) {
        this.valueService = valueService;
    }

    /**
     * @param documentMetadataService the documentMetadataService to set
     */
    @Required
    public void setDocumentMetadataService(DocumentMetadataService documentMetadataService) {
        this.documentMetadataService = documentMetadataService;
    }

    /**
     * @param applicationDao the applicationDao to set
     */
    @Required
    public void setApplicationDao(ApplicationDao applicationDao) {
        this.applicationDao = applicationDao;
    }

    /**
     * @param requestSubjectDao the requestSubjectDao to set
     */
    @Required
    public void setRequestSubjectDao(RequestSubjectDao requestSubjectDao) {
        this.requestSubjectDao = requestSubjectDao;
    }

    /**
     * @param fieldDao the fieldDao to set
     */
    @Required
    public void setFieldDao(FieldDao fieldDao) {
        this.fieldDao = fieldDao;
    }

    /**
     * @param applicationContentConditionDao the applicationContentConditionDao to set
     */
    @Required
    public void setApplicationContentConditionDao(ApplicationContentConditionDao applicationContentConditionDao) {
        this.applicationContentConditionDao = applicationContentConditionDao;
    }

    /**
     * @param validationService the validationService to set
     */
    @Required
    public void setValidationService(ValidationService validationService) {
        this.validationService = validationService;
    }

    /**
     * @param requestgroupsService the requestgroupsService to set
     */
    @Required
    public void setRequestgroupsService(RequestgroupsService requestgroupsService) {
        this.requestgroupsService = requestgroupsService;
    }
}

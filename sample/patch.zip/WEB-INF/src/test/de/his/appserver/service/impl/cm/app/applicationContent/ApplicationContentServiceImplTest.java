package de.his.appserver.service.impl.cm.app.applicationContent;

import static de.his.matcher.HISMatchers.size;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.faces.model.SelectItemGroup;

import org.hamcrest.Matchers;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Required;

import de.his.appserver.model.cm.app.applicationContent.ApplicationContentCondition;
import de.his.appserver.model.cm.app.applicationContent.ApplicationContentInput;
import de.his.appserver.model.cm.app.applicationContent.FieldInput.FieldInputDiscriminatorType;
import de.his.appserver.model.cm.stu.fee.FeeLogger;
import de.his.appserver.model.sul.zul.bewerbung.AdmissionPackage;
import de.his.appserver.model.sul.zul.bewerbung.Application;
import de.his.appserver.model.sul.zul.bewerbung.Request;
import de.his.appserver.model.sul.zul.bewerbung.RequestSubject;
import de.his.appserver.persistence.dao.iface.sul.zul.bewerbung.RequestDao;
import de.his.appserver.service.dto.gen.iface.AbstractSelectionItemDto;
import de.his.appserver.service.dto.gen.iface.ApplicationContentAdmissionPackageDto;
import de.his.appserver.service.dto.gen.iface.ApplicationContentConditionDto;
import de.his.appserver.service.dto.gen.iface.ApplicationContentDto;
import de.his.appserver.service.dto.gen.iface.ApplicationContentInputDto;
import de.his.appserver.service.dto.gen.iface.DateFieldDto;
import de.his.appserver.service.dto.gen.iface.DecimalFieldDto;
import de.his.appserver.service.dto.gen.iface.DocumentUploadFieldDto;
import de.his.appserver.service.dto.gen.iface.FieldDto;
import de.his.appserver.service.dto.gen.iface.InputSelectionItemDto;
import de.his.appserver.service.dto.gen.iface.IntegerFieldDto;
import de.his.appserver.service.dto.gen.iface.KeyTableSelectionFieldDto;
import de.his.appserver.service.dto.gen.iface.PeriodFieldDto;
import de.his.appserver.service.dto.gen.iface.SelectionFieldDto;
import de.his.appserver.service.dto.gen.iface.SelectionItemDto;
import de.his.appserver.service.dto.gen.iface.SelectionItemGroupDto;
import de.his.appserver.service.dto.gen.iface.TextFieldDto;
import de.his.appserver.service.iface.cm.app.applicationContent.ApplicationContentService;
import de.his.core.testing.HISinOneBaseDaoTestCase;
import de.his.core.util.junit.MapSize;
import de.his.core.util.junit.TestOwner;

/**
 * Company: HIS
 * @author schwaff
 */
@TestOwner(cvsLogin="schwaff#his.de")
public class ApplicationContentServiceImplTest extends HISinOneBaseDaoTestCase {

    private static final Long LANGUAGE_ID_GERMAN = Long.valueOf(12);

    private ApplicationContentService applicationContentService;
    
    private RequestDao requestDao;

    /** condition, that only returns true, if the applicant is born before 01.01.1950 */
    private final String condition = 
        " var strDate = \"01.01.1950\";" +
        " var dateParts = strDate.split(\".\");" +
        " var date = new Date(dateParts[2], (dateParts[1] - 1), dateParts[0]);" +
        " if (person.birthdate != null && person.birthdate.before(date)) {" +
        "   return true;" +
        " } else {" +
        "   return false;" +
        " }";
    
    /** condition, that should cause a Script-Exception (the object 'prerson' is spelled wrong) */
    private final String conditionWithWrongSyntax = 
        " var strDate = \"01.01.1950\";" +
        " var dateParts = strDate.split(\".\");" +
        " var date = new Date(dateParts[2], (dateParts[1] - 1), dateParts[0]);" +
        " if (prerson.birthdate != null && person.birthdate.before(date)) {" +
        "   return true;" +
        " } else {" +
        "   return false;" +
        " }";
    
    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#createApplicationContent()}.
     */
    @Test
    public void testCreateApplicationContent() {
        ApplicationContentDto applicationContentDto = _createApplicationContent();
        assertNotNull(applicationContentDto.getId());
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#deleteApplicationContent(Long)}.
     */
    @Test
    public void testDeleteApplicationContent() {
        ApplicationContentDto applicationContentDto = _createApplicationContent();
        Long applicationContentId = applicationContentDto.getId();
        this.applicationContentService.deleteApplicationContent(applicationContentId);
        try {
            this.applicationContentService.loadApplicationContent(applicationContentId);
            fail("Exception expected");
        } catch (Exception e) {
            assertThat(e.getMessage(), equalTo("applicationContentDto with id " + applicationContentId + " cannot be found!"));
        }
    }
    
    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#saveApplicationContentAsCopy(ApplicationContentDto)}.
     */
    @Test
    public void testSaveApplicationContentAsCopy() {
        ApplicationContentDto applicationContentDto = _createApplicationContent();
        ApplicationContentDto applicationContentCopy = this.applicationContentService.saveApplicationContentAsCopy(applicationContentDto);
        assertThat(applicationContentCopy.getName(), equalTo("Defaulttext (Kopie)"));
    }
    
    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#createApplicationContentAdmissionPackage(ApplicationContentDto)}.
     */
    @Test
    public void testCreateApplicationContentAdmissionPackage() {
        ApplicationContentDto applicationContentDto = _createApplicationContent();
        applicationContentDto.setIsMultiple(Boolean.TRUE);
        ApplicationContentAdmissionPackageDto applicationContentAdmissionPackage = this.applicationContentService.createApplicationContentAdmissionPackage(applicationContentDto);
        assertThat(applicationContentAdmissionPackage, notNullValue());
        applicationContentAdmissionPackage.setAdmissionPackageId(Long.valueOf(9)); // 9*BA LA Blockflöte
        applicationContentAdmissionPackage.setIsOptional(Boolean.TRUE);
        this.applicationContentService.saveApplicationContentAdmissionPackage(applicationContentAdmissionPackage);
        assertThat(applicationContentAdmissionPackage.getId(), notNullValue());
    }
    
    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#saveApplicationContent(de.his.appserver.service.dto.gen.iface.ApplicationContentDto)}.
     */
    @Test
    public void testSaveApplicationContent() {
        ApplicationContentDto applicationContentDto = _createApplicationContent();
                
        this.applicationContentService.saveApplicationContent(applicationContentDto);
        assertNotNull(applicationContentDto.getId());
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#getApplicationContentAdmissionPackagesByRequestId(Long)}.
     */
    @Test
    public void testGetApplicationContentAdmissionPackagesByRequestId() {
        // search for the Request (with id 21) from Sebastian Sense on BA LA Blockflöte
        Long requestId = Long.valueOf(21);
        Request request = this.requestDao.findById(requestId);
        
        // 9 BA LA Blockflöte
        AdmissionPackage admissionPackageBlockfloete = request.getRequestSubjects().iterator().next().getCourseOfStudy().getAdmissionPackage(Integer.valueOf(1));
        
        ApplicationContentDto applicationContentDto = _createApplicationContent();
        applicationContentDto.setIsMultiple(Boolean.FALSE);
        this.applicationContentService.saveApplicationContent(applicationContentDto);
        assertNotNull(applicationContentDto.getId());
        
        ApplicationContentAdmissionPackageDto applicationContentAdmissionPackage = this.applicationContentService.createApplicationContentAdmissionPackage(applicationContentDto.getId(), admissionPackageBlockfloete.getId());
        applicationContentAdmissionPackage.setIsOptional(Boolean.TRUE);
        applicationContentAdmissionPackage.setSortorder(Integer.valueOf(1));
        this.applicationContentService.saveApplicationContentAdmissionPackage(applicationContentAdmissionPackage);
        assertNotNull(applicationContentAdmissionPackage.getId());
        
        // search for the ApplicationContent by the RequestSubject from Sebastian Sense on BA LA Blockflöte
        List<ApplicationContentAdmissionPackageDto> applicationContentAdmissionPackagesByRequest = this.applicationContentService.getApplicationContentAdmissionPackagesByRequestId(requestId);
        assertNotNull(applicationContentAdmissionPackagesByRequest);
        assertThat(applicationContentAdmissionPackagesByRequest, size(1));
        List<Long> applicationContentIds = new ArrayList<Long>();
        for (ApplicationContentAdmissionPackageDto ApplicationContentAdmissionPackageDto : applicationContentAdmissionPackagesByRequest) {
            applicationContentIds.add(ApplicationContentAdmissionPackageDto.getApplicationContentId());
        }
        
        List<ApplicationContentDto> applicationContents = this.applicationContentService.loadApplicationContents(applicationContentIds);
        ApplicationContentDto applicationContentByRequestSubject = applicationContents.get(0);
        assertThat(applicationContentByRequestSubject.getName(), equalTo("Defaulttext"));
    }


    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#getApplicationContentProcessing(Long)}.
     */
    @Test
    public void testGetApplicationContentProcessing() {
        Long admissionPackageIdBlockfloete = Long.valueOf(9); // BA LA Blockflöte
        Long requestSubjectId = Long.valueOf(33); // RequestSubject 'BA LA Blockflöte' von Sebastian Sense;
        Long applicationId = Long.valueOf(22); // Application von Sebastian Sense
        
        this.createApplicationContentInputs(requestSubjectId, admissionPackageIdBlockfloete);
        
        Map<Long, List<ApplicationContentDto>> applicationContentProcessing = this.applicationContentService.getApplicationContentProcessing(applicationId);
        assertThat(applicationContentProcessing, MapSize.mapSize(1));
    }
    
    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#createField(ApplicationContentDto, de.his.appserver.model.cm.app.applicationContent.FieldInput.FieldInputDiscriminatorType)}.
     */
    @Test
    public void testCreateFields() {
        ApplicationContentDto applicationContentDto = _createApplicationContent();
        
        FieldDto dateField = this.applicationContentService.createField(applicationContentDto, FieldInputDiscriminatorType.DATE);
        dateField.setDefaulttext("dateField");
        dateField.setHelpbuttonText("dateFieldHelpbuttonText");
        dateField.setDefaultlanguage(ApplicationContentServiceImplTest.LANGUAGE_ID_GERMAN);
        assertTrue(dateField instanceof DateFieldDto);

        FieldDto decimalField = this.applicationContentService.createField(applicationContentDto, FieldInputDiscriminatorType.DECIMAL);
        decimalField.setDefaulttext("decimalField");
        decimalField.setHelpbuttonText("decimalFieldHelpbuttonText");
        decimalField.setDefaultlanguage(ApplicationContentServiceImplTest.LANGUAGE_ID_GERMAN);
        assertTrue(decimalField instanceof DecimalFieldDto);
        
        FieldDto documentField = this.applicationContentService.createField(applicationContentDto, FieldInputDiscriminatorType.DOCUMENT);
        documentField.setDefaulttext("documentField");
        documentField.setHelpbuttonText("documentFieldHelpbuttonText");
        documentField.setDefaultlanguage(ApplicationContentServiceImplTest.LANGUAGE_ID_GERMAN);
        assertTrue(documentField instanceof DocumentUploadFieldDto);

        FieldDto integerField = this.applicationContentService.createField(applicationContentDto, FieldInputDiscriminatorType.INTEGER);
        integerField.setDefaulttext("integerField");
        integerField.setHelpbuttonText("integerFieldHelpbuttonText");
        integerField.setDefaultlanguage(ApplicationContentServiceImplTest.LANGUAGE_ID_GERMAN);
        assertTrue(integerField instanceof IntegerFieldDto);

        FieldDto keyTableSelectionField = this.applicationContentService.createField(applicationContentDto, FieldInputDiscriminatorType.KEY_TABLE_SELECTION);
        keyTableSelectionField.setDefaulttext("keyTableSelectionField");
        keyTableSelectionField.setHelpbuttonText("keyTableSelectionFieldHelpbuttonText");
        keyTableSelectionField.setDefaultlanguage(ApplicationContentServiceImplTest.LANGUAGE_ID_GERMAN);
        assertTrue(keyTableSelectionField instanceof KeyTableSelectionFieldDto);

        FieldDto periodField = this.applicationContentService.createField(applicationContentDto, FieldInputDiscriminatorType.PERIOD);
        periodField.setDefaulttext("periodField");
        periodField.setHelpbuttonText("periodFieldHelpbuttonText");
        periodField.setDefaultlanguage(ApplicationContentServiceImplTest.LANGUAGE_ID_GERMAN);
        assertTrue(periodField instanceof PeriodFieldDto);

        FieldDto simpleSelectionField = this.applicationContentService.createField(applicationContentDto, FieldInputDiscriminatorType.SIMPLE_SELECTION);
        simpleSelectionField.setDefaulttext("simpleSelectionField");
        simpleSelectionField.setHelpbuttonText("simpleSelectionFieldHelpbuttonText");
        simpleSelectionField.setDefaultlanguage(ApplicationContentServiceImplTest.LANGUAGE_ID_GERMAN);
        assertTrue(simpleSelectionField instanceof SelectionFieldDto);

        FieldDto textField = this.applicationContentService.createField(applicationContentDto, FieldInputDiscriminatorType.TEXT);
        textField.setDefaulttext("textField");
        textField.setHelpbuttonText("textFieldHelpbuttonText");
        textField.setDefaultlanguage(ApplicationContentServiceImplTest.LANGUAGE_ID_GERMAN);
        assertTrue(textField instanceof TextFieldDto);
        
        assertThat(applicationContentDto.getApplicationContentFields(), size(8));
        this.applicationContentService.saveApplicationContent(applicationContentDto);
        assertNotNull(applicationContentDto.getId());
    }
    
    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#createField(ApplicationContentDto, de.his.appserver.model.cm.app.applicationContent.FieldInput.FieldInputDiscriminatorType)}.
     */
    @Test
    public void testDeleteFields() {
        ApplicationContentDto applicationContentDto = _createApplicationContent();
        
        FieldDto dateField = this.applicationContentService.createField(applicationContentDto, "DATE");
        dateField.setDefaulttext("dateField");
        dateField.setHelpbuttonText("dateFieldHelpbuttonText");
        dateField.setDefaultlanguage(ApplicationContentServiceImplTest.LANGUAGE_ID_GERMAN);
        assertTrue(dateField instanceof DateFieldDto);

        assertThat(applicationContentDto.getApplicationContentFields(), size(1));
        this.applicationContentService.saveApplicationContent(applicationContentDto);
        assertNotNull(applicationContentDto.getId());
        
        // Now mark this field to delete
        dateField.setMarkedToDelete(true);
        applicationContentDto.removeFromApplicationContentFields(dateField);
        this.applicationContentService.saveApplicationContent(applicationContentDto);
        
        ApplicationContentDto applicationContentDto2 = this.applicationContentService.loadApplicationContent(applicationContentDto.getId());
        assertThat(applicationContentDto2.getApplicationContentFields(), size(0));
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#addSelectionItem(de.his.appserver.service.dto.base.GeneratedDtoBase)}.
     */
    @Test
    public void testAddSelectionField() {
        ApplicationContentDto applicationContentDto = _createApplicationContent();
        
        FieldDto simpleSelectionField = this.applicationContentService.createField(applicationContentDto, FieldInputDiscriminatorType.SIMPLE_SELECTION);
        assertTrue(simpleSelectionField instanceof SelectionFieldDto);
        SelectionFieldDto selectionFieldDto = (SelectionFieldDto) simpleSelectionField;
        List<SelectItemGroup> _selectionItems = this.applicationContentService.getSelectionItems(selectionFieldDto);
        assertThat(_selectionItems, notNullValue());
        
        selectionFieldDto.setDefaulttext("simpleSelectionField");
        selectionFieldDto.setHelpbuttonText("simpleSelectionFieldHelpbuttonText");
        selectionFieldDto.setDefaultlanguage(ApplicationContentServiceImplTest.LANGUAGE_ID_GERMAN);

        SelectionItemDto addSelectionField1 = this.applicationContentService.addSelectionItem(selectionFieldDto);
        addSelectionField1.setName("SelectionItemDto name eins");
        addSelectionField1.setUniquename("SelectionItemDto uniquename eins");
        addSelectionField1.setIsDefault(Boolean.FALSE);

        SelectionItemDto addSelectionField2 = this.applicationContentService.addSelectionItem(selectionFieldDto);
        addSelectionField2.setName("SelectionItemDto name zwei");
        addSelectionField2.setUniquename("SelectionItemDto uniquename zwei");
        addSelectionField2.setIsDefault(Boolean.FALSE);
        
        SelectionItemGroupDto selectionItemGroup = this.applicationContentService.addSelectionItemGroup(selectionFieldDto);
        selectionItemGroup.setName("selectionItemGroup");

        SelectionItemDto addSelectionField3 = this.applicationContentService.addSelectionItem(selectionItemGroup);
        addSelectionField3.setName("SelectionItemDto name drei");
        addSelectionField3.setUniquename("SelectionItemDto uniquename drei");
        addSelectionField3.setIsDefault(Boolean.FALSE);
        
        
        this.applicationContentService.saveApplicationContent(applicationContentDto);
        SelectionFieldDto fieldDto = (SelectionFieldDto) applicationContentDto.getApplicationContentFields().get(0);
        assertNotNull(fieldDto.getId());
        assertThat(fieldDto.getSelectionItems(), size(3));
        AbstractSelectionItemDto selectionItemDto = fieldDto.getSelectionItems().get(0);
        assertNotNull(selectionItemDto.getId());
        

        ApplicationContentDto applicationContentDto2 = this.applicationContentService.loadApplicationContent(applicationContentDto.getId());
        assertThat(applicationContentDto2.getApplicationContentFields(), size(1));
        FieldDto applicationContentField2 = applicationContentDto2.getApplicationContentFields().get(0);
        assertTrue(applicationContentField2 instanceof SelectionFieldDto);
        SelectionFieldDto selectionFieldDto2 = (SelectionFieldDto) applicationContentField2;

        List<SelectItemGroup> __selectionItems = this.applicationContentService.getSelectionItems(selectionFieldDto2);
        assertThat(__selectionItems, size(2));
        
        // jetzt das eine SelectionItem wieder löschen
        List<AbstractSelectionItemDto> selectionItems = selectionFieldDto2.getSelectionItems();
        AbstractSelectionItemDto itemDto = selectionItems.get(0);
        selectionItems.remove(itemDto);
        itemDto.setMarkedToDelete(true);
        this.applicationContentService.saveApplicationContent(applicationContentDto2);
        
        ApplicationContentDto applicationContentDto3 = this.applicationContentService.loadApplicationContent(applicationContentDto.getId());
        assertThat(applicationContentDto3.getApplicationContentFields(), size(1));
        FieldDto applicationContentField3 = applicationContentDto3.getApplicationContentFields().get(0);
        assertTrue(applicationContentField3 instanceof SelectionFieldDto);
        SelectionFieldDto selectionFieldDto3 = (SelectionFieldDto) applicationContentField3;
        assertThat(selectionFieldDto3.getSelectionItems(), size(2));
    }
    
    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#loadApplicationContent(java.lang.Long)}.
     */
    @Test
    public final void testLoadApplicationContent() {
        ApplicationContentDto applicationContent = this.applicationContentService.loadApplicationContent(Long.valueOf(3));
        assertThat(applicationContent.getName(), equalTo("Kinderbetreuung"));
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#loadApplicationContents(java.util.List)}.
     */
    @Test
    public final void testLoadApplicationContents() {
        List<Long> applicationContentIds = new ArrayList<Long>();
        applicationContentIds.add(Long.valueOf(2));
        applicationContentIds.add(Long.valueOf(3));
        applicationContentIds.add(Long.valueOf(5));
        List<ApplicationContentDto> loadApplicationContents = this.applicationContentService.loadApplicationContents(applicationContentIds);
        assertThat(loadApplicationContents, size(3));
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#getApplicationContentAdmissionPackagesIdsByRequestId(java.lang.Long)}.
     */
    @Test
    public final void testGetApplicationContentAdmissionPackagesIdsByRequestId() {
        List<Long> applicationContentAdmissionPackagesIdsByRequestId = this.applicationContentService.getApplicationContentAdmissionPackagesIdsByRequestId(Long.valueOf(33));
        assertThat(applicationContentAdmissionPackagesIdsByRequestId, size(0));
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#createApplicationContentAdmissionPackage(java.lang.Long, java.lang.Long)}.
     */
    @Test
    public final void testCreateApplicationContentAdmissionPackageLongLong() {
        // ApplicationContent (2) = Berufsausbildung
        Long applicationContentId = Long.valueOf(2);
        // Admissionpackage (9) = LA Blockflöte
        ApplicationContentAdmissionPackageDto applicationContentAdmissionPackage = this.applicationContentService.createApplicationContentAdmissionPackage(applicationContentId, Long.valueOf(9));
        assertThat(applicationContentAdmissionPackage.getApplicationContentId(), equalTo(applicationContentId));
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#saveApplicationContentAdmissionPackage(de.his.appserver.service.dto.gen.iface.ApplicationContentAdmissionPackageDto)}.
     */
    @Test
    public final void testSaveApplicationContentAdmissionPackage() {
        // ApplicationContent (2) = Berufsausbildung
        Long applicationContentId = Long.valueOf(2);
        // Admissionpackage (9) = LA Blockflöte
        ApplicationContentAdmissionPackageDto applicationContentAdmissionPackage = this.applicationContentService.createApplicationContentAdmissionPackage(applicationContentId, Long.valueOf(9));
        // Pflichtfelder ausfüllen
        applicationContentAdmissionPackage.setIsOptional(Boolean.FALSE);
        applicationContentAdmissionPackage.setSortorder(Integer.valueOf(1));
        
        // Noch nicht gespeichert
        assertThat(applicationContentAdmissionPackage.getId(), nullValue());
        this.applicationContentService.saveApplicationContentAdmissionPackage(applicationContentAdmissionPackage);
        // Und jetzt gespeichert
        assertThat(applicationContentAdmissionPackage.getId(), notNullValue());
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#createField(de.his.appserver.service.dto.gen.iface.ApplicationContentDto, java.lang.String)}.
     */
    @SuppressWarnings("unused")
    @Test
    public final void testCreateFieldApplicationContentDtoString() {
        ApplicationContentDto applicationContent = this.applicationContentService.createApplicationContent();
        SelectionFieldDto selectionFieldDto = (SelectionFieldDto) this.applicationContentService.createField(applicationContent, "SIMPLE_SELECTION");
        KeyTableSelectionFieldDto keyTableSelectionFieldDto = (KeyTableSelectionFieldDto) this.applicationContentService.createField(applicationContent, "KEY_TABLE_SELECTION");
        DocumentUploadFieldDto documentUploadFieldDto = (DocumentUploadFieldDto) this.applicationContentService.createField(applicationContent, "DOCUMENT");
        DecimalFieldDto decimalFieldDto = (DecimalFieldDto) this.applicationContentService.createField(applicationContent, "DECIMAL");
        IntegerFieldDto integerFieldDto = (IntegerFieldDto) this.applicationContentService.createField(applicationContent, "INTEGER");
        TextFieldDto textField = (TextFieldDto) this.applicationContentService.createField(applicationContent, "TEXT");
        PeriodFieldDto periodFieldDto = (PeriodFieldDto) this.applicationContentService.createField(applicationContent, "PERIOD");
        DateFieldDto dateFieldDto = (DateFieldDto) this.applicationContentService.createField(applicationContent, "DATE");
        assertThat(applicationContent.getApplicationContentFields(), size(8));
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#createField(de.his.appserver.service.dto.gen.iface.ApplicationContentDto, de.his.appserver.model.cm.app.applicationContent.FieldInput.FieldInputDiscriminatorType)}.
     */
    @Test
    public final void testCreateFieldApplicationContentDtoFieldInputDiscriminatorType() {
        ApplicationContentDto applicationContent = this.applicationContentService.createApplicationContent();
        this.applicationContentService.createField(applicationContent, FieldInputDiscriminatorType.SIMPLE_SELECTION);
        this.applicationContentService.createField(applicationContent, FieldInputDiscriminatorType.KEY_TABLE_SELECTION);
        this.applicationContentService.createField(applicationContent, FieldInputDiscriminatorType.DOCUMENT);
        this.applicationContentService.createField(applicationContent, FieldInputDiscriminatorType.DECIMAL);
        this.applicationContentService.createField(applicationContent, FieldInputDiscriminatorType.INTEGER);
        this.applicationContentService.createField(applicationContent, FieldInputDiscriminatorType.TEXT);
        this.applicationContentService.createField(applicationContent, FieldInputDiscriminatorType.PERIOD);
        this.applicationContentService.createField(applicationContent, FieldInputDiscriminatorType.DATE);
        assertThat(applicationContent.getApplicationContentFields(), size(8));
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#addSelectionItem(de.his.appserver.service.dto.base.GeneratedDtoBase)}.
     */
    @Test
    public final void testAddSelectionItem() {
        ApplicationContentDto applicationContent = this.applicationContentService.createApplicationContent();
        SelectionFieldDto selectionFieldDto = (SelectionFieldDto) this.applicationContentService.createField(applicationContent, FieldInputDiscriminatorType.SIMPLE_SELECTION);
        this.applicationContentService.addSelectionItem(selectionFieldDto);
        assertThat(selectionFieldDto.getSelectionItems(), size(1));
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#addSelectionItemGroup(de.his.appserver.service.dto.gen.iface.SelectionFieldDto)}.
     */
    @Test
    public final void testAddSelectionItemGroup() {
        ApplicationContentDto applicationContent = this.applicationContentService.createApplicationContent();
        SelectionFieldDto selectionFieldDto = (SelectionFieldDto) this.applicationContentService.createField(applicationContent, FieldInputDiscriminatorType.SIMPLE_SELECTION);
        SelectionItemGroupDto selectionItemGroup = this.applicationContentService.addSelectionItemGroup(selectionFieldDto);
        this.applicationContentService.addSelectionItem(selectionItemGroup);
        assertThat(selectionItemGroup.getSelectionItems(), size(1));
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#setKeyTableSelectionItems(de.his.appserver.service.dto.gen.iface.KeyTableSelectionFieldDto, de.his.appclient.jsf.genericSearch.SelectedValuesHashMap)}.
     */
    @Test
    public final void testSetKeyTableSelectionItems() {
        // TODO
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#saveApplicationContentInputs(java.util.List)}.
     */
    @Test
    public final void testSaveApplicationContentInput() {
        Long requestSubjectId = Long.valueOf(33); // RequestSubject 'BA LA Blockflöte' von Sebastian Sense;
        Long admissionPackageIdBlockfloete = Long.valueOf(9); // BA LA Blockflöte
        
        this.createApplicationContentInputs(requestSubjectId, admissionPackageIdBlockfloete);
        List<ApplicationContentInputDto> applicationContentInputDtos = new ArrayList<ApplicationContentInputDto>();
        
        List<ApplicationContentAdmissionPackageDto> applicationContentAdmissionPackagesByRequestId = this.applicationContentService.getApplicationContentAdmissionPackagesByRequestSubjectId(requestSubjectId);
        for (ApplicationContentAdmissionPackageDto ApplicationContentAdmissionPackageDto : applicationContentAdmissionPackagesByRequestId) {
            Long applicationContentId = ApplicationContentAdmissionPackageDto.getApplicationContentId();
            ApplicationContentInputDto applicationContentInput = this.applicationContentService.createApplicationContentInput(applicationContentId, requestSubjectId, true);
            applicationContentInputDtos.add(applicationContentInput);
        }
        assertThat(applicationContentInputDtos, size(4));
        this.applicationContentService.saveApplicationContentInputs(applicationContentInputDtos);
        boolean hasAndyInputsNoId = false;
        for (ApplicationContentAdmissionPackageDto ApplicationContentAdmissionPackageDto : applicationContentAdmissionPackagesByRequestId) {
            if(ApplicationContentAdmissionPackageDto.getId() == null) {
                hasAndyInputsNoId = true;
            }
        }
        assertFalse(hasAndyInputsNoId);
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#getAllApplicationContentInputDtos(java.lang.Long)}.
     */
    @Test
    public final void testGetAllApplicationContentInputDtos() {
        Long requestId = Long.valueOf(21); // Request von Sebastian Sense
        Long admissionPackageIdBlockfloete = Long.valueOf(9); // BA LA Blockflöte
        Long requestSubjectId = Long.valueOf(33); // RequestSubject 'BA LA Blockflöte' von Sebastian Sense;
        
        
        this.createApplicationContentInputs(requestSubjectId, admissionPackageIdBlockfloete);
        
        List<Long> requestIds = new ArrayList<Long>();
        requestIds.add(requestId);
        
        Map<Long, List<ApplicationContentInputDto>> allApplicationContentInputDtos = this.applicationContentService.getAllApplicationContentInputDtos(requestIds );
        assertThat(allApplicationContentInputDtos, MapSize.mapSize(1));
        assertThat(allApplicationContentInputDtos.get(requestId), size(3));
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#getApplicationContentInputDtos(java.lang.Long, java.lang.Long)}.
     */
    @Test
    public final void testGetApplicationContentInputDtos() {
        Long requestSubjectId = Long.valueOf(33); // RequestSubject 'BA LA Blockflöte' von Sebastian Sense;
        Long admissionPackageIdBlockfloete = Long.valueOf(9); // BA LA Blockflöte
        Long applicationContentKinderbetreuung = Long.valueOf(3);
        
        this.createApplicationContentInputs(requestSubjectId, admissionPackageIdBlockfloete);
        
        List<ApplicationContentInputDto> applicationContentInputDtos = this.applicationContentService.getApplicationContentInputDtos(requestSubjectId, applicationContentKinderbetreuung);
        assertThat(applicationContentInputDtos, size(1));
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#getApplicationContentInputDtosProcessing(java.lang.Long)}.
     */
    @Test
    public final void testGetApplicationContentInputDtosProcessing() {
        Long requestSubjectId = Long.valueOf(33); // RequestSubject 'BA LA Blockflöte' von Sebastian Sense;
        Long applicationId = Long.valueOf(22); // Application von Sebastian Sense
        Long admissionPackageIdBlockfloete = Long.valueOf(9); // BA LA Blockflöte
        
        this.createApplicationContentInputs(requestSubjectId, admissionPackageIdBlockfloete);
        
        Map<Long, Collection<ApplicationContentInputDto>> applicationContentInputDtosProcessing = this.applicationContentService.getApplicationContentInputDtosProcessing(applicationId);
        assertThat(applicationContentInputDtosProcessing, MapSize.mapSize(1));
    }

    /**
     * Test method ApplicationContentServiceImpl.evaluateCondition().
     */
    @Test
    public final void testEvaluateConditionPositive() {
        
        Calendar cal = Calendar.getInstance();
        cal.set(1949, Calendar.DECEMBER, 31);
        
        Request request = this.requestDao.findById(Long.valueOf(33));
        RequestSubject requestSubject = request.getRequestSubjects().iterator().next();
        Application application = request.getApplication();
        application.getApplicant().getPerson().setBirthdate(cal.getTime());
        this.requestDao.makePersistent(request);
        
        this.requestDao.flush();
        this.requestDao.clear();
        
        ApplicationContentCondition applicationContentCondition = new ApplicationContentCondition();
        applicationContentCondition.setExpression(condition);
        applicationContentCondition.setUniqueName("Altersprüfung");
        
        boolean evaluateCondition = ApplicationContentServiceImpl.evaluateCondition(applicationContentCondition, requestSubject.getId());
        assertTrue(evaluateCondition);
    }

    /**
     * Test method for ApplicationContentServiceImpl.evaluateCondition().
     */
    @Test
    public final void testEvaluateConditionNegative() {

        Calendar cal = Calendar.getInstance();
        cal.set(1950, Calendar.JANUARY, 1);

        Request request = this.requestDao.findById(Long.valueOf(33));
        RequestSubject requestSubject = request.getRequestSubjects().iterator().next();
        Application application = request.getApplication();
        application.getApplicant().getPerson().setBirthdate(cal.getTime());
        this.requestDao.makePersistent(request);
        
        ApplicationContentCondition applicationContentCondition = new ApplicationContentCondition();
        applicationContentCondition.setExpression(condition);
        applicationContentCondition.setUniqueName("Altersprüfung");

        boolean evaluateCondition = ApplicationContentServiceImpl.evaluateCondition(applicationContentCondition, requestSubject.getId());
        assertFalse(evaluateCondition);
    }
    
    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#createInputKeySelectionItem()}.
     */
    @Test
    public final void testCreateInputKeySelectionItem() {
        // TODO
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#createApplicationContentInput(Long, Long, boolean)}.
     */
    @Test
    public final void testCreateApplicationContentInput() {
        Long admissionPackageIdBlockfloete = Long.valueOf(9); // BA LA Blockflöte
        Long requestSubjectId = Long.valueOf(33); // RequestSubject 'BA LA Blockflöte' von Sebastian Sense;
        
        this.createApplicationContentInputs(requestSubjectId, admissionPackageIdBlockfloete);
        List<ApplicationContentInputDto> applicationContentInputDtos = new ArrayList<ApplicationContentInputDto>();
        
        List<ApplicationContentAdmissionPackageDto> applicationContentAdmissionPackagesByRequestId = this.applicationContentService.getApplicationContentAdmissionPackagesByRequestSubjectId(requestSubjectId);
        for (ApplicationContentAdmissionPackageDto ApplicationContentAdmissionPackageDto : applicationContentAdmissionPackagesByRequestId) {
            Long applicationContentId = ApplicationContentAdmissionPackageDto.getApplicationContentId();
            ApplicationContentInputDto applicationContentInput = this.applicationContentService.createApplicationContentInput(applicationContentId, requestSubjectId, true);
            applicationContentInputDtos.add(applicationContentInput);
        }
        assertThat(applicationContentInputDtos, size(4));
    }
    
    /**
     * 
     */
    @Test
    @TestOwner(cvsLogin="eden#his.de")
    public final void testValidateApplicationContentInputDto() {
        testCreateApplicationContentInput();
        
        Long applicationId = Long.valueOf(22); // Application von Sebastian Sense
        Long requestSubjectId = Long.valueOf(33); // RequestSubject 'BA LA Blockflöte' von Sebastian Sense;
        
        Map<Long, Collection<ApplicationContentInputDto>> applicationContentInputDtoMap = this.applicationContentService.getApplicationContentInputDtosProcessing(applicationId);
        Collection<ApplicationContentInputDto> applicationContentInputs = applicationContentInputDtoMap.get(requestSubjectId);
        
        Iterator<ApplicationContentInputDto> iterator = applicationContentInputs.iterator();
        while (iterator.hasNext()){
            ApplicationContentInputDto applicationContentInput = iterator.next();
            Long id = applicationContentInput.getApplicationContentDefinitionId();
            if (id.equals(Long.valueOf(5))){
                String test = this.applicationContentService.validateApplicationContentInputDto(applicationContentInput);
                assertEquals("- Note", test);
            } else if (id.equals(Long.valueOf(2))){
                String test = this.applicationContentService.validateApplicationContentInputDto(applicationContentInput);
                assertNull(test);
            }
        }
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#createFieldInputOnlineApplication(de.his.appserver.service.dto.gen.iface.ApplicationContentInputDto)}.
     */
    @Test
    public final void testCreateFieldInputOnlineApplication() {
        Long admissionPackageIdBlockfloete = Long.valueOf(9); // BA LA Blockflöte
        Long requestSubjectId = Long.valueOf(33); // RequestSubject 'BA LA Blockflöte' von Sebastian Sense;
        
        this.createApplicationContentInputs(requestSubjectId, admissionPackageIdBlockfloete);
        List<ApplicationContentInputDto> applicationContentInputDtos = new ArrayList<ApplicationContentInputDto>();
        
        List<ApplicationContentAdmissionPackageDto> applicationContentAdmissionPackagesByRequestId = this.applicationContentService.getApplicationContentAdmissionPackagesByRequestSubjectId(requestSubjectId);
        for (ApplicationContentAdmissionPackageDto applicationContentAdmissionPackageDto : applicationContentAdmissionPackagesByRequestId) {
            Long applicationContentId = applicationContentAdmissionPackageDto.getApplicationContentId();
            ApplicationContentInputDto applicationContentInput = this.applicationContentService.createApplicationContentInput(applicationContentId, requestSubjectId, true);
            applicationContentInputDtos.add(applicationContentInput);
            if(applicationContentAdmissionPackageDto.isOptional()) {
                this.applicationContentService.createFieldInputOnlineApplication(applicationContentInput);                
            }
        }
        assertThat(applicationContentInputDtos, size(4));
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#createFieldInputApplicationProcessing(de.his.appserver.service.dto.gen.iface.ApplicationContentInputDto)}.
     */
    @Test
    public final void testCreateFieldInputApplicationProcessing() {
        Long admissionPackageIdBlockfloete = Long.valueOf(9); // BA LA Blockflöte
        Long requestSubjectId = Long.valueOf(33); // RequestSubject 'BA LA Blockflöte' von Sebastian Sense;
        
        this.createApplicationContentInputs(requestSubjectId, admissionPackageIdBlockfloete);
        List<ApplicationContentInputDto> applicationContentInputDtos = new ArrayList<ApplicationContentInputDto>();
        
        List<ApplicationContentAdmissionPackageDto> applicationContentAdmissionPackagesByRequestId = this.applicationContentService.getApplicationContentAdmissionPackagesByRequestSubjectId(requestSubjectId);
        for (ApplicationContentAdmissionPackageDto ApplicationContentAdmissionPackageDto : applicationContentAdmissionPackagesByRequestId) {
            Long applicationContentId = ApplicationContentAdmissionPackageDto.getApplicationContentId();
            ApplicationContentInputDto applicationContentInputDto = this.applicationContentService.createApplicationContentInput(applicationContentId, requestSubjectId, false);
            this.applicationContentService.createFieldInputApplicationProcessing(applicationContentInputDto);
        }
        assertThat(applicationContentInputDtos, size(0));
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#getAllApplicationContents()}.
     */
    @Test
    public final void testGetAllApplicationContents() {
        List<ApplicationContentDto> allApplicationContents = this.applicationContentService.getAllApplicationContents();
        assertThat(allApplicationContents, size(6));
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#getAllApplicationContentsWithFields()}.
     */
    @Test
    public final void testGetAllApplicationContentsWithFields() {
        List<ApplicationContentDto> allApplicationContentsWithFields = this.applicationContentService.getAllApplicationContentsWithFields();
        assertThat(allApplicationContentsWithFields, size(6));
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#getKeyTableSelectionItems(KeyTableSelectionFieldDto)}.
     */
    @Test
    public final void testGetKeyTableSelectionItems() {
        // TODO
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#deleteOptionalApplicationContentInputFields(de.his.appserver.service.dto.gen.iface.ApplicationContentInputDto)}.
     */
    @Test
    public final void testDeleteOptionalApplicationContentInputFields() {
        Long admissionPackageIdBlockfloete = Long.valueOf(9); // BA LA Blockflöte
        Long requestSubjectId = Long.valueOf(33); // RequestSubject 'BA LA Blockflöte' von Sebastian Sense;
        
        this.createApplicationContentInputs(requestSubjectId, admissionPackageIdBlockfloete);
        List<ApplicationContentInputDto> applicationContentInputDtos = new ArrayList<ApplicationContentInputDto>();
        
        List<ApplicationContentAdmissionPackageDto> applicationContentAdmissionPackagesByRequestId = this.applicationContentService.getApplicationContentAdmissionPackagesByRequestSubjectId(requestSubjectId);
        for (ApplicationContentAdmissionPackageDto ApplicationContentAdmissionPackageDto : applicationContentAdmissionPackagesByRequestId) {
            Long applicationContentId = ApplicationContentAdmissionPackageDto.getApplicationContentId();
            ApplicationContentInputDto applicationContentInput = this.applicationContentService.createApplicationContentInput(applicationContentId, requestSubjectId, true);
            applicationContentInputDtos.add(applicationContentInput);
            this.applicationContentService.deleteOptionalApplicationContentInputFields(applicationContentInput);
        }
        assertThat(applicationContentInputDtos, size(4));
    }

    /**
     * @return ApplicationContentDto
     */
    protected ApplicationContentDto _createApplicationContent() {
        ApplicationContentDto applicationContentDto = this.applicationContentService.createApplicationContent();
        applicationContentDto.setName("Defaulttext");
        applicationContentDto.setUniquename("Uniquename");
        applicationContentDto.setHelpbuttonText("HelpbuttonText");
        applicationContentDto.setDefaultlanguage(ApplicationContentServiceImplTest.LANGUAGE_ID_GERMAN);
        
        this.applicationContentService.saveApplicationContent(applicationContentDto);
        return applicationContentDto;
    }
    
    
    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#saveApplicationContentField(de.his.appserver.service.dto.gen.iface.FieldDto)}.
     */
    @Test
    public final void testSaveApplicationContentField() {
        ApplicationContentDto applicationContent = this.applicationContentService.createApplicationContent();
        applicationContent.setHelpbuttonText("helpbuttonText");
        applicationContent.setName("name");
        applicationContent.setUniquename("uniquename");
        
        SelectionFieldDto selectionFieldDto = (SelectionFieldDto) this.applicationContentService.createField(applicationContent, "SIMPLE_SELECTION");
        selectionFieldDto.setDefaulttext("defaulttext");
        selectionFieldDto.setUniquename("uniquename");
        selectionFieldDto.setHelpbuttonText("helpbuttonText");
        selectionFieldDto.setMultipleSelectionAllowed(Boolean.FALSE);
        
        try {
            this.applicationContentService.saveApplicationContentField(selectionFieldDto);
            fail("Exception expected!");
        } catch (Exception e) {
            assertThat(e.getMessage(), equalTo("cm.app.applicationContent.selectionField.minTwoSelections"));
        }
        
        SelectionItemDto selectionItem1 = this.applicationContentService.addSelectionItem(selectionFieldDto);
        selectionItem1.setName("selection Item 1");
        selectionItem1.setUniquename("1");
        selectionItem1.setIsDefault(Boolean.TRUE);

        SelectionItemDto selectionItem2 = this.applicationContentService.addSelectionItem(selectionFieldDto);
        selectionItem2.setName("selection Item 2");
        selectionItem2.setUniquename("2");
        selectionItem2.setIsDefault(Boolean.FALSE);
        
        SelectionItemGroupDto selectionItemGroup = this.applicationContentService.addSelectionItemGroup(selectionFieldDto);
        selectionItemGroup.setName("selection Group");

        SelectionItemDto selectionItem3 = this.applicationContentService.addSelectionItem(selectionItemGroup);
        selectionItem3.setName("selection Item 3");
        selectionItem3.setUniquename("3");
        selectionItem3.setIsDefault(Boolean.TRUE);

        SelectionItemDto selectionItem4 = this.applicationContentService.addSelectionItem(selectionItemGroup);
        selectionItem4.setName("selection Item 4");
        selectionItem4.setUniquename("4");
        selectionItem4.setIsDefault(Boolean.FALSE);

        try {
            this.applicationContentService.saveApplicationContentField(selectionFieldDto);
            fail("Exception expected!");
        } catch (Exception e) {
            assertThat(e.getMessage(), equalTo("cm.app.applicationContent.selectionField.multipleSelectionNotAllowed"));
        }
        
        selectionItem1.setIsDefault(Boolean.FALSE);
        this.applicationContentService.saveApplicationContentField(selectionFieldDto);
        
        assertThat(applicationContent.getApplicationContentFields(), size(1));
        
        TextFieldDto textFieldDto = (TextFieldDto) this.applicationContentService.createField(applicationContent, "TEXT");
        textFieldDto.setDefaulttext("defaulttext");
        textFieldDto.setUniquename("uniquename");
        textFieldDto.setHelpbuttonText("helpbuttonText");
        try {
            this.applicationContentService.saveApplicationContentField(textFieldDto);
            fail("Upps, das hätte nicht gespeichert werden düfen ...");
        } catch (Exception e) {
            assertThat(e.getLocalizedMessage(), equalTo("Der Schlüssel uniquename wird bereits verwendet. Bitte wählen Sie einen anderen, noch nicht verwendeten Schlüssel"));
        }
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#createApplicationContentAdmissionPackage(de.his.appserver.service.dto.gen.iface.ApplicationContentDto)}.
     */
    @Test
    public final void testCreateApplicationContentAdmissionPackageApplicationContentDto() {
        ApplicationContentDto applicationContent = this.applicationContentService.createApplicationContent();
        ApplicationContentAdmissionPackageDto createApplicationContentAdmissionPackage = this.applicationContentService.createApplicationContentAdmissionPackage(applicationContent);
        assertThat(createApplicationContentAdmissionPackage, notNullValue());
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#getAllApplicationContentInputDtos(java.lang.Long)}.
     */
    @Test
    public final void testGetAllApplicationContentInputDtosLong() {
        Long requestId = Long.valueOf(21); // Request von Sebastian Sense
        Long requestSubjectId = Long.valueOf(33); // RequestSubject 'BA LA Blockflöte' von Sebastian Sense;
        Long admissionPackageIdBlockfloete = Long.valueOf(9); // BA LA Blockflöte
        
        this.createApplicationContentInputs(requestSubjectId, admissionPackageIdBlockfloete);
        
        List<ApplicationContentInputDto> allApplicationContentInputDtos = this.applicationContentService.getAllApplicationContentInputDtos(requestId);
        assertThat(allApplicationContentInputDtos, size(3));
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#createInputSelectionItem()}.
     */
    @Test
    public final void testCreateInputSelectionItem() {
        // TODO fail("Not yet implemented"); 
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#createKeyTableSelectionFieldDto(java.lang.Long)}.
     */
    @Test
    public final void testCreateKeyTableSelectionFieldDto() {
        KeyTableSelectionFieldDto keyTableSelectionFieldDto = this.applicationContentService.createKeyTableSelectionFieldDto(Long.valueOf(3));
        assertThat(keyTableSelectionFieldDto.getSelectedItems(), size(16));
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#createSelectionFieldDto(java.lang.Long)}.
     */
    @Test
    public final void testCreateSelectionFieldDto() {
        SelectionFieldDto selectionFieldDto = this.applicationContentService.createSelectionFieldDto(Long.valueOf(12));
        assertThat(selectionFieldDto.getSelectionItems(), size(3));
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#createApplicationContentCondition()}.
     */
    @Test
    public final void testCreateApplicationContentCondition() {
        ApplicationContentConditionDto createApplicationContentCondition = this.applicationContentService.createApplicationContentCondition();
        assertThat(createApplicationContentCondition, notNullValue());
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#readApplicationContentCondition(java.lang.Long)}.
     */
    @Test
    public final void testReadApplicationContentCondition() {
        Long applicationContentConditionId = Long.valueOf(11915); // Altersprüfung
        ApplicationContentConditionDto applicationContentCondition = this.applicationContentService.readApplicationContentCondition(applicationContentConditionId );
        assertThat(applicationContentCondition, notNullValue());
        assertThat(applicationContentCondition.getDefaulttext(), equalTo("Altersprüfung"));
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#saveApplicationContentCondition(de.his.appserver.service.dto.gen.iface.ApplicationContentConditionDto)}.
     */
    @Test
    public final void testSaveApplicationContentCondition() {
        ApplicationContentConditionDto applicationContentCondition = this.applicationContentService.createApplicationContentCondition();
        applicationContentCondition.setDefaulttext("Test");
        applicationContentCondition.setUniqueName("Test");
        applicationContentCondition.setExpression("return true;");
        this.applicationContentService.saveApplicationContentCondition(applicationContentCondition);
        assertThat(applicationContentCondition.getId(), notNullValue());
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#getAllApplicationContentConditions()}.
     */
    @Test
    public final void testGetAllApplicationContentConditions() {
        Map<Long, ApplicationContentConditionDto> allApplicationContentConditions = this.applicationContentService.getAllApplicationContentConditions();
        assertThat(allApplicationContentConditions, MapSize.mapSize(2));
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#deleteApplicationContentCondition(java.lang.Long, boolean)}.
     */
    @Test
    public final void testDeleteApplicationContentCondition() {
        Long applicationContentConditionId = Long.valueOf(11915); // Altersprüfung
        assertFalse(this.applicationContentService.deleteApplicationContentCondition(applicationContentConditionId, true));
        
        ApplicationContentConditionDto applicationContentCondition = this.applicationContentService.createApplicationContentCondition();
        applicationContentCondition.setDefaulttext("Test");
        applicationContentCondition.setUniqueName("Test");
        applicationContentCondition.setExpression("return true;");
        this.applicationContentService.saveApplicationContentCondition(applicationContentCondition);
        assertThat(applicationContentCondition.getId(), notNullValue());
        assertTrue(this.applicationContentService.deleteApplicationContentCondition(applicationContentCondition.getId(), true));
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#testCondition(de.his.appserver.service.dto.gen.iface.ApplicationContentConditionDto, java.lang.Long, de.his.appserver.model.cm.stu.fee.FeeLogger)}.
     */
    @Test
    public final void testTestCondition() {
        Long applicationContentConditionId = Long.valueOf(11915); // Altersprüfung
        Long requestSubjectId = Long.valueOf(33); // RequestSubject 'BA LA Blockflöte' von Sebastian Sense;
        ApplicationContentConditionDto applicationContentCondition = this.applicationContentService.readApplicationContentCondition(applicationContentConditionId );
        FeeLogger feeLogger = new FeeLogger();
        boolean testCondition = this.applicationContentService.testCondition(applicationContentCondition, requestSubjectId, feeLogger );
        assertFalse(testCondition);
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#testCondition(de.his.appserver.service.dto.gen.iface.ApplicationContentConditionDto, java.lang.Long, de.his.appserver.model.cm.stu.fee.FeeLogger)}.
     */
    @Test
    public final void testTestConditionWrongSyntax() {
        Long applicationContentConditionId = Long.valueOf(11915); // Altersprüfung
        Long requestSubjectId = Long.valueOf(33); // RequestSubject 'BA LA Blockflöte' von Sebastian Sense;
        ApplicationContentConditionDto applicationContentCondition = this.applicationContentService.readApplicationContentCondition(applicationContentConditionId );
        applicationContentCondition.setExpression(conditionWithWrongSyntax);
        FeeLogger feeLogger = new FeeLogger();
        try {
            this.applicationContentService.testCondition(applicationContentCondition, requestSubjectId, feeLogger );
            fail("Exception expected");
        } catch (Exception e) {
            assertThat(e.getMessage(), equalTo("Evaluation of condition failed."));
            assertThat(feeLogger.getMessage(), Matchers.containsString("ReferenceError: \"prerson\" is not defined. (<Unknown source>#2) in <Unknown source> at line number 2"));
            assertTrue("We should have line-number " + String.valueOf(feeLogger.getLineNumber()), feeLogger.getLineNumber() == 2);
//            assertTrue("We should have column-number " + String.valueOf(feeLogger.getColumnNumber()), feeLogger.getColumnNumber() == -1);
        }
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#evaluateCondition(ApplicationContentCondition, Long)}.
     */
    @Test
    public final void testEvaluateConditionApplicationContentConditionApplication() {
        // TODO fail("Not yet implemented"); 
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#evaluateCondition(ApplicationContentCondition, Long, FeeLogger)}.
     */
    @Test
    public final void testEvaluateConditionApplicationContentConditionApplicationAdmissionPackage() {
        // TODO fail("Not yet implemented"); 
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#isUsedInOnlineApplication(java.lang.Long)}.
     */
    @Test
    public final void testIsUsedInOnlineApplication() {
        Long applicationContentConditionId = Long.valueOf(11915); // Altersprüfung
        boolean usedInOnlineApplication = this.applicationContentService.isUsedInOnlineApplication(applicationContentConditionId);
        assertFalse(usedInOnlineApplication);
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#countUsagesInApplicationContents(java.lang.Long)}.
     */
    @Test
    public final void testCountUsagesInApplicationContents() {
        Long applicationContentConditionId = Long.valueOf(11915); // Altersprüfung
        int countUsagesInApplicationContents = this.applicationContentService.countUsagesInApplicationContents(applicationContentConditionId);
        assert(countUsagesInApplicationContents == 0);
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#getSelectionItems(de.his.appserver.service.dto.gen.iface.SelectionFieldDto)}.
     */
    @Test
    public final void testGetSelectionItems() {
        InputSelectionItemDto selectionItemDto = this.applicationContentService.createInputSelectionItem();
        assertThat(selectionItemDto, notNullValue());
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#isAnyRequestSubmitted(java.util.List)}.
     */
    @Test
    public final void testIsAnyRequestSubmitted() {
        Long applicationContentBerufsausbildung = Long.valueOf(2);
        Long applicationContentKinderbetreuung = Long.valueOf(3);
        Long applicationContentInformatikPraktikum = Long.valueOf(5);
        Long applicationContentAltersprüfung = Long.valueOf(6);
        Long admissionPackageId = Long.valueOf(9);
//        Long requestId = Long.valueOf(21); // Request von Sebastian Sense
        Long requestSubjectId = Long.valueOf(33); // RequestSubject 'BA LA Blockflöte' von Sebastian Sense;
        
        this.applicationContentService.saveApplicationContentAdmissionPackage(this.applicationContentService.createApplicationContentAdmissionPackage(applicationContentBerufsausbildung, admissionPackageId ));
        this.applicationContentService.saveApplicationContentAdmissionPackage(this.applicationContentService.createApplicationContentAdmissionPackage(applicationContentKinderbetreuung, admissionPackageId));
        this.applicationContentService.saveApplicationContentAdmissionPackage(this.applicationContentService.createApplicationContentAdmissionPackage(applicationContentInformatikPraktikum, admissionPackageId));
        this.applicationContentService.saveApplicationContentAdmissionPackage(this.applicationContentService.createApplicationContentAdmissionPackage(applicationContentAltersprüfung, admissionPackageId));
        
        List<ApplicationContentInputDto> allApplicationContentInputDtos = new ArrayList<ApplicationContentInputDto>();
        List<ApplicationContentAdmissionPackageDto> applicationContentAdmissionPackagesByRequestId = this.applicationContentService.getApplicationContentAdmissionPackagesByRequestSubjectId(requestSubjectId);
        for (ApplicationContentAdmissionPackageDto ApplicationContentAdmissionPackageDto : applicationContentAdmissionPackagesByRequestId) {
            List<ApplicationContentInputDto> applicationContentInputDtos = this.applicationContentService.getApplicationContentInputDtos(requestSubjectId, ApplicationContentAdmissionPackageDto.getApplicationContentId());
            allApplicationContentInputDtos.addAll(applicationContentInputDtos);
        }
        
        boolean anyRequestSubmitted = this.applicationContentService.isAnyRequestSubmitted(allApplicationContentInputDtos);
        assertFalse(anyRequestSubmitted);
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#findFieldInputCountByField(java.lang.Long)}.
     */
    @Test
    public final void testFindFieldInputCountByField() {
        Long fieldId = Long.valueOf(11); // 11 * TextField Altersbegründung
        int findFieldInputCountByField = this.applicationContentService.findFieldInputCountByField(fieldId);
        assert(findFieldInputCountByField == 0);
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#getTitlesOfAffectedCourses(List)}.
     */
    @Test
    public void testGetTitlesOfAffectedCourses() {
        Long requestSubjectId = Long.valueOf(33); // RequestSubject 'BA LA Blockflöte' von Sebastian Sense;
        Long admissionPackageIdBlockfloete = Long.valueOf(9); // BA LA Blockflöte
        
        this.createApplicationContentInputs(requestSubjectId, admissionPackageIdBlockfloete);
        List<ApplicationContentInputDto> applicationContentInputDtos = new ArrayList<ApplicationContentInputDto>();
        
        List<ApplicationContentAdmissionPackageDto> applicationContentAdmissionPackagesByRequestId = this.applicationContentService.getApplicationContentAdmissionPackagesByRequestSubjectId(requestSubjectId);
        for (ApplicationContentAdmissionPackageDto ApplicationContentAdmissionPackageDto : applicationContentAdmissionPackagesByRequestId) {
            Long applicationContentId = ApplicationContentAdmissionPackageDto.getApplicationContentId();
            ApplicationContentInputDto applicationContentInput = this.applicationContentService.createApplicationContentInput(applicationContentId, requestSubjectId, true);
            applicationContentInputDtos.add(applicationContentInput);
        }
        assertThat(applicationContentInputDtos, size(4));
        this.applicationContentService.saveApplicationContentInputs(applicationContentInputDtos);
        Set<String> titlesOfAffectedCourses = this.applicationContentService.getTitlesOfAffectedCourses(applicationContentInputDtos);
        assertThat(titlesOfAffectedCourses, size(0)); // All aus dem sleben Fach, es wird nichts angezeigt
    }

    /**
     * Test method for {@link de.his.appserver.service.impl.cm.app.applicationContent.ApplicationContentServiceImpl#getApplicationContentInputs(Long, String)}.
     */
    @Test
    public void testGetApplicationContentInputs() {
        Long requestSubjectId = Long.valueOf(33); // RequestSubject 'BA LA Blockflöte' von Sebastian Sense;
        Long admissionPackageIdBlockfloete = Long.valueOf(9); // BA LA Blockflöte
        
        this.createApplicationContentInputs(requestSubjectId, admissionPackageIdBlockfloete);
        
        List<ApplicationContentInput> applicationContentInputs = this.applicationContentService.getApplicationContentInputs(requestSubjectId, "BA");
        assertThat(applicationContentInputs, size(1));
        
        applicationContentInputs = this.applicationContentService.getApplicationContentInputs(requestSubjectId, null);
        assertThat(applicationContentInputs, size(3));
    }

    
    
    private void createApplicationContentInputs(Long requestSubjectId, Long admissionPackageId) {
        
        Long applicationContentBerufsausbildung = Long.valueOf(2);
        Long applicationContentKinderbetreuung = Long.valueOf(3);
        Long applicationContentInformatikPraktikum = Long.valueOf(5);
        Long applicationContentAltersprüfung = Long.valueOf(6);
        this.applicationContentService.saveApplicationContentAdmissionPackage(this.applicationContentService.createApplicationContentAdmissionPackage(applicationContentBerufsausbildung, admissionPackageId));
        this.applicationContentService.saveApplicationContentAdmissionPackage(this.applicationContentService.createApplicationContentAdmissionPackage(applicationContentKinderbetreuung, admissionPackageId));
        this.applicationContentService.saveApplicationContentAdmissionPackage(this.applicationContentService.createApplicationContentAdmissionPackage(applicationContentInformatikPraktikum, admissionPackageId));
        this.applicationContentService.saveApplicationContentAdmissionPackage(this.applicationContentService.createApplicationContentAdmissionPackage(applicationContentAltersprüfung, admissionPackageId));
        
        List<ApplicationContentInputDto> allApplicationContentInputDtos = new ArrayList<ApplicationContentInputDto>();
        List<ApplicationContentAdmissionPackageDto> applicationContentAdmissionPackagesByRequestId = this.applicationContentService.getApplicationContentAdmissionPackagesByRequestSubjectId(requestSubjectId);
        for (ApplicationContentAdmissionPackageDto ApplicationContentAdmissionPackageDto : applicationContentAdmissionPackagesByRequestId) {
            List<ApplicationContentInputDto> applicationContentInputDtos = this.applicationContentService.getApplicationContentInputDtos(requestSubjectId, ApplicationContentAdmissionPackageDto.getApplicationContentId());
            allApplicationContentInputDtos.addAll(applicationContentInputDtos);
        }
        this.applicationContentService.saveApplicationContentInputs(allApplicationContentInputDtos);
    }
    
    // SETTER

    /**
     * @param applicationContentService the applicationContentService to set
     */
    @Required
    public void setApplicationContentService(ApplicationContentService applicationContentService) {
        this.applicationContentService = applicationContentService;
    }

    /**
     * @param requestDao the requestDao to set
     */
    @Required
    public void setRequestDao(RequestDao requestDao) {
        this.requestDao = requestDao;
    }

}

/*
 * Copyright (c) 2011 HIS GmbH All Rights Reserved.
 *
 * $Id: AdmissionPackageDaoImplTest.java,v 1.4.8.2 2013-12-03 07:28:46 schwaff#his.de Exp $
 * $Log: AdmissionPackageDaoImplTest.java,v $
 * Revision 1.4.8.2  2013-12-03 07:28:46  schwaff#his.de
 * #102016 – Bugfix: BB: Massenzuordung von Zulassungspaketen ohne sortorder
 *
 * Revision 1.4.8.1  2013-08-26 06:53:06  schwaff#his.de
 * corrected test-cases (#00000)
 *
 * Revision 1.4  2013-04-24 06:58:02  schwaff#his.de
 * #88091 – Zulassungspakete werden bewerbungssemesterbezogen konfiguriert
 *
 * Revision 1.3  2013-04-23 08:38:03  schwaff#his.de
 * added method getAvailableTermsOfAdmissionPackages
 *
 * Revision 1.2  2012-03-15 15:23:13  lustig#his.de
 * Wichtige Teile der HISinOne Test-Infrastruktur nach  'de.his.core.testing' verschoben (fixes #65420)
 *
 * Revision 1.1  2011-12-13 09:37:16  schwaff#his.de
 * Added new testcases
 *
 */
package de.his.appserver.persistence.dao.impl.hibernate.sul.zul.bewerbung;

import static de.his.matcher.HISMatchers.size;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertThat;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Required;

import de.his.appserver.model.common.Term;
import de.his.appserver.model.sul.zul.bewerbung.AdmissionPackage;
import de.his.appserver.model.sul.zul.bewerbung.AdmissiontypeValue.AdmissiontypeEnum;
import de.his.appserver.persistence.dao.iface.sul.zul.bewerbung.AdmissionPackageDao;
import de.his.appserver.service.dto.iface.common.TermDto;
import de.his.appserver.service.iface.sul.common.TermService;
import de.his.core.testing.HISinOneBaseDaoTestCase;
import de.his.core.util.junit.TestOwner;

/**
 * Company: HIS
 * @author schwaff
 * @version $Revision: 1.4.8.2 $
 */
@TestOwner(cvsLogin="schwaff#his.de")
public class AdmissionPackageDaoImplTest extends HISinOneBaseDaoTestCase {

    private AdmissionPackageDao admissionPackageDao;
    private TermService termService;
    
    /**
     * Test method for {@link de.his.appserver.persistence.dao.impl.hibernate.sul.zul.bewerbung.AdmissionPackageDaoImpl#findByAdmissionType(Long, Integer, Long)}.
     */
    @Test
    public final void testFindByAdmissionType() {
        TermDto term = this.termService.getAdmissionTermFromGlobalConf();
        List<AdmissionPackage> findByAdmissionType = this.admissionPackageDao.findByAdmissionType(AdmissiontypeEnum.FREE.getHisKey(), term.getYear(), term.getTermTypeId());
        assertThat(findByAdmissionType, not(size(0)));
    }

    /**
     * Test method for {@link de.his.appserver.persistence.dao.impl.hibernate.sul.zul.bewerbung.AdmissionPackageDaoImpl#findByShorttext(java.lang.String)}.
     */
    @Test
    public final void testFindByShorttext() {
        AdmissionPackage admissionPackage = this.admissionPackageDao.findByShorttext("BA LA Posaune");
        assertThat(admissionPackage.getId(), equalTo(Long.valueOf(10)));
    }
    
    /**
     * Test method for {@link de.his.appserver.persistence.dao.impl.hibernate.sul.zul.bewerbung.AdmissionPackageDaoImpl#getAvailableTermsOfAdmissionPackages()}.
     */
    @Test
    public final void testGetAvailableTermsOfAdmissionPackages() {
        List<Term> availableTermsOfAdmissionPackages = this.admissionPackageDao.getAvailableTermsOfAdmissionPackages();
        assertThat(availableTermsOfAdmissionPackages, size(1));
    }

    /**
     * Test method for {@link de.his.appserver.persistence.dao.impl.hibernate.sul.zul.bewerbung.AdmissionPackageDaoImpl#getAdmissionPackagesByTerm(Integer, Long)}.
     */
    @Test
    public final void testGetAdmissionPackagesByTerm() {
        TermDto term = this.termService.getAdmissionTermFromGlobalConf();
        List<AdmissionPackage> admissionPackagesByTerm = this.admissionPackageDao.getAdmissionPackagesByTerm(term.getYear(), term.getTermTypeId());
        assertThat("found " + admissionPackagesByTerm.size(), admissionPackagesByTerm, size(16));
    }


    /**
     * Test method for {@link de.his.appserver.persistence.dao.impl.hibernate.sul.zul.bewerbung.AdmissionPackageDaoImpl#getNextApplicationContentAdmissionPackageSortorder(Long)}.
     */
    @Test
    public final void testGetNextApplicationContentAdmissionPackageSortorder() {
        Long admissionPackageId = Long.valueOf(6); // Master - Informatik, 1. Fachsemester
        Integer sortorder = this.admissionPackageDao.getNextApplicationContentAdmissionPackageSortorder(admissionPackageId);
        assertThat(sortorder, equalTo(Integer.valueOf(6)));
        
        admissionPackageId = Long.valueOf(1); // Bachelor - Angewandte Informatik, 1. Fachsemester
        sortorder = this.admissionPackageDao.getNextApplicationContentAdmissionPackageSortorder(admissionPackageId);
        assertThat(sortorder, equalTo(Integer.valueOf(0)));
    }
    
    
    /**
     * @param admissionPackageDao the admissionPackageDao to set
     */
    @Required
    public void setAdmissionPackageDao(AdmissionPackageDao admissionPackageDao) {
        this.admissionPackageDao = admissionPackageDao;
    }

    /**
     * @param termService the termService to set
     */
    @Required
    public void setTermService(TermService termService) {
        this.termService = termService;
    }

}

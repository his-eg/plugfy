/**
 * 
 * @author keunecke
 */
public class TestClassA {

    public TestClassB field;

}
